# -*- coding: utf-8 -*-
"""NRW Lokalradio background metadata service.

Playback is never dependent on Surfmusik. The service only enriches the
currently playing item with the title supplied by Surfmusik's AJAX endpoint.
"""
import json
import os
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import surfmusik

LOG = '[NRWLokalradio][Surfmusik-Service]'
STATE_FILE = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.audio.nrwlokalradio'), 'playback_state.json')


def read_state():
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}


def split_title(value):
    value = (value or '').strip()
    if ' - ' in value:
        artist, title = value.split(' - ', 1)
        return artist.strip(), title.strip()
    return '', value


def update_info(player, station, title):
    if not title or not player.isPlayingAudio():
        return
    artist, song = split_title(title)
    try:
        li = xbmcgui.ListItem()
        li.setPath(player.getPlayingFile())
        # Kodi 21: expliziter InfoTagMusic-Setter; Fallback auf setInfo für ältere Kodi-Versionen.
        try:
            tag = li.getMusicInfoTag()
            tag.setTitle(song or title)
            if artist:
                tag.setArtist(artist)
            tag.setAlbum(station or '')
            tag.setGenre('Lokalradio NRW')
        except Exception:
            li.setInfo('music', {
                'title': song or title,
                'artist': artist,
                'album': station or '',
                'genre': 'Lokalradio NRW',
            })
        player.updateInfoTag(li)
        xbmc.log(f'{LOG} INFO UPDATE: station={station} artist={artist!r} title={song or title!r}', xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(f'{LOG} InfoTag-Update FEHLER: {type(exc).__name__}: {exc}', xbmc.LOGWARNING)


class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = xbmc.Player()
        self.current_url = ''
        self.station_id = ''
        self.station_name = ''
        self.surf_id = ''
        self.last_title = ''
        self.last_poll = 0.0
        self.lock = threading.Lock()

    def refresh_state(self):
        state = read_state()
        self.station_id = state.get('station_id', '')
        self.station_name = state.get('station', '')
        xbmc.log(f'{LOG} STATE: station_id={self.station_id!r} station={self.station_name!r} saved_url={state.get("url", "")!r}', xbmc.LOGINFO)
        if self.player.isPlayingAudio():
            try:
                self.current_url = self.player.getPlayingFile()
            except Exception:
                pass

    def discover(self):
        if self.surf_id or not self.station_name:
            return
        entry = surfmusik.find_station(self.station_name)
        if entry:
            self.surf_id = entry['id']
            xbmc.log(f'{LOG} MATCH: station={self.station_name!r} -> surf_id={self.surf_id} surf_name={entry["name"]!r} surf_url={entry["url"]}', xbmc.LOGINFO)
        else:
            xbmc.log(f'{LOG} KEIN MATCH: {self.station_name} (Playback bleibt unverändert)', xbmc.LOGDEBUG)

    def poll_title(self):
        self.discover()
        if not self.surf_id:
            return
        xbmc.log(f'{LOG} TITLE REQUEST: station={self.station_name!r} surf_id={self.surf_id}', xbmc.LOGINFO)
        title = surfmusik.get_title(self.surf_id)
        xbmc.log(f'{LOG} TITLE RESULT: surf_id={self.surf_id} value={title!r}', xbmc.LOGINFO)
        if title and title != self.last_title:
            self.last_title = title
            update_info(self.player, self.station_name, title)

    def check(self):
        if not self.player.isPlayingAudio():
            if self.current_url:
                xbmc.log(f'{LOG} STOP: {self.station_name}', xbmc.LOGDEBUG)
            self.current_url = ''
            self.station_id = ''
            self.station_name = ''
            self.surf_id = ''
            self.last_title = ''
            return
        try:
            url = self.player.getPlayingFile()
        except Exception:
            url = ''
        if url != self.current_url:
            self.current_url = url
            self.refresh_state()
            self.surf_id = ''
            self.last_title = ''
            self.last_poll = 0.0
            xbmc.log(f'{LOG} START: station={self.station_name!r} station_id={self.station_id!r} URL={url!r}', xbmc.LOGINFO)
        if time.time() - self.last_poll >= 30.0:
            self.last_poll = time.time()
            try:
                self.poll_title()
            except Exception as exc:
                xbmc.log(f'{LOG} Polling-Fehler (ignoriert): {type(exc).__name__}: {exc}', xbmc.LOGDEBUG)

    def run(self):
        xbmc.log(f'{LOG} SERVICE GESTARTET – Surfmusik optional, Playback unabhängig', xbmc.LOGINFO)
        while not self.abortRequested():
            self.check()
            if self.waitForAbort(1.0):
                break
        xbmc.log(f'{LOG} SERVICE BEENDET', xbmc.LOGINFO)


if __name__ == '__main__':
    Monitor().run()
