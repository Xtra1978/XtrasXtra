#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Playback remains deliberately based on the known-good 1.4.3 path.

Surfmusik is metadata-only in 1.7.1. It must never be able to prevent playback.
"""
import json
import os

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON_ICON   = 'special://home/addons/plugin.audio.nrwlokalradio/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.audio.nrwlokalradio/resources/media/fanart.jpg'
STATE_FILE = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.audio.nrwlokalradio'), 'playback_state.json')


def _save_state(station_id, station, url):
    try:
        folder = os.path.dirname(STATE_FILE)
        xbmcvfs.mkdirs(folder)
        with open(STATE_FILE, 'w', encoding='utf-8') as fh:
            json.dump({'station_id': station_id or '', 'station': station or '', 'url': url or ''}, fh)
    except Exception as exc:
        xbmc.log(f'[NRWLokalradio][STATE] Schreiben fehlgeschlagen: {exc}', xbmc.LOGDEBUG)


def play(handle, url, title, station='', thumb='', station_id=''):
    xbmc.log(f'[NRWLokalradio] Spiele: {title} -> {url}', xbmc.LOGINFO)
    if not url:
        xbmcgui.Dialog().notification('NRW Lokalradio', 'Stream-URL nicht verfügbar.', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    mime = 'audio/aac' if ('.aac' in url.lower() or '/aac' in url.lower()) else 'audio/mpeg'
    li = xbmcgui.ListItem(label=station or title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setProperty('nrw_station', station or title)
    li.setProperty('nrw_station_id', station_id or '')
    li.setProperty('nrw_stream_url', url)
    li.setProperty('StationName', station or title)
    li.setArt({'icon': thumb or ADDON_ICON, 'thumb': thumb or ADDON_ICON, 'fanart': ADDON_FANART})
    li.setInfo('music', {'genre': 'Lokalradio NRW'})

    # EXAKT die funktionierende 1.4.3 Playback-Konfiguration.
    li.setProperty('inputstream', 'inputstream.ffmpegdirect')
    li.setProperty('inputstream.ffmpegdirect.stream_mode', 'default')
    li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
    li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
    li.setMimeType(mime)

    _save_state(station_id, station or title, url)
    xbmc.log(f'[NRWLokalradio][PLAYBACK] Fallback/Original-Stream freigegeben; Surfmusik ist nicht Voraussetzung.', xbmc.LOGINFO)
    xbmcplugin.setResolvedUrl(handle, True, li)
