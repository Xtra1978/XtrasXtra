#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""URL-Router für das NRW Lokalradio Addon."""

from urllib.parse import parse_qsl
from resources.lib import ui, player


def dispatch(base_url, handle, args, addon):
    params = dict(parse_qsl(args.lstrip('?')))
    mode   = params.get('mode', 'main')

    if mode == 'main':
        ui.show_main_menu(base_url, handle, addon)
    elif mode == 'region':
        region = params.get('region', '')
        ui.show_region(base_url, handle, addon, region)
    elif mode == 'all_stations':
        ui.show_all_stations(base_url, handle, addon)
    elif mode == 'station':
        station_id = params.get('station_id', '')
        ui.show_station_streams(base_url, handle, addon, station_id)
    elif mode == 'play':
        url     = params.get('url', '')
        title   = params.get('title', '')
        station = params.get('station', '')
        thumb   = params.get('thumb', '')
        station_id = params.get('station_id', '')
        player.play(handle, url, title, station, thumb, station_id)
    elif mode == 'search':
        query = params.get('query', '')
        if not query:
            query = ui.ask_search(addon)
        if query:
            ui.show_search_results(base_url, handle, addon, query)
    elif mode == 'favourites':
        ui.show_favourites(base_url, handle, addon)
    elif mode == 'toggle_fav':
        station_id = params.get('station_id', '')
        ui.toggle_favourite(station_id, addon)
        import xbmc
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'open_web':
        import xbmc
        import xbmcgui
        import xbmcplugin
        web_url = params.get('url', '')
        if web_url:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{web_url})')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    else:
        ui.show_main_menu(base_url, handle, addon)
