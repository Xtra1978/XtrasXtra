#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Senderdatenbank: Alle NRW-Lokalradios mit verifizierten Stream-URLs.

Stream-Quellen (verifiziert Mai 2026):
  - stream.lokalradio.nrw  → offizieller zentraler CDN für NRW-Lokalradios
  - *.cast.addradio.de     → addradio CDN (Hagen, Münster, Bielefeld etc.)
  - *.c.nmdn.net           → NMDN CDN (Köln, Aachen, NE-WS)
  - *.kasserver.com        → Kasserver (Unna, 91.2)
  - direkte Sender-Server  → Lippewelle, Hellweg, MK

HINWEIS: edge.live.mp3.mdn.newmedia.nacamar.net ist nicht mehr erreichbar!
Alle URLs wurden auf stream.lokalradio.nrw migriert.
"""

REGIONS = [
    'Ruhrgebiet',
    'Rheinland',
    'Münsterland & Niederrhein',
    'Ostwestfalen-Lippe',
    'Bergisches Land & Sauerland',
    'Südwestfalen & Siegerland',
    'Radio NRW',
]

STATIONS = [

    # ==================================================================
    # RUHRGEBIET
    # ==================================================================
    {
        'name':     '98.5 Radio Bochum',
        'id':       'radiobochum',
        'region':   'Ruhrgebiet',
        'city':     'Bochum',
        'freq':     '98,5 MHz',
        'website':  'https://www.radio985.de',
        'icon_url': 'https://www.radio985.de/fileadmin/template/images/radio985_logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiobochum.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Duisburg',
        'id':       'radioduisburg',
        'region':   'Ruhrgebiet',
        'city':     'Duisburg',
        'freq':     '103,3 MHz',
        'website':  'https://www.radioduisburg.de',
        'icon_url': 'https://www.radioduisburg.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioduisburg.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Essen',
        'id':       'radioessen',
        'region':   'Ruhrgebiet',
        'city':     'Essen',
        'freq':     '106,3 MHz',
        'website':  'https://www.radioessen.de',
        'icon_url': 'https://www.radioessen.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioessen.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Emscher Lippe',
        'id':       'radioemscherlippe',
        'region':   'Ruhrgebiet',
        'city':     'Gelsenkirchen / Bottrop / Recklinghausen',
        'freq':     '91,8 MHz',
        'website':  'https://www.radioemscherlippe.de',
        'icon_url': 'https://www.radioemscherlippe.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioemscherlippe.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Herne 90acht',
        'id':       'radioherne',
        'region':   'Ruhrgebiet',
        'city':     'Herne',
        'freq':     '90,8 MHz',
        'website':  'https://www.radioherne.de',
        'icon_url': 'https://www.radioherne.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioherne.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Mülheim',
        'id':       'radiomuelheim',
        'region':   'Ruhrgebiet',
        'city':     'Mülheim an der Ruhr',
        'freq':     '92,9 MHz',
        'website':  'https://www.radiomuelheim.de',
        'icon_url': 'https://www.radiomuelheim.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiomuelheim.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Oberhausen',
        'id':       'radiooberhausen',
        'region':   'Ruhrgebiet',
        'city':     'Oberhausen',
        'freq':     '106,2 MHz',
        'website':  'https://www.radiooberhausen.de',
        'icon_url': 'https://www.radiooberhausen.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiooberhausen.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Vest',
        'id':       'radiovest',
        'region':   'Ruhrgebiet',
        'city':     'Recklinghausen / Marl',
        'freq':     '97,5 MHz',
        'website':  'https://www.radiovest.de',
        'icon_url': 'https://www.radiovest.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiovest.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio 91.2',
        'id':       'radio912',
        'region':   'Ruhrgebiet',
        'city':     'Dortmund',
        'freq':     '91,2 MHz',
        'website':  'https://www.radio912.de',
        'icon_url': 'https://www.radio912.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'http://dd28838.kasserver.com:8004',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Ennepe Ruhr',
        'id':       'radioenneperuhr',
        'region':   'Ruhrgebiet',
        'city':     'Ennepe-Ruhr-Kreis',
        'freq':     '91,5 MHz',
        'website':  'https://www.radioenneperuhr.de',
        'icon_url': 'https://www.radioenneperuhr.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioenneperuhr.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     '107.7 Radio Hagen',
        'id':       'radiohagen',
        'region':   'Ruhrgebiet',
        'city':     'Hagen',
        'freq':     '107,7 MHz',
        'website':  'https://www.radiohagen.de',
        'icon_url': 'https://www.radiohagen.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 192 kbps (HiFi)',
             'url':   'http://radiohagen.cast.addradio.de/radiohagen/simulcast/high/stream.mp3',
             'quality': 'MP3 192 kbps'},
            {'label': 'AAC 64 kbps',
             'url':   'http://radiohagen.cast.addradio.de/radiohagen/simulcast/low/stream.aac',
             'quality': 'AAC 64 kbps'},
        ],
    },

    # ==================================================================
    # RHEINLAND
    # ==================================================================
    {
        'name':     'Antenne Düsseldorf',
        'id':       'antennedus',
        'region':   'Rheinland',
        'city':     'Düsseldorf',
        'freq':     '107,6 MHz',
        'website':  'https://www.antenneduesseldorf.de',
        'icon_url': 'https://www.antenneduesseldorf.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/antennedus.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Neandertal',
        'id':       'neandertal',
        'region':   'Rheinland',
        'city':     'Kreis Mettmann',
        'freq':     '102,5 MHz',
        'website':  'https://www.radioneandertal.de',
        'icon_url': 'https://www.radioneandertal.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/neandertal.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Wuppertal',
        'id':       'radiowuppertal',
        'region':   'Rheinland',
        'city':     'Wuppertal',
        'freq':     '107,4 MHz',
        'website':  'https://www.radiowuppertal.de',
        'icon_url': 'https://www.radiowuppertal.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiowuppertal.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio RSG',
        'id':       'radiorsg',
        'region':   'Rheinland',
        'city':     'Remscheid / Solingen',
        'freq':     '105,3 MHz',
        'website':  'https://www.radiorsg.de',
        'icon_url': 'https://www.radiorsg.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiorsg.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Leverkusen',
        'id':       'radioleverkusen',
        'region':   'Rheinland',
        'city':     'Leverkusen',
        'freq':     '95,6 MHz',
        'website':  'https://www.radioleverkusen.de',
        'icon_url': 'https://www.radioleverkusen.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioleverkusen.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Berg',
        'id':       'radioberg',
        'region':   'Rheinland',
        'city':     'Rheinisch-Bergischer Kreis',
        'freq':     '96,3 MHz',
        'website':  'https://www.radioberg.de',
        'icon_url': 'https://www.radioberg.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioberg.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Köln',
        'id':       'radiokoeln',
        'region':   'Rheinland',
        'city':     'Köln',
        'freq':     '107,1 MHz',
        'website':  'https://www.radiokoeln.de',
        'icon_url': 'https://www.radiokoeln.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (NMDN)',
             'url':   'http://mp3.radiokoeln.c.nmdn.net/ps-radiokoeln/livestream.mp3',
             'quality': 'MP3 128 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/radiokoeln.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Erft',
        'id':       'radioerft',
        'region':   'Rheinland',
        'city':     'Rhein-Erft-Kreis',
        'freq':     '100,5 MHz',
        'website':  'https://www.radioerft.de',
        'icon_url': 'https://www.radioerft.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioerft.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Bonn/Rhein-Sieg',
        'id':       'radiobonn',
        'region':   'Rheinland',
        'city':     'Bonn / Rhein-Sieg-Kreis',
        'freq':     '97,8 MHz',
        'website':  'https://www.radiobonn.de',
        'icon_url': 'https://www.radiobonn.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiobonn.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Euskirchen',
        'id':       'radioeuskirchen',
        'region':   'Rheinland',
        'city':     'Kreis Euskirchen',
        'freq':     '99,7 MHz',
        'website':  'https://www.radioeuskirchen.de',
        'icon_url': 'https://www.radioeuskirchen.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioeuskirchen.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Antenne AC',
        'id':       'antenneac',
        'region':   'Rheinland',
        'city':     'Städteregion Aachen',
        'freq':     '107,8 MHz',
        'website':  'https://www.antenne-ac.de',
        'icon_url': 'https://www.antenne-ac.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (NMDN)',
             'url':   'http://mp3.antenneac.c.nmdn.net/ps-antenneac/livestream.mp3',
             'quality': 'MP3 128 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/antenneac.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Rur',
        'id':       'radiorur',
        'region':   'Rheinland',
        'city':     'Kreis Düren',
        'freq':     '95,4 MHz',
        'website':  'https://www.radiorur.de',
        'icon_url': 'https://www.radiorur.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiorur.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio 90,1',
        'id':       'radio901',
        'region':   'Rheinland',
        'city':     'Mönchengladbach',
        'freq':     '90,1 MHz',
        'website':  'https://www.radio901.de',
        'icon_url': 'https://www.radio901.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiomg.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'NE-WS 89.4',
        'id':       'news894',
        'region':   'Rheinland',
        'city':     'Rhein-Kreis Neuss',
        'freq':     '89,4 MHz',
        'website':  'https://www.news894.de',
        'icon_url': 'https://www.news894.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (NMDN)',
             'url':   'http://mp3.news894.c.nmdn.net/news894/livestream.mp3',
             'quality': 'MP3 128 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/news894.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Antenne Niederrhein',
        'id':       'antennenr',
        'region':   'Rheinland',
        'city':     'Kreis Kleve / Kreis Wesel',
        'freq':     '97,4 MHz',
        'website':  'https://www.antenneniederrhein.de',
        'icon_url': 'https://www.antenneniederrhein.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/antennenr.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Kreis Wesel',
        'id':       'radiokw',
        'region':   'Rheinland',
        'city':     'Kreis Wesel',
        'freq':     '103,0 MHz',
        'website':  'https://www.radiokw.de',
        'icon_url': 'https://www.radiokw.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiokw.mp3',
             'quality': 'MP3'},
        ],
    },

    # ==================================================================
    # MÜNSTERLAND & NIEDERRHEIN
    # ==================================================================
    {
        'name':     'Antenne Münster',
        'id':       'antennemuenster',
        'region':   'Münsterland & Niederrhein',
        'city':     'Münster',
        'freq':     '95,4 MHz',
        'website':  'https://www.antennemuenster.de',
        'icon_url': 'https://www.antennemuenster.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 HiFi (addradio)',
             'url':   'https://antennemuenster-ais-edge-400b-dus-dtag-cdn.cast.addradio.de/antennemuenster/live/mp3/high',
             'quality': 'MP3 128 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/antennemuenster.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Kiepenkerl',
        'id':       'radiokiepenkerl',
        'region':   'Münsterland & Niederrhein',
        'city':     'Kreis Coesfeld',
        'freq':     '103,8 MHz',
        'website':  'https://www.radiokiepenkerl.de',
        'icon_url': 'https://www.radiokiepenkerl.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiokiepenkerl.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio WMW',
        'id':       'radiowmw',
        'region':   'Münsterland & Niederrhein',
        'city':     'Kreis Borken',
        'freq':     '97,6 MHz',
        'website':  'https://www.radiowmw.de',
        'icon_url': 'https://www.radiowmw.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiowmw.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio RST',
        'id':       'radiorst',
        'region':   'Münsterland & Niederrhein',
        'city':     'Kreis Steinfurt',
        'freq':     '105,6 MHz',
        'website':  'https://www.radiorst.de',
        'icon_url': 'https://www.radiorst.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 HiFi (addradio)',
             'url':   'https://radiorst-ais-edge-3003-fra-eco-cdn.cast.addradio.de/radiorst/simulcast/high/stream.mp3',
             'quality': 'MP3 192 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/radiorst.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Warendorf',
        'id':       'radiowarendorf',
        'region':   'Münsterland & Niederrhein',
        'city':     'Kreis Warendorf',
        'freq':     '99,0 MHz',
        'website':  'https://www.radiowarendorf.de',
        'icon_url': 'https://www.radiowarendorf.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiowarendorf.mp3',
             'quality': 'MP3'},
        ],
    },

    # ==================================================================
    # OSTWESTFALEN-LIPPE
    # ==================================================================
    {
        'name':     'Radio Bielefeld',
        'id':       'radiobielefeld',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Bielefeld',
        'freq':     '98,3 MHz',
        'website':  'https://www.radiobielefeld.de',
        'icon_url': 'https://www.radiobielefeld.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (addradio)',
             'url':   'https://radiobielefeld-ais-edge-3003-fra-eco-cdn.cast.addradio.de/radiobielefeld/simulcast/high/stream.mp3',
             'quality': 'MP3 192 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/radiobielefeld.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Gütersloh',
        'id':       'radioguetersloh',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Gütersloh',
        'freq':     '95,9 MHz',
        'website':  'https://www.radioguetersloh.de',
        'icon_url': 'https://www.radioguetersloh.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioguetersloh.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Herford',
        'id':       'radioherford',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Herford',
        'freq':     '94,9 MHz',
        'website':  'https://www.radioherford.de',
        'icon_url': 'https://www.radioherford.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radioherford.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Hochstift',
        'id':       'radiohochstift',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Paderborn / Höxter',
        'freq':     '107,6 MHz',
        'website':  'https://www.radiohochstift.de',
        'icon_url': 'https://www.radiohochstift.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (addradio)',
             'url':   'https://radiohochstift-ais-edge-3003-fra-eco-cdn.cast.addradio.de/radiohochstift/simulcast/high/stream.mp3',
             'quality': 'MP3 192 kbps'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/radiohochstift.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Lippe',
        'id':       'radiolippe',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Kreis Lippe',
        'freq':     '98,8 MHz',
        'website':  'https://www.radiolippe.de',
        'icon_url': 'https://www.radiolippe.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiolippe.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Lippewelle Hamm',
        'id':       'radiolippewelle',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Hamm',
        'freq':     '90,1 MHz',
        'website':  'https://www.lippewelle.de',
        'icon_url': 'https://www.lippewelle.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'http://80.237.210.54:8000',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Hellweg Radio',
        'id':       'hellwegradio',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Kreis Soest',
        'freq':     '107,4 MHz',
        'website':  'https://www.hellwegradio.de',
        'icon_url': 'https://www.hellwegradio.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'http://84.19.184.35:8000',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Antenne Unna',
        'id':       'antenneunna',
        'region':   'Ostwestfalen-Lippe',
        'city':     'Kreis Unna',
        'freq':     '107,0 MHz',
        'website':  'https://www.antenneunna.de',
        'icon_url': 'https://www.antenneunna.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (kasserver)',
             'url':   'http://dd11422.kasserver.com:8010',
             'quality': 'MP3'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/antenneunna.mp3',
             'quality': 'MP3'},
        ],
    },

    # ==================================================================
    # BERGISCHES LAND & SAUERLAND
    # ==================================================================
    {
        'name':     'Radio MK',
        'id':       'radiomk',
        'region':   'Bergisches Land & Sauerland',
        'city':     'Märkischer Kreis',
        'freq':     '96,4 MHz',
        'website':  'https://www.radiomk.de',
        'icon_url': 'https://www.radiomk.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (kasserver)',
             'url':   'http://dd28838.kasserver.com',
             'quality': 'MP3'},
            {'label': 'MP3 Stream (Backup)',
             'url':   'https://stream.lokalradio.nrw/radiomk.mp3',
             'quality': 'MP3'},
        ],
    },
    {
        'name':     'Radio Sauerland',
        'id':       'radiosauerland',
        'region':   'Bergisches Land & Sauerland',
        'city':     'Hochsauerlandkreis',
        'freq':     '107,2 MHz',
        'website':  'https://www.radiosauerland.de',
        'icon_url': 'https://www.radiosauerland.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'https://stream.lokalradio.nrw/radiosauerland.mp3',
             'quality': 'MP3'},
        ],
    },

    # ==================================================================
    # SÜDWESTFALEN & SIEGERLAND
    # ==================================================================
    {
        'name':     'Radio Siegen',
        'id':       'radiosiegen',
        'region':   'Südwestfalen & Siegerland',
        'city':     'Siegen-Wittgenstein',
        'freq':     '95,2 MHz',
        'website':  'https://www.radiosiegen.de',
        'icon_url': 'https://www.radiosiegen.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream (lokalradio.nrw)',
             'url':   'http://stream.lokalradio.nrw/444z53v',
             'quality': 'MP3'},
            {'label': 'MP3 Stream (addradio)',
             'url':   'https://radiosiegen-ais-edge-3003-fra-eco-cdn.cast.addradio.de/radiosiegen/simulcast/high/stream.mp3',
             'quality': 'MP3 192 kbps'},
        ],
    },

    # ==================================================================
    # RADIO NRW RAHMENPROGRAMM
    # ==================================================================
    {
        'name':     'Radio NRW (Rahmenprogramm)',
        'id':       'radionrw',
        'region':   'Radio NRW',
        'city':     'Oberhausen (landesweit)',
        'freq':     'Webstream',
        'website':  'https://www.radionrw.de',
        'icon_url': 'https://www.radionrw.de/fileadmin/template/images/logo.png',
        'streams': [
            {'label': 'MP3 Stream',
             'url':   'http://osl.radionrw.de/osl',
             'quality': 'MP3'},
        ],
    },
]


def get_all_stations():
    return STATIONS

def get_stations_by_region(region):
    return [s for s in STATIONS if s['region'] == region]

def get_station_by_id(station_id):
    for s in STATIONS:
        if s['id'] == station_id:
            return s
    return None

def search_stations(query):
    q = query.lower()
    return [s for s in STATIONS if
            q in s['name'].lower() or
            q in s['city'].lower() or
            q in s['region'].lower()]
