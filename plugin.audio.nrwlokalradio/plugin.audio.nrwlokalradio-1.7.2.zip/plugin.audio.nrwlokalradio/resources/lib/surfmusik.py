# -*- coding: utf-8 -*-
"""Surfmusik metadata helper.

WICHTIG: Dieses Modul ist bewusst niemals Teil des Playback-Pfades.
Wenn Surfmusik nicht erreichbar ist, bleibt der laufende Stream unangetastet.
"""
import html
import re
import urllib.parse
import urllib.request

import xbmc

LOG = '[NRWLokalradio][Surfmusik]'
BASE = 'https://www.surfmusik.de'
NRW_PAGE = BASE + '/land/nordrhein-westfalen.html'

_cache = None

ALIASES = {
    'radioherne90acht': 'radioherne90acht',
    'radiokreiswesel': 'radiokw',
    'radiokw': 'radiokw',
    'radiowarendorf': 'radiowaf',
    'radiowaf': 'radiowaf',
}


def _norm(value):
    value = html.unescape(value or '').lower()
    value = value.replace('&', ' und ')
    value = re.sub(r'\b(?:fm|mhz|radio)\b', ' ', value)
    value = re.sub(r'\d+', ' ', value)
    value = re.sub(r'[^a-z0-9äöüß]+', ' ', value)
    return re.sub(r'\s+', ' ', value).strip()


def _fetch(url, timeout=8):
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 Kodi NRW-Lokalradio/1.7.1',
        'Accept': 'text/html, */*',
        'Cache-Control': 'no-cache',
    })
    with urllib.request.urlopen(req, timeout=timeout) as response:
        data = response.read()
        xbmc.log(f'{LOG} HTTP OK: {url} status={getattr(response, "status", "?")} bytes={len(data)}', xbmc.LOGINFO)
        return data.decode('utf-8', 'replace')


def _catalog():
    global _cache
    if _cache is not None:
        return _cache
    try:
        xbmc.log(f'{LOG} KATALOG REQUEST: {NRW_PAGE}', xbmc.LOGINFO)
        source = _fetch(NRW_PAGE)
        xbmc.log(f'{LOG} KATALOG HTML: chars={len(source)}', xbmc.LOGINFO)
        result = []
        seen = set()
        pattern = re.compile(r'href=["\']([^"\']*/radio/[^"\']+,([0-9]+)\.html)["\'][^>]*>(.*?)</a>', re.I | re.S)
        for href, sid, label in pattern.findall(source):
            label = re.sub(r'<[^>]+>', ' ', label)
            label = re.sub(r'\s+', ' ', html.unescape(label)).strip()
            url = urllib.parse.urljoin(BASE, href)
            key = (sid, label)
            if key not in seen:
                seen.add(key)
                result.append({'id': sid, 'name': label, 'url': url})
        _cache = result
        xbmc.log(f'{LOG} KATALOG PARSE: {len(result)} Einträge', xbmc.LOGINFO)
        if result:
            xbmc.log(f'{LOG} KATALOG SAMPLE: {result[:5]!r}', xbmc.LOGDEBUG)
        return result
    except Exception as exc:
        xbmc.log(f'{LOG} Katalog FEHLER: {type(exc).__name__}: {exc}', xbmc.LOGWARNING)
        _cache = []
        return _cache


def find_station(station_name):
    """Return Surfmusik entry or None. Never raises into playback."""
    wanted = _norm(station_name)
    xbmc.log(f'{LOG} MATCH REQUEST: original={station_name!r} normalized={wanted!r}', xbmc.LOGINFO)
    if not wanted:
        xbmc.log(f'{LOG} MATCH ABORT: empty normalized station', xbmc.LOGWARNING)
        return None
    # Bekannte redaktionelle Namensvarianten.
    compact = re.sub(r'[^a-z0-9]', '', wanted)
    alias = ALIASES.get(compact, compact)
    entries = _catalog()
    xbmc.log(f'{LOG} MATCH CATALOG SIZE: {len(entries)}', xbmc.LOGINFO)
    for entry in entries:
        en = _norm(entry['name'])
        ec = re.sub(r'[^a-z0-9]', '', en)
        if ec == alias or ec == compact:
            xbmc.log(f'{LOG} MATCH EXACT: {entry!r}', xbmc.LOGINFO)
            return entry
    # Zweiter Versuch: alle Tokens müssen vorkommen.
    tokens = [x for x in wanted.split() if len(x) > 2]
    best = None
    best_score = 0
    for entry in entries:
        en = _norm(entry['name'])
        score = sum(1 for token in tokens if token in en)
        if tokens and score == len(tokens):
            xbmc.log(f'{LOG} MATCH TOKENS: tokens={tokens!r} entry={entry!r}', xbmc.LOGINFO)
            return entry
        if score > best_score:
            best, best_score = entry, score
    if best_score >= max(1, len(tokens) - 1):
        return best
    xbmc.log(f'{LOG} MATCH NONE: station={station_name!r} normalized={wanted!r}', xbmc.LOGWARNING)
    return None


def get_title(station_id):
    """Read Surfmusik's separate title endpoint."""
    if not station_id:
        return ''
    url = f'{BASE}/ajax/title.php?s={urllib.parse.quote(str(station_id))}'
    try:
        xbmc.log(f'{LOG} TITLE HTTP REQUEST: {url}', xbmc.LOGINFO)
        raw = _fetch(url, timeout=6)
        xbmc.log(f'{LOG} TITLE RAW: {raw[:500]!r}', xbmc.LOGINFO)
        text = re.sub(r'<[^>]+>', ' ', raw)
        text = html.unescape(text)
        text = re.sub(r'\s+', ' ', text).strip()
        xbmc.log(f'{LOG} TITLE PARSED: {text!r}', xbmc.LOGINFO)
        return text
    except Exception as exc:
        xbmc.log(f'{LOG} Titel-Fehler s={station_id}: {type(exc).__name__}: {exc}', xbmc.LOGDEBUG)
        return ''
