#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI-Modul: Menüs, Listen, Suche und Favoriten für NRW Lokalradio."""

import json
from urllib.parse import urlencode, quote

import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib.stations import (
    REGIONS, get_all_stations, get_stations_by_region,
    get_station_by_id, search_stations
)

ADDON_ICON   = 'special://home/addons/plugin.audio.nrwlokalradio/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.audio.nrwlokalradio/resources/media/fanart.jpg'
ICON_DIR     = 'special://home/addons/plugin.audio.nrwlokalradio/resources/media/icons/'
STATION_ICON_DIR = 'special://home/addons/plugin.audio.nrwlokalradio/resources/media/stations/'

REGION_ICONS = {
    'Ruhrgebiet':                  ICON_DIR + 'ruhrgebiet.png',
    'Rheinland':                   ICON_DIR + 'rheinland.png',
    'Münsterland & Niederrhein':   ICON_DIR + 'muensterland.png',
    'Ostwestfalen-Lippe':          ICON_DIR + 'owl.png',
    'Bergisches Land & Sauerland': ICON_DIR + 'bergisches_land.png',
    'Südwestfalen & Siegerland':   ICON_DIR + 'suedwestfalen.png',
    'Radio NRW':                   ICON_DIR + 'radionrw.png',
}


def build_url(base_url, params):
    return '{0}?{1}'.format(base_url, urlencode(params))


def _li(label, thumb='', fanart='', info=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        'icon':   thumb  or ADDON_ICON,
        'thumb':  thumb  or ADDON_ICON,
        'fanart': fanart or ADDON_FANART,
    })
    if info:
        li.setInfo('music', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _get_icon(station):
    # Lokales Logo bevorzugen. Fallback bleibt die bisherige offizielle URL.
    local = STATION_ICON_DIR + station.get('id', '') + '.png'
    import xbmcvfs
    try:
        if xbmcvfs.exists(local):
            return local
    except Exception:
        pass
    return station.get('icon_url', '') or ADDON_ICON


# -----------------------------------------------------------------------
# Hauptmenü
# -----------------------------------------------------------------------

def show_main_menu(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, 'NRW Lokalradio')
    xbmcplugin.setContent(handle, 'songs')

    favs      = _load_favourites(addon)
    fav_label = f'Favoriten ({len(favs)})' if favs else 'Favoriten'

    # Feste Einträge oben
    fixed = [
        ('Alle 45 Programme',        {'mode': 'all_stations'},  ICON_DIR + 'all_stations.png'),
        (fav_label,               {'mode': 'favourites'},    ICON_DIR + 'favourites.png'),
        ('Sender suchen',         {'mode': 'search'},        ICON_DIR + 'search.png'),
        ('Radio NRW Rahmenprogramm', {'mode': 'station', 'station_id': 'radionrw'},
                                                             ICON_DIR + 'radionrw.png'),
    ]
    for label, params, icon in fixed:
        url = build_url(base_url, params)
        li  = _li(label, thumb=icon)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    # Regionen
    for region in REGIONS:
        if region == 'Radio NRW':
            continue
        count = len(get_stations_by_region(region))
        icon  = REGION_ICONS.get(region, ADDON_ICON)
        label = f'{region}  ({count} Sender)'
        url   = build_url(base_url, {'mode': 'region', 'region': region})
        li    = _li(label, thumb=icon)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


# -----------------------------------------------------------------------
# Alle Sender
# -----------------------------------------------------------------------

def show_all_stations(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, 'Alle 45 Programme (44 Lokalradios + Radio NRW Rahmenprogramm)')
    xbmcplugin.setContent(handle, 'songs')
    stations = sorted(get_all_stations(), key=lambda s: s['name'])
    favs     = _load_favourites(addon)
    for station in stations:
        _add_station_item(base_url, handle, addon, station, favs)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(handle)


# -----------------------------------------------------------------------
# Region
# -----------------------------------------------------------------------

def show_region(base_url, handle, addon, region):
    icon = REGION_ICONS.get(region, ADDON_ICON)
    xbmcplugin.setPluginCategory(handle, region)
    xbmcplugin.setContent(handle, 'songs')
    stations = get_stations_by_region(region)
    favs     = _load_favourites(addon)
    for station in stations:
        _add_station_item(base_url, handle, addon, station, favs)
    xbmcplugin.endOfDirectory(handle)


# -----------------------------------------------------------------------
# Sender-Item
# -----------------------------------------------------------------------

def _add_station_item(base_url, handle, addon, station, favs=None):
    if favs is None:
        favs = []

    name    = station['name']
    s_id    = station['id']
    freq    = station.get('freq', '')
    city    = station.get('city', '')
    icon    = _get_icon(station)
    streams = station.get('streams', [])
    is_fav  = s_id in favs
    region  = station.get('region', '')

    fav_mark = '[*] ' if is_fav else ''
    label    = f'{fav_mark}{name}'
    if freq and freq != 'Webstream':
        label += f'  [{freq}]'

    info = {
        'title':  name,
        'artist': city,
        'album':  region,
        'genre':  'Lokalradio NRW',
    }

    ctx = [(
        'Aus Favoriten entfernen' if is_fav else 'Zu Favoriten hinzufuegen',
        f'RunPlugin({build_url(base_url, {"mode": "toggle_fav", "station_id": s_id})})'
    )]

    if len(streams) == 1:
        stream = streams[0]
        li = _li(label, thumb=icon, info=info, playable=True)
        li.addContextMenuItems(ctx)
        url = build_url(base_url, {
            'mode': 'play', 'url': stream['url'],
            'title': name, 'station': name, 'thumb': icon, 'station_id': s_id,
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    else:
        li = _li(label, thumb=icon, info=info)
        li.addContextMenuItems(ctx)
        url = build_url(base_url, {'mode': 'station', 'station_id': s_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)


# -----------------------------------------------------------------------
# Stream-Auswahl
# -----------------------------------------------------------------------

def show_station_streams(base_url, handle, addon, station_id):
    station = get_station_by_id(station_id)
    if not station:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    name = station['name']
    icon = _get_icon(station)
    xbmcplugin.setPluginCategory(handle, name)
    xbmcplugin.setContent(handle, 'songs')

    for stream in station.get('streams', []):
        s_label = f"{stream['label']}  ({stream['quality']})"
        info = {
            'title':  name,
            'artist': station.get('city', ''),
            'album':  station.get('region', ''),
            'genre':  'Lokalradio NRW',
        }
        li  = _li(s_label, thumb=icon, info=info, playable=True)
        url = build_url(base_url, {
            'mode': 'play', 'url': stream['url'],
            'title': f"{name} – {stream['label']}",
            'station': name, 'thumb': icon, 'station_id': station_id,
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    # Website-Link
    li_web = _li(f'{name} Website', thumb=ADDON_ICON)
    web_url = build_url(base_url, {'mode': 'open_web', 'url': station.get('website', '')})
    xbmcplugin.addDirectoryItem(handle=handle, url=web_url, listitem=li_web, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


# -----------------------------------------------------------------------
# Suche
# -----------------------------------------------------------------------

def ask_search(addon):
    return xbmcgui.Dialog().input('NRW Lokalradio suchen', type=xbmcgui.INPUT_ALPHANUM)


def show_search_results(base_url, handle, addon, query):
    xbmcplugin.setPluginCategory(handle, f'Suche: {query}')
    xbmcplugin.setContent(handle, 'songs')
    results = search_stations(query)
    favs    = _load_favourites(addon)
    if not results:
        xbmcgui.Dialog().notification('NRW Lokalradio', f'Kein Sender gefunden fuer "{query}".',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        for station in results:
            _add_station_item(base_url, handle, addon, station, favs)
    xbmcplugin.endOfDirectory(handle)


# -----------------------------------------------------------------------
# Favoriten
# -----------------------------------------------------------------------

def _load_favourites(addon):
    raw = addon.getSetting('favourites') or '[]'
    try:
        return json.loads(raw)
    except Exception:
        return []


def _save_favourites(favs, addon):
    addon.setSetting('favourites', json.dumps(favs))


def toggle_favourite(station_id, addon):
    favs = _load_favourites(addon)
    if station_id in favs:
        favs.remove(station_id)
        xbmcgui.Dialog().notification('NRW Lokalradio', 'Aus Favoriten entfernt.',
                                      xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        favs.append(station_id)
        xbmcgui.Dialog().notification('NRW Lokalradio', 'Zu Favoriten hinzugefuegt!',
                                      xbmcgui.NOTIFICATION_INFO, 2000)
    _save_favourites(favs, addon)


def show_favourites(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, 'Meine Favoriten')
    xbmcplugin.setContent(handle, 'songs')
    favs     = _load_favourites(addon)
    stations = [get_station_by_id(s_id) for s_id in favs]
    stations = [s for s in stations if s]
    if not stations:
        li = _li('Noch keine Favoriten – per Kontextmenue hinzufuegen')
        xbmcplugin.addDirectoryItem(handle=handle, url='', listitem=li, isFolder=False)
    else:
        for station in stations:
            _add_station_item(base_url, handle, addon, station, favs)
    xbmcplugin.endOfDirectory(handle)
