Lokale Senderlogos
===================

Dateiname = Sender-ID aus stations.py, z.B. radiobochum.png.
Das Addon bevorzugt diese lokalen Dateien. Fehlt eine Datei, wird automatisch
auf die in stations.py hinterlegte offizielle icon_url zurückgefallen.

Hinweis: Das mitgelieferte 3PO-Senderlogo-Repository wurde geprüft; die
benötigten NRW-Lokalradio-Logos sind dort nicht in passender Form enthalten.
Es wurden daher keine fremden/falschen Logos als Ersatz eingebaut.
