#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NRW Lokalradio Kodi Addon – Alle 45 Programme (44 Lokalradios + Radio NRW Rahmenprogramm)."""

import sys
import xbmcaddon
from resources.lib import router

ADDON    = xbmcaddon.Addon()
HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]
ARGS     = sys.argv[2]

if __name__ == '__main__':
    router.dispatch(BASE_URL, HANDLE, ARGS, ADDON)
