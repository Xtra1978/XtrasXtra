# -*- coding: utf-8 -*-
"""
KiBeats Router - komplette Navigations- und Wiedergabelogik.
addon.py bleibt schlank und delegiert alles hierher (gleiches Muster wie SW1).
"""
import os
from datetime import datetime
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import kibeats_api, storage
from resources.lib.loading_overlay import KiSpinner

_ADDON = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo('id')

_SPLASH_SESSION_FLAG = 'kibeats_splash_shown'

# Eigenes kompaktes Addon-Log, getrennt von der grossen kodi.log - Standardfeature
# in groesseren Addons dieses Portfolios. Wird nur geschrieben, wenn "Debug-Log
# aktivieren" in den Settings an ist. Datei wird bei Erreichen von ~1 MB einmal
# rotiert (alte Datei -> .1), damit sie nicht unbegrenzt waechst.
_PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
_LOG_FILE = os.path.join(_PROFILE, 'kibeats_debug.log')
_LOG_MAX_BYTES = 1024 * 1024

# Session wird pro Addon-Aufruf einmal aufgebaut (Kodi startet fuer jeden Menuaufruf
# einen frischen Python-Prozess, ein Login haelt also nicht ueber mehrere Aufrufe hinweg -
# TODO: falls Login-Nutzung sich haeufig zeigt, Session-Cookie in storage.py persistieren,
# damit nicht bei jedem Aufruf neu eingeloggt werden muss).
_session = kibeats_api.get_session()


def _t(string_id):
    return _ADDON.getLocalizedString(string_id)


def _log(msg):
    # Immer auch in die normale kodi.log (praktisch fuer's schnelle Mitlesen),
    # zusaetzlich bei aktiviertem Debug-Log in die eigene kompakte Datei.
    xbmc.log('[plugin.audio.kibeats] %s' % msg, xbmc.LOGINFO)
    if not _ADDON.getSettingBool('debug_log'):
        return
    try:
        if not xbmcvfs.exists(_PROFILE):
            xbmcvfs.mkdirs(_PROFILE)

        # xbmcvfs.File kennt keinen zuverlaessigen Append-Modus ('a') - daher
        # bestehenden Inhalt lesen, neue Zeile in Python anhaengen und komplett
        # neu schreiben ('w'). Bei Ueberschreiten von _LOG_MAX_BYTES wird von
        # vorne abgeschnitten (einfache Rotation ohne zweite Datei).
        existing = ''
        if xbmcvfs.exists(_LOG_FILE):
            rf = xbmcvfs.File(_LOG_FILE)
            try:
                existing = rf.read()
            finally:
                rf.close()

        line = '%s  %s\n' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), msg)
        new_content = existing + line
        if len(new_content.encode('utf-8', 'ignore')) > _LOG_MAX_BYTES:
            new_content = new_content[len(new_content) // 3:]  # aeltestes Drittel abschneiden

        wf = xbmcvfs.File(_LOG_FILE, 'w')
        try:
            ok = wf.write(new_content)
            if not ok:
                xbmc.log('[plugin.audio.kibeats] Debug-Log write() lieferte False fuer %s' % _LOG_FILE, xbmc.LOGWARNING)
        finally:
            wf.close()
    except Exception as e:
        xbmc.log('[plugin.audio.kibeats] Debug-Log-Fehler (Pfad: %s): %s' % (_LOG_FILE, e), xbmc.LOGERROR)


def _maybe_login():
    if _ADDON.getSettingBool('use_login'):
        email = _ADDON.getSetting('login_email')
        password = _ADDON.getSetting('login_password')
        if email and password:
            ok = kibeats_api.login(_session, email, password)
            _log('Login %s' % ('erfolgreich' if ok else 'fehlgeschlagen'))
            if not ok:
                xbmcgui.Dialog().notification(
                    'KiBeats', _t(30018), xbmcgui.NOTIFICATION_WARNING, 3000
                )


def _run_login_flow(dialog):
    """Fragt E-Mail/Benutzername + Passwort ab und versucht sofort einen Testlogin.
    Bricht der Nutzer eine der beiden Eingaben ab, geht's zurueck in den Free-Modus -
    entspricht dem Button 'Doch im Free-Modus bleiben' aus der urspruenglichen Planung."""
    email = dialog.input(_t(30023))
    if not email:
        return
    password = dialog.input(_t(30024), option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:
        return

    ok = kibeats_api.login(_session, email, password)
    if ok:
        _ADDON.setSetting('use_login', 'true')
        _ADDON.setSetting('login_email', email)
        _ADDON.setSetting('login_password', password)
        dialog.notification('KiBeats', _t(30050), xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        dialog.notification('KiBeats', _t(30018), xbmcgui.NOTIFICATION_WARNING, 3000)


def _maybe_first_run_assistant():
    """Einmaliger Einrichtungsassistent beim allerersten Addon-Start: Free-Modus oder
    gleich einloggen. Laeuft nur, solange 'first_run_done' noch nicht gesetzt ist -
    egal wie er ausgeht (Free-Modus, erfolgreicher oder abgebrochener Login), wird
    danach nicht erneut gefragt (manuell zuruecksetzbar ueber die Settings)."""
    if _ADDON.getSettingBool('first_run_done'):
        return

    dialog = xbmcgui.Dialog()
    want_login = dialog.yesno(
        'KiBeats', _t(30049), yeslabel=_t(30051), nolabel=_t(30052),
    )
    if want_login:
        _run_login_flow(dialog)

    _ADDON.setSetting('first_run_done', 'true')


def _icon(name):
    return _ADDON.getAddonInfo('path') + '/resources/media/icons/' + name


def _addon_icon():
    return _ADDON.getAddonInfo('path') + '/icon.png'


def build_url(base_url, **kwargs):
    return base_url + '?' + urlencode(kwargs)


def _add_menu_item(handle, base_url, label, action, is_folder=True, icon=None, **extra_params):
    li = xbmcgui.ListItem(label=label)
    icon = icon or _addon_icon()
    li.setArt({'icon': icon, 'thumb': icon})
    url = build_url(base_url, action=action, **extra_params)
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)


def _add_track_items(handle, base_url, tracks):
    """Rendert eine Liste von Track-dicts (id/title/artist/cover/file) als spielbare Items."""
    for track in tracks:
        title = track.get('title') or '?'
        artist = track.get('artist') or ''
        cover = track.get('cover') or ''
        track_id = track.get('id')

        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': cover, 'icon': cover})
        info_tag = li.getMusicInfoTag()
        info_tag.setTitle(title)
        info_tag.setArtist(artist)
        li.setProperty('IsPlayable', 'true')

        context_menu = []
        if storage.is_favorite(track_id):
            context_menu.append((
                _t(30017),
                'RunPlugin(%s)' % build_url(base_url, action='remove_favorite', track_id=track_id),
            ))
        else:
            context_menu.append((
                _t(30016),
                'RunPlugin(%s)' % build_url(
                    base_url, action='add_favorite', track_id=track_id,
                    title=title, artist=artist, cover=cover, file=track.get('file', ''),
                ),
            ))
        context_menu.append((
            _t(30035),
            'RunPlugin(%s)' % build_url(
                base_url, action='add_to_playlist', track_id=track_id,
                title=title, artist=artist, cover=cover, file=track.get('file', ''),
            ),
        ))
        li.addContextMenuItems(context_menu)

        url = build_url(base_url, action='play', file=track.get('file', ''))
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)


def _root_menu(handle, base_url):
    win = xbmcgui.Window(10000)
    if not win.getProperty(_SPLASH_SESSION_FLAG):
        spinner = KiSpinner()
        spinner.start()
        spinner.stop()  # erzwingt ueber die Mindestanzeigedauer den Splash-Effekt
        win.setProperty(_SPLASH_SESSION_FLAG, 'true')

    _maybe_first_run_assistant()
    _add_menu_item(handle, base_url, _t(30000), 'home', icon=_icon('icon_home.png'))
    _add_menu_item(handle, base_url, _t(30001), 'explore', icon=_icon('icon_explore.png'))
    _add_menu_item(handle, base_url, _t(30002), 'charts', icon=_icon('icon_charts.png'))
    _add_menu_item(handle, base_url, _t(30003), 'radio', icon=_icon('icon_radio.png'))
    _add_menu_item(handle, base_url, _t(30004), 'albums', icon=_icon('icon_albums.png'))
    _add_menu_item(handle, base_url, _t(30006), 'events', icon=_icon('icon_events.png'))
    _add_menu_item(handle, base_url, _t(30007), 'favorites', icon=_icon('icon_favorites.png'))
    _add_menu_item(handle, base_url, _t(30008), 'playlists', icon=_icon('icon_playlists.png'))
    _add_menu_item(handle, base_url, _t(30009), 'generator', icon=_icon('icon_generator.png'))
    _add_menu_item(handle, base_url, _t(30010), 'clear_cache', is_folder=False, icon=_icon('icon_cache.png'))
    _add_menu_item(handle, base_url, _t(30011), 'open_settings', is_folder=False, icon=_icon('icon_settings.png'))
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _not_implemented(handle):
    xbmcgui.Dialog().notification('KiBeats', _t(30019), xbmcgui.NOTIFICATION_INFO, 2500)
    xbmcplugin.endOfDirectory(handle, succeeded=False)


def _home(handle, base_url):
    tracks = kibeats_api.get_home_tracks(_session)
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _albums_genre_menu(handle, base_url):
    _add_menu_item(handle, base_url, _t(30012), 'albums_list')
    for slug, name in kibeats_api.ALBUM_GENRES:
        _add_menu_item(handle, base_url, name, 'albums_list', genre=slug)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _albums_list(handle, base_url, params):
    genre = params.get('genre')
    page = int(params.get('page', 1))
    albums, has_next = kibeats_api.get_albums(_session, genre=genre, page=page)

    for album in albums:
        label = '%s - %s (%s Tracks)' % (album['title'], album['artist'], album['track_count'])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': album['cover'], 'icon': album['cover']})
        url = build_url(base_url, action='album_detail', album_id=album['id'])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    if has_next:
        _add_menu_item(
            handle, base_url, _t(30015), 'albums_list',
            genre=genre or '', page=page + 1,
        )

    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _album_detail(handle, base_url, params):
    album_id = params.get('album_id')
    tracks = kibeats_api.get_album_detail(_session, album_id)
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _favorites(handle, base_url):
    tracks = storage.get_favorites()
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _add_favorite(params):
    storage.add_favorite({
        'id': params.get('track_id'),
        'title': params.get('title'),
        'artist': params.get('artist'),
        'cover': params.get('cover'),
        'file': params.get('file'),
    })


def _remove_favorite(params):
    storage.remove_favorite(params.get('track_id'))


def _add_to_playlist(params):
    track = {
        'id': params.get('track_id'),
        'title': params.get('title'),
        'artist': params.get('artist'),
        'cover': params.get('cover'),
        'file': params.get('file'),
    }
    playlists = storage.get_playlists()
    names = [p['name'] for p in playlists]
    options = names + [_t(30032)]
    idx = xbmcgui.Dialog().select(_t(30033), options)
    if idx < 0:
        return
    if idx == len(names):
        new_name = xbmcgui.Dialog().input(_t(30030))
        if not new_name:
            return
        storage.create_playlist(new_name, [track])
    else:
        storage.add_track_to_playlist(names[idx], track)
    xbmcgui.Dialog().notification('KiBeats', _t(30031), xbmcgui.NOTIFICATION_INFO, 1500)


def _playlists_menu(handle, base_url):
    playlists = storage.get_playlists()
    for p in playlists:
        name = p.get('name')
        li = xbmcgui.ListItem(label='%s (%d)' % (name, len(p.get('tracks', []))))
        li.setArt({'icon': 'DefaultMusicPlaylists.png'})
        li.addContextMenuItems([(
            _t(30034),
            'RunPlugin(%s)' % build_url(base_url, action='delete_playlist', name=name),
        )])
        url = build_url(base_url, action='playlist_detail', name=name)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _playlist_detail(handle, base_url, params):
    name = params.get('name')
    tracks = storage.get_playlist_tracks(name)
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _delete_playlist(params):
    storage.delete_playlist(params.get('name'))


def _generator(handle, base_url):
    dialog = xbmcgui.Dialog()

    count_options = ['10', '25', '50']
    count_idx = dialog.select(_t(30026), count_options)
    if count_idx < 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    count = int(count_options[count_idx])

    # Mehrfachauswahl: "Alle Genres" ist kein eigener Listeneintrag mehr - leere
    # Auswahl (Dialog mit "OK" ohne Haken oder Abbruch) bedeutet automatisch alle.
    genre_labels = [name for _slug, name in kibeats_api.ALBUM_GENRES]
    selected = dialog.multiselect(_t(30027), genre_labels)
    genres = None
    if selected:
        if len(selected) > 3:
            selected = selected[:3]
            dialog.notification('KiBeats', _t(30036), xbmcgui.NOTIFICATION_INFO, 2500)
        genres = [kibeats_api.ALBUM_GENRES[i][0] for i in selected]

    import random
    spinner = KiSpinner()
    spinner.start()
    try:
        pool = kibeats_api.get_track_pool(_session, genres=genres, target_count=count)
    finally:
        spinner.stop()
    if not pool:
        dialog.notification('KiBeats', _t(30028), xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    random.shuffle(pool)
    result = pool[:count]
    if len(result) < count:
        _log('Generator: nur %d von %d angefragten Tracks gefunden (Genres=%s erschoepft)' % (
            len(result), count, genres or 'alle'))
    storage.set_last_generated(result)

    save_li = xbmcgui.ListItem(label=_t(30029))
    save_url = build_url(base_url, action='save_generated')
    xbmcplugin.addDirectoryItem(handle, save_url, save_li, isFolder=False)

    _add_track_items(handle, base_url, result)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _save_generated():
    tracks = storage.get_last_generated()
    if not tracks:
        return
    name = xbmcgui.Dialog().input(_t(30030))
    if not name:
        return
    storage.create_playlist(name, tracks)
    xbmcgui.Dialog().notification('KiBeats', _t(30031), xbmcgui.NOTIFICATION_INFO, 2000)


def _explore_menu(handle, base_url):
    _add_menu_item(handle, base_url, _t(30037), 'explore_list', sort='', icon=_icon('icon_newtracks.png'))
    _add_menu_item(handle, base_url, _t(30038), 'explore_genre_menu')
    _add_menu_item(handle, base_url, _t(30039), 'explore_mood_menu')
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _explore_genre_menu(handle, base_url):
    for slug, name in kibeats_api.EXPLORE_GENRES:
        _add_menu_item(handle, base_url, name, 'explore_list', genre=slug)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _explore_mood_menu(handle, base_url):
    for slug, name in kibeats_api.EXPLORE_MOODS:
        _add_menu_item(handle, base_url, name, 'explore_list', mood=slug)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _explore_list(handle, base_url, params):
    genre = params.get('genre')
    mood = params.get('mood')
    sort = params.get('sort') or None
    page = int(params.get('page', 1))
    tracks, has_next = kibeats_api.get_explore_tracks(_session, genre=genre, mood=mood, sort=sort, page=page)
    _add_track_items(handle, base_url, tracks)
    if has_next:
        _add_menu_item(
            handle, base_url, _t(30015), 'explore_list',
            genre=genre or '', mood=mood or '', sort=sort or '', page=page + 1,
        )
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _charts_menu(handle, base_url):
    _add_menu_item(handle, base_url, _t(30040), 'charts_tracks', icon=_icon('icon_trending.png'))
    _add_menu_item(handle, base_url, _t(30041), 'charts_period_menu')
    _add_menu_item(handle, base_url, _t(30042), 'charts_creators', icon=_icon('icon_creator.png'))
    _add_menu_item(handle, base_url, _t(30043), 'charts_playlists')
    _add_menu_item(handle, base_url, _t(30044), 'explore_genre_menu')
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _charts_tracks(handle, base_url, params):
    period = params.get('period') or None
    tracks = kibeats_api.get_chart_tracks(_session, period=period)
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _charts_period_menu(handle, base_url):
    periods = kibeats_api.get_chart_periods(_session)
    for period in periods:
        _add_menu_item(handle, base_url, period, 'charts_tracks', period=period)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _charts_creators(handle, base_url):
    creators = kibeats_api.get_chart_creators(_session)
    for c in creators:
        li = xbmcgui.ListItem(label=c['label'])
        li.setArt({'icon': 'DefaultArtist.png'})
        url = build_url(base_url, action='noop')
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _charts_playlists(handle, base_url):
    playlists = kibeats_api.get_chart_playlists(_session)
    for p in playlists:
        label = '%s - %s' % (p['title'], p['creator'])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultMusicPlaylists.png'})
        url = build_url(base_url, action='chart_playlist_detail', playlist_id=p['id'])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _chart_playlist_detail(handle, base_url, params):
    tracks = kibeats_api.get_playlist_detail(_session, params.get('playlist_id'))
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _radio_menu(handle, base_url):
    stations = kibeats_api.get_radio_stations(_session)
    for s in stations:
        li = xbmcgui.ListItem(label=s['name'])
        li.setArt({'thumb': s['cover'], 'icon': s['cover']})
        li.setProperty('IsPlayable', 'true')
        info_tag = li.getMusicInfoTag()
        info_tag.setTitle(s['name'])
        url = build_url(base_url, action='play_radio', stream_url=s['stream_url'], name=s['name'], cover=s['cover'])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _play_radio(handle, params):
    stream_url = params.get('stream_url')
    name = params.get('name', 'Radio')
    _log('Radio Play: %s' % stream_url)

    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty('IsPlayable', 'true')
    info_tag = li.getMusicInfoTag()
    info_tag.setTitle(name)

    # Sofern verfuegbar: ICY-Metadata (aktueller Kuenstler/Track) direkt am Stream
    # abfragen und in Titel/Interpret einblenden - schlaegt der Stream keine
    # Metadaten vor, bleibt es einfach beim Sendernamen (kein Fehler, kein Abbruch).
    now_playing = kibeats_api.get_now_playing_icy(stream_url)
    if now_playing:
        _log('Radio Now Playing: %s' % now_playing)
        if ' - ' in now_playing:
            artist, title = now_playing.split(' - ', 1)
            info_tag.setArtist(artist.strip())
            info_tag.setTitle(title.strip())
        else:
            info_tag.setTitle(now_playing)

    xbmcplugin.setResolvedUrl(handle, True, li)


def _events_menu(handle, base_url):
    _add_menu_item(handle, base_url, _t(30045), 'events_list')
    _add_menu_item(handle, base_url, _t(30046), 'compilations_list')
    _add_menu_item(handle, base_url, _t(30047), 'battle')
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _events_list(handle, base_url):
    events = kibeats_api.get_events(_session)
    for ev in events:
        li = xbmcgui.ListItem(label=ev['title'])
        li.setArt({'thumb': ev['cover'], 'icon': ev['cover']})
        url = build_url(base_url, action='event_detail', event_id=ev['id'])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _event_detail(handle, base_url, params):
    tracks = kibeats_api.get_event_detail(_session, params.get('event_id'))
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _compilations_list(handle, base_url):
    comps = kibeats_api.get_compilations(_session)
    for c in comps:
        li = xbmcgui.ListItem(label=c['title'])
        li.setArt({'thumb': c['cover'], 'icon': c['cover']})
        url = build_url(base_url, action='compilation_detail', compilation_id=c['id'])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def _compilation_detail(handle, base_url, params):
    tracks = kibeats_api.get_compilation_detail(_session, params.get('compilation_id'))
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _battle(handle, base_url):
    tracks = kibeats_api.get_battle_tracks(_session)
    if not tracks:
        xbmcgui.Dialog().notification('KiBeats', _t(30048), xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    _add_track_items(handle, base_url, tracks)
    xbmcplugin.setContent(handle, 'songs')
    xbmcplugin.endOfDirectory(handle)


def _play(handle, params):
    file_url = params.get('file')
    _log('Play: %s' % file_url)
    li = xbmcgui.ListItem(path=file_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)


def _clear_cache():
    # TODO: sobald ein echter HTTP-Cache eingebaut ist (analog SW1 Cache Cleaner),
    # hier den Cache-Ordner im Addon-Profil leeren statt nur die Meldung zu zeigen.
    xbmcgui.Dialog().notification('KiBeats', _t(30020), xbmcgui.NOTIFICATION_INFO, 2000)


def _reset_first_run():
    _ADDON.setSetting('first_run_done', 'false')
    xbmcgui.Dialog().notification('KiBeats', _t(30055), xbmcgui.NOTIFICATION_INFO, 2500)


def _dispatch(base_url, handle, params):
    action = params.get('action')

    if action == 'play':
        _play(handle, params)
        return

    if action == 'add_favorite':
        _add_favorite(params)
        return
    if action == 'remove_favorite':
        _remove_favorite(params)
        return
    if action == 'add_to_playlist':
        _add_to_playlist(params)
        return
    if action == 'delete_playlist':
        _delete_playlist(params)
        return
    if action == 'save_generated':
        _save_generated()
        return
    if action == 'clear_cache':
        _clear_cache()
        return
    if action == 'reset_first_run':
        _reset_first_run()
        return
    if action == 'open_settings':
        _ADDON.openSettings()
        return
    if action == 'play_radio':
        _play_radio(handle, params)
        return
    if action == 'noop':
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    _maybe_login()

    if action is None:
        _root_menu(handle, base_url)
    elif action == 'home':
        _home(handle, base_url)
    elif action == 'albums':
        _albums_genre_menu(handle, base_url)
    elif action == 'albums_list':
        _albums_list(handle, base_url, params)
    elif action == 'album_detail':
        _album_detail(handle, base_url, params)
    elif action == 'favorites':
        _favorites(handle, base_url)
    elif action == 'playlists':
        _playlists_menu(handle, base_url)
    elif action == 'playlist_detail':
        _playlist_detail(handle, base_url, params)
    elif action == 'generator':
        _generator(handle, base_url)
    elif action == 'explore':
        _explore_menu(handle, base_url)
    elif action == 'explore_genre_menu':
        _explore_genre_menu(handle, base_url)
    elif action == 'explore_mood_menu':
        _explore_mood_menu(handle, base_url)
    elif action == 'explore_list':
        _explore_list(handle, base_url, params)
    elif action == 'charts':
        _charts_menu(handle, base_url)
    elif action == 'charts_tracks':
        _charts_tracks(handle, base_url, params)
    elif action == 'charts_period_menu':
        _charts_period_menu(handle, base_url)
    elif action == 'charts_creators':
        _charts_creators(handle, base_url)
    elif action == 'charts_playlists':
        _charts_playlists(handle, base_url)
    elif action == 'chart_playlist_detail':
        _chart_playlist_detail(handle, base_url, params)
    elif action == 'radio':
        _radio_menu(handle, base_url)
    elif action == 'events':
        _events_menu(handle, base_url)
    elif action == 'events_list':
        _events_list(handle, base_url)
    elif action == 'event_detail':
        _event_detail(handle, base_url, params)
    elif action == 'compilations_list':
        _compilations_list(handle, base_url)
    elif action == 'compilation_detail':
        _compilation_detail(handle, base_url, params)
    elif action == 'battle':
        _battle(handle, base_url)
    else:
        _not_implemented(handle)


def route(base_url, handle, params):
    action = params.get('action')
    xbmc.log('[plugin.audio.kibeats] Debug-Log Einstellung: %s | Pfad: %s' % (
        _ADDON.getSettingBool('debug_log'), _LOG_FILE), xbmc.LOGINFO)
    _log('Route: %s | params=%s' % (action, params))
    try:
        _dispatch(base_url, handle, params)
    except Exception:
        # Unerwartete Fehler landen mit vollem Traceback im eigenen Debug-Log statt
        # nur still zu scheitern - vorher liess sich z.B. der setResolvedUrl-Bug
        # (falscher Handle) im Log gar nicht direkt erkennen.
        import traceback
        _log('UNHANDLED EXCEPTION:\n' + traceback.format_exc())
        raise
