# -*- coding: utf-8 -*-
"""
Eigenes JSON-basiertes Speichersystem fuer BeatFavoriten und BeatListen (Playlists),
unabhaengig von Kodis eingebauten Favoriten - gleiches Muster wie MySounds/MyLists
bei SoundWave 1.
"""
import json
import os
import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))

FAVORITES_FILE = os.path.join(_PROFILE, 'favorites.json')
PLAYLISTS_FILE = os.path.join(_PROFILE, 'playlists.json')


def _ensure_profile_dir():
    if not xbmcvfs.exists(_PROFILE):
        xbmcvfs.mkdirs(_PROFILE)


def _load(path):
    _ensure_profile_dir()
    if not xbmcvfs.exists(path):
        return []
    f = xbmcvfs.File(path)
    try:
        raw = f.read()
    finally:
        f.close()
    if not raw:
        return []
    try:
        return json.loads(raw)
    except ValueError:
        return []


def _save(path, data):
    _ensure_profile_dir()
    f = xbmcvfs.File(path, 'w')
    try:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))
    finally:
        f.close()


# --- BeatFavoriten -----------------------------------------------------

def get_favorites():
    return _load(FAVORITES_FILE)


def is_favorite(track_id):
    return any(str(t.get('id')) == str(track_id) for t in get_favorites())


def add_favorite(track):
    favs = get_favorites()
    if not is_favorite(track.get('id')):
        favs.append(track)
        _save(FAVORITES_FILE, favs)


def remove_favorite(track_id):
    favs = [t for t in get_favorites() if str(t.get('id')) != str(track_id)]
    _save(FAVORITES_FILE, favs)


# --- BeatListen (eigene Playlisten) -------------------------------------

def get_playlists():
    return _load(PLAYLISTS_FILE)


def create_playlist(name, tracks=None):
    playlists = get_playlists()
    playlists.append({'name': name, 'tracks': tracks or []})
    _save(PLAYLISTS_FILE, playlists)


def delete_playlist(name):
    playlists = [p for p in get_playlists() if p.get('name') != name]
    _save(PLAYLISTS_FILE, playlists)


def add_track_to_playlist(name, track):
    playlists = get_playlists()
    for p in playlists:
        if p.get('name') == name:
            p['tracks'].append(track)
            break
    _save(PLAYLISTS_FILE, playlists)


def get_playlist_tracks(name):
    for p in get_playlists():
        if p.get('name') == name:
            return p.get('tracks', [])
    return []


# --- Beatgenerator (transienter Zwischenspeicher fuer das zuletzt generierte Ergebnis) ---

LAST_GENERATED_FILE = os.path.join(_PROFILE, 'last_generated.json')


def set_last_generated(tracks):
    _save(LAST_GENERATED_FILE, tracks)


def get_last_generated():
    return _load(LAST_GENERATED_FILE)
