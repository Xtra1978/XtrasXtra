# -*- coding: utf-8 -*-
"""
Eigenes Lade-Overlay ("KI denkt nach") fuer laengere Wartezeiten im Addon, z.B.
waehrend der Beatgenerator mehrere Alben nacheinander abfragt. Blendet zwischen
den drei mitgelieferten Terminator-Schaedel-Zustaenden (neutral/wakeup/active)
durch, solange die eigentliche Arbeit im Hintergrund laeuft.

Nutzung:
    spinner = KiSpinner()
    spinner.start()
    try:
        ... langsamer Netzwerkkram ...
    finally:
        spinner.stop()
"""
import time
import threading

import xbmcaddon
import xbmcgui

_ADDON = xbmcaddon.Addon()
_MEDIA_DIR = _ADDON.getAddonInfo('path') + '/resources/media/spinner/'
_FRAMES = ['neutral.jpg', 'wakeup.jpg', 'active.jpg', 'wakeup.jpg']
_FRAME_DELAY = 0.5  # Sekunden pro Frame

# Von Python aus per WindowDialog erzeugte Controls verwenden als Koordinatenraum
# die 720p-Basisaufloesung (1280x720), NICHT 1080p - unabhaengig von der tatsaechlichen
# Bildschirmaufloesung, die Kodi automatisch hochskaliert. Ein zu groSSer/falsch
# positionierter erster Wurf (1920er-Koordinaten) liess das Overlay riesig und
# rechtsbuendig wirken statt klein und zentriert.
_SCREEN_W, _SCREEN_H = 1280, 720

# Seitenverhaeltnis der Originalbilder (~456x768) beibehalten, aber deutlich kleiner.
_IMG_W = 160
_IMG_H = int(_IMG_W * 768 / 456)
_IMG_X = int((_SCREEN_W - _IMG_W) / 2)
_IMG_Y = int((_SCREEN_H - _IMG_H) / 2)

# Auch bei sehr schnellen Antworten (z.B. Generator in ~2-3 Sekunden fertig) soll der
# Spinner nicht nur aufblitzen, sondern mindestens so lange sichtbar bleiben.
_MIN_VISIBLE_SECONDS = 2.5


class _SpinnerWindow(xbmcgui.WindowDialog):
    def __init__(self):
        super(_SpinnerWindow, self).__init__()
        self.image = xbmcgui.ControlImage(_IMG_X, _IMG_Y, _IMG_W, _IMG_H, _MEDIA_DIR + _FRAMES[0])
        self.addControl(self.image)


class KiSpinner(object):
    def __init__(self):
        self._window = None
        self._thread = None
        self._stop_event = threading.Event()
        self._started_at = None

    def start(self):
        self._window = _SpinnerWindow()
        self._window.show()
        self._started_at = time.time()
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._animate)
        self._thread.daemon = True
        self._thread.start()

    def _animate(self):
        i = 0
        while not self._stop_event.is_set():
            frame = _FRAMES[i % len(_FRAMES)]
            try:
                self._window.image.setImage(_MEDIA_DIR + frame)
            except Exception:
                break
            i += 1
            self._stop_event.wait(_FRAME_DELAY)

    def stop(self):
        if self._started_at is not None:
            remaining = _MIN_VISIBLE_SECONDS - (time.time() - self._started_at)
            if remaining > 0:
                time.sleep(remaining)
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1)
        if self._window:
            self._window.close()
            self._window = None
