# -*- coding: utf-8 -*-
"""
KiBeats.net Quellmodul.

Login ist rein session-basiert (Cookie PHPSESSID), kein Token/API-Key noetig.
Der komplette Musikkatalog ist ohne Login sichtbar - Login wird trotzdem optional
angeboten, falls kuenftig Inhalte nur fuer registrierte Nutzer dazukommen
(z.B. Replay-Option, Archive).

WICHTIG: Parsing basiert auf Server-gerendertem HTML (kein JSON-API vorhanden).
Aenderungen am KiBeats-Frontend koennen die Regex hier brechen - typisch fuer
alle Addons in diesem Portfolio, die auf HTML-Scraping statt offizieller API setzen.
"""
import re
import requests

BASE_URL = 'https://kibeats.net'

# Bestaetigte Genre-Liste von /albums (Filter-Chips im HTML) - Stand: erste HAR-Erfassung.
# Die Genre-Liste von /explore ist umfangreicher (~50 Genres laut Nav-Links) und noch
# nicht vollstaendig erfasst - TODO sobald weiteres HAR-Material fuer /explore vorliegt.
ALBUM_GENRES = [
    ('akustik', 'Akustik'), ('alternative', 'Alternative'), ('ambient', 'Ambient'),
    ('americana', 'Americana'), ('blues', 'Blues'), ('edm', 'EDM'),
    ('electronic', 'Electronic'), ('experimental', 'Experimental'), ('folk', 'Folk'),
    ('gothic', 'Gothic'), ('hip-hop', 'Hip-Hop'), ('house', 'House'),
    ('industrial', 'Industrial'), ('kinderlieder', 'Kinderlieder'),
    ('classical', 'Klassik'), ('latin', 'Latin'), ('medieval', 'Medieval'),
    ('metal', 'Metal'), ('orchestral', 'Orchestral'), ('pop', 'Pop'),
    ('punk', 'Punk'), ('rnb', 'R&B'), ('rap', 'Rap'), ('rock', 'Rock'),
    ('songwriter', 'Songwriter'), ('soul', 'Soul'), ('techno', 'Techno'),
    ('weihnachtsmusik', 'Weihnachtsmusik'), ('weltmusik', 'Weltmusik'),
]

_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/124.0 Safari/537.36',
}


def get_session():
    """Neue requests.Session mit Standard-Headern. Cookie-Handling passiert automatisch."""
    session = requests.Session()
    session.headers.update(_HEADERS)
    return session


def login(session, email, password):
    """
    Loggt ein, sofern der Nutzer das in den Settings aktiviert hat.
    Session-Cookie (PHPSESSID) wird von requests.Session automatisch uebernommen
    und bei Folgerequests mitgeschickt - kein manuelles Cookie-Handling noetig.
    Rueckgabe: True bei Erfolg (Redirect auf /dashboard), sonst False.
    """
    resp = session.post(
        BASE_URL + '/login',
        data={'login': email, 'password': password},
        allow_redirects=False,
        timeout=15,
    )
    return resp.status_code == 302 and 'dashboard' in resp.headers.get('Location', '')


def _extract_data_song_tracks(html):
    """
    Extrahiert alle [data-song]-Kacheln einer Seite (Home, Explore, Album-Detail, ...).
    Das JS liest per JSON.parse(el.dataset.song) - das Attribut ist valides JSON,
    in einfache Anfuehrungszeichen gefasst (doppelte Anfuehrungszeichen im JSON selbst
    wuerden sonst mit dem HTML-Attribut kollidieren).
    Dedupliziert nach Track-ID: manche Seiten (z.B. Event-Detail) zeigen denselben Track
    zweimal an (einmal in einer Gewinner-/Highlight-Box, einmal in der normalen Liste).
    """
    import json
    tracks = []
    seen_ids = set()
    for match in re.finditer(r"data-song=(['\"])(\{.*?\})\1", html, re.DOTALL):
        raw_json = match.group(2)
        # HTML-Entities zurueckwandeln (&quot; &amp; etc.), bevor JSON geparst wird
        raw_json = (raw_json.replace('&quot;', '"')
                             .replace('&#39;', "'")
                             .replace('&amp;', '&'))
        try:
            track = json.loads(raw_json)
        except ValueError:
            continue
        track_id = track.get('id')
        if track_id is not None and track_id in seen_ids:
            continue
        if track_id is not None:
            seen_ids.add(track_id)
        tracks.append(track)
    return tracks


def get_albums(session, genre=None, sort='newest', query=None, page=1):
    """
    Laedt /albums (frei zugaenglich, kein Login noetig).
    Liefert (album_liste, hat_naechste_seite).
    """
    params = {'sort': sort, 'page': page}
    if genre:
        params['genre'] = genre
    if query:
        params['q'] = query

    resp = session.get(BASE_URL + '/albums', params=params, timeout=15)
    html = resp.text

    albums = []
    # Jede Album-Kachel: <a href="/album/{id}" class="track-card" ...>...</a>
    card_pattern = re.compile(
        r'<a href="/album/(\d+)" class="track-card".*?</a>', re.DOTALL
    )
    for card in card_pattern.finditer(html):
        block = card.group(0)
        album_id = card.group(1)

        cover_match = re.search(r'<img src="([^"]+)"', block)
        title_match = re.search(r'class="track-card-title">([^<]+)<', block)
        artist_match = re.search(r'class="track-card-artist">([^<]+)<', block)
        tracks_match = re.search(r'([\d]+)\s*Tracks?\s*</span>', block)
        genre_match = re.search(r'class="badge"[^>]*>([^<]+)</span>', block)

        albums.append({
            'id': album_id,
            'title': title_match.group(1).strip() if title_match else '?',
            'artist': artist_match.group(1).strip() if artist_match else '?',
            'cover': cover_match.group(1) if cover_match else '',
            'track_count': tracks_match.group(1) if tracks_match else '',
            'genre': genre_match.group(1) if genre_match else '',
        })

    # Naechste Seite vorhanden, wenn ein page-btn mit Pfeil-Icon (naechste Seite) existiert
    has_next = bool(re.search(r'/albums\?[^"]*page=%d[^"]*"\s+class="page-btn"><i class="fas fa-chevron-right"' % (int(page) + 1), html)) \
        or bool(re.search(r'class="page-btn"><i class="fas fa-chevron-right"', html))

    return albums, has_next


def get_album_detail(session, album_id):
    """
    TODO: Noch kein HAR/HTML-Mitschnitt einer Album-Detailseite vorhanden.
    Erwartet wird eine Trackliste im gleichen [data-song]-Muster wie Home/Alben-Cover.
    Sobald ein Mitschnitt von /album/<id> vorliegt, hier die echte Struktur eintragen.
    """
    resp = session.get(BASE_URL + '/album/' + str(album_id), timeout=15)
    return _extract_data_song_tracks(resp.text)


def get_home_tracks(session):
    """
    Startseite - liefert alle dort vorhandenen [data-song]-Kacheln (Spotlight/Neue Tracks/etc.
    sind aktuell noch nicht sauber nach Sektion getrennt geparst - TODO: Section-Header
    im HTML identifizieren, um z.B. nur "Neue Tracks" statt der kompletten Seite zu liefern).
    """
    resp = session.get(BASE_URL + '/', timeout=15)
    return _extract_data_song_tracks(resp.text)


def get_track_pool(session, genres=None, target_count=25, max_albums=25):
    """
    Sammelt einen Track-Pool fuer den Beatgenerator, optional ueber bis zu mehrere
    gleichzeitig gewaehlte Genres hinweg (genres=None oder leere Liste = alle Genres).
    Holt pro Genre so lange weitere Album-Seiten nach, bis das jeweilige Genre-Budget
    an Alben ausgeschoepft oder genug Tracks insgesamt zusammengekommen sind.
    Solide Zwischenloesung, solange /explore noch keinen eigenen HAR-Mitschnitt hat -
    sobald der vorliegt, kann der Generator direkt darauf zugreifen statt ueber Alben
    zu gehen.
    """
    import random

    genre_list = genres if genres else [None]
    per_genre_album_budget = max(5, max_albums // len(genre_list))

    pool = []
    for genre in genre_list:
        seen_album_ids = set()
        page = 1
        while len(pool) < target_count and len(seen_album_ids) < per_genre_album_budget:
            albums, has_next = get_albums(session, genre=genre, page=page)
            if not albums:
                break
            random.shuffle(albums)
            new_albums_found = False
            for album in albums:
                if album['id'] in seen_album_ids:
                    continue
                new_albums_found = True
                seen_album_ids.add(album['id'])
                pool.extend(get_album_detail(session, album['id']))
                if len(pool) >= target_count or len(seen_album_ids) >= per_genre_album_budget:
                    break
            if not has_next or not new_albums_found:
                # Keine neuen Alben mehr auf dieser Seite (z.B. Pagination-Kante) -
                # ohne diesen Abbruch wuerde has_next=True sonst zur Endlosschleife fuehren.
                break
            page += 1

    return pool


# Vollstaendige Genre-Liste von /explore (Filter-Chips + Genre-Spotlight), 48 Genres -
# umfangreicher als die 29 auf /albums.
EXPLORE_GENRES = [
    ('afro-house', 'Afro House'), ('afrobeats', 'Afrobeats'), ('akustik', 'Akustik'),
    ('alternative', 'Alternative'), ('ambient', 'Ambient'), ('americana', 'Americana'),
    ('bachata', 'Bachata'), ('blues', 'Blues'), ('contemporary', 'Contemporary'),
    ('dance', 'Dance'), ('electronic', 'Electronic'), ('experimental', 'Experimental'),
    ('folk', 'Folk'), ('funk', 'Funk'), ('gospel', 'Gospel'), ('gothic', 'Gothic'),
    ('hardstyle', 'Hardstyle'), ('house', 'House'), ('industrial', 'Industrial'),
    ('kinderlieder', 'Kinderlieder'), ('latin', 'Latin'), ('medieval', 'Medieval'),
    ('metal', 'Metal'), ('ndw', 'NDW'), ('orchestral', 'Orchestral'), ('punk', 'Punk'),
    ('rap', 'Rap'), ('reggae', 'Reggae'), ('schlager', 'Schlager'),
    ('songwriter', 'Songwriter'), ('soul', 'Soul'), ('soundtrack', 'Soundtrack'),
    ('synthwave', 'Synthwave'), ('techno', 'Techno'), ('trance', 'Trance'),
    ('trap', 'Trap'), ('volksmusik', 'Volksmusik'), ('weihnachtsmusik', 'Weihnachtsmusik'),
    ('weltmusik', 'Weltmusik'), ('pop', 'Pop'), ('rock', 'Rock'), ('hip-hop', 'Hip-Hop'),
    ('edm', 'EDM'), ('rnb', 'R&B'), ('jazz', 'Jazz'), ('classical', 'Klassik'),
    ('country', 'Country'), ('lofi', 'Lo-Fi'),
]

EXPLORE_MOODS = [
    ('happy', 'Happy'), ('sad', 'Sad'), ('energetic', 'Energetic'), ('relaxed', 'Relaxed'),
    ('romantic', 'Romantic'), ('dark', 'Dark'), ('uplifting', 'Uplifting'),
    ('melancholic', 'Melancholic'),
]

EXPLORE_SORTS = [
    (None, 'Neueste'), ('popular', 'Beliebt'), ('trending', 'Trending'), ('oldest', 'Älteste'),
]


def get_explore_tracks(session, genre=None, mood=None, sort=None, query=None, page=1):
    """
    /explore - gleiches Grid-/Pagination-Muster wie /albums, nur eben einzelne Tracks
    statt Alben (data-song-Kacheln direkt in der Ergebnisliste).
    """
    params = {'page': page}
    if genre:
        params['genre'] = genre
    if mood:
        params['mood'] = mood
    if sort:
        params['sort'] = sort
    if query:
        params['q'] = query
    resp = session.get(BASE_URL + '/explore', params=params, timeout=15)
    html = resp.text
    tracks = _extract_data_song_tracks(html)
    has_next = bool(re.search(r'class="page-btn"><i class="fas fa-chevron-right"', html))
    return tracks, has_next


# --- Charts --------------------------------------------------------------

def get_chart_periods(session):
    """Liest die verfuegbaren Monats-Snapshots aus dem <select> auf /charts aus."""
    resp = session.get(BASE_URL + '/charts', params={'tab': 'tracks'}, timeout=15)
    return re.findall(r'<option value="(\d{4}-\d{2})"', resp.text)


def get_chart_tracks(session, period=None, monthly=False):
    """
    tab=tracks (Aktuell) oder tab=tracks mit period=YYYY-MM (Monat-Snapshot), bzw.
    tab=tracks_monthly fuer die laufende Monatswertung ohne festen Snapshot.
    Alle drei liefern data-song-Kacheln im gleichen Format wie ueberall sonst.
    """
    params = {'tab': 'tracks_monthly' if monthly else 'tracks'}
    if period:
        params['period'] = period
    resp = session.get(BASE_URL + '/charts', params=params, timeout=15)
    return _extract_data_song_tracks(resp.text)


def get_chart_playlists(session, period=None):
    """
    tab=playlists - Rangliste, kein data-song-Muster sondern eigene Zeilen mit Link
    auf /playlists/view/<id>. Top-3-Podest hat keinen Link, daher wird nur die
    "Vollstaendiges Ranking"-Liste (Rang 4+) geparst, die zuverlaessig verlinkt ist.
    """
    params = {'tab': 'playlists'}
    if period:
        params['period'] = period
    resp = session.get(BASE_URL + '/charts', params=params, timeout=15)
    html = resp.text
    playlists = []
    for m in re.finditer(
        r'<a href="/playlists/view/(\d+)"[^>]*>([^<]+)</a>\s*'
        r'<div[^>]*>\s*<span>([^<]*)</span>',
        html,
    ):
        playlists.append({'id': m.group(1), 'title': m.group(2).strip(), 'creator': m.group(3).strip()})
    return playlists


def get_chart_creators(session, period=None):
    """
    tab=users - wie bei Playlists hat nur die Rangliste ab Platz 4 einen verlaesslichen
    Link (/profile?user=...); das Top-3-Podest wird hier bewusst nicht mitgenommen,
    um das Parsing robust zu halten.
    """
    params = {'tab': 'users'}
    if period:
        params['period'] = period
    resp = session.get(BASE_URL + '/charts', params=params, timeout=15)
    html = resp.text
    creators = []
    for m in re.finditer(r'href="/profile\?user=([^"]+)"[^>]*>([^<]*)</a>', html):
        username = m.group(1)
        if username not in [c['username'] for c in creators]:
            creators.append({'username': username, 'label': m.group(2).strip() or username})
    return creators


def get_playlist_detail(session, playlist_id):
    """
    TODO: noch kein eigener HAR-Mitschnitt einer /playlists/view/<id>-Seite vorhanden -
    Annahme (konsistent mit dem Rest der Seite): data-song-Kacheln wie bei Alben/Home.
    """
    resp = session.get(BASE_URL + '/playlists/view/' + str(playlist_id), timeout=15)
    return _extract_data_song_tracks(resp.text)


# --- Radio -----------------------------------------------------------------

def get_radio_stations(session, genre=None):
    """
    /radio - liest Sendername, Slug, Cover und direkten Stream-Link (steckt schon in
    der Listenseite selbst im onclick="toggleRadioPlay(...)", kein Detailseiten-Aufruf
    noetig).
    """
    params = {}
    if genre:
        params['genre'] = genre
    resp = session.get(BASE_URL + '/radio', params=params, timeout=15)
    html = resp.text

    hrefs = re.findall(r'href="(/radio/[a-zA-Z0-9-]+)" class="radio-card-logo"', html)
    names = re.findall(r'radio-card-logo"[^>]*>\s*<img src="([^"]+)" alt="([^"]+)"', html)
    streams = re.findall(r'toggleRadioPlay\(this, "(.*?)", (\d+)\)', html)

    stations = []
    for i, href in enumerate(hrefs):
        cover, name = names[i] if i < len(names) else ('', href.rsplit('/', 1)[-1])
        stream_url, sid = streams[i] if i < len(streams) else ('', '')
        stations.append({
            'id': sid,
            'slug': href.rsplit('/', 1)[-1],
            'name': name,
            'cover': cover,
            'stream_url': stream_url.replace('\\/', '/'),
        })
    return stations


def get_now_playing_icy(stream_url, timeout=4):
    """
    Best-effort ICY-Metadata-Abfrage direkt am Stream (Icecast/Shoutcast): fragt per
    Icy-MetaData: 1-Header an und liest nur so viel wie noetig, um den naechsten
    StreamTitle-Metadatenblock zu bekommen. Liefert None, wenn der Stream keine
    ICY-Metadaten sendet oder die Abfrage fehlschlaegt - Aufrufer muss damit rechnen
    und die Anzeige einfach weglassen (deshalb "sofern verfuegbar").
    """
    try:
        resp = requests.get(
            stream_url, headers={'Icy-MetaData': '1', 'User-Agent': _HEADERS['User-Agent']},
            stream=True, timeout=timeout,
        )
        meta_interval = int(resp.headers.get('icy-metaint', 0))
        if not meta_interval:
            resp.close()
            return None

        raw = resp.raw
        raw.read(meta_interval)
        length_byte = raw.read(1)
        if not length_byte:
            resp.close()
            return None
        meta_length = ord(length_byte) * 16
        metadata = raw.read(meta_length).decode('utf-8', errors='ignore')
        resp.close()

        m = re.search(r"StreamTitle='([^']*)'", metadata)
        if not m or not m.group(1):
            return None
        return m.group(1)  # meist "Artist - Titel"
    except Exception:
        return None


# --- Events & Contests -------------------------------------------------------

def _extract_cards(html, path_prefix):
    """Generischer Karten-Parser fuer /events und /compilations (gleiches Markup)."""
    cards = []
    pattern = re.compile(
        r'href="%s/(\d+)"[^>]*>.*?<img src="([^"]+)" alt="([^"]*)"' % re.escape(path_prefix),
        re.DOTALL,
    )
    for m in pattern.finditer(html):
        cards.append({'id': m.group(1), 'cover': m.group(2), 'title': m.group(3)})
    return cards


def get_events(session):
    resp = session.get(BASE_URL + '/events', timeout=15)
    return _extract_cards(resp.text, '/events')


def get_event_detail(session, event_id):
    resp = session.get(BASE_URL + '/events/' + str(event_id), timeout=15)
    return _extract_data_song_tracks(resp.text)


def get_compilations(session):
    resp = session.get(BASE_URL + '/compilations', timeout=15)
    return _extract_cards(resp.text, '/compilations')


def get_compilation_detail(session, compilation_id):
    """TODO: noch kein eigener Mitschnitt einer Compilation-Detailseite - Annahme
    analog Event-Detail (data-song-Kacheln)."""
    resp = session.get(BASE_URL + '/compilations/' + str(compilation_id), timeout=15)
    return _extract_data_song_tracks(resp.text)


def get_battle_tracks(session):
    """/battles zeigt oft 'Kein Battle aktiv' - dann leere Liste zurueckgeben."""
    resp = session.get(BASE_URL + '/battles', timeout=15)
    return _extract_data_song_tracks(resp.text)
