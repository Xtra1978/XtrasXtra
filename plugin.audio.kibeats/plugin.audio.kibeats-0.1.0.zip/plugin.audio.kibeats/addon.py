# -*- coding: utf-8 -*-
"""
KiBeats Kodi Addon - Entry point.
Hält sich bewusst schlank - die eigentliche Logik lebt in resources/lib/router.py,
gleiches Architekturmuster wie bei den anderen Addons (z.B. SoundWave 1).
"""
import sys
from urllib.parse import parse_qsl

from resources.lib.router import route

if __name__ == '__main__':
    handle = int(sys.argv[1])
    base_url = sys.argv[0]
    params = dict(parse_qsl(sys.argv[2][1:]))
    route(base_url, handle, params)
