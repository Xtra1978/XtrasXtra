# -*- coding: utf-8 -*-
"""
plugin.audio.fluxfm
Slim entrypoint - all real logic lives in resources/lib/router.py
"""
import sys
from urllib.parse import parse_qsl

from resources.lib.router import route

if __name__ == "__main__":
    handle = int(sys.argv[1])
    base_url = sys.argv[0]
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    route(base_url, handle, params)
