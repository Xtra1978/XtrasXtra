# -*- coding: utf-8 -*-
"""
Lightweight background service. Kodi's Player has no built-in concept of
"now playing metadata changed" for a live Icecast stream, so this polls
current-track every POLL_SECONDS while a FluxFM channel is playing and
pushes updates via Player.updateInfoTag() (Kodi 20+).
"""
import xbmc
import xbmcgui

from resources.lib import api
from resources.lib.logger import log, log_error

WINDOW = xbmcgui.Window(10000)
PROP_CHANNEL_ID = "fluxfm.playing_channel_id"
PROP_CHANNEL_TITLE = "fluxfm.playing_channel_title"
POLL_SECONDS = 20


class FluxServiceMonitor(xbmc.Monitor):
    pass


def _is_our_stream(path):
    return bool(path) and "radiosphere.io" in path and "/channels/" in path


def _update_now_playing(player, channel_id, channel_title):
    track = api.get_current_track(channel_id)
    title, artist = api.track_title_artist(track)
    if not title:
        return

    if WINDOW.getProperty("fluxfm.last_title") == title:
        return  # nothing changed, avoid needless updateInfoTag calls

    item = xbmcgui.ListItem()
    info = {"title": title, "album": channel_title}
    if artist:
        info["artist"] = artist
    item.setInfo("music", info)
    try:
        player.updateInfoTag(item)
        WINDOW.setProperty("fluxfm.last_title", title)
        log("Now playing updated: %s - %s" % (artist, title))
    except Exception as e:
        log_error("updateInfoTag failed: %s" % e)


def run():
    player = xbmc.Player()
    monitor = FluxServiceMonitor()

    while not monitor.abortRequested():
        try:
            if player.isPlayingAudio() and _is_our_stream(player.getPlayingFile()):
                channel_id = WINDOW.getProperty(PROP_CHANNEL_ID)
                channel_title = WINDOW.getProperty(PROP_CHANNEL_TITLE)
                if channel_id:
                    _update_now_playing(player, channel_id, channel_title)
            else:
                WINDOW.setProperty("fluxfm.last_title", "")
        except Exception as e:
            log_error("Service loop error: %s" % e)

        if monitor.waitForAbort(POLL_SECONDS):
            break


if __name__ == "__main__":
    run()
