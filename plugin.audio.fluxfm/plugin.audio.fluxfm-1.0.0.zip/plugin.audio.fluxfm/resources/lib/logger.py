# -*- coding: utf-8 -*-
"""
Dedicated, compact addon-specific debug log - separate from kodi.log.
Toggle + max size are controlled via addon settings (debug_log_enabled,
debug_log_max_kb).
"""
import os
import time

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
LOG_PATH = os.path.join(PROFILE, "fluxfm_debug.log")


def _enabled():
    return ADDON.getSettingBool("debug_log_enabled")


def _max_bytes():
    try:
        return int(ADDON.getSettingInt("debug_log_max_kb")) * 1024
    except Exception:
        return 512 * 1024


def _rotate_if_needed():
    try:
        if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > _max_bytes():
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("")
    except OSError:
        pass


def log(message, level="INFO"):
    if not _enabled():
        return
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE, exist_ok=True)
    _rotate_if_needed()
    line = "%s [%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), level, message)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def log_error(message):
    log(message, level="ERROR")
