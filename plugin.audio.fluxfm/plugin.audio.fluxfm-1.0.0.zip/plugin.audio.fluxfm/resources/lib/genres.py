# -*- coding: utf-8 -*-
"""
The RadioSphere API exposes no genre/tag field on channels (verified via
HAR capture). This mapping is curated by hand from each channel's name
and on-site description, mirroring the same 31 channels returned by
GET /channels. Keyed by the channel "name" (slug), not the UUID, since
slugs are stable and readable.
"""

GENRE_MAP = {
    "FluxFM": "Hauptsender",
    "fluxfm-finest": "Indie / Alternative",
    "flux-lounge": "Chill / Lounge",
    "clubsandwich": "Electronic / DJ",
    "electronic-chillout": "Chill",
    "listen-to-berlin": "Indie / Newcomer",
    "chillhop": "Chill",
    "80s": "Jahrzehnte",
    "90s": "Jahrzehnte",
    "70s": "Jahrzehnte",
    "60s": "Jahrzehnte",
    "2000er": "Jahrzehnte",
    "indiedisco": "Indie",
    "elektro-flux": "Electronic",
    "berlin-beach-house": "Electronic / Chill",
    "techno-underground": "Electronic / Techno",
    "sound-of-berlin": "Electronic",
    "mini-flux": "Kids",
    "boom-fm-classics": "HipHop",
    "jazz-schwarzenstein": "Jazz",
    "x-jazz": "Jazz",
    "neofm": "Pop / Alternative",
    "metal-fm": "Metal",
    "alternative": "Alternative",
    "b-funk": "Funk / Soul",
    "anima-radio": "Chill / Ambient",
    "yoga-sounds": "Chill / Meditation",
    "chillout-radio": "Chill",
    "htgp": "Chill / Psychedelic",
    "traumerei": "Chill / Ambient",
    "john-reed-radio": "Workout / Fitness",
}

# Fixed display order for the Genres menu
GENRE_ORDER = [
    "Indie / Alternative", "Indie", "Indie / Newcomer", "Alternative",
    "Electronic", "Electronic / DJ", "Electronic / Techno", "Electronic / Chill",
    "Chill", "Chill / Lounge", "Chill / Ambient", "Chill / Meditation", "Chill / Psychedelic",
    "Pop / Alternative", "HipHop", "Metal", "Funk / Soul", "Jazz",
    "Jahrzehnte", "Kids", "Workout / Fitness",
]


def genre_for(channel):
    return GENRE_MAP.get(channel.get("name"), "Sonstige")


def group_by_genre(channels):
    grouped = {}
    for ch in channels:
        genre = genre_for(ch)
        grouped.setdefault(genre, []).append(ch)
    return grouped


def ordered_genres(grouped):
    ordered = [g for g in GENRE_ORDER if g in grouped]
    remaining = sorted(g for g in grouped if g not in GENRE_ORDER)
    return ordered + remaining
