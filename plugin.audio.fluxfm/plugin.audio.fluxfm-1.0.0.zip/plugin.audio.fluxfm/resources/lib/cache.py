# -*- coding: utf-8 -*-
"""
Lightweight JSON disk cache for channel/post lookups.
Cleanup behaviour (auto on startup, on-demand via settings, interval)
is controlled entirely through addon settings - see settings.xml.
"""
import json
import os
import time

import xbmcaddon
import xbmcvfs

from resources.lib.logger import log

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_DIR = os.path.join(PROFILE, "cache")


def _ensure_dir():
    if not os.path.isdir(CACHE_DIR):
        os.makedirs(CACHE_DIR, exist_ok=True)


def _path(key):
    safe = "".join(c if c.isalnum() else "_" for c in key)
    return os.path.join(CACHE_DIR, safe + ".json")


def get(key, max_age_seconds=300):
    _ensure_dir()
    path = _path(key)
    if not os.path.exists(path):
        return None
    if time.time() - os.path.getmtime(path) > max_age_seconds:
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def set(key, value):
    _ensure_dir()
    try:
        with open(_path(key), "w", encoding="utf-8") as f:
            json.dump(value, f)
    except OSError:
        pass


def clear_all():
    """Manual 'Cache leeren' action, also called automatically per settings."""
    _ensure_dir()
    count = 0
    for name in os.listdir(CACHE_DIR):
        try:
            os.remove(os.path.join(CACHE_DIR, name))
            count += 1
        except OSError:
            pass
    log("Cache cleared (%d files)" % count)
    return count


def auto_clean_if_due():
    """Called once on addon start. Respects cache_auto_clean_days setting."""
    if not ADDON.getSettingBool("cache_auto_clean_enabled"):
        return
    marker = os.path.join(PROFILE, ".last_cache_clean")
    days = ADDON.getSettingInt("cache_auto_clean_days") or 7
    due = True
    if os.path.exists(marker):
        due = (time.time() - os.path.getmtime(marker)) > days * 86400
    if due:
        clear_all()
        _ensure_dir()
        with open(marker, "w", encoding="utf-8") as f:
            f.write(str(time.time()))
