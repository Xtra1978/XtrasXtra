# -*- coding: utf-8 -*-
"""
Thin client for the public FluxFM / RadioSphere API.
No login, no paywall - matches Kodinerds acceptance rules.
"""
import json
from urllib.request import Request, urlopen
from urllib.error import URLError

from resources.lib.logger import log, log_error

API_HOST = "https://fluxmusic.api.radiosphere.io"
USER_AGENT = "Kodi-plugin.audio.fluxfm/1.0"

# FluxFM's RadioSphere backend serves /channels fine without these, but
# /posts and /posts/groups silently return an empty-but-paginated result
# without them (confirmed via HAR: the web app always sends x-app +
# x-api-version). Mirror the browser exactly to avoid that.
APP_ID = "1303b052-0c58-4d21-8445-ad750cc45d26"
DEFAULT_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "de,de-DE;q=0.9,en;q=0.8",
    "Origin": "https://www.fluxfm.de",
    "Referer": "https://www.fluxfm.de/",
    "X-Api-Version": "radiosphere-v1.5",
    "X-App": APP_ID,
}

# Tag id used site-wide for "highlight" / curated Mediathek posts
TAG_HIGHLIGHT = "cfdc18b1-705c-41de-b058-69b674aaddf3"

# The 8 podcast series exposed on fluxfm.de/podcast - there is no API
# endpoint that lists these groups, so they are hardcoded (verified via HAR).
# setting_id maps to a boolean toggle in settings.xml so the user can pick
# which Mediathek categories show up.
PODCAST_GROUPS = [
    ("50faa39e-af0e-41f9-b386-7707a23b4931", "Interviews & Beiträge", "show_group_interviews"),
    ("d8f5d614-c934-4b44-9e0a-2abfe619fd58", "Berlin History Snippets", "show_group_berlin_history"),
    ("923457e6-80d5-42b4-be85-36acce218363", "Breitbild", "show_group_breitbild"),
    ("e52501b6-9ed3-4ceb-94b5-3d60acc516f9", "Was für ein Leben", "show_group_was_fuer_ein_leben"),
    ("344ca8db-0524-445e-8878-b727d36c614a", "Durch die Woche mit", "show_group_durch_die_woche"),
    ("50f628f4-26ae-4008-a5d5-d4a6221a9282", "Kiez und Kids", "show_group_kiez_und_kids"),
    ("d39cfb4f-2add-45c7-baf0-48f427265be5", "MODUS OPERANDI", "show_group_modus_operandi"),
    ("97a7fbf2-af1e-4bd7-b629-2473ca0068b7", "Radio Arty", "show_group_radio_arty"),
]


def _get(url):
    req = Request(url, headers=DEFAULT_HEADERS)
    try:
        with urlopen(req, timeout=10) as resp:
            data = resp.read()
        return json.loads(data)
    except URLError as e:
        log_error("API request failed: %s (%s)" % (url, e))
        return None
    except json.JSONDecodeError as e:
        log_error("API returned invalid JSON: %s (%s)" % (url, e))
        return None


def get_channels():
    """Return all 31 channels in one call (API has no pagination for this)."""
    log("Fetching channel list")
    data = _get(API_HOST + "/channels")
    if not data:
        return []
    return data.get("items", [])


def get_channel(channel_id):
    return _get("%s/channels/%s" % (API_HOST, channel_id))


def get_current_track(channel_id):
    return _get("%s/channels/%s/current-track" % (API_HOST, channel_id))


import datetime

HISTORY_WINDOW_DAYS = 90  # how far back "Playlisten" browsing/search reaches


def get_track_history(channel_id, offset=None, limit=25, days_back=HISTORY_WINDOW_DAYS):
    """from/to appear to be required by the API (always sent by the web app).
    A single wide from..to window is used, with next/prev cursors paging
    through it - avoids guessing whether from/to alone can be omitted."""
    now = datetime.datetime.utcnow()
    date_from = (now - datetime.timedelta(days=days_back)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    date_to = now.strftime("%Y-%m-%dT%H:%M:%S.000Z")
    url = (
        "%s/channels/%s/track-history?limit=%d&check-favorites=false"
        "&from=%s&to=%s" % (API_HOST, channel_id, limit, date_from, date_to)
    )
    if offset:
        url += "&offset=%s" % offset
    return _get(url)


def track_title_artist(track_response):
    """current-track and track-history items both nest the actual data
    under a 'track' key - title / artistCredits / artwork."""
    if not track_response:
        return None, None
    track = track_response.get("track", track_response)
    title = track.get("title")
    artist = track.get("artistCredits") or track.get("artist")
    return title, artist


def get_group_posts(group_id, offset=None, limit=20):
    url = "%s/posts/groups/%s/posts?limit=%d" % (API_HOST, group_id, limit)
    if offset:
        url += "&offset=%s" % offset
    return _get(url)


def get_posts_by_tag(tag_id, offset=None, limit=20):
    url = "%s/posts?tags=%s&limit=%d" % (API_HOST, tag_id, limit)
    if offset:
        url += "&offset=%s" % offset
    return _get(url)


def best_stream_url(channel, high_quality):
    """Pick aac (HQ, if enabled and available) or mp3 from a channel's streams."""
    streams = channel.get("streams", [])
    aac = next((s for s in streams if s.get("encoding") == "aac"), None)
    mp3 = next((s for s in streams if s.get("encoding") == "mp3"), None)
    if high_quality and aac:
        return aac["url"]
    return (mp3 or aac or {}).get("url")


def best_audio_url(post):
    """Direct, DRM-free episode stream URL from a Mediathek post."""
    audio = post.get("audio") or {}
    sources = audio.get("sources", [])
    if sources:
        return sources[0].get("url")
    return None
