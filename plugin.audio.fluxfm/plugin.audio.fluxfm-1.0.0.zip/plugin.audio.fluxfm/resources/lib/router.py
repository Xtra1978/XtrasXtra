# -*- coding: utf-8 -*-
import os
import sys
from urllib.parse import urlencode

import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import api, cache, favorites, genres
from resources.lib.logger import log
from resources.lib.textutils import _clean

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
MENU_ICON = os.path.join(ADDON_PATH, "resources", "media", "menuicon.jpg")
FANART = os.path.join(ADDON_PATH, "resources", "media", "fanart.jpg")


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _url(base_url, **kwargs):
    return "%s?%s" % (base_url, urlencode(kwargs))


def route(base_url, handle, params):
    cache.auto_clean_if_due()
    action = params.get("action")

    if action is None:
        show_main_menu(base_url, handle)
    elif action == "live":
        show_live_streams(base_url, handle)
    elif action == "genres":
        show_genres(base_url, handle)
    elif action == "genre":
        show_genre_channels(base_url, handle, params["name"])
    elif action == "mediathek":
        show_mediathek_groups(base_url, handle)
    elif action == "group":
        show_group_episodes(base_url, handle, params["id"], params.get("offset"))
    elif action == "playlists":
        show_playlist_channels(base_url, handle)
    elif action == "search_menu":
        show_playlist_channels(base_url, handle, for_search=True)
    elif action == "playlist_channel":
        show_track_history(base_url, handle, params["id"], params.get("offset"))
    elif action == "search_playlists":
        search_track_history(base_url, handle, params["id"])
    elif action == "noop":
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    elif action == "fluxoriten":
        show_fluxoriten(base_url, handle)
    elif action == "toggle_favorite":
        toggle_favorite(params["channel_id"])
    elif action == "play_channel":
        play_channel(params["channel_id"])
    elif action == "play_episode":
        play_episode(params["url"])
    elif action == "clear_cache":
        clear_cache()
    elif action == "settings":
        ADDON.openSettings()
    else:
        log("Unknown action: %s" % action)
        xbmcplugin.endOfDirectory(handle, succeeded=False)


# ---------------------------------------------------------------- main menu

def show_main_menu(base_url, handle):
    entries = [
        (_(30000), "live"),
        (_(30001), "genres"),
        (_(30002), "mediathek"),
        (_(30042), "playlists"),
        (_(30047), "search_menu"),
        (_(30003), "fluxoriten"),
    ]
    for label, action in entries:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        url = _url(base_url, action=action)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    settings_item = xbmcgui.ListItem(label=_(30004))
    settings_item.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
    xbmcplugin.addDirectoryItem(
        handle, _url(base_url, action="settings"), settings_item, isFolder=False
    )

    xbmcplugin.setContent(handle, "files")
    xbmcplugin.endOfDirectory(handle)


# ------------------------------------------------------------ live streams

def _all_channels():
    data = cache.get("channels", max_age_seconds=300)
    if data is None:
        data = api.get_channels()
        cache.set("channels", data)
    return data or []


def _channel_listitem(base_url, channel):
    title = channel.get("title", channel.get("name"))
    sub_title = channel.get("subTitle", "")
    summary = _clean(channel.get("summary", ""))

    li = xbmcgui.ListItem(label=title)
    li.setProperty("IsPlayable", "true")
    image = (channel.get("contentGraph", {}).get("attributes", {}).get("image", {}) or {}).get("url")
    if image:
        li.setArt({"thumb": image, "fanart": image})

    info_tag = li.getMusicInfoTag()
    info_tag.setTitle(title)
    if sub_title:
        info_tag.setComment(sub_title)
    if summary:
        info_tag.setComment(summary)

    is_fav = favorites.is_favorite(channel["channelId"])
    fav_label = _(30007) if is_fav else _(30006)
    fav_url = _url(base_url, action="toggle_favorite", channel_id=channel["channelId"])
    li.addContextMenuItems([(fav_label, "RunPlugin(%s)" % fav_url)])

    play_url = _url(base_url, action="play_channel", channel_id=channel["channelId"])
    return play_url, li


def show_live_streams(base_url, handle):
    channels = _all_channels()
    for channel in channels:
        url, li = _channel_listitem(base_url, channel)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.endOfDirectory(handle)


# ------------------------------------------------------------------ genres

def show_genres(base_url, handle):
    channels = _all_channels()
    grouped = genres.group_by_genre(channels)
    for genre_name in genres.ordered_genres(grouped):
        li = xbmcgui.ListItem(label=genre_name)
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        url = _url(base_url, action="genre", name=genre_name)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, "files")
    xbmcplugin.endOfDirectory(handle)


def show_genre_channels(base_url, handle, genre_name):
    channels = _all_channels()
    grouped = genres.group_by_genre(channels)
    for channel in grouped.get(genre_name, []):
        url, li = _channel_listitem(base_url, channel)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.endOfDirectory(handle)


# --------------------------------------------------------------- mediathek

def show_mediathek_groups(base_url, handle):
    for group_id, title, setting_id in api.PODCAST_GROUPS:
        if not ADDON.getSettingBool(setting_id):
            continue
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        url = _url(base_url, action="group", id=group_id)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, "files")
    xbmcplugin.endOfDirectory(handle)


def show_group_episodes(base_url, handle, group_id, offset):
    # Some groups mix written articles (no audio) with real podcast
    # episodes. Auto-advance through empty pages server-side so the user
    # doesn't have to click through dead-end "next page" entries.
    playable = []
    hops = 0
    while hops < 6:
        data = api.get_group_posts(group_id, offset=offset, limit=25)
        if not data:
            break
        playable = [p for p in data.get("items", []) if p.get("audio")]
        offset = data.get("next")
        hops += 1
        if playable or not offset:
            break

    if data is None:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not playable:
        li = xbmcgui.ListItem(label=_(30009))
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        xbmcplugin.addDirectoryItem(handle, base_url, li, isFolder=False)

    for post in playable:
        attrs = post.get("contentGraph", {}).get("attributes", {})
        title = attrs.get("title", post.get("title"))
        sub_title = attrs.get("subTitle", "")
        summary = _clean(attrs.get("summary", ""))
        image = (attrs.get("image") or {}).get("url")
        audio_url = api.best_audio_url(post)
        if not audio_url:
            continue

        li = xbmcgui.ListItem(label=title)
        li.setProperty("IsPlayable", "true")
        if image:
            li.setArt({"thumb": image, "fanart": image})
        info_tag = li.getMusicInfoTag()
        info_tag.setTitle(title)
        if sub_title:
            info_tag.setComment(sub_title)
        elif summary:
            info_tag.setComment(summary)

        play_url = _url(base_url, action="play_episode", url=audio_url)
        xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)

    next_offset = data.get("next")
    if next_offset:
        li = xbmcgui.ListItem(label=_(30008))
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        url = _url(base_url, action="group", id=group_id, offset=next_offset)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.endOfDirectory(handle)


# --------------------------------------------------------------- playlisten

def show_playlist_channels(base_url, handle, for_search=False):
    channels = _all_channels()
    action = "search_playlists" if for_search else "playlist_channel"
    for channel in channels:
        title = channel.get("title", channel.get("name"))
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": MENU_ICON, "fanart": FANART})
        image = (channel.get("contentGraph", {}).get("attributes", {}).get("image", {}) or {}).get("url")
        if image:
            li.setArt({"thumb": image, "fanart": image})
        url = _url(base_url, action=action, id=channel["channelId"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.setContent(handle, "files")
    xbmcplugin.endOfDirectory(handle)


def _track_history_listitem(base_url, entry):
    title, artist = api.track_title_artist(entry)
    if not title:
        return None
    started = entry.get("start", "")
    time_label = ""
    if started:
        # "2026-08-06T06:10:00.000Z" -> "06.08. 06:10"
        try:
            dt = started.replace("Z", "").split(".")[0]
            date_part, time_part = dt.split("T")
            y, m, d = date_part.split("-")
            time_label = "%s.%s. %s  " % (d, m, time_part[:5])
        except (ValueError, IndexError):
            pass
    label = "%s%s – %s" % (time_label, artist or "?", title)

    li = xbmcgui.ListItem(label=label)
    artwork = entry.get("track", {}).get("artwork")
    if isinstance(artwork, str) and artwork:
        li.setArt({"thumb": artwork})
    info_tag = li.getMusicInfoTag()
    info_tag.setTitle(title)
    if artist:
        info_tag.setArtist(artist)
    return li


def show_track_history(base_url, handle, channel_id, offset):
    data = api.get_track_history(channel_id, offset=offset)
    if not data:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    search_li = xbmcgui.ListItem(label=_(30043))
    search_li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
    xbmcplugin.addDirectoryItem(
        handle, _url(base_url, action="search_playlists", id=channel_id), search_li, isFolder=True
    )

    items = data.get("items", [])
    for entry in items:
        li = _track_history_listitem(base_url, entry)
        if li:
            xbmcplugin.addDirectoryItem(handle, base_url, li, isFolder=False)

    if not items:
        li = xbmcgui.ListItem(label=_(30009))
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        xbmcplugin.addDirectoryItem(handle, base_url, li, isFolder=False)

    next_offset = data.get("next")
    if next_offset:
        li = xbmcgui.ListItem(label=_(30008))
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        url = _url(base_url, action="playlist_channel", id=channel_id, offset=next_offset)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.endOfDirectory(handle)


def search_track_history(base_url, handle, channel_id):
    keyboard = xbmcgui.Dialog().input(_(30043), type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = keyboard.strip().lower()
    max_pages = ADDON.getSettingInt("search_max_pages") or 15
    matches = []
    offset = None

    progress = xbmcgui.DialogProgress()
    progress.create("FluxFM", _(30044))
    for page in range(max_pages):
        if progress.iscanceled():
            break
        data = api.get_track_history(channel_id, offset=offset, limit=50)
        if not data:
            break
        for entry in data.get("items", []):
            title, artist = api.track_title_artist(entry)
            haystack = ((title or "") + " " + (artist or "")).lower()
            if query in haystack:
                matches.append(entry)
        progress.update(int((page + 1) * 100 / max_pages), _(30044))
        offset = data.get("next")
        if not offset:
            break
    progress.close()

    if not matches:
        li = xbmcgui.ListItem(label=_(30009))
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        xbmcplugin.addDirectoryItem(handle, base_url, li, isFolder=False)
    for entry in matches:
        li = _track_history_listitem(base_url, entry)
        if li:
            xbmcplugin.addDirectoryItem(handle, base_url, li, isFolder=False)

    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.endOfDirectory(handle)


# -------------------------------------------------------------- fluxoriten

def show_fluxoriten(base_url, handle):
    stored = favorites.list_all()
    if not stored:
        li = xbmcgui.ListItem(label=_(30009))
        li.setArt({"icon": MENU_ICON, "thumb": MENU_ICON, "fanart": FANART})
        xbmcplugin.addDirectoryItem(handle, base_url, li, isFolder=False)
    for channel in stored:
        url, li = _channel_listitem(base_url, channel)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.endOfDirectory(handle)


def toggle_favorite(channel_id):
    channels = _all_channels()
    channel = next((c for c in channels if c["channelId"] == channel_id), None)
    if not channel:
        # fall back: might already be a stored favorite being removed
        channel = next((c for c in favorites.list_all() if c["channelId"] == channel_id), None)
    if channel:
        favorites.toggle(channel)
        import xbmc
        xbmc.executebuiltin("Container.Refresh")


# ------------------------------------------------------------------- play

def play_channel(channel_id):
    channels = _all_channels()
    channel = next((c for c in channels if c["channelId"] == channel_id), None)
    if not channel:
        channel = api.get_channel(channel_id)
    if not channel:
        xbmcgui.Dialog().notification("FluxFM", _(30009))
        return

    high_quality = ADDON.getSettingBool("stream_quality_hq")
    stream_url = api.best_stream_url(channel, high_quality)
    if not stream_url:
        xbmcgui.Dialog().notification("FluxFM", _(30009))
        return

    channel_title = channel.get("title", channel.get("name"))
    li = xbmcgui.ListItem(label=channel_title, path=stream_url)
    li.setProperty("IsPlayable", "true")

    info_tag = li.getMusicInfoTag()
    info_tag.setTitle(channel_title)

    track = api.get_current_track(channel_id)
    now_playing_title, now_playing_artist = api.track_title_artist(track)
    if now_playing_title:
        info_tag.setTitle(now_playing_title)
        if now_playing_artist:
            info_tag.setArtist(now_playing_artist)
        info_tag.setAlbum(channel_title)

    image = (channel.get("contentGraph", {}).get("attributes", {}).get("image", {}) or {}).get("url")
    if image:
        li.setArt({"thumb": image, "fanart": image})

    # Let the background service (service.py) know which channel is
    # playing so it can keep polling current-track and refresh the
    # title/artist live via Player.updateInfoTag().
    xbmcgui.Window(10000).setProperty("fluxfm.playing_channel_id", channel_id)
    xbmcgui.Window(10000).setProperty("fluxfm.playing_channel_title", channel_title)

    handle = int(sys.argv[1])
    xbmcplugin.setResolvedUrl(handle, True, li)


def play_episode(url):
    li = xbmcgui.ListItem(path=url)
    li.setProperty("IsPlayable", "true")
    handle = int(sys.argv[1])
    xbmcplugin.setResolvedUrl(handle, True, li)


def clear_cache():
    count = cache.clear_all()
    xbmcgui.Dialog().notification("FluxFM", "%d" % count)
