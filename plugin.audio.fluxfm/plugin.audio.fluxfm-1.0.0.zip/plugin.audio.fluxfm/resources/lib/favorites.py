# -*- coding: utf-8 -*-
"""
Fluxoriten: addon-own favorites system, independent of Kodi's built-in
favorites (standard across Sascha's addons).
"""
import json
import os

import xbmcaddon
import xbmcvfs

from resources.lib.logger import log

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
FILE_PATH = os.path.join(PROFILE, "fluxoriten.json")


def _ensure_dir():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE, exist_ok=True)


def _load():
    _ensure_dir()
    if not os.path.exists(FILE_PATH):
        return {}
    try:
        with open(FILE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def _save(data):
    _ensure_dir()
    with open(FILE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def list_all():
    """Returns list of stored channel dicts, in the order they were added."""
    data = _load()
    return list(data.values())


def is_favorite(channel_id):
    return channel_id in _load()


def add(channel):
    data = _load()
    data[channel["channelId"]] = channel
    _save(data)
    log("Added to Fluxoriten: %s" % channel.get("title"))


def remove(channel_id):
    data = _load()
    if channel_id in data:
        title = data[channel_id].get("title")
        del data[channel_id]
        _save(data)
        log("Removed from Fluxoriten: %s" % title)


def toggle(channel):
    if is_favorite(channel["channelId"]):
        remove(channel["channelId"])
        return False
    add(channel)
    return True
