# -*- coding: utf-8 -*-
import re

_TAG_RE = re.compile(r"<[^>]+>")


def _clean(text, max_len=400):
    """Strip HTML tags and break at a word boundary near max_len."""
    if not text:
        return ""
    text = _TAG_RE.sub("", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= max_len:
        return text
    cut = text.rfind(" ", 0, max_len)
    if cut == -1:
        cut = max_len
    return text[:cut].rstrip() + "..."
