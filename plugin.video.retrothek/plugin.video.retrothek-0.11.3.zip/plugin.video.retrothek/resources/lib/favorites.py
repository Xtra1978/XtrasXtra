# -*- coding: utf-8 -*-
"""
Eigenes, Kodi-unabhaengiges Favoritensystem ("Meine Retros").
Gleiche Machart wie das Favoritensystem in XCast-Portal:
lokale JSON-Datei im Addon-Profilordner, kein Rueckgriff auf die
Kodi-Standard-Favoriten (die nur einzelne Aufrufe merken, keine Metadaten).
"""
import json
import os

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
FAVORITES_FILE = os.path.join(PROFILE_PATH, "favorites.json")


def _ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_PATH):
        xbmcvfs.mkdirs(PROFILE_PATH)


def _load():
    if not xbmcvfs.exists(FAVORITES_FILE):
        return {}
    f = xbmcvfs.File(FAVORITES_FILE)
    try:
        raw = f.read()
    finally:
        f.close()
    try:
        return json.loads(raw) if raw else {}
    except ValueError:
        return {}


def _save(data):
    _ensure_profile_dir()
    f = xbmcvfs.File(FAVORITES_FILE, "w")
    try:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))
    finally:
        f.close()


def _fav_key(provider, item_id):
    return "{}::{}".format(provider, item_id)


def add_favorite(item_dict):
    data = _load()
    key = _fav_key(item_dict["provider"], item_dict["id"])
    data[key] = item_dict
    _save(data)


def remove_favorite(provider, item_id):
    data = _load()
    key = _fav_key(provider, item_id)
    if key in data:
        del data[key]
        _save(data)


def is_favorite(provider, item_id):
    data = _load()
    return _fav_key(provider, item_id) in data


def list_favorites(category=None):
    data = _load()
    items = list(data.values())
    if category:
        items = [i for i in items if i.get("category") == category]
    return items
