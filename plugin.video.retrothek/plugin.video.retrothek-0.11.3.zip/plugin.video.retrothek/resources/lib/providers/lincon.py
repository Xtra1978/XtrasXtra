# -*- coding: utf-8 -*-
"""
LincOn.com Classic TV Provider.
Klassische US-TV-Sendungen, direkt selbst gehostet als MP4-Dateien
(kein Archive.org/YouTube/Vimeo-Umweg noetig) - bestaetigt per
HAR-Mitschnitt: Detailseite bettet einen iframe
(player-embed/id/{numeric_id}) ein, der wiederum ein <video><source
type="video/mp4" src="..."> enthaelt.

HINWEIS: Das Uebersichtsseiten-HTML (video-category/{slug}/) war im
HAR-Mitschnitt ohne Inhalt (0 Bytes) - das Link-Regex hier ist nach
bestem Wissen (typisches WordPress-Muster) gebaut, aber noch nicht
gegen die echte Seite verifiziert.
"""
import re

import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, resolve_parallel, log

BASE_URL = "https://lincon.com/site"

CATEGORY_MAP = {
    "serien": ["classic-tv", "pre-1950-television"],
}

_LINK_RE = re.compile(
    r'<a[^>]+href="(https://lincon\.com/site/classic-tv/[a-z0-9\-]+/)"[^>]*>\s*([^<]+?)\s*</a>',
    re.IGNORECASE,
)
_IFRAME_ID_RE = re.compile(r'player-embed/id/(\d+)')
_SOURCE_RE = re.compile(r'<source[^>]+src="([^"]+\.mp4)"', re.IGNORECASE)
_TITLE_RE = re.compile(r'<title>([^<]+?)(?:\s*-\s*LincOn\.com)?</title>')


class LincOnProvider(ProviderBase):
    key = "lincon"
    name = "LincOn.com Classic TV"

    def list_category(self, category, offset=0, size=50):
        slugs = CATEGORY_MAP.get(category, [])
        candidates = []
        for genre in slugs:
            path = "/video-category/{}/".format(genre)
            try:
                html = self._fetch(path)
            except requests.RequestException as exc:
                log("lincon: Abruf {} fehlgeschlagen: {}".format(path, exc), force=True)
                continue
            found = _LINK_RE.findall(html)
            log("lincon: {} -> {} Rohtreffer (html-laenge {})".format(path, len(found), len(html)), force=True)
            for url, title in found:
                candidates.append((url, _clean(title)))
        resolved = resolve_parallel(candidates, lambda c: self._get_detail_item(c, category), max_items=25)
        log("lincon: {} von {} Kandidaten erfolgreich aufgeloest".format(
            len(resolved), min(len(candidates), 25)), force=True)
        return resolved

    def search(self, query, category=None):
        return []  # kein dediziertes Such-API bekannt

    def resolve_stream(self, item_id):
        # item_id = numerische Player-ID
        try:
            html = self._fetch("/player-embed/id/{}/".format(item_id))
        except requests.RequestException:
            return None
        match = _SOURCE_RE.search(html)
        return match.group(1) if match else None

    def _get_detail_item(self, candidate, category):
        url, title = candidate
        try:
            resp = requests.get(url, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
            resp.raise_for_status()
        except requests.RequestException:
            return None
        html = resp.text

        id_match = _IFRAME_ID_RE.search(html)
        if not id_match:
            return None  # kein Player-Embed gefunden -> vermutlich keine Episodenseite
        player_id = id_match.group(1)

        title_match = _TITLE_RE.search(html)
        final_title = _clean(title_match.group(1)) if title_match else title

        return RetroItem(
            id=player_id,
            provider="lincon",
            category=category,
            title=final_title,
            language="en",
            source_page=url,
        )

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
