# -*- coding: utf-8 -*-
"""
Einheitliches Item-Datenmodell fuer alle Provider (siehe Konzept-Skizze).
Jeder Provider-Adapter liefert Listen von RetroItem zurueck, damit
Kategorie-Ansicht, Suche und Favoriten quellenunabhaengig arbeiten koennen.
"""


class RetroItem(object):
    __slots__ = (
        "id", "provider", "category", "title", "description",
        "year", "duration", "language", "genre", "thumb",
        "stream_url", "subtitle_url", "source_page",
    )

    def __init__(self, id, provider, category, title, description="",
                 year=None, duration=0, language="", genre=None,
                 thumb="", stream_url="", subtitle_url=None, source_page=""):
        self.id = id
        self.provider = provider
        self.category = category          # filme | serien | dokus | kids
        self.title = title
        self.description = description
        self.year = year
        self.duration = duration          # Sekunden
        self.language = language          # de | en | mixed
        self.genre = genre or []
        self.thumb = thumb
        self.stream_url = stream_url
        self.subtitle_url = subtitle_url
        self.source_page = source_page    # Original-URL, nur intern/Debug

    def to_dict(self):
        return {slot: getattr(self, slot) for slot in self.__slots__}


class ProviderBase(object):
    """Abstrakte Basisklasse. Jeder Provider-Adapter implementiert diese Methoden."""

    key = "base"           # muss zu settings_helper.PROVIDER_SETTING_IDS passen
    name = "Base Provider"

    def list_category(self, category, offset=0, size=50):
        """Liefert eine Liste von RetroItem fuer eine Hauptkategorie."""
        raise NotImplementedError

    def search(self, query, category=None):
        """Liefert eine Liste von RetroItem fuer eine Suchanfrage."""
        raise NotImplementedError

    def resolve_stream(self, item_id):
        """Loest ggf. erst beim Abspielen die finale Stream-URL auf
        (z.B. wenn der Provider keine dauerhaft gueltigen Direktlinks liefert)."""
        raise NotImplementedError
