# -*- coding: utf-8 -*-
"""
DocumentaryStorm.com Provider.
Kuratierte Doku-Sammlung (PBS, NOVA, National Geographic, National Film Board),
von Bibliotheken als Bildungsressource empfohlen. Videos laufen ueber
eingebettete YouTube/Vimeo-Player -> Video-ID extrahieren, Wiedergabe
ueber die jeweilige offizielle Plattform-Anbindung.
"""
import re

import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, resolve_parallel

BASE_URL = "https://www.documentarystorm.com"

_ITEM_RE = re.compile(r'<a href="(https://www\.documentarystorm\.com/[^"/]+/)"[^>]*>([^<]+)</a>', re.IGNORECASE)
_YT_EMBED_RE = re.compile(r'youtube\.com/embed/([A-Za-z0-9_\-]{11})')
_VIMEO_EMBED_RE = re.compile(r'player\.vimeo\.com/video/(\d+)')


class DocumentaryStormProvider(ProviderBase):
    key = "documentarystorm"
    name = "DocumentaryStorm.com"

    def list_category(self, category, offset=0, size=50):
        if category != "dokus":
            return []
        page = (offset // size) + 1 if size else 1
        html = self._fetch("/page/{}/".format(page))
        slugs = []
        for url, _title in _ITEM_RE.findall(html):
            slugs.append(url.rstrip("/").rsplit("/", 1)[-1])
        return resolve_parallel(slugs, self.get_detail_item, max_items=15)

    def search(self, query, category=None):
        html = self._fetch("/?s={}".format(requests.utils.quote(query)))
        slugs = []
        for url, _title in _ITEM_RE.findall(html):
            slugs.append(url.rstrip("/").rsplit("/", 1)[-1])
        return resolve_parallel(slugs, self.get_detail_item, max_items=15)

    def get_detail_item(self, slug):
        html = self._fetch("/{}/".format(slug))

        yt_match = _YT_EMBED_RE.search(html)
        if yt_match:
            video_id = yt_match.group(1)
            return RetroItem(
                id=slug,
                provider="documentarystorm",
                category="dokus",
                title=slug.replace("-", " ").title(),
                stream_url="plugin://plugin.video.youtube/play/?video_id={}".format(video_id),
                source_page="{}/{}/".format(BASE_URL, slug),
            )

        vimeo_match = _VIMEO_EMBED_RE.search(html)
        if vimeo_match:
            return RetroItem(
                id=slug,
                provider="documentarystorm",
                category="dokus",
                title=slug.replace("-", " ").title(),
                stream_url="https://player.vimeo.com/video/{}".format(vimeo_match.group(1)),
                source_page="{}/{}/".format(BASE_URL, slug),
            )
        return None

    def resolve_stream(self, item_id):
        item = self.get_detail_item(item_id)
        return item.stream_url if item else None

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
