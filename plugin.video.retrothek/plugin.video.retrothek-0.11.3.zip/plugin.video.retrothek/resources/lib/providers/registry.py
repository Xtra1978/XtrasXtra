# -*- coding: utf-8 -*-
"""
Zentrale Provider-Registry. Neue Quellen werden nur hier eingetragen,
der Rest des Addons iteriert generisch darueber.
"""
from ..settings_helper import is_provider_enabled
from .archive_org import ArchiveOrgProvider
from .publicdomainmovie import PublicDomainMovieProvider
from .publicdomainmovie_org import PublicDomainMovieOrgProvider
from .lincon import LincOnProvider
from .retroflix import RetroFlixProvider
from .reruncentury import RerunCenturyProvider
from .documentarystorm import DocumentaryStormProvider
from .mediathek import MediathekProvider
from .ardzdf_retro import ArdZdfRetroProvider
from .wikimedia import WikimediaProvider
from .british_council import BritishCouncilProvider
from .dhm_marshall import DhmMarshallProvider

_ALL_PROVIDERS = [
    ArchiveOrgProvider,
    PublicDomainMovieProvider,
    PublicDomainMovieOrgProvider,
    LincOnProvider,
    RetroFlixProvider,
    RerunCenturyProvider,
    DocumentaryStormProvider,
    MediathekProvider,
    ArdZdfRetroProvider,
    WikimediaProvider,
    BritishCouncilProvider,
    DhmMarshallProvider,
]


def get_active_providers():
    """Liefert nur die Provider-Instanzen, die in den Settings aktiviert sind."""
    return [cls() for cls in _ALL_PROVIDERS if is_provider_enabled(cls.key)]


def get_provider_by_key(key):
    for cls in _ALL_PROVIDERS:
        if cls.key == key:
            return cls()
    return None
