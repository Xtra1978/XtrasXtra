# -*- coding: utf-8 -*-
"""
ARD/ZDF Retro Provider.

Teile dieser Anbindung basieren mit freundlicher Genehmigung von rols1
(https://github.com/rols1/Kodi-Addon-ARDundZDF, MIT-Lizenz) auf dessen
ARDundZDF-Addon. Siehe Addon-Beschreibung in addon.xml fuer die
Namensnennung.

Endpunkt siehe ARD_RETRO_URL. Fuer ZDF-Inhalte bisher kein Endpunkt
bekannt, daher ZDF-Parameter entbehrlich (ZDF GraphQL, ZDF Auth-Header-
Schema).
ARD_ITEM_URL entfaellt - den Link zu allen Streamquellen ermitteln wir
in teaser.links.target.href(). Den abspielbaren HLS-Link ermitteln wir
darueber in resolve_stream(). Vorerst verzichten wir auf MP4-Formate
und DGS.

In den ARD-Daten koennen redakt. Inhalte und Verweise auf weitere
Rubriken enthalten sein (Teaser ohne duration). Diese filtern wir in
list_category() aus.

Bilder: fuer die dynamischen Image-URLs wurde die Breite 640
voreingestellt (IMG_WIDTH).

STAND (rols1, 29.07.): Es gibt zusaetzliche ARD-Retro-Rubriken
(ARD_URL_CODES/ARD_BASE unten), die sich einzeln abfragen liessen.
Nach Dublettenpruefung durch rols1 zeigte sich aber: diese Rubriken
enthalten KEINE zusaetzlichen Datensaetze gegenueber ARD_RETRO_URL
allein - komplett redundant. Daher bewusst NICHT aktiv abgefragt
(ARD_RETRO_MORE = False), das wuerde nur unnoetige Ladezeit kosten.
Bleibt als Code-Geruest erhalten, falls sich das kuenftig aendert.
"""
import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, safe_int, log

# --- ARD Retro (verifizierte Endpunkte) ----------------------------------
ARD_RETRO_URL = "https://api.ardmediathek.de/page-gateway/pages/ard/editorial/retro?embedded=true"
ARD_BASE = "https://api.ardmediathek.de/page-gateway/widgets/ard/editorials"

# Per rols1 bestaetigt redundant zu ARD_RETRO_URL - siehe Docstring oben.
# Bewusst deaktiviert, Struktur bleibt fuer spaeter erhalten.
ARD_RETRO_MORE = False
ARD_URL_CODES = [
    "3GLSO7b0N5QkIN7wxbg2do%3A858855822693185035|Stars aus Film, Fernsehen und Politik",
    "3GLSO7b0N5QkIN7wxbg2do%3A-8622720540877810766|Italien-Sehnsucht in den 60er Jahren",
    "3GLSO7b0N5QkIN7wxbg2do%3A1899640390985812580|Widerstand gegen Hitler",
    "3GLSO7b0N5QkIN7wxbg2do%3A-1577926472130422468|Die Welt der Neugeborenen damals",
    "3GLSO7b0N5QkIN7wxbg2do%3A-6804529260661937364|Aktuelle Empfehlungen",
    "3GLSO7b0N5QkIN7wxbg2do%3A4709596239009347831|Die angesagtesten Oldtimer",
    "3GLSO7b0N5QkIN7wxbg2do%3A-6926974871919066903|Damals im Juli",
    "3GLSO7b0N5QkIN7wxbg2do%3A7476319703132734984|Die schoensten Schloesser und Burgen",
    "3GLSO7b0N5QkIN7wxbg2do%3A6385825968551082171|Meistgesehen",
]
ARD_URL_ADD = "pageNumber=0&pageSize=100"

IMG_WIDTH = "640"


class ArdZdfRetroProvider(ProviderBase):
    key = "ardzdf_retro"
    name = "ARD/ZDF Retro"

    def list_category(self, category, offset=0, size=50):
        if category not in ("serien", "filme"):
            return []

        urls = [(ARD_RETRO_URL, "Retro-Basis")]
        if ARD_RETRO_MORE:
            for url_code in ARD_URL_CODES:
                code, title = url_code.split("|")
                url = "{}/{}?{}".format(ARD_BASE, code, ARD_URL_ADD)
                urls.append((url, title))

        items = []
        seen_ids = set()  # Dubletten-Filter (siehe rols1s Hitler-Fund)
        removed_no_duration = 0

        for url, title in urls:
            try:
                resp = requests.get(url, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
                resp.raise_for_status()
                data = resp.json()
            except (requests.RequestException, ValueError) as exc:
                log("ardzdf_retro: Abruf {} fehlgeschlagen: {}".format(title, exc))
                continue

            widgets = data.get("widgets", [])
            if widgets:
                teasers = []
                for widget in widgets:
                    teasers.extend(widget.get("teasers", []))
            else:
                teasers = data.get("teasers", [])

            for teaser in teasers:
                if not teaser.get("duration"):  # Beitraege ohne Video ausfiltern
                    removed_no_duration += 1
                    continue
                item = self._teaser_to_item(teaser, title, category)
                if item.id in seen_ids:
                    continue  # Dublette (z.B. derselbe Beitrag in mehreren Rubriken)
                seen_ids.add(item.id)
                items.append(item)

        log("ardzdf_retro: {} Treffer insgesamt, {} ohne duration entfernt".format(
            len(items), removed_no_duration))
        return items[offset:offset + size]

    def search(self, query, category=None):
        # ARD page-gateway hat keinen dedizierten Such-Endpunkt in der
        # uebernommenen Referenz -> vorerst nur ueber die Retro-Rubrik
        # selbst durchsuchbar (clientseitige Titel-Filterung).
        items = self.list_category(category or "serien", size=200)
        query_lower = query.lower()
        return [i for i in items if query_lower in (i.title or "").lower()]

    def resolve_stream(self, item_id):
        # item_id aus _teaser_to_item: Link zu allen Streamquellen
        try:
            resp = requests.get(item_id, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
            resp.raise_for_status()
            data = resp.json()
            stream_array = data["widgets"][0]["mediaCollection"]["embedded"]["streams"][0]["media"]
            stream_url = ""
            for item in stream_array:  # vorerst ermitteln wir nur die master.m3u8 (MP4 bei Bedarf)
                if "mpegurl" in item["mimeType"]:
                    stream_url = item["url"]
                    break
            return stream_url
        except (requests.RequestException, ValueError, KeyError, IndexError, TypeError) as exc:
            log("ardzdf_retro: resolve_stream fehlgeschlagen: {}".format(exc))
            return None

    def _teaser_to_item(self, teaser, title, category):
        links = teaser.get("links", {}) or {}
        target = links.get("target", {}) or {}
        href = target.get("href", "") or ""  # komplette URL in teaser.links.target.href

        dur = safe_int(teaser.get("duration"))
        dauer = "Dauer: {}".format(self._seconds_translate(dur)) if dur else ""

        descr = target.get("description", "") or ""
        if not descr and "show" in teaser:  # diverse Varianten fuer description
            show = teaser.get("show", {}) or {}
            descr = show.get("longSynopsis", "") or ""
        if dauer:
            descr = "[B]{}[/B] | {}".format(dauer, descr)
        descr = "{} | Rubrik: [B]{}[/B]".format(descr, title)

        img = (teaser.get("images", {}) or {}).get("aspect16x9", {}).get("src", "")
        img = img.replace("{width}", IMG_WIDTH)  # dynamische Image-URL mit beliebiger Breite

        return RetroItem(
            id=href,
            provider="ardzdf_retro",
            category=category,
            title=_clean(teaser.get("longTitle") or teaser.get("title", "")),
            description=_clean(descr),
            duration=dur,
            language="de",
            thumb=img,
        )

    def _seconds_translate(self, seconds):
        try:
            seconds = int(seconds)
        except (TypeError, ValueError) as exc:
            log("ardzdf_retro: seconds_translate Fehler: {}".format(exc))
            return ""

        if seconds < 60:
            return "{} Sek.".format(seconds)

        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        return "{:02d}:{:02d}:{:02d} Std.".format(hours, minutes, secs)
