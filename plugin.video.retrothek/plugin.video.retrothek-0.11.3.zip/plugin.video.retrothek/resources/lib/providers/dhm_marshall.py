# -*- coding: utf-8 -*-
"""
DHM Zeughauskino Provider - Filme des Marshall-Plans.
Offizielle Reihe des Deutschen Historischen Museums, kostenlos online
gestellt. Videos laufen ueber einen Plyr-Player mit Vimeo-Embed
(bestaetigt per HAR-Mitschnitt: data-plyr-embed-id enthaelt die
Vimeo-Player-URL).
"""
import re

import requests

from .base import ProviderBase, RetroItem
from .vimeo_utils import resolve_vimeo
from ..utils import _clean, resolve_parallel

BASE_URL = "https://www.dhm.de"
SERIES_INDEX = "/zeughauskino/filmreihen/online-filmreihen/filme-des-marshall-plans/"

_LINK_RE = re.compile(
    r'href="(/zeughauskino/filmreihen/online-filmreihen/filme-des-marshall-plans/[a-z0-9\-]+/)"'
)
_VIMEO_RE = re.compile(r'data-plyr-embed-id="https://player\.vimeo\.com/video/(\d+)')
_TITLE_RE = re.compile(r'<h1>\s*([^<]+?)\s*</h1>', re.DOTALL)
_DESC_RE = re.compile(r'name="description" content="([^"]+)"')


class DhmMarshallProvider(ProviderBase):
    key = "dhm_marshall"
    name = "DHM Zeughauskino (Marshall-Plan)"

    def list_category(self, category, offset=0, size=50):
        if category != "dokus":
            return []
        html = self._fetch(SERIES_INDEX)
        slugs = sorted(set(
            m.rstrip("/").rsplit("/", 1)[-1] for m in _LINK_RE.findall(html)
        ))
        return resolve_parallel(slugs, self._get_detail_item, max_items=25)

    def search(self, query, category=None):
        if category and category != "dokus":
            return []  # dieser Anbieter hat ausschliesslich Dokus-Inhalte
        items = self.list_category("dokus", size=200)
        query_lower = query.lower()
        return [i for i in items if query_lower in (i.title or "").lower()]

    def resolve_stream(self, item_id):
        return resolve_vimeo(item_id)

    def _get_detail_item(self, slug):
        path = "{}{}/".format(SERIES_INDEX, slug)
        html = self._fetch(path)

        vimeo_match = _VIMEO_RE.search(html)
        if not vimeo_match:
            return None  # kein Vimeo-Embed gefunden -> Titel ueberspringen
        video_id = vimeo_match.group(1)

        title_match = _TITLE_RE.search(html)
        desc_match = _DESC_RE.search(html)

        return RetroItem(
            id=video_id,
            provider="dhm_marshall",
            category="dokus",
            title=_clean(title_match.group(1)) if title_match else slug.replace("-", " ").title(),
            description=_clean(desc_match.group(1)) if desc_match else "",
            language="de",
            source_page=BASE_URL + path,
        )

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
