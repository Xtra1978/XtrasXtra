# -*- coding: utf-8 -*-
"""
RerunCentury.com Provider - reiner Serien-Fokus (klassisches US-TV 40er-70er).
Videos liegen bei Internet Archive, RerunCentury liefert nur die
bereits genre-sortierte Zuordnung Serie -> Archive-Identifier.
"""
import re

import requests

from .base import ProviderBase, RetroItem
from .archive_org import DOWNLOAD_BASE
from ..utils import _clean, safe_int, log

BASE_URL = "https://www.reruncentury.com"

_SERIES_RE = re.compile(r'<a href="(/ia/series/[^"]+)"[^>]*>([^<]+)</a>', re.IGNORECASE)
_EPISODE_RE = re.compile(
    r"<img src='https://archive\.org/download/([^/']+)/[^']*'><br><b>([^<]+)</b>"
)
_GENRE_PAGES = [
    "Comedy_Variety", "Situation_Comedy", "Crime_and_Detective",
    "Dramatic_Anthology", "Game_Show", "Adventure_Series",
    "Science_Fiction_Anthology", "Non-Fiction", "Reality", "Music_and_Variety",
]


class RerunCenturyProvider(ProviderBase):
    key = "reruncentury"
    name = "RerunCentury.com"

    def list_category(self, category, offset=0, size=50):
        if category != "serien":
            return []
        items = []
        for genre_slug in _GENRE_PAGES:
            try:
                html = self._fetch("/ia/genre/{}/".format(genre_slug))
            except requests.RequestException as exc:
                log("reruncentury: Abruf {} fehlgeschlagen: {}".format(genre_slug, exc), force=True)
                continue
            found = _EPISODE_RE.findall(html)
            log("reruncentury: {} -> {} Treffer (html-laenge {})".format(genre_slug, len(found), len(html)), force=True)
            for identifier, title in found:
                items.append(self._to_item(identifier, title, genre_slug))
        return items

    def search(self, query, category=None):
        html = self._fetch("/?s={}".format(requests.utils.quote(query)))
        items = []
        for identifier, title in _EPISODE_RE.findall(html):
            items.append(self._to_item(identifier, title, genre=None))
        return items

    def resolve_stream(self, item_id):
        # item_id ist bereits der Archive.org-Identifier -> Metadaten dort abfragen
        from .archive_org import ArchiveOrgProvider
        return ArchiveOrgProvider().resolve_stream(item_id)

    def _to_item(self, identifier, title, genre):
        return RetroItem(
            id=identifier,
            provider="reruncentury",
            category="serien",
            title=_clean(title),
            genre=[genre] if genre else [],
            thumb="https://archive.org/services/img/{}".format(identifier),
            source_page="https://archive.org/details/{}".format(identifier),
        )

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
