# -*- coding: utf-8 -*-
"""
British Council Film Archive Provider.
Ueber 100 Kurzdokumentationen aus den 1940ern, explizit als "rights-free"
deklariert, CC BY-NC lizenziert. Videos laufen als Vimeo-Embeds direkt
auf der jeweiligen Filmseite (bestaetigt per HAR-Mitschnitt).
"""
import json
import re

import requests

from .base import ProviderBase, RetroItem
from .vimeo_utils import resolve_vimeo
from ..utils import _clean, resolve_parallel, log

BASE_URL = "https://film.britishcouncil.org"
ARCHIVE_INDEX = "/resources/film-archive"

_LINK_RE = re.compile(r'href="(/resources/film-archive/[a-z0-9\-]+)"')
_EXCLUDED_SLUGS = {"about", "how-to-use"}  # Infoseiten, keine Filme (per HTML-Analyse bestaetigt)
_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.DOTALL)
_VIMEO_SRC_RE = re.compile(r'"src":"https://player\.vimeo\.com/video/(\d+)"')


class BritishCouncilProvider(ProviderBase):
    key = "british_council"
    name = "British Council Film Archive"

    def list_category(self, category, offset=0, size=50):
        if category != "dokus":
            return []
        html = self._fetch(ARCHIVE_INDEX)
        slugs = sorted(set(
            m.replace("/resources/film-archive/", "")
            for m in _LINK_RE.findall(html)
        ) - _EXCLUDED_SLUGS)
        log("british_council: Index -> {} Slugs gefunden (html-laenge {})".format(len(slugs), len(html)), force=True)
        resolved = resolve_parallel(slugs, self._get_detail_item, max_items=25)
        log("british_council: {} von {} Slugs erfolgreich aufgeloest".format(len(resolved), min(len(slugs), 25)), force=True)
        return resolved

    def search(self, query, category=None):
        if category and category != "dokus":
            return []  # dieser Anbieter hat ausschliesslich Dokus-Inhalte
        # Kein dediziertes Such-API bekannt -> Kategorie-Ergebnisse client-seitig filtern
        items = self.list_category("dokus", size=200)
        query_lower = query.lower()
        return [i for i in items if query_lower in (i.title or "").lower()]

    def resolve_stream(self, item_id):
        return resolve_vimeo(item_id)

    def _get_detail_item(self, slug):
        html = self._fetch("{}/{}".format(ARCHIVE_INDEX, slug))

        vimeo_match = _VIMEO_SRC_RE.search(html)
        if not vimeo_match:
            return None  # kein Vimeo-Embed gefunden -> Titel ueberspringen
        video_id = vimeo_match.group(1)

        next_data_match = _NEXT_DATA_RE.search(html)
        title = slug.replace("-", " ").title()
        description = ""
        if next_data_match:
            try:
                data = json.loads(next_data_match.group(1))
                page = data.get("props", {}).get("pageProps", {}).get("page", {})
                title = page.get("title") or title
                description = page.get("description") or ""
            except (ValueError, AttributeError):
                pass

        return RetroItem(
            id=video_id,
            provider="british_council",
            category="dokus",
            title=_clean(title),
            description=_clean(description),
            language="en",
            source_page="{}{}/{}".format(BASE_URL, ARCHIVE_INDEX, slug),
        )

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
