# -*- coding: utf-8 -*-
"""
Wikimedia Commons Provider.
Duenne, aber sauber lizenzierte PD-Filmauswahl (meist US-Klassiker).
Nutzt die offizielle MediaWiki-API mit Kategorie-Abfrage.
"""
import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, log

API_URL = "https://commons.wikimedia.org/w/api.php"

CATEGORY_MAP = {
    # "Public_domain_films" (urspruengliche Annahme) existiert nicht bzw.
    # enthaelt nur Bilder ueber Filme, keine Videos selbst. Echte,
    # bestaetigte Kategorie mit tatsaechlichen Videodateien:
    "filme": "Videos_of_films_in_the_public_domain",
    # Keine bestaetigte eigene Kategorie fuer Kids/Zeichentrick gefunden -
    # bewusst weggelassen statt zu raten, bis das verifiziert ist.
}


class WikimediaProvider(ProviderBase):
    key = "wikimedia"
    name = "Wikimedia Commons"

    def list_category(self, category, offset=0, size=50):
        commons_cat = CATEGORY_MAP.get(category)
        if not commons_cat:
            return []
        params = {
            "action": "query",
            "list": "categorymembers",
            "cmtitle": "Category:{}".format(commons_cat),
            "cmtype": "file",
            "cmlimit": size,
            "format": "json",
        }
        resp = requests.get(API_URL, params=params, timeout=15,
                             headers={"User-Agent": "Retrothek-Kodi-Addon/0.6 (https://github.com/xtra78/plugin.video.retrothek)"})
        resp.raise_for_status()
        data = resp.json()
        members = data.get("query", {}).get("categorymembers", [])
        log("wikimedia: Category:{} -> status {}, {} Treffer, error={}".format(
            commons_cat, resp.status_code, len(members), data.get("error")), force=True)
        return [self._to_item(m, category) for m in members]

    def search(self, query, category=None):
        params = {
            "action": "query",
            "list": "search",
            "srsearch": "{} filetype:video".format(query),
            "srnamespace": 6,  # File-Namespace
            "format": "json",
        }
        resp = requests.get(API_URL, params=params, timeout=15,
                             headers={"User-Agent": "Retrothek-Kodi-Addon/0.6 (https://github.com/xtra78/plugin.video.retrothek)"})
        resp.raise_for_status()
        results = resp.json().get("query", {}).get("search", [])
        return [self._to_item(r, category=None) for r in results]

    def resolve_stream(self, item_id):
        params = {
            "action": "query",
            "titles": item_id,
            "prop": "imageinfo",
            "iiprop": "url",
            "format": "json",
        }
        resp = requests.get(API_URL, params=params, timeout=15,
                             headers={"User-Agent": "Retrothek-Kodi-Addon/0.6 (https://github.com/xtra78/plugin.video.retrothek)"})
        resp.raise_for_status()
        pages = resp.json().get("query", {}).get("pages", {})
        for page in pages.values():
            imageinfo = page.get("imageinfo")
            if imageinfo:
                return imageinfo[0].get("url")
        return None

    @staticmethod
    def _to_item(member, category):
        title = member.get("title", "")
        return RetroItem(
            id=title,
            provider="wikimedia",
            category=category or "filme",
            title=_clean(title.replace("File:", "")),
            source_page="https://commons.wikimedia.org/wiki/{}".format(title.replace(" ", "_")),
        )
