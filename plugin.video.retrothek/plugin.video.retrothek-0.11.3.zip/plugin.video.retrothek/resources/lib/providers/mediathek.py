# -*- coding: utf-8 -*-
"""
MediathekViewWeb-API Provider (ARD, ZDF, ARTE, 3sat, WDR, MDR, SWR, BR,
KiKA, ZDFtivi, ORF, SRF u.a.). Kein Auth noetig, direkte Stream-URLs.

Kein natives Genre/Typ-Feld -> Kategorisierung ueber Topic-Keywords,
Sender-Whitelist (Kids) und Mindestdauer (Filme), siehe mapping.py-Diskussion.

Wichtig: sortBy unterstuetzt KEIN "title" -> fuer eine echte A-Z-Ansicht
muss die komplette Trefferliste geholt und lokal sortiert werden
(siehe cache.py).
"""
import json

import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, safe_int

API_URL = "https://mediathekviewweb.de/api/query"

KIDS_CHANNELS = ("KiKA", "ZDFtivi", "SRF Kids")

FILM_KEYWORDS = ("spielfilm", "film der woche", "filmreihe")
DOKU_KEYWORDS = ("dokumentation", "doku", "reportage")
SERIE_KEYWORDS = ("serie", "folge")


class MediathekProvider(ProviderBase):
    key = "mediathek"
    name = "MediathekViewWeb"

    def _query(self, fields, offset=0, size=50, sort_by="timestamp", duration_min=None):
        body = {
            "queries": [{"fields": ["title", "topic"], "query": q} for q in fields] or [{"fields": ["title"], "query": ""}],
            "sortBy": sort_by,
            "sortOrder": "desc",
            "future": False,
            "offset": offset,
            "size": size,
        }
        if duration_min:
            body["duration_min"] = duration_min

        resp = requests.post(API_URL, data=json.dumps(body), timeout=15,
                              headers={"Content-Type": "application/json"})
        resp.raise_for_status()
        return resp.json().get("result", {}).get("results", [])

    def list_category(self, category, offset=0, size=50):
        if category == "kids":
            results = self._query_by_channels(KIDS_CHANNELS, offset, size)
        elif category == "filme":
            results = self._query(list(FILM_KEYWORDS), offset, size, duration_min=4200)  # >70min
        elif category == "dokus":
            results = self._query(list(DOKU_KEYWORDS), offset, size)
        elif category == "serien":
            results = self._query(list(SERIE_KEYWORDS), offset, size)
        else:
            results = []
        return [self._to_item(r, category) for r in results]

    def search(self, query, category=None):
        results = self._query([query], size=50, sort_by="channel")
        return [self._to_item(r, category=None) for r in results]

    def resolve_stream(self, item_id):
        # item_id enthaelt bereits die finale Stream-URL (siehe _to_item) -> kein extra Call noetig
        return item_id

    def _query_by_channels(self, channels, offset, size):
        results = []
        for channel in channels:
            body = {
                "queries": [{"fields": ["channel"], "query": channel}],
                "sortBy": "timestamp",
                "sortOrder": "desc",
                "offset": offset,
                "size": size,
            }
            resp = requests.post(API_URL, data=json.dumps(body), timeout=15,
                                  headers={"Content-Type": "application/json"})
            resp.raise_for_status()
            results.extend(resp.json().get("result", {}).get("results", []))
        return results

    @staticmethod
    def _to_item(result, category):
        stream_url = result.get("url_video_hd") or result.get("url_video") or ""
        return RetroItem(
            id=stream_url,
            provider="mediathek",
            category=category or "dokus",
            title=_clean(result.get("title", "")),
            description=_clean(result.get("description", "")),
            duration=safe_int(result.get("duration")),
            language="de",
            thumb="",  # MediathekViewWeb liefert i.d.R. keine Thumbnails
            stream_url=stream_url,
            subtitle_url=result.get("url_subtitle") or None,
            source_page=result.get("url_website", ""),
        )
