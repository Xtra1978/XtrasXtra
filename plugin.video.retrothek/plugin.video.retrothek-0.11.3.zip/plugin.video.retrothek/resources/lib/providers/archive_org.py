# -*- coding: utf-8 -*-
"""
Internet Archive Provider.
Nutzt die offizielle, dokumentierte Advanced-Search-API von archive.org.
Kein Auth, keine Rate-Limit-Ueberraschungen, Embedding ausdruecklich erwuenscht.
https://archive.org/advancedsearch.php
"""
import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, safe_int

SEARCH_URL = "https://archive.org/advancedsearch.php"
METADATA_URL = "https://archive.org/metadata/{identifier}"
DOWNLOAD_BASE = "https://archive.org/download/{identifier}/{filename}"

# Kuratierte Collections pro Hauptkategorie. Bewusst kein reines
# Text-Keyword-Matching (zu fehleranfaellig), sondern feste,
# stabile Collection-IDs, die Archive.org selbst pflegt.
COLLECTION_MAP = {
    "filme": ["feature_films", "classic_tv_movies"],
    "serien": ["classic_tv"],
    "dokus": ["documentary_films", "prelinger"],
    "kids": ["cartoons", "classic_cartoons"],
}


def _as_scalar(value):
    """Archive.org liefert manche Felder je nach Item als Liste statt
    als Einzelwert zurueck (Solr-Eigenheit, betrifft nicht nur 'year',
    sondern auch 'title', 'description', 'language')."""
    if isinstance(value, (list, tuple)):
        return value[0] if value else ""
    return value or ""


class ArchiveOrgProvider(ProviderBase):
    key = "archive_org"
    name = "Internet Archive"

    def _query(self, collection, offset=0, size=50, extra_query=""):
        query = 'collection:({}) AND mediatype:(movies)'.format(collection)
        if extra_query:
            query += " AND {}".format(extra_query)

        params = {
            "q": query,
            "fl[]": ["identifier", "title", "description", "year", "date", "runtime", "language"],
            "rows": size,
            "start": offset,
            "output": "json",
        }
        resp = requests.get(SEARCH_URL, params=params, timeout=15)
        resp.raise_for_status()
        return resp.json().get("response", {}).get("docs", [])

    def list_category(self, category, offset=0, size=50):
        collections = COLLECTION_MAP.get(category, [])
        items = []
        for collection in collections:
            docs = self._query(collection, offset=offset, size=size)
            for doc in docs:
                items.append(self._doc_to_item(doc, category))
        return items

    def search(self, query, category=None):
        items = []
        for category, collections in COLLECTION_MAP.items():
            for collection in collections:
                docs = self._query(
                    collection,
                    size=25,
                    extra_query='title:({})'.format(query),
                )
                for doc in docs:
                    items.append(self._doc_to_item(doc, category))
        return items

    def resolve_stream(self, item_id):
        """Item_id = Archive-Identifier. Holt die passende MP4-Datei aus den Metadaten.
        Bevorzugt bekannte Streaming-Ableitungen (z.B. '_512kb.mp4', h.264-Format-Angabe),
        da die schlicht groesste Datei oft ein unkomprimiertes Master-File ist, das sich
        nicht zuverlaessig direkt streamen laesst (siehe Praxis-Feedback: manche Titel
        spielten, andere nicht - genau dieses Muster)."""
        resp = requests.get(METADATA_URL.format(identifier=item_id), timeout=15)
        resp.raise_for_status()
        data = resp.json()
        files = data.get("files", [])

        mp4_files = [f for f in files if f.get("name", "").lower().endswith(".mp4")]
        if not mp4_files:
            return None

        # 1. Bevorzugt: bekannte Streaming-Ableitung am Dateinamen erkennen
        for suffix in ("_512kb.mp4", "_256kb.mp4"):
            for f in mp4_files:
                if f.get("name", "").lower().endswith(suffix):
                    return DOWNLOAD_BASE.format(identifier=item_id, filename=f["name"])

        # 2. Bevorzugt: Format-Metadatenfeld nennt eine bekannte Streaming-Ableitung
        streaming_formats = ("512kb mpeg4", "h.264", "mpeg4")
        candidates = [f for f in mp4_files if any(
            fmt in (f.get("format", "") or "").lower() for fmt in streaming_formats
        )]
        if candidates:
            best = min(candidates, key=lambda f: safe_int(f.get("size", 0)) or float("inf"))
            return DOWNLOAD_BASE.format(identifier=item_id, filename=best["name"])

        # 3. Fallback: kleinste MP4-Datei statt groesster (Master-Files sind meist die groessten
        # und am ehesten fuer direktes Streaming ungeeignet)
        best = min(mp4_files, key=lambda f: safe_int(f.get("size", 0)) or float("inf"))
        return DOWNLOAD_BASE.format(identifier=item_id, filename=best["name"])

    @staticmethod
    def _doc_to_item(doc, category):
        identifier = doc.get("identifier", "")
        year = safe_int(doc.get("year")) or None
        if not year:
            date_value = doc.get("date")
            if isinstance(date_value, (list, tuple)):
                date_value = date_value[0] if date_value else None
            if date_value and len(str(date_value)) >= 4:
                year = safe_int(str(date_value)[:4]) or None

        return RetroItem(
            id=identifier,
            provider="archive_org",
            category=category,
            title=_as_scalar(doc.get("title", identifier)) or identifier,
            description=_clean(_as_scalar(doc.get("description", ""))),
            year=year,
            duration=0,  # Runtime-Format bei Archive uneinheitlich, ggf. beim Resolve nachladen
            language=_as_scalar(doc.get("language", "")),
            thumb="https://archive.org/services/img/{}".format(identifier),
            stream_url="",  # wird erst bei resolve_stream() aufgeloest
            source_page="https://archive.org/details/{}".format(identifier),
        )
