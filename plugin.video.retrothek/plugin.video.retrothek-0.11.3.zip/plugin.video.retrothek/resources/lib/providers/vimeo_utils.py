# -*- coding: utf-8 -*-
"""
Gemeinsamer Vimeo-Resolver, genutzt von britishcouncil.py und
dhm_marshall.py - beide Quellen betten ihre Filme als normale
Vimeo-Player ein (kein Custom-Protokoll wie bei Rakuten/Popcorntimes).
"""
import json
import re

import requests

_CONFIG_RE = re.compile(r'"progressive":(\[.*?\])', re.DOTALL)
_PLAYER_URL = "https://player.vimeo.com/video/{video_id}"


def resolve_vimeo(video_id):
    """Holt die Vimeo-Player-Seite und extrahiert die beste progressive
    MP4-URL aus der eingebetteten Config. Kein offizielles API noetig,
    das ist dasselbe Prinzip wie bei vielen anderen Vimeo-Embeds."""
    try:
        resp = requests.get(_PLAYER_URL.format(video_id=video_id), timeout=15,
                             headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
    except requests.RequestException:
        return None

    match = _CONFIG_RE.search(resp.text)
    if not match:
        return None

    try:
        progressive = json.loads(match.group(1))
    except ValueError:
        return None

    if not progressive:
        return None

    # Beste verfuegbare Qualitaet (hoechste Aufloesung) waehlen
    best = max(progressive, key=lambda p: p.get("width", 0))
    return best.get("url")
