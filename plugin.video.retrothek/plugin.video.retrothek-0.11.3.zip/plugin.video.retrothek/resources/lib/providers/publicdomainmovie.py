# -*- coding: utf-8 -*-
"""
publicdomainmovie.net Provider.
CC-Zero lizenziert, quillt aus Internet Archive, bereits sauber nach
Genre kategorisiert (Comedy, Drama & Romance, Sci-Fi & Horror, Cartoons).
Kein JSON-API vorhanden -> HTML-Scraping der Kategorie-/Detailseiten.
"""
import re

import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, safe_int, log

BASE_URL = "https://publicdomainmovie.net"

# publicdomainmovie.net-eigene Kategorie-Pfade -> unsere Hauptkategorien.
# WICHTIG: kein "/category/"-Praefix (fruehere Annahme war falsch),
# echte Pfade aus HAR-Mitschnitt vom 28.07. bestaetigt. Dokus-Kategorie
# war im mitgeschnittenen Klickpfad nicht dabei, daher bewusst weggelassen
# statt zu raten.
CATEGORY_MAP = {
    "filme": ["feature_movies", "drama_and_romance", "science_fiction_and_horror", "comedy_movies"],
    "kids": ["cartoons"],
}

_LINK_RE = re.compile(r'<a[^>]+href="/movie/([^"]+)"[^>]*>(.*?)</a>', re.IGNORECASE | re.DOTALL)
_DOWNLOAD_RE = re.compile(r'href="(https?://[^"]+\.mp4[^"]*)"', re.IGNORECASE)
_YEAR_RE = re.compile(r'Year:\s*<[^>]*>?\s*(\d{4})', re.IGNORECASE)
_GENRE_RE = re.compile(r'/genre/([a-z0-9\-]+)/?"[^>]*>([^<]+)</a>', re.IGNORECASE)
_DESC_RE = re.compile(r'<div[^>]+class="[^"]*field-name-body[^"]*"[^>]*>(.*?)</div>', re.IGNORECASE | re.DOTALL)


class PublicDomainMovieProvider(ProviderBase):
    key = "publicdomainmovie"
    name = "publicdomainmovie.net"

    def list_category(self, category, offset=0, size=50):
        slugs = CATEGORY_MAP.get(category, [])
        items = []
        page = offset // size if size else 0
        for slug in slugs:
            path = "/{}".format(slug) if page == 0 else "/{}?page={}".format(slug, page)
            try:
                html = self._fetch(path)
            except requests.RequestException as exc:
                log("publicdomainmovie: Abruf {} fehlgeschlagen: {}".format(path, exc), force=True)
                continue
            found = self._parse_listing(html, category)
            log("publicdomainmovie: {} -> {} Treffer (html-laenge {})".format(path, len(found), len(html)), force=True)
            items.extend(found)
        return items

    def search(self, query, category=None):
        html = self._fetch("/search/node/{}".format(requests.utils.quote(query)))
        return self._parse_listing(html, category)

    def resolve_stream(self, item_id):
        html = self._fetch("/movie/{}".format(item_id))
        match = _DOWNLOAD_RE.search(html)
        return match.group(1) if match else None

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text

    def _parse_listing(self, html, category):
        items = []
        for slug, title_html in _LINK_RE.findall(html):
            title = _clean(title_html)
            if not title:
                continue
            items.append(RetroItem(
                id=slug,
                provider="publicdomainmovie",
                category=category or "filme",
                title=title,
                thumb="",  # Thumb wird ueber Detailseite nachgeladen (Performance-Tradeoff)
                source_page="{}/movie/{}".format(BASE_URL, slug),
            ))
        return items

    def get_detail(self, item_id):
        """Ergaenzende Detailinfos (Jahr, Genre, Beschreibung) fuer die Infoscreen-Ansicht."""
        html = self._fetch("/movie/{}".format(item_id))
        year_match = _YEAR_RE.search(html)
        desc_match = _DESC_RE.search(html)
        genres = [g[1] for g in _GENRE_RE.findall(html)]
        return {
            "year": safe_int(year_match.group(1)) if year_match else None,
            "description": _clean(desc_match.group(1)) if desc_match else "",
            "genre": genres,
        }
