# -*- coding: utf-8 -*-
"""
RetroFlix.org Provider.
Reines PD-Archiv (Movies/Cartoons/Documentaries/Anime), verlinkt aber
teils auf YouTube statt auf direkt gehostete Dateien (z.B. Archive.org).
Wichtig laut Absprache: YouTube-basierte Eintraege werden konsequent
NICHT uebernommen, nur Titel mit direktem Stream-Host (Archive.org etc.).
"""
import re

import requests

from .base import ProviderBase, RetroItem
from ..utils import _clean, safe_int, resolve_parallel

BASE_URL = "https://retroflix.org"

CATEGORY_MAP = {
    "filme": "movies",
    "kids": "cartoons",
    "dokus": None,  # laeuft ueber /genre/documentary/, siehe list_category
}

# Alles, was auf YouTube zeigt, wird ausgeschlossen (siehe Absprache).
_YOUTUBE_HOSTS = ("youtube.com", "youtu.be")

_ITEM_RE = re.compile(r'<a href="(?:https://retroflix\.org)?(/watch/[^"]+)"[^>]*>\s*([^<]+?)\s*</a>', re.IGNORECASE)
_DIRECT_URL_RE = re.compile(r'(?:href|src)="(https?://(?:archive\.org|[^"]+\.(?:mp4|m3u8))[^"]*)"', re.IGNORECASE)
_YEAR_RE = re.compile(r'/year-released/(\d{4})/')
_GENRE_RE = re.compile(r'/genre/([a-z0-9\-]+)/">([^<]+)</a>')
_LANGUAGE_RE = re.compile(r'/language/([a-z\-]+)/">([^<]+)</a>')
_DESC_RE = re.compile(r'name="description" content="([^"]+)"')


class RetroFlixProvider(ProviderBase):
    key = "retroflix"
    name = "RetroFlix.org"

    def list_category(self, category, offset=0, size=50):
        candidates = self._list_candidates(category, offset, size)
        return resolve_parallel(
            candidates,
            lambda c: self.get_detail_item(c[0], category),
            max_items=15,
        )

    def _list_candidates(self, category, offset=0, size=50):
        if category not in CATEGORY_MAP and category != "dokus":
            return []  # RetroFlix bietet z.B. keine Serien an

        page = (offset // size) + 1 if size else 1
        slug = CATEGORY_MAP.get(category)
        if category == "dokus":
            path = "/genre/documentary/page/{}/".format(page)
        else:
            path = "/browse/{}/page/{}/".format(slug, page)

        html = self._fetch(path)
        entries = []
        for watch_path, title in _ITEM_RE.findall(html):
            slug_id = watch_path.strip("/").split("/")[-1]
            entries.append((slug_id, _clean(title)))
        return entries

    def search(self, query, category=None):
        html = self._fetch("/?s={}".format(requests.utils.quote(query)))
        entries = []
        for watch_path, title in _ITEM_RE.findall(html):
            slug_id = watch_path.strip("/").split("/")[-1]
            entries.append((slug_id, _clean(title)))
        return resolve_parallel(
            entries,
            lambda c: self.get_detail_item(c[0], category),
            max_items=15,
        )

    def get_detail_item(self, slug_id, category):
        """Laedt die Watch-Seite, prueft Host der Stream-URL.
        Gibt None zurueck, wenn es sich um einen YouTube-Eintrag handelt
        -> wird vom Aufrufer verworfen (siehe mapping.py)."""
        html = self._fetch("/watch/{}/".format(slug_id))

        direct_match = _DIRECT_URL_RE.search(html)
        if not direct_match:
            return None  # kein direkter Host gefunden -> vermutlich YouTube-Embed, raus

        stream_url = direct_match.group(1)
        if any(host in stream_url for host in _YOUTUBE_HOSTS):
            return None  # explizit ausschliessen

        year_match = _YEAR_RE.search(html)
        desc_match = _DESC_RE.search(html)
        genres = [g[1] for g in _GENRE_RE.findall(html)]
        languages = [l[1] for l in _LANGUAGE_RE.findall(html)]

        return RetroItem(
            id=slug_id,
            provider="retroflix",
            category=category,
            title=slug_id.replace("-", " ").title(),
            description=_clean(desc_match.group(1)) if desc_match else "",
            year=safe_int(year_match.group(1)) if year_match else None,
            language=",".join(languages),
            genre=genres,
            stream_url=stream_url,
            source_page="{}/watch/{}/".format(BASE_URL, slug_id),
        )

    def resolve_stream(self, item_id):
        item = self.get_detail_item(item_id, category=None)
        return item.stream_url if item else None

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
