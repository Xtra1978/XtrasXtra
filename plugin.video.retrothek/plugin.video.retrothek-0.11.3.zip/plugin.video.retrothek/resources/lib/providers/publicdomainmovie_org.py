# -*- coding: utf-8 -*-
"""
publicdomainmovie.org Provider.

WICHTIG: eigenstaendige Seite, NICHT zu verwechseln mit
publicdomainmovie.net (siehe publicdomainmovie.py) - unterschiedliche
Betreiber, unterschiedliche Technik (WordPress/Elementor statt Drupal).

Bettet Filme direkt als Internet-Archive-Player ein
(<iframe src="https://archive.org/embed/{identifier}">), tatsaechlich
gestreamt wird die "_512kb.mp4"-Ableitung - bestaetigt per HAR-Mitschnitt
(archive.org/download/tombstone_canyon/tombstone_canyon_512kb.mp4).
Nutzt daher fuer die Stream-Aufloesung dieselbe Logik wie unser
Archive.org-Provider.

Kategorie-URLs per HAR bestaetigt: /adventure/, /comedy/, /crime/,
/thriller/, /mystery/, /horror/, /sci-fi/, /drama/, /action/,
/tv-shows/, /cartoons/, /biopic/, /musicals/, /romance/, /history/,
/documentary/.

HINWEIS: Das genaue HTML-Format der Uebersichtsseiten (welcher Link-
Pattern die einzelnen Filme auflistet) war im HAR-Mitschnitt nicht als
Textinhalt enthalten (nur die Netzwerk-Anfragen selbst) - das Regex
hier ist nach bestem Wissen (typisches WordPress/Elementor-Muster)
gebaut, aber noch nicht gegen die echte Seite verifiziert.
"""
import re

import requests

from .base import ProviderBase, RetroItem
from .archive_org import ArchiveOrgProvider
from ..utils import _clean, resolve_parallel

BASE_URL = "https://publicdomainmovie.org"

CATEGORY_MAP = {
    "filme": ["adventure", "comedy", "crime", "thriller", "mystery", "horror",
              "sci-fi", "drama", "action", "romance", "history", "biopic", "musicals"],
    "kids": ["cartoons"],
    "dokus": ["documentary"],
    "serien": ["tv-shows"],
}

_LINK_RE = re.compile(
    r'<a class="p-flink" href="https://publicdomainmovie\.org/([a-z0-9\-]+)/"[^>]*title="([^"]+)"',
    re.IGNORECASE,
)
_TITLE_SUFFIX_RE = re.compile(r'\s*(?:\(\d{4}\))?\s*Full Movie Review.*$', re.IGNORECASE)
_EMBED_RE = re.compile(r'archive\.org/embed/([a-zA-Z0-9_\-]+)')


class PublicDomainMovieOrgProvider(ProviderBase):
    key = "publicdomainmovie_org"
    name = "publicdomainmovie.org"

    def list_category(self, category, offset=0, size=50):
        slugs = CATEGORY_MAP.get(category, [])
        candidates = []
        for genre in slugs:
            try:
                html = self._fetch("/{}/".format(genre))
            except requests.RequestException:
                continue
            for slug, title in _LINK_RE.findall(html):
                clean_title = _TITLE_SUFFIX_RE.sub("", title).strip()
                candidates.append((slug, _clean(clean_title), category))
        return resolve_parallel(candidates, self._resolve_item, max_items=25)

    def search(self, query, category=None):
        return []  # kein dediziertes Such-API bekannt

    def resolve_stream(self, item_id):
        # item_id = Archive.org-Identifier -> dieselbe Aufloesung wie beim
        # normalen Archive.org-Provider (bevorzugt _512kb.mp4 etc.)
        return ArchiveOrgProvider().resolve_stream(item_id)

    def _resolve_item(self, candidate):
        slug, title, category = candidate
        try:
            html = self._fetch("/{}/".format(slug))
        except requests.RequestException:
            return None
        match = _EMBED_RE.search(html)
        if not match:
            return None
        identifier = match.group(1)
        return RetroItem(
            id=identifier,
            provider="publicdomainmovie_org",
            category=category,
            title=title or slug.replace("-", " ").title(),
            thumb="https://archive.org/services/img/{}".format(identifier),
            source_page="{}/{}/".format(BASE_URL, slug),
        )

    def _fetch(self, path):
        resp = requests.get(BASE_URL + path, timeout=15, headers={"User-Agent": "Retrothek-Kodi-Addon"})
        resp.raise_for_status()
        return resp.text
