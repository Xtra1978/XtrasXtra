# -*- coding: utf-8 -*-
"""
Zentrales Routing fuer Retrothek. addon.py delegiert komplett hierher.
"""
from urllib.parse import urlencode

import xbmcaddon
import xbmcgui
import xbmcplugin

from . import categories
from . import favorites
from . import cache
from . import settings_helper
from . import url_checker
from .providers.registry import get_provider_by_key
from .utils import seconds_to_hms, log

BASE_URL = None
HANDLE = None


def build_url(**kwargs):
    return "{}?{}".format(BASE_URL, urlencode(kwargs))


def route(base_url, handle, params):
    global BASE_URL, HANDLE
    BASE_URL = base_url
    HANDLE = handle

    if settings_helper.is_first_run() and params.get("action") != "setup_wizard":
        show_setup_wizard()
        return

    if cache.invalidate_on_version_change():
        log("Neue Addon-Version erkannt, Cache automatisch geleert", force=True)

    if (params.get("action") is None
            and settings_helper.get_bool("ask_before_open", default=False)):
        if xbmcgui.Dialog().yesno("Retrothek", "Cache jetzt leeren?", defaultbutton=xbmcgui.DLG_YESNO_NO_BTN):
            clear_cache(silent=True)

    action = params.get("action")

    try:
        if action is None:
            show_main_menu()
        elif action == "category":
            show_category(params["category"], params.get("mode", "root"), params.get("decade"),
                           params.get("letter"), params.get("provider"))
        elif action == "az_index":
            show_az_index(params["category"])
        elif action == "by_provider":
            show_by_provider_index(params["category"])
        elif action == "search":
            do_search(params.get("category"))
        elif action == "favorites":
            show_favorites()
        elif action == "toggle_favorite":
            toggle_favorite(params)
        elif action == "play":
            play_item(params)
        elif action == "setup_wizard":
            run_setup_wizard()
        elif action == "open_settings":
            open_settings()
        elif action == "clear_cache":
            clear_cache()
        elif action == "decades":
            show_decades(params["category"])
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    except Exception as exc:
        # Sicherheitsnetz: ein unerwarteter Fehler darf nie zu einer
        # haengenden/leeren Seite ohne Rueckmeldung fuehren.
        log("Unerwarteter Fehler bei action={}: {}".format(action, exc), force=True)
        xbmcgui.Dialog().notification("Retrothek", "Unerwarteter Fehler - siehe Log",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def open_settings():
    """Oeffnet den nativen Kodi-Settings-Dialog des Addons.
    Kein directory-Aufbau noetig, daher endOfDirectory mit succeeded=False,
    damit Kodi keinen leeren Ordner anzeigt."""
    xbmcaddon.Addon().openSettings()
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)


def clear_cache(silent=False):
    """Verknuepft mit dem 'Cache jetzt leeren'-Button in den Settings
    und dem Hauptmenue-Eintrag. silent=True wird von der optionalen
    Start-Abfrage genutzt, die selbst keine eigene Verzeichnis-Antwort
    schickt (der Hauptmenue-Aufbau folgt danach normal weiter)."""
    count = cache.clear_all()
    log("Cache manuell geleert, {} Dateien entfernt".format(count), force=True)
    if silent:
        return
    xbmcgui.Dialog().notification("Retrothek", "Cache geleert ({} Dateien)".format(count),
                                   xbmcgui.NOTIFICATION_INFO)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)


def show_setup_wizard():
    """Startet den Einrichtungsassistenten beim allerersten Aufruf (first_run Flag)."""
    run_setup_wizard()


def run_setup_wizard():
    # Vereinfachte Dialog-basierte Variante; das WindowXMLDialog mit
    # den Retro-TV-Buttons wird als eigenes Skin-Fenster nachgereicht,
    # sobald die Icon-Grafiken (4 Zustaende je Anbieter) vorliegen.
    dialog = xbmcgui.Dialog()

    lang_options = ["Deutsch", "Englisch", "Beide Sprachen"]
    lang_choice = dialog.select("Sprache", lang_options)
    if lang_choice >= 0:
        settings_helper.set_setting("language_filter", str(lang_choice if lang_choice < 2 else 2))

    provider_labels = list(settings_helper.PROVIDER_SETTING_IDS.keys())
    preselected = list(range(len(provider_labels)))
    chosen = dialog.multiselect("Anbieter auswaehlen", provider_labels, preselect=preselected)
    if chosen is not None:
        for idx, key in enumerate(provider_labels):
            setting_id = settings_helper.PROVIDER_SETTING_IDS[key]
            settings_helper.set_setting(setting_id, "true" if idx in chosen else "false")

    settings_helper.set_first_run_done()

    if xbmcgui.Dialog().yesno("Retrothek", "Einrichtung abgeschlossen. Addon jetzt starten?"):
        show_main_menu()
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)


def _media_path(filename):
    return "special://home/addons/plugin.video.retrothek/resources/media/{}".format(filename)


def show_main_menu():
    entries = [
        ("Filme", build_url(action="category", category="filme"), "filme.png"),
        ("Serien", build_url(action="category", category="serien"), "serien.png"),
        ("Dokus", build_url(action="category", category="dokus"), "dokus.png"),
        ("Kids", build_url(action="category", category="kids"), "kids.png"),
        ("Suche", build_url(action="search"), "suche.png"),
        ("Meine Retros", build_url(action="favorites"), "favoriten.png"),
        ("Cache jetzt leeren", build_url(action="clear_cache"), "cache_leeren.png"),
        ("Einstellungen", build_url(action="open_settings"), "settings.png"),
    ]
    non_folder_labels = ("Einstellungen", "Cache jetzt leeren")
    for label, url, icon in entries:
        list_item = xbmcgui.ListItem(label=label)
        icon_path = _media_path(icon)
        list_item.setArt({"icon": icon_path, "thumb": icon_path})
        is_folder = label not in non_folder_labels
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    xbmcplugin.endOfDirectory(HANDLE)


def show_category(category, mode="root", decade=None, letter=None, provider=None):
    log("Oeffne Kategorie {} (mode={}, decade={}, letter={}, provider={})".format(
        category, mode, decade, letter, provider))

    if mode not in ("items",):
        failed_providers = url_checker.check_active_providers()
        if failed_providers:
            xbmcgui.Dialog().notification(
                "Retrothek",
                "Nicht erreichbar: {}".format(", ".join(failed_providers)),
                xbmcgui.NOTIFICATION_WARNING,
            )

    sub_entries = [
        ("Suche", build_url(action="search", category=category), "suche.png"),
        ("A-Z", build_url(action="az_index", category=category), "az.png"),
        ("Neu hinzugefuegt", build_url(action="category", category=category, mode="new"), "neu.png"),
        ("Jahrzehnte", build_url(action="decades", category=category), "decades.png"),
        ("Nach Anbieter", build_url(action="by_provider", category=category), "nach_anbieter.png"),
    ]
    is_root_view = mode == "root" and not decade and not letter and not provider
    if is_root_view:
        for label, url, icon in sub_entries:
            list_item = xbmcgui.ListItem(label=label)
            if icon:
                icon_path = _media_path(icon)
                list_item.setArt({"icon": icon_path, "thumb": icon_path})
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, True)
        # Root-Ansicht zeigt bewusst keine Titel mehr direkt - nur die
        # Unterpunkte. Vollstaendige Liste gibt's weiterhin ueber A-Z,
        # gefiltert per Buchstabe, oder ueber Nach Anbieter.
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if provider:
        items = categories.get_provider_items(provider, category)
    else:
        items = categories.get_category_items(category, mode=mode)
        if decade:
            decade_int = int(decade)
            items = [i for i in items if i.get("year") and (i["year"] // 10) * 10 == decade_int]
        if letter:
            items = [i for i in items if _starts_with_letter(i.get("title", ""), letter)]

    log("Kategorie {}: {} Treffer geladen".format(category, len(items)))
    _render_items(items)
    xbmcplugin.endOfDirectory(HANDLE)


def show_by_provider_index(category):
    """Listet alle aktiven Anbieter fuer eine Kategorie als eigene
    Unterordner - erleichtert das Eingrenzen toter URLs/fehlerhafter
    Anbieter, da man gezielt in einen einzelnen Anbieter reinschauen kann."""
    from .providers.registry import get_active_providers
    for prov in get_active_providers():
        url = build_url(action="category", category=category, mode="items", provider=prov.key)
        list_item = xbmcgui.ListItem(label=prov.name)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, True)
    xbmcplugin.endOfDirectory(HANDLE)


def _starts_with_letter(title, letter):
    first_char = (title or "").strip()[:1].upper()
    if letter == "0-9":
        return first_char.isdigit()
    return first_char == letter


def show_az_index(category):
    """Zeigt das Buchstaben-Register fuer eine Kategorie (A-Z + 0-9),
    damit man sich nicht durch eine einzige lange Liste wuehlen muss."""
    items = categories.get_category_items(category, mode="az")
    available_letters = set()
    for item in items:
        title = (item.get("title") or "").strip()
        if not title:
            continue
        first_char = title[0].upper()
        available_letters.add("0-9" if first_char.isdigit() else first_char)

    alphabet = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + ["0-9"]
    icon_path = _media_path("az.png")
    for letter in alphabet:
        if letter not in available_letters:
            continue  # nur Buchstaben mit tatsaechlichen Treffern anzeigen
        url = build_url(action="category", category=category, mode="az", letter=letter)
        list_item = xbmcgui.ListItem(label=letter)
        list_item.setArt({"icon": icon_path, "thumb": icon_path})
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_decades(category):
    """Zeigt die verfuegbaren Jahrzehnte fuer eine Kategorie (v.a. bei
    Archive.org-basierten Quellen sinnvoll, da dort ein sauberes
    Produktionsjahr vorliegt - siehe Konzeptdiskussion)."""
    decades = categories.get_decades(category)
    if not decades:
        xbmcgui.Dialog().notification("Retrothek", "Keine Jahrzehnte-Daten verfuegbar",
                                       xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for decade in decades:
        label = "{}er".format(decade)
        url = build_url(action="category", category=category, mode="az", decade=decade)
        list_item = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, True)
    xbmcplugin.endOfDirectory(HANDLE)


def do_search(category=None):
    keyboard_query = xbmcgui.Dialog().input("Suche")
    if not keyboard_query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    items = categories.search_all(keyboard_query, category=category)
    _render_items(items)
    xbmcplugin.endOfDirectory(HANDLE)


def show_favorites():
    items = favorites.list_favorites()
    _render_items(items, is_favorites_view=True)
    xbmcplugin.endOfDirectory(HANDLE)


def toggle_favorite(params):
    provider = params["provider"]
    item_id = params["id"]
    if favorites.is_favorite(provider, item_id):
        favorites.remove_favorite(provider, item_id)
    else:
        item_dict = {
            "provider": provider,
            "id": item_id,
            "category": params.get("category", ""),
            "title": params.get("title", ""),
            "thumb": params.get("thumb", ""),
            "year": safe_int_or_none(params.get("year")),
            "duration": safe_int_or_none(params.get("duration")),
            "genre": [g for g in params.get("genre", "").split(",") if g],
        }
        favorites.add_favorite(item_dict)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def safe_int_or_none(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def play_item(params):
    provider_key = params["provider"]
    item_id = params["id"]
    provider = get_provider_by_key(provider_key)
    if provider is None:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    stream_url = provider.resolve_stream(item_id)
    if not stream_url:
        xbmcgui.Dialog().notification("Retrothek", "Stream nicht verfuegbar", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    list_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)


def _render_items(items, is_favorites_view=False):
    for item in items:
        list_item = xbmcgui.ListItem(label=item.get("title", ""))

        try:
            # Kodi 20+ (Nexus/Omega): neue InfoTagVideo-Setter-API
            info_tag = list_item.getVideoInfoTag()
            info_tag.setPlot(item.get("description", ""))
            if item.get("year"):
                info_tag.setYear(item["year"])
            if item.get("duration"):
                info_tag.setDuration(item["duration"])
            if item.get("genre"):
                info_tag.setGenres(item["genre"])
        except AttributeError:
            # Kodi 19 (Matrix): Fallback auf die klassische setInfo()-API
            info = {"plot": item.get("description", "")}
            if item.get("year"):
                info["year"] = item["year"]
            if item.get("duration"):
                info["duration"] = item["duration"]
            if item.get("genre"):
                info["genre"] = item["genre"]
            list_item.setInfo("video", info)

        if item.get("thumb"):
            list_item.setArt({"thumb": item["thumb"], "icon": item["thumb"]})

        list_item.setProperty("IsPlayable", "true")

        context_menu = [(
            "Aus Meine Retros entfernen" if is_favorites_view else "Zu Meine Retros hinzufuegen",
            "RunPlugin({})".format(build_url(
                action="toggle_favorite",
                provider=item.get("provider", ""),
                id=item.get("id", ""),
                category=item.get("category", ""),
                title=item.get("title", ""),
                thumb=item.get("thumb", ""),
                year=item.get("year") or "",
                duration=item.get("duration") or "",
                genre=",".join(item.get("genre") or []),
            ))
        )]
        list_item.addContextMenuItems(context_menu)

        url = build_url(action="play", provider=item.get("provider", ""), id=item.get("id", ""))
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, False)
