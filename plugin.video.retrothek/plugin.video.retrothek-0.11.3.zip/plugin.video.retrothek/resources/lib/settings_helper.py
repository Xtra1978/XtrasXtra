# -*- coding: utf-8 -*-
"""
Zentrale Settings-Zugriffsschicht.
Standard: alle Settings ausschliesslich ueber addon.getSetting() lesen,
nirgends hartcodiert im Code duplizieren.
"""
import xbmcaddon

ADDON = xbmcaddon.Addon()


def get_bool(setting_id, default=True):
    value = ADDON.getSettingBool(setting_id) if hasattr(ADDON, "getSettingBool") else ADDON.getSetting(setting_id)
    if isinstance(value, str):
        return value.lower() == "true"
    return bool(value) if value is not None else default


def get_string(setting_id, default=""):
    value = ADDON.getSetting(setting_id)
    return value if value else default


def get_int(setting_id, default=0):
    try:
        return int(ADDON.getSetting(setting_id))
    except (TypeError, ValueError):
        return default


def set_setting(setting_id, value):
    ADDON.setSetting(setting_id, str(value))


# --- Provider-Toggles ---------------------------------------------------
PROVIDER_SETTING_IDS = {
    "archive_org": "provider_archive_org",
    "publicdomainmovie": "provider_publicdomainmovie",
    "publicdomainmovie_org": "provider_publicdomainmovie_org",
    "lincon": "provider_lincon",
    "retroflix": "provider_retroflix",
    "reruncentury": "provider_reruncentury",
    "documentarystorm": "provider_documentarystorm",
    "mediathek": "provider_mediathek",
    "ardzdf_retro": "provider_ardzdf_retro",
    "wikimedia": "provider_wikimedia",
    "british_council": "provider_british_council",
    "dhm_marshall": "provider_dhm_marshall",
}


def is_provider_enabled(provider_key):
    setting_id = PROVIDER_SETTING_IDS.get(provider_key)
    if not setting_id:
        return True
    return get_bool(setting_id, default=True)


def get_language_filter():
    """0 = Deutsch, 1 = Englisch, 2 = Beide (Standard, siehe settings.xml)"""
    return get_int("language_filter", default=2)


def is_first_run():
    return get_bool("first_run", default=True)


def set_first_run_done():
    set_setting("first_run", "false")
