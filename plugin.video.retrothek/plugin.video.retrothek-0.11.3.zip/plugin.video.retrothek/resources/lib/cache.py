# -*- coding: utf-8 -*-
"""
Lokaler Cache fuer Faelle, in denen ein Provider kein serverseitiges
Sortieren nach Titel anbietet (v.a. MediathekViewWeb -> siehe Diskussion:
API kennt nur sortBy=timestamp/duration/channel, kein "title").

Bei Providern mit nativer Titel-Sortierung (Archive.org, RetroFlix,
publicdomainmovie.net) wird dieser Cache nicht benoetigt.

Speicherort: xbmcvfs.translatePath(special://profile/addon_data/...)
"""
import json
import os
import time

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

DEFAULT_TTL_HOURS = 6


def _ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_PATH):
        xbmcvfs.mkdirs(PROFILE_PATH)


def _cache_file(cache_key):
    return os.path.join(PROFILE_PATH, "cache_{}.json".format(cache_key))


def get_cached(cache_key, ttl_hours=DEFAULT_TTL_HOURS):
    path = _cache_file(cache_key)
    if not xbmcvfs.exists(path):
        return None

    f = xbmcvfs.File(path)
    try:
        raw = f.read()
    finally:
        f.close()

    try:
        payload = json.loads(raw)
    except ValueError:
        return None

    age_hours = (time.time() - payload.get("timestamp", 0)) / 3600
    if age_hours > ttl_hours:
        return None

    return payload.get("data")


def set_cached(cache_key, data):
    _ensure_profile_dir()
    payload = {"timestamp": time.time(), "data": data}
    f = xbmcvfs.File(_cache_file(cache_key), "w")
    try:
        f.write(json.dumps(payload))
    finally:
        f.close()


def sorted_by_title(items, cache_key, ttl_hours=DEFAULT_TTL_HOURS):
    """Liefert eine nach Titel sortierte Liste aus dem Cache, oder
    sortiert + cached die uebergebene Liste, falls kein gueltiger
    Cache-Eintrag vorliegt."""
    cached = get_cached(cache_key, ttl_hours)
    if cached is not None:
        return cached

    sorted_items = sorted(items, key=lambda i: (i.get("title") or "").lower())
    if sorted_items:  # leere Ergebnisse bewusst nicht cachen (siehe Absicherung)
        set_cached(cache_key, sorted_items)
    return sorted_items


def clear_all():
    """Fuer den 'Cache leeren'-Button in den Settings."""
    _ensure_profile_dir()
    dirs, files = xbmcvfs.listdir(PROFILE_PATH)
    for filename in files:
        if filename.startswith("cache_"):
            xbmcvfs.delete(os.path.join(PROFILE_PATH, filename))
    return len(files)


_VERSION_MARKER_FILE = os.path.join(PROFILE_PATH, "cache_addon_version.txt")


def invalidate_on_version_change():
    """Leert den Cache automatisch, wenn seit dem letzten Start eine neue
    Addon-Version installiert wurde (z.B. nach einem Bugfix wie beim
    Archive.org-Jahres-Feld). Verhindert, dass veraltete Daten ueber die
    volle TTL haengen bleiben, ohne bei jedem Start manuell nachfragen
    zu muessen."""
    _ensure_profile_dir()
    current_version = ADDON.getAddonInfo("version")

    stored_version = None
    if xbmcvfs.exists(_VERSION_MARKER_FILE):
        f = xbmcvfs.File(_VERSION_MARKER_FILE)
        try:
            stored_version = f.read().strip()
        finally:
            f.close()

    if stored_version != current_version:
        clear_all()
        f = xbmcvfs.File(_VERSION_MARKER_FILE, "w")
        try:
            f.write(current_version)
        finally:
            f.close()
        return True
    return False
