# -*- coding: utf-8 -*-
"""
Orchestrierungsschicht fuer die vier Hauptkategorien (Filme/Serien/Dokus/Kids).
Fragt alle aktiven Provider ab, vereinheitlicht auf RetroItem/dict und
stellt Suche, A-Z und "Neu hinzugefuegt" bereit.

Quelle bleibt fuer den Nutzer unsichtbar (siehe Absprache) - taucht
nirgends in der Anzeige auf, nur intern als Feld fuer die Settings-Filter.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import cache
from .providers.registry import get_active_providers
from .utils import log

MAIN_CATEGORIES = ("filme", "serien", "dokus", "kids")

# Provider mit nativer Titel-Sortierung -> kein Cache noetig.
NATIVE_TITLE_SORT_PROVIDERS = {"archive_org", "retroflix", "publicdomainmovie", "reruncentury", "wikimedia"}

_PROVIDER_TIMEOUT = 20  # Sekunden - ein einzelner haengender Provider darf die anderen nicht blockieren


def get_provider_items(provider_key, category):
    """Fragt gezielt nur EINEN Anbieter ab (statt aller aktiven), fuer die
    "Nach Anbieter"-Ansicht - damit sich tote URLs/fehlerhafte Anbieter
    einfach isolieren lassen, ohne im Gesamt-Sammelsurium unterzugehen."""
    from .providers.registry import get_provider_by_key
    provider = get_provider_by_key(provider_key)
    if provider is None:
        return []
    try:
        items = provider.list_category(category, 0, 200)
    except Exception as exc:
        log("Provider {} fehlgeschlagen: {}".format(provider_key, exc))
        return []
    item_dicts = [item.to_dict() if hasattr(item, "to_dict") else item for item in items]
    return sorted(item_dicts, key=lambda i: (i.get("title") or "").lower())


def get_category_items(category, mode="az"):
    """mode: 'az' | 'new' | 'search' (query separat behandelt)
    Liefert immer die vollstaendige Ergebnismenge - es gibt bewusst keine
    Paginierung in der Oberflaeche, daher auch keine kuenstliche Kappung
    hier (siehe Fund von rols1: 199 Archive.org-Treffer wurden vorher
    stillschweigend auf 50 abgeschnitten)."""
    all_items = []
    providers = get_active_providers()

    with ThreadPoolExecutor(max_workers=max(1, len(providers))) as pool:
        futures = {pool.submit(p.list_category, category, 0, 200): p for p in providers}
        for future in as_completed(futures):
            provider = futures[future]
            try:
                items = future.result(timeout=_PROVIDER_TIMEOUT)
            except Exception as exc:
                # Ein einzelner Provider-Ausfall/Timeout darf nie das gesamte Menue blockieren
                log("Provider {} fehlgeschlagen: {}".format(provider.key, exc))
                continue
            for item in items:
                all_items.append(item.to_dict() if hasattr(item, "to_dict") else item)

    if mode == "az":
        cache_key = "az_{}".format(category)
        sorted_items = cache.sorted_by_title(all_items, cache_key)
    elif mode == "new":
        sorted_items = sorted(all_items, key=lambda i: i.get("year") or 0, reverse=True)
    else:
        sorted_items = all_items

    return sorted_items


def search_all(query, category=None):
    results = []
    providers = get_active_providers()
    with ThreadPoolExecutor(max_workers=max(1, len(providers))) as pool:
        futures = {pool.submit(p.search, query, category): p for p in providers}
        for future in as_completed(futures):
            provider = futures[future]
            try:
                items = future.result(timeout=_PROVIDER_TIMEOUT)
            except Exception as exc:
                log("Provider {} (Suche) fehlgeschlagen: {}".format(provider.key, exc))
                continue
            for item in items:
                item_dict = item.to_dict() if hasattr(item, "to_dict") else item
                if category and item_dict.get("category") not in (category, None):
                    continue
                results.append(item_dict)
    return results


def get_decades(category):
    """Nur fuer Provider mit sauberem Produktionsjahr sinnvoll (v.a. Archive.org-basiert)."""
    items = get_category_items(category, mode="az")
    years = [i.get("year") for i in items if i.get("year")]
    decades = sorted({(y // 10) * 10 for y in years}, reverse=True)
    return decades
