# -*- coding: utf-8 -*-
"""
Allgemeine Hilfsfunktionen, u.a. die addon-uebergreifend genutzte
_clean() Funktion nach etabliertem Standard:
- HTML-Tags entfernen
- Abbruch an einer Wortgrenze bei ~400 Zeichen, mit Ellipse
"""
import re

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")

MAX_DESC_LENGTH = 400


def _clean(raw_text):
    """Bereinigt Beschreibungstexte aus Provider-Quellen fuer die Anzeige in Kodi."""
    if not raw_text:
        return ""

    text = _TAG_RE.sub("", raw_text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    text = _WS_RE.sub(" ", text).strip()

    if len(text) <= MAX_DESC_LENGTH:
        return text

    truncated = text[:MAX_DESC_LENGTH]
    last_space = truncated.rfind(" ")
    if last_space > 0:
        truncated = truncated[:last_space]

    return truncated.rstrip(",.;: ") + " ..."


def seconds_to_hms(seconds):
    """Wandelt Sekunden in ein lesbares h:mm Format fuer Listitem-Infos um."""
    try:
        seconds = int(seconds)
    except (TypeError, ValueError):
        return ""
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    if hours:
        return "{}h {:02d}min".format(hours, minutes)
    return "{}min".format(minutes)


def safe_int(value, default=0):
    """Robust gegen Archive.org-Eigenheit: manche Felder (z.B. 'year')
    kommen je nach Item als Liste statt als Einzelwert zurueck."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else None
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def log(message, force=False):
    """Schreibt ins Kodi-Log, sofern debug_logging in den Settings aktiv ist
    (oder force=True fuer Fehler, die immer geloggt werden sollen).
    Schreibt zusaetzlich in eine eigene, kompakte Addon-Log-Datei
    (special://profile/addon_data/plugin.video.retrothek/retrothek.log),
    damit man nicht das komplette kodi.log durchsuchen muss."""
    import xbmc
    from . import settings_helper

    if not (force or settings_helper.get_bool("debug_logging", default=False)):
        return

    xbmc.log("[Retrothek] {}".format(message), level=xbmc.LOGINFO)
    _write_own_log(message)


def _write_own_log(message):
    import time
    import xbmcaddon
    import xbmcvfs

    try:
        addon = xbmcaddon.Addon()
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdirs(profile_path)

        log_path = profile_path + "retrothek.log"
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = "{} {}\n".format(timestamp, message)

        # Bestehenden Inhalt einlesen statt im Anhaenge-Modus zu oeffnen -
        # xbmcvfs.File(..., "a") verhielt sich auf manchen Plattformen
        # (Android) offenbar nicht zuverlaessig (nur der allererste
        # Schreibvorgang landete in der Datei, alle folgenden nicht,
        # ohne sichtbaren Fehler). Lesen+Zusammenfuegen+komplett
        # Neuschreiben ist portabler.
        existing = ""
        if xbmcvfs.exists(log_path):
            f = xbmcvfs.File(log_path)
            try:
                existing = f.read()
            finally:
                f.close()

        # Bei ca. 2 MB neu anfangen, damit die Datei nicht unbegrenzt waechst
        if len(existing.encode("utf-8", errors="ignore")) >= 2 * 1024 * 1024:
            existing = ""

        f = xbmcvfs.File(log_path, "w")
        try:
            f.write(existing + line)
        finally:
            f.close()
    except Exception as exc:
        # Eigenes Logging darf das Addon nie zum Absturz bringen, aber
        # wenigstens ins normale kodi.log durchreichen statt komplett
        # zu verschlucken (das hat die Fehlersuche zuletzt erschwert)
        try:
            import xbmc
            xbmc.log("[Retrothek] Eigene Log-Datei fehlgeschlagen: {}".format(exc), level=xbmc.LOGWARNING)
        except Exception:
            pass


def resolve_parallel(candidates, resolver_fn, max_items=15, max_workers=5):
    """Loest eine Liste von Kandidaten (z.B. (slug, titel)-Tupel) parallel
    und mit fester Obergrenze auf, statt sie sequenziell durchzugehen.
    Verhindert, dass eine Kategorie mit vielen Treffern das Addon fuer
    Minuten blockiert (jeder Einzel-Request hat ein eigenes Timeout).
    resolver_fn(candidate) -> Item oder None (None wird verworfen)."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    limited = candidates[:max_items]
    if not limited:
        return []

    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(resolver_fn, c): c for c in limited}
        for future in as_completed(futures):
            try:
                item = future.result()
            except Exception:
                continue
            if item is not None:
                results.append(item)
    return results
