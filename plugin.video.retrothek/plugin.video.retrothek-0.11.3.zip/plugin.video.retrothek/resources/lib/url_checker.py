# -*- coding: utf-8 -*-
"""
URL-Pruefung nach der vereinbarten Variante 1: kein Dauer-Service im
Hintergrund, sondern ein kurzer Erreichbarkeits-Check beim Oeffnen einer
Kategorie. Bei Ausfaellen wird eine Kodi-Notification gezeigt statt
eines stillen Fehlers.
"""
import requests

from . import settings_helper
from .utils import log
from .providers.registry import get_active_providers

# Health-Check-Endpunkt je Provider-Key. Bewusst die jeweilige
# API-/Basis-URL, nicht eine tiefe Unterseite, um den Check schnell
# und ressourcenschonend zu halten.
HEALTH_CHECK_URLS = {
    "archive_org": "https://archive.org",
    "publicdomainmovie": "https://publicdomainmovie.net",
    "retroflix": "https://retroflix.org",
    "reruncentury": "https://www.reruncentury.com",
    "documentarystorm": "https://www.documentarystorm.com",
    "videogold": "https://videogold.de",
    "mediathek": "https://mediathekviewweb.de",
    "ardzdf_retro": "https://www.ardmediathek.de",
    "wikimedia": "https://commons.wikimedia.org",
    "popcorntimes": "https://popcorntimes.tv",
}

_CHECK_TIMEOUT = 12  # publicdomainmovie.net faellt wiederholt durch kuerzere
                      # Zeitlimits, obwohl echte Anfragen danach erfolgreich sind

# Ohne eigenen User-Agent blocken manche Seiten (v.a. Wikimedia, das
# sogar eine aussagekraeftige UA-Kennung verlangt) den Standard-UA von
# requests pauschal mit HTTP 403 -> false positive beim Check.
_CHECK_HEADERS = {
    "User-Agent": "Retrothek-Kodi-Addon/0.2 (https://github.com/xtra78/plugin.video.retrothek)"
}


def check_active_providers():
    """Prueft alle aktuell aktiven Provider und gibt eine Liste der
    Anzeigenamen zurueck, die gerade nicht erreichbar sind. Wird nur
    aufgerufen, wenn url_check_enabled in den Settings aktiv ist."""
    if not settings_helper.get_bool("url_check_enabled", default=True):
        return []

    from concurrent.futures import ThreadPoolExecutor, as_completed

    providers = [p for p in get_active_providers() if p.key in HEALTH_CHECK_URLS]
    if not providers:
        return []

    failed = []
    with ThreadPoolExecutor(max_workers=min(8, len(providers))) as pool:
        futures = {pool.submit(_check_one, p): p for p in providers}
        for future in as_completed(futures):
            provider = futures[future]
            if not future.result():
                failed.append(provider.name)
    return failed


def _check_one(provider):
    url = HEALTH_CHECK_URLS.get(provider.key)
    try:
        resp = requests.head(url, timeout=_CHECK_TIMEOUT, allow_redirects=True, headers=_CHECK_HEADERS)
        if resp.status_code >= 400:
            resp = requests.get(url, timeout=_CHECK_TIMEOUT, headers=_CHECK_HEADERS)
        if resp.status_code >= 400:
            log("URL-Check fehlgeschlagen fuer {}: HTTP {}".format(provider.name, resp.status_code))
            return False
        return True
    except requests.RequestException as exc:
        log("URL-Check fehlgeschlagen fuer {}: {}".format(provider.name, exc))
        return False
