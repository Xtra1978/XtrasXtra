# -*- coding: utf-8 -*-
"""
Retrothek - Einstiegspunkt
Haelt sich an das etablierte Muster: addon.py bleibt schlank und
delegiert das komplette Routing an resources/lib/router.py
"""
import sys
from urllib.parse import parse_qsl

from resources.lib import router

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
PARAMS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}


def main():
    router.route(BASE_URL, HANDLE, PARAMS)


if __name__ == "__main__":
    main()
