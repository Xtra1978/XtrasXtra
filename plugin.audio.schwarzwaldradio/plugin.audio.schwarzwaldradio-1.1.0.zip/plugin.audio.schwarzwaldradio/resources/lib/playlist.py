#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Playlist-Modul: Zeigt den aktuell laufenden Titel und die letzten gespielten Songs.
Nutzt den Streamonkey Metadata-Endpunkt (liefert JSON mit aktuellem Titel/Interpret).
"""

import json
import xbmc
import xbmcgui
import xbmcplugin

from urllib.request import urlopen, Request
from urllib.error   import URLError

from resources.lib.ui import ADDON_ICON, ADDON_FANART, build_url, add_directory_item

UA = 'Mozilla/5.0 (compatible; Kodi Schwarzwaldradio Addon/1.0)'

# Bekannte Metadata-Endpunkte (Streamonkey liefert JSON mit Titel/Interpret)
METADATA_URLS = [
    'https://frontend.streamonkey.net/fho-schwarzwaldradiolive/metadata',
    'https://np.tritondigital.com/public/nowplaying?mountName=SCHWARZWALDRADIO&numberToFetch=10&eventType=track',
    'https://api.streamonkey.net/fho-schwarzwaldradio/nowplaying',
]

# Playlist-Seite der Website (RSS)
PLAYLIST_RSS = 'https://www.schwarzwaldradio.com/playlist-und-songsuche/feed/'
PLAYLIST_WEB = 'https://www.schwarzwaldradio.com/playlist-und-songsuche/'

# MusicBrainz Cover-Art Fallback
MUSICBRAINZ_COVER = 'https://coverartarchive.org/release/{mbid}/front-250'


def show_playlist(base_url, handle, addon):
    """Zeigt die aktuelle Playlist – jetzt spielend und zuletzt gespielt."""
    xbmcplugin.setPluginCategory(handle, '🎵 Playlist – Was läuft gerade?')
    xbmcplugin.setContent(handle, 'songs')

    tracks = _fetch_nowplaying()

    if not tracks:
        # Fallback: Link zur Playlist-Seite
        xbmcgui.Dialog().notification(
            'Schwarzwaldradio',
            'Playlist-Daten momentan nicht verfügbar.',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        li = xbmcgui.ListItem(label='🌐 Playlist auf schwarzwaldradio.com öffnen')
        li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
        url = build_url(base_url, {'mode': 'open_website', 'url': PLAYLIST_WEB})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for i, track in enumerate(tracks):
        artist = track.get('artist', track.get('interpret', 'Unbekannt'))
        title  = track.get('title',  track.get('titel',    'Unbekannt'))
        time   = track.get('time',   track.get('zeit',     ''))
        cover  = track.get('cover',  '')

        if i == 0:
            label = f'▶  {artist} – {title}'
            if time:
                label += f'  ({time})'
        else:
            label = f'{artist} – {title}'
            if time:
                label += f'  [{time}]'

        info = {
            'title':  title,
            'artist': artist,
            'album':  'Schwarzwaldradio',
        }

        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon':   cover or ADDON_ICON,
            'thumb':  cover or ADDON_ICON,
            'fanart': ADDON_FANART,
        })
        li.setInfo('music', info)

        # Klick → Stream starten
        stream_url = build_url(base_url, {
            'mode':  'play_stream',
            'url':   'https://frontend.streamonkey.net/fho-schwarzwaldradiolive/stream/mp3',
            'title': f'{artist} – {title}',
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=handle, url=stream_url, listitem=li, isFolder=False)

    # Refresh-Button
    li_refresh = xbmcgui.ListItem(label='🔄  Aktualisieren')
    li_refresh.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART})
    url_refresh = build_url(base_url, {'mode': 'playlist'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url_refresh, listitem=li_refresh, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def _fetch_nowplaying():
    """Versucht Playlist-Daten von verschiedenen Endpunkten zu laden."""
    # 1) Streamonkey Metadata API
    for meta_url in METADATA_URLS:
        try:
            req  = Request(meta_url, headers={'User-Agent': UA, 'Accept': 'application/json'})
            resp = urlopen(req, timeout=8)
            data = json.loads(resp.read().decode('utf-8'))
            tracks = _parse_metadata(data)
            if tracks:
                xbmc.log(f'[Schwarzwaldradio] Playlist von {meta_url}: {len(tracks)} Titel', xbmc.LOGINFO)
                return tracks
        except Exception as e:
            xbmc.log(f'[Schwarzwaldradio] Metadata-Fehler {meta_url}: {e}', xbmc.LOGDEBUG)

    # 2) RSS-Feed der Playlist-Seite
    try:
        import xml.etree.ElementTree as ET
        req  = Request(PLAYLIST_RSS, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=8)
        root = ET.fromstring(resp.read())
        ch   = root.find('channel')
        tracks = []
        if ch:
            for item in ch.findall('item')[:15]:
                t = item.find('title')
                if t is not None and t.text:
                    # Typisches Format: "Interpret – Titel"
                    parts = t.text.split(' – ', 1)
                    artist = parts[0].strip() if len(parts) > 1 else 'Schwarzwaldradio'
                    title  = parts[1].strip() if len(parts) > 1 else t.text.strip()
                    tracks.append({'artist': artist, 'title': title})
        if tracks:
            return tracks
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] RSS-Playlist-Fehler: {e}', xbmc.LOGDEBUG)

    return []


def _parse_metadata(data):
    """Parst verschiedene Metadata-JSON-Formate."""
    tracks = []

    # Format 1: Streamonkey {"title": "...", "artist": "...", "history": [...]}
    if isinstance(data, dict):
        current = data.get('now_playing', data.get('current', data))
        artist  = (current.get('artist') or current.get('interpret') or
                   data.get('artist') or '')
        title   = (current.get('title')  or current.get('titel')    or
                   data.get('title')  or '')
        cover   = current.get('artwork_url', current.get('cover', ''))
        if artist or title:
            tracks.append({'artist': artist, 'title': title, 'time': 'Jetzt', 'cover': cover})

        # History
        for entry in data.get('song_history', data.get('history', []))[:14]:
            a = entry.get('artist', entry.get('interpret', ''))
            t = entry.get('title',  entry.get('titel',    ''))
            c = entry.get('artwork_url', entry.get('cover', ''))
            played = entry.get('played_at', entry.get('time', ''))
            if a or t:
                tracks.append({'artist': a, 'title': t, 'time': played, 'cover': c})

    # Format 2: Triton Digital [{...}, {...}]
    elif isinstance(data, list):
        for entry in data[:15]:
            a = entry.get('name', '')
            t = entry.get('cueTitle', entry.get('title', ''))
            if a or t:
                tracks.append({'artist': a, 'title': t})

    return tracks
