#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mediathek-Modul: Podcasts und Sendungen von Schwarzwaldradio
Parst RSS-Feeds und die Mediathek-Seite der Website.
"""

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError
    from urllib import urlencode

try:
    import xml.etree.ElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcplugin
from resources.lib.ui import ADDON_ICON, ADDON_FANART, add_directory_item, add_playable_item

# -----------------------------------------------------------------------
# Bekannte RSS/Podcast-Feeds von Schwarzwaldradio
# -----------------------------------------------------------------------
PODCAST_FEEDS = [
    {
        'title': '🎙️ Aus dem Programm (Alle Sendungen)',
        'url': 'https://www.schwarzwaldradio.com/mediathek/podcast/aus-dem-programm/',
        'feed': None,  # Wird via Web-Scraping geladen
        'description': 'Alle Sendungen aus dem Schwarzwaldradio-Programm'
    },
]

# Bekannte Sendungsformate / Kategorien laut Website & Wikipedia
SHOW_CATEGORIES = [
    {
        'id': 'classic_hits',
        'title': '🎶 Classic Hits & Super Oldies',
        'description': 'Das Hauptprogramm: die besten Oldies von den 50ern bis zur Jahrtausendwende'
    },
    {
        'id': 'special',
        'title': '🌟 Sondersendungen',
        'description': 'Soul, Rock, Disco, Country und weitere Spezialformate'
    },
    {
        'id': 'nacht',
        'title': '🌙 Die Nacht',
        'description': 'Schwarzwaldradio am späten Abend'
    },
    {
        'id': 'frauenquote',
        'title': '♀️ Die Schwarzwaldradio Frauenquote',
        'description': 'Hits beliebter Interpretinnen'
    },
    {
        'id': 'tanzparty',
        'title': '💃 Die Schwarzwaldradio Tanzparty',
        'description': 'Zum Tanzen: die besten Partyhits'
    },
    {
        'id': 'tanzshow',
        'title': '🕺 Die Schwarzwaldradio Tanzshow',
        'description': 'Tanzmusik vom Feinsten'
    },
    {
        'id': 'morgen',
        'title': '☀️ Schwarzwaldradio am Morgen',
        'description': 'Der perfekte Start in den Tag'
    },
    {
        'id': 'mittag',
        'title': '🌞 Schwarzwaldradio am Mittag',
        'description': 'Die besten Hits zur Mittagszeit'
    },
    {
        'id': 'abend',
        'title': '🌆 Schwarzwaldradio am Abend',
        'description': 'Entspannte Musik für den Abend'
    },
    {
        'id': 'samstag',
        'title': '🎉 Samstag Nachmittag',
        'description': 'Die schönsten Hits für das Wochenende'
    },
]

# Bekannte Moderatoren
MODERATOREN = [
    'Fritz Egner', 'Rainer Nitschke', 'Benny Schnier', 'Charly McThorn',
    'Uwe Carsten', 'Kati Huhn', 'Sandra Laeske', 'Patrick Fuchs',
    'Volker Franck', 'Frank Dickerhof', 'Matthias Drescher', 'Corinne Frech'
]

MEDIATHEK_BASE_URL = 'https://www.schwarzwaldradio.com/mediathek/'
USER_AGENT = 'Mozilla/5.0 (compatible; Kodi Schwarzwaldradio Addon/1.0)'


def show_mediathek(base_url, handle, addon):
    """Zeigt das Mediathek-Hauptmenü."""
    xbmcplugin.setPluginCategory(handle, 'Mediathek & Podcasts')
    xbmcplugin.setContent(handle, 'episodes')

    # Hauptkategorie: Alle Podcasts direkt laden
    add_directory_item(
        handle=handle,
        base_url=base_url,
        label='📻 Alle Sendungen (Mediathek)',
        params={'mode': 'mediathek_category', 'category': 'all_shows'},
        description='Alle verfügbaren Sendungen und Podcast-Episoden'
    )

    # Sendungsformate
    add_directory_item(
        handle=handle,
        base_url=base_url,
        label='📋 Sendungsformate',
        params={'mode': 'mediathek_category', 'category': 'formats'},
        description='Übersicht aller Sendungsformate'
    )

    # Moderatoren
    add_directory_item(
        handle=handle,
        base_url=base_url,
        label='🎤 Moderatoren',
        params={'mode': 'mediathek_category', 'category': 'moderatoren'},
        description='Alle Moderatoren von Schwarzwaldradio'
    )

    xbmcplugin.endOfDirectory(handle)


def show_category(base_url, handle, addon, category):
    """Zeigt Inhalte einer bestimmten Kategorie."""
    xbmcplugin.setContent(handle, 'episodes')

    if category == 'formats':
        _show_formats(base_url, handle, addon)
    elif category == 'moderatoren':
        _show_moderatoren(base_url, handle, addon)
    elif category == 'all_shows':
        _show_all_shows(base_url, handle, addon)
    else:
        xbmcplugin.endOfDirectory(handle)


def _show_formats(base_url, handle, addon):
    """Zeigt alle Sendungsformate."""
    xbmcplugin.setPluginCategory(handle, 'Sendungsformate')
    for show in SHOW_CATEGORIES:
        add_directory_item(
            handle=handle,
            base_url=base_url,
            label=show['title'],
            params={
                'mode': 'mediathek_category',
                'category': 'format_{0}'.format(show['id'])
            },
            description=show['description']
        )
    xbmcplugin.endOfDirectory(handle)


def _show_moderatoren(base_url, handle, addon):
    """Zeigt alle Moderatoren."""
    xbmcplugin.setPluginCategory(handle, 'Moderatoren')
    for mod in MODERATOREN:
        li = xbmcgui.ListItem(label='🎤 {0}'.format(mod))
        li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
        li.setInfo('music', {'comment': 'Moderator bei Schwarzwaldradio'})
        # Öffnet die Website-Seite des Moderators
        url_param = 'https://www.schwarzwaldradio.com/'
        from resources.lib.ui import build_url
        url = build_url(base_url, {
            'mode': 'open_website',
            'url': 'https://www.schwarzwaldradio.com/moderatoren/'
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)


def _show_all_shows(base_url, handle, addon):
    """
    Lädt und zeigt Podcast-Episoden von der Schwarzwaldradio-Mediathek.
    Versucht zuerst den RSS-Feed, dann Fallback auf direkte Links.
    """
    xbmcplugin.setPluginCategory(handle, 'Alle Sendungen')

    episodes = _fetch_podcast_episodes()

    if episodes:
        for ep in episodes:
            info = {
                'title': ep.get('title', ''),
                'artist': 'Schwarzwaldradio',
                'album': ep.get('show', 'Schwarzwaldradio Mediathek'),
                'comment': ep.get('description', ''),
                'date': ep.get('date', ''),
                'duration': ep.get('duration', 0),
            }
            add_playable_item(
                handle=handle,
                base_url=base_url,
                label=ep.get('title', 'Unbekannte Sendung'),
                params={
                    'mode': 'play_podcast',
                    'url': ep.get('url', ''),
                    'title': ep.get('title', 'Podcast'),
                },
                info=info,
            )
    else:
        # Fallback: Direkte Links zur Mediathek-Website
        _show_mediathek_fallback(base_url, handle, addon)

    xbmcplugin.endOfDirectory(handle)


def _fetch_podcast_episodes():
    """
    Versucht, Podcast-Episoden von bekannten RSS-Endpunkten zu laden.
    Gibt eine Liste von Episoden-Dicts zurück oder eine leere Liste bei Fehler.
    """
    episodes = []

    # Bekannte RSS-Feed-URLs für Schwarzwaldradio
    rss_urls = [
        'https://www.schwarzwaldradio.com/feed/',
        'https://www.schwarzwaldradio.com/mediathek/podcast/aus-dem-programm/feed/',
        'https://www.schwarzwaldradio.com/mediathek/feed/',
    ]

    for rss_url in rss_urls:
        try:
            req = Request(rss_url, headers={'User-Agent': USER_AGENT})
            response = urlopen(req, timeout=10)
            content = response.read()
            episodes = _parse_rss(content)
            if episodes:
                xbmc.log('[Schwarzwaldradio] RSS geladen: {0} ({1} Episoden)'.format(
                    rss_url, len(episodes)), xbmc.LOGINFO)
                return episodes
        except Exception as e:
            xbmc.log('[Schwarzwaldradio] RSS-Fehler für {0}: {1}'.format(rss_url, str(e)),
                     xbmc.LOGWARNING)

    return episodes


def _parse_rss(content):
    """Parst einen RSS-Feed und gibt Episoden-Dicts zurück."""
    episodes = []
    try:
        root = ET.fromstring(content)
        # Namespace-Map für iTunes-Tags
        ns = {
            'itunes': 'http://www.itunes.com/dtds/podcast-1.0.dtd',
            'content': 'http://purl.org/rss/1.0/modules/content/',
        }

        channel = root.find('channel')
        if channel is None:
            return episodes

        for item in channel.findall('item'):
            title = _get_text(item, 'title')
            description = _get_text(item, 'description') or \
                          _get_text(item, 'itunes:summary', ns)
            pub_date = _get_text(item, 'pubDate')
            duration = _get_text(item, 'itunes:duration', ns) or '0'

            # Audio-URL aus enclosure oder link
            enclosure = item.find('enclosure')
            audio_url = ''
            if enclosure is not None:
                audio_url = enclosure.get('url', '')

            if not audio_url:
                audio_url = _get_text(item, 'link') or ''

            if title and audio_url:
                # Dauer in Sekunden umrechnen
                dur_secs = _parse_duration(duration)
                episodes.append({
                    'title': title,
                    'url': audio_url,
                    'description': _strip_html(description),
                    'date': pub_date,
                    'duration': dur_secs,
                    'show': 'Schwarzwaldradio Podcast',
                })
    except Exception as e:
        xbmc.log('[Schwarzwaldradio] RSS-Parse-Fehler: {0}'.format(str(e)), xbmc.LOGWARNING)

    return episodes


def _show_mediathek_fallback(base_url, handle, addon):
    """Zeigt Fallback-Links zur Mediathek, wenn kein RSS verfügbar."""
    fallback_items = [
        {
            'title': '🌐 Mediathek auf schwarzwaldradio.com öffnen',
            'url': 'https://www.schwarzwaldradio.com/mediathek/'
        },
        {
            'title': '🌐 Podcasts auf schwarzwaldradio.com öffnen',
            'url': 'https://www.schwarzwaldradio.com/mediathek/podcast/aus-dem-programm/'
        },
        {
            'title': '🌐 Schwarzwaldradio bei TuneIn',
            'url': 'https://tunein.com/radio/Schwarzwaldradio-s96770/'
        },
    ]

    from resources.lib.ui import build_url
    for item in fallback_items:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
        url = build_url(base_url, {'mode': 'open_website', 'url': item['url']})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)


def play_podcast(handle, url, title, addon):
    """Startet die Wiedergabe eines Podcast/einer Sendung."""
    xbmc.log('[Schwarzwaldradio] Spiele Podcast: {0}'.format(url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
    li.setInfo('music', {
        'title': title,
        'artist': 'Schwarzwaldradio',
    })
    xbmcplugin.setResolvedUrl(handle, True, li)


# -----------------------------------------------------------------------
# Hilfsfunktionen
# -----------------------------------------------------------------------

def _get_text(element, tag, ns=None):
    """Gibt den Textinhalt eines XML-Elements zurück."""
    try:
        if ns:
            child = element.find(tag, ns)
        else:
            child = element.find(tag)
        if child is not None and child.text:
            return child.text.strip()
    except Exception:
        pass
    return ''


def _strip_html(text):
    """Entfernt einfache HTML-Tags aus einem String."""
    import re
    if not text:
        return ''
    clean = re.sub(r'<[^>]+>', '', text)
    return clean.strip()


def _parse_duration(duration_str):
    """Parst Dauer-Strings (HH:MM:SS oder MM:SS oder Sekunden) in Sekunden."""
    try:
        if ':' in str(duration_str):
            parts = str(duration_str).split(':')
            parts = [int(p) for p in parts]
            if len(parts) == 3:
                return parts[0] * 3600 + parts[1] * 60 + parts[2]
            elif len(parts) == 2:
                return parts[0] * 60 + parts[1]
        else:
            return int(duration_str)
    except (ValueError, TypeError):
        return 0
