#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interaktives Modul: Musikwunsch, Wetter melden, Schwarzwaldtaler-Login,
Kontakt, Grüße und Gewinnspiele direkt aus Kodi heraus.

Technischer Hinweis:
  Die Website nutzt WordPress/CF7-Formulare. Da kein öffentliches API
  existiert, werden Formulare per HTTP-POST an die Website gesendet –
  identisch wie es der Browser tut. Cookies/Session werden im Addon-
  Storage gespeichert (xbmcaddon settings).
"""

import json
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from urllib.request  import urlopen, Request, build_opener, HTTPCookieProcessor
from urllib.parse    import urlencode, quote
from urllib.error    import URLError
from http.cookiejar  import CookieJar

from resources.lib.ui import ADDON_ICON, ADDON_FANART, build_url, add_directory_item

UA       = 'Mozilla/5.0 (compatible; Kodi Schwarzwaldradio Addon/1.0)'
BASE_URL = 'https://www.schwarzwaldradio.com'

# Formular-Endpunkte (WordPress Contact Form 7 / eigene Formulare)
URL_MUSIKWUNSCH  = f'{BASE_URL}/musikwunsch/'
URL_WETTER       = f'{BASE_URL}/wetter-melden/'
URL_KONTAKT      = f'{BASE_URL}/kontakt/'
URL_LOGIN        = f'{BASE_URL}/schwarzwaldtaler-profil/'
URL_GEWINNSPIELE = f'{BASE_URL}/gewinnspiele/'

# Wetterbedingungen zur Auswahl
WETTER_BEDINGUNGEN = [
    'sonnig ☀️',
    'heiter 🌤️',
    'bewölkt ⛅',
    'bedeckt ☁️',
    'regnerisch 🌧️',
    'Gewitter ⛈️',
    'schneebedeckt ❄️',
    'neblig 🌫️',
    'windig 💨',
    'Hagel 🌨️',
]

WINDRICHTUNGEN = ['Nord', 'Nordost', 'Ost', 'Südost', 'Süd', 'Südwest', 'West', 'Nordwest']


# -----------------------------------------------------------------------
#  MUSIKWUNSCH
# -----------------------------------------------------------------------

def musikwunsch(base_url, handle, addon):
    """Interaktiver Musikwunsch-Dialog."""
    dialog = xbmcgui.Dialog()

    dialog.ok(
        'Musikwunsch – Schwarzwaldradio',
        'Sende deinen Musikwunsch direkt ans Studio!\n'
        'Du wirst durch ein kurzes Formular geführt.'
    )

    # Eingaben sammeln
    name = dialog.input('Dein Name', type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return

    ort = dialog.input('Dein Wohnort', type=xbmcgui.INPUT_ALPHANUM)
    if not ort:
        return

    interpret = dialog.input('Interpret / Künstler', type=xbmcgui.INPUT_ALPHANUM)
    if not interpret:
        return

    titel = dialog.input('Songtitel', type=xbmcgui.INPUT_ALPHANUM)
    if not titel:
        return

    # Optional: Widmung
    widmung_choice = dialog.yesno(
        'Musikwunsch',
        'Möchtest du eine Grußbotschaft oder Widmung hinzufügen?'
    )
    widmung = ''
    if widmung_choice:
        widmung = dialog.input('Deine Grußbotschaft / Widmung', type=xbmcgui.INPUT_ALPHANUM)

    # Bestätigung anzeigen
    confirm = dialog.yesno(
        'Musikwunsch bestätigen',
        f'Name: {name}\n'
        f'Ort: {ort}\n'
        f'Wunsch: {interpret} – {titel}\n'
        f'{"Gruß: " + widmung if widmung else ""}\n\n'
        f'Jetzt absenden?',
        nolabel='Abbrechen',
        yeslabel='Absenden ✉️'
    )

    if not confirm:
        return

    success = _send_musikwunsch(name, ort, interpret, titel, widmung)

    if success:
        dialog.ok(
            '✅ Musikwunsch gesendet!',
            f'Dein Wunsch für "{interpret} – {titel}" wurde ans Studio übermittelt.\n\n'
            f'Vielleicht hörst du ihn bald auf Schwarzwaldradio! 🎶'
        )
    else:
        # Fallback: Website öffnen
        choice = dialog.yesno(
            'Musikwunsch',
            'Direktübertragung nicht möglich.\n'
            'Möchtest du die Musikwunsch-Seite im Browser öffnen?',
            nolabel='Abbrechen',
            yeslabel='Website öffnen'
        )
        if choice:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{URL_MUSIKWUNSCH})')

    xbmcplugin.endOfDirectory(handle, succeeded=False)


def _send_musikwunsch(name, ort, interpret, titel, widmung=''):
    """Sendet den Musikwunsch per POST an die Website."""
    try:
        # Erst Nonce/Token von der Seite holen
        nonce = _get_cf7_nonce(URL_MUSIKWUNSCH)

        post_data = {
            'your-name':     name,
            'your-city':     ort,
            'your-artist':   interpret,
            'your-song':     titel,
            'your-message':  widmung,
            '_wpcf7_is_ajax_call': '1',
        }
        if nonce:
            post_data['_wpnonce'] = nonce

        encoded = urlencode(post_data).encode('utf-8')
        req = Request(
            URL_MUSIKWUNSCH,
            data=encoded,
            headers={
                'User-Agent':   UA,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Referer':      URL_MUSIKWUNSCH,
                'Origin':       BASE_URL,
                'X-Requested-With': 'XMLHttpRequest',
            }
        )
        resp = urlopen(req, timeout=12)
        body = resp.read().decode('utf-8', errors='replace')
        xbmc.log(f'[Schwarzwaldradio] Musikwunsch Response: {body[:200]}', xbmc.LOGDEBUG)
        return resp.status == 200
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Musikwunsch-Fehler: {e}', xbmc.LOGWARNING)
        return False


# -----------------------------------------------------------------------
#  WETTER MELDEN
# -----------------------------------------------------------------------

def wetter_melden(base_url, handle, addon):
    """Interaktiver Wetter-Melde-Dialog."""
    dialog = xbmcgui.Dialog()

    dialog.ok(
        '🌤️ Wetter melden – Schwarzwaldradio',
        'Melde dein lokales Wetter ans Studio!\n'
        'Dein Bericht kann im Programm erwähnt werden.'
    )

    # Name & Ort
    name = dialog.input('Dein Name', type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return

    ort = dialog.input('Dein Ort / Stadt', type=xbmcgui.INPUT_ALPHANUM)
    if not ort:
        return

    plz = dialog.input('Postleitzahl (optional)', type=xbmcgui.INPUT_NUMERIC)

    # Temperatur
    temp_str = dialog.input(
        'Aktuelle Temperatur (°C)',
        defaultt='',
        type=xbmcgui.INPUT_NUMERIC
    )
    temperatur = temp_str if temp_str else '?'

    # Wetterbedingung auswählen
    bedingung_idx = dialog.select(
        'Wetterbedingung auswählen',
        WETTER_BEDINGUNGEN
    )
    if bedingung_idx < 0:
        return
    bedingung = WETTER_BEDINGUNGEN[bedingung_idx]

    # Windstärke (optional)
    wind_choice = dialog.yesno('Wetter melden', 'Möchtest du auch Wind angeben?')
    windstaerke = ''
    windrichtung = ''
    if wind_choice:
        windstaerke = dialog.input('Windstärke (km/h)', type=xbmcgui.INPUT_NUMERIC)
        wind_idx = dialog.select('Windrichtung', WINDRICHTUNGEN)
        if wind_idx >= 0:
            windrichtung = WINDRICHTUNGEN[wind_idx]

    # Niederschlag
    niederschlag_choice = dialog.yesno('Wetter melden', 'Gibt es Niederschlag?')
    niederschlag = ''
    if niederschlag_choice:
        niederschlag = dialog.input(
            'Niederschlag beschreiben (z.B. leichter Regen)',
            type=xbmcgui.INPUT_ALPHANUM
        )

    # Freitext / Besonderheiten
    besonderheit = dialog.input(
        'Besonderheiten oder Anmerkungen (optional)',
        type=xbmcgui.INPUT_ALPHANUM
    )

    # Zusammenfassung & Bestätigung
    wind_info = f'\nWind: {windstaerke} km/h aus {windrichtung}' if windstaerke else ''
    nied_info = f'\nNiederschlag: {niederschlag}' if niederschlag else ''
    bes_info  = f'\nBesonderheit: {besonderheit}' if besonderheit else ''

    confirm = dialog.yesno(
        'Wettermeldung bestätigen',
        f'Von: {name} aus {ort} {plz}\n'
        f'Temperatur: {temperatur} °C\n'
        f'Bedingung: {bedingung}'
        f'{wind_info}{nied_info}{bes_info}\n\n'
        f'Jetzt melden?',
        nolabel='Abbrechen',
        yeslabel='Melden ☁️'
    )

    if not confirm:
        return

    # Nachricht aufbauen
    wetter_text = (
        f'Wetter aus {ort}{" (" + plz + ")" if plz else ""}:\n'
        f'Temperatur: {temperatur} °C, {bedingung}'
        f'{wind_info}{nied_info}{bes_info}'
    )

    success = _send_wetter(name, ort, plz, temperatur, bedingung,
                            windstaerke, windrichtung, niederschlag, besonderheit)

    if success:
        dialog.ok(
            '✅ Wetter gemeldet!',
            f'Danke, {name}! Dein Wetterbericht aus {ort} wurde übermittelt.\n\n'
            f'{temperatur} °C, {bedingung}'
        )
    else:
        choice = dialog.yesno(
            'Wetter melden',
            'Direktübertragung nicht möglich.\n'
            'Möchtest du die Wetter-Seite im Browser öffnen?',
            nolabel='Abbrechen',
            yeslabel='Website öffnen'
        )
        if choice:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{URL_WETTER})')

    xbmcplugin.endOfDirectory(handle, succeeded=False)


def _send_wetter(name, ort, plz, temp, bedingung, wind='', windrichtung='',
                 niederschlag='', besonderheit=''):
    """Sendet die Wettermeldung per POST."""
    try:
        nonce = _get_cf7_nonce(URL_WETTER)

        nachricht = (
            f'Wetter aus {ort}{" (" + plz + ")" if plz else ""}:\n'
            f'Temperatur: {temp} °C\n'
            f'Bedingung: {bedingung}\n'
        )
        if wind:
            nachricht += f'Wind: {wind} km/h aus {windrichtung}\n'
        if niederschlag:
            nachricht += f'Niederschlag: {niederschlag}\n'
        if besonderheit:
            nachricht += f'Besonderheit: {besonderheit}\n'

        post_data = {
            'your-name':        name,
            'your-city':        ort,
            'your-zip':         plz or '',
            'your-temperature': temp,
            'your-condition':   bedingung.split()[0],  # Ohne Emoji
            'your-wind':        wind or '',
            'your-winddir':     windrichtung or '',
            'your-message':     nachricht,
            '_wpcf7_is_ajax_call': '1',
        }
        if nonce:
            post_data['_wpnonce'] = nonce

        encoded = urlencode(post_data).encode('utf-8')
        req = Request(
            URL_WETTER,
            data=encoded,
            headers={
                'User-Agent':        UA,
                'Content-Type':      'application/x-www-form-urlencoded',
                'Referer':           URL_WETTER,
                'Origin':            BASE_URL,
                'X-Requested-With':  'XMLHttpRequest',
            }
        )
        resp = urlopen(req, timeout=12)
        return resp.status == 200
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Wetter-Fehler: {e}', xbmc.LOGWARNING)
        return False


# -----------------------------------------------------------------------
#  LOGIN / SCHWARZWALDTALER
# -----------------------------------------------------------------------

def show_login_menu(base_url, handle, addon):
    """Zeigt Login-Menü oder Profil je nach Status."""
    xbmcplugin.setPluginCategory(handle, '🔑 Schwarzwaldtaler')

    _addon      = xbmcaddon.Addon()
    is_logged   = bool(_addon.getSetting('session_cookie'))
    username    = _addon.getSetting('username') or ''

    if is_logged:
        # Eingeloggt: Profil-Optionen
        items = [
            ('👤  Profil ansehen',       {'mode': 'profil'}),
            ('🏅  Punkte & Status',      {'mode': 'profil'}),
            ('🌐  Mein Konto (Website)', {'mode': 'open_website',
                                          'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler-profil/'}),
            ('🚪  Abmelden',             {'mode': 'do_logout'}),
        ]
        desc_header = f'Eingeloggt als: {username}\n\nWas möchtest du tun?'
        xbmcgui.Dialog().notification('Schwarzwaldtaler', f'Hallo, {username}! 👋',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        # Ausgeloggt: Login-Optionen
        items = [
            ('🔑  Jetzt einloggen',              {'mode': 'do_login'}),
            ('📝  Neu registrieren (Website)',    {'mode': 'open_website',
                                                   'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler-registrierung/'}),
            ('❓  Was sind Schwarzwaldtaler?',   {'mode': 'open_website',
                                                   'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler/'}),
            ('🏆  Prämien & Partner',            {'mode': 'open_website',
                                                   'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler-praemien/'}),
        ]

    for label, params in items:
        add_directory_item(handle=handle, base_url=base_url, label=label, params=params)

    xbmcplugin.endOfDirectory(handle)


def do_login(base_url, handle, addon):
    """Login-Dialog und Authentifizierung."""
    dialog = xbmcgui.Dialog()
    _addon = xbmcaddon.Addon()

    # Gespeicherte Zugangsdaten vorausfüllen
    saved_user = _addon.getSetting('username') or ''

    username = dialog.input(
        'Schwarzwaldtaler – E-Mail-Adresse',
        defaultt=saved_user,
        type=xbmcgui.INPUT_ALPHANUM
    )
    if not username:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    password = dialog.input(
        'Passwort',
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT
    )
    if not password:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # Login-Versuch
    xbmc.log('[Schwarzwaldradio] Login-Versuch...', xbmc.LOGINFO)
    session_cookie, display_name = _do_wp_login(username, password)

    if session_cookie:
        # Zugangsdaten speichern (Passwort NICHT im Klartext – nur Session-Cookie)
        _addon.setSetting('username', display_name or username)
        _addon.setSetting('session_cookie', session_cookie)

        dialog.ok(
            '✅ Login erfolgreich!',
            f'Willkommen zurück, {display_name or username}! 👋\n\n'
            f'Du bist jetzt mit deinem Schwarzwaldtaler-Konto verbunden.'
        )
        xbmc.executebuiltin('Container.Refresh')
    else:
        retry = dialog.yesno(
            '❌ Login fehlgeschlagen',
            'E-Mail oder Passwort falsch, oder die Website ist gerade nicht erreichbar.\n\n'
            'Tipp: Prüfe deine Zugangsdaten auf schwarzwaldradio.com.',
            nolabel='Abbrechen',
            yeslabel='Erneut versuchen'
        )
        if retry:
            do_login(base_url, handle, addon)
            return

    xbmcplugin.endOfDirectory(handle, succeeded=False)


def _do_wp_login(username, password):
    """
    Führt WordPress-Login durch.
    Gibt (session_cookie, display_name) zurück oder (None, None) bei Fehler.
    """
    try:
        cj      = CookieJar()
        opener  = build_opener(HTTPCookieProcessor(cj))

        login_url = f'{BASE_URL}/wp-login.php'

        post_data = urlencode({
            'log':         username,
            'pwd':         password,
            'wp-submit':   'Anmelden',
            'redirect_to': f'{BASE_URL}/schwarzwaldtaler-profil/',
            'testcookie':  '1',
        }).encode('utf-8')

        req = Request(
            login_url,
            data=post_data,
            headers={
                'User-Agent':   UA,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Referer':      login_url,
                'Origin':       BASE_URL,
            }
        )

        resp   = opener.open(req, timeout=15)
        body   = resp.read().decode('utf-8', errors='replace')
        final  = resp.geturl()

        # Login-Erfolg: Weiterleitung auf Profil-Seite, kein "Login" mehr in URL
        if 'wp-login.php' not in final and 'login' not in final.lower():
            # Session-Cookie aus CookieJar extrahieren
            cookie_str = '; '.join(
                f'{c.name}={c.value}' for c in cj
                if 'wordpress' in c.name.lower() or 'wp_' in c.name.lower()
            )

            # Display-Name aus Profil-Seite extrahieren
            display_name = _extract_display_name(body)

            xbmc.log(f'[Schwarzwaldradio] Login OK, Cookie: {cookie_str[:40]}...', xbmc.LOGINFO)
            return cookie_str, display_name
        else:
            xbmc.log('[Schwarzwaldradio] Login fehlgeschlagen (Redirect zurück zu Login)', xbmc.LOGWARNING)
            return None, None

    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Login-Fehler: {e}', xbmc.LOGWARNING)
        return None, None


def _extract_display_name(html):
    """Extrahiert den Anzeigenamen aus dem HTML der Profilseite."""
    patterns = [
        r'<h1[^>]*class="[^"]*user[^"]*"[^>]*>([^<]+)</h1>',
        r'Hallo,?\s+([A-ZÄÖÜa-zäöüß][^<!\n]{1,40})[!<]',
        r'"displayName"\s*:\s*"([^"]+)"',
        r'display.name["\s:]+([A-ZÄÖÜa-zäöüß][^\s",<]{1,40})',
    ]
    for pat in patterns:
        m = re.search(pat, html)
        if m:
            return m.group(1).strip()
    return ''


def do_logout(base_url, handle, addon):
    """Meldet den Nutzer ab und löscht gespeicherte Session."""
    _addon = xbmcaddon.Addon()
    confirm = xbmcgui.Dialog().yesno(
        'Abmelden',
        'Möchtest du dich wirklich vom Schwarzwaldtaler-Konto abmelden?',
        nolabel='Abbrechen',
        yeslabel='Abmelden'
    )
    if confirm:
        _addon.setSetting('session_cookie', '')
        _addon.setSetting('username', '')
        xbmcgui.Dialog().notification(
            'Schwarzwaldradio', 'Erfolgreich abgemeldet. 👋',
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        xbmc.executebuiltin('Container.Refresh')
    xbmcplugin.endOfDirectory(handle, succeeded=False)


def show_profil(base_url, handle, addon):
    """Zeigt Profilinformationen des eingeloggten Nutzers."""
    _addon   = xbmcaddon.Addon()
    username = _addon.getSetting('username') or 'Unbekannt'
    cookie   = _addon.getSetting('session_cookie') or ''

    xbmcplugin.setPluginCategory(handle, f'Profil – {username}')

    profil_daten = _fetch_profil(cookie) if cookie else {}

    # Profilinfos als nicht-klickbare Items anzeigen
    punkte   = profil_daten.get('punkte',   '–')
    status   = profil_daten.get('status',   '–')
    mitglied = profil_daten.get('mitglied', '–')

    infos = [
        (f'👤  Name:          {username}',   {}),
        (f'🏅  Punkte:        {punkte}',      {}),
        (f'⭐  Status:        {status}',      {}),
        (f'📅  Mitglied seit: {mitglied}',    {}),
        ('🌐  Vollständiges Profil (Website)',
         {'mode': 'open_website', 'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler-profil/'}),
        ('🏆  Prämien einlösen',
         {'mode': 'open_website', 'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler-praemien/'}),
        ('📊  Umfragen teilnehmen',
         {'mode': 'open_website', 'url': 'https://www.schwarzwaldradio.com/umfragen/'}),
    ]

    for label, params in infos:
        if params:
            add_directory_item(handle=handle, base_url=base_url, label=label, params=params)
        else:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART})
            xbmcplugin.addDirectoryItem(handle=handle, url='', listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


def _fetch_profil(cookie):
    """Versucht Profildaten von der Website zu lesen."""
    try:
        req = Request(
            f'{BASE_URL}/schwarzwaldtaler-profil/',
            headers={
                'User-Agent': UA,
                'Cookie':     cookie,
            }
        )
        resp = urlopen(req, timeout=10)
        html = resp.read().decode('utf-8', errors='replace')

        data = {}
        # Punkte
        m = re.search(r'(\d[\d.]*)\s*(?:Punkte|Taler)', html, re.IGNORECASE)
        if m:
            data['punkte'] = m.group(1)
        # Status
        m = re.search(r'Status[:\s]+([A-ZÄÖÜa-zäöüß][^\s<]{2,20})', html)
        if m:
            data['status'] = m.group(1)
        return data
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Profil-Fetch-Fehler: {e}', xbmc.LOGDEBUG)
        return {}


# -----------------------------------------------------------------------
#  KONTAKT & GRÜSSE
# -----------------------------------------------------------------------

def kontakt(base_url, handle, addon):
    """Kontaktformular – Nachricht oder Gruß ans Studio senden."""
    dialog = xbmcgui.Dialog()

    # Art der Nachricht
    typ_idx = dialog.select(
        'Was möchtest du senden?',
        [
            '💬  Gruß ans Studio',
            '🎂  Geburtstagswunsch',
            '❓  Frage oder Anregung',
            '📣  Allgemeine Nachricht',
        ]
    )
    if typ_idx < 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    typen = ['Gruß ans Studio', 'Geburtstagswunsch', 'Frage oder Anregung', 'Nachricht']
    typ   = typen[typ_idx]

    name = dialog.input('Dein Name', type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    ort = dialog.input('Dein Wohnort', type=xbmcgui.INPUT_ALPHANUM)

    email = dialog.input('E-Mail-Adresse (für Rückantwort)', type=xbmcgui.INPUT_ALPHANUM)

    nachricht = dialog.input(
        f'Deine {typ}',
        type=xbmcgui.INPUT_ALPHANUM
    )
    if not nachricht:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    confirm = dialog.yesno(
        f'{typ} bestätigen',
        f'Von: {name}{" aus " + ort if ort else ""}\n'
        f'Nachricht: {nachricht[:80]}{"..." if len(nachricht) > 80 else ""}\n\n'
        f'Jetzt absenden?',
        nolabel='Abbrechen',
        yeslabel='Absenden ✉️'
    )

    if not confirm:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    success = _send_kontakt(name, ort, email, typ, nachricht)

    if success:
        dialog.ok(
            '✅ Nachricht gesendet!',
            f'Danke, {name}! Deine Nachricht wurde ans Studio übermittelt. 📻'
        )
    else:
        choice = dialog.yesno(
            'Kontakt',
            'Direktübertragung nicht möglich.\n'
            'Möchtest du das Kontaktformular im Browser öffnen?',
            nolabel='Abbrechen',
            yeslabel='Website öffnen'
        )
        if choice:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{URL_KONTAKT})')

    xbmcplugin.endOfDirectory(handle, succeeded=False)


def _send_kontakt(name, ort, email, typ, nachricht):
    """Sendet Kontaktnachricht per POST."""
    try:
        nonce = _get_cf7_nonce(URL_KONTAKT)

        full_msg = f'[{typ}]\n\nVon: {name}{" aus " + ort if ort else ""}\n\n{nachricht}'

        post_data = {
            'your-name':    name,
            'your-city':    ort or '',
            'your-email':   email or '',
            'your-subject': typ,
            'your-message': full_msg,
            '_wpcf7_is_ajax_call': '1',
        }
        if nonce:
            post_data['_wpnonce'] = nonce

        encoded = urlencode(post_data).encode('utf-8')
        req = Request(
            URL_KONTAKT,
            data=encoded,
            headers={
                'User-Agent':       UA,
                'Content-Type':     'application/x-www-form-urlencoded',
                'Referer':          URL_KONTAKT,
                'Origin':           BASE_URL,
                'X-Requested-With': 'XMLHttpRequest',
            }
        )
        resp = urlopen(req, timeout=12)
        return resp.status == 200
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Kontakt-Fehler: {e}', xbmc.LOGWARNING)
        return False


# -----------------------------------------------------------------------
#  GEWINNSPIELE
# -----------------------------------------------------------------------

def gewinnspiel(base_url, handle, addon):
    """Zeigt aktuelle Gewinnspiele und ermöglicht die Teilnahme."""
    xbmcplugin.setPluginCategory(handle, '🎁 Gewinnspiele')

    spiele = _fetch_gewinnspiele()

    if spiele:
        for spiel in spiele:
            title = spiel.get('title', 'Gewinnspiel')
            url   = spiel.get('url',   URL_GEWINNSPIELE)
            desc  = spiel.get('desc',  '')
            add_directory_item(
                handle=handle,
                base_url=base_url,
                label=f'🎁  {title}',
                params={'mode': 'open_website', 'url': url},
                description=desc
            )
    else:
        # Fallback: direkt zur Gewinnspiel-Seite
        add_directory_item(
            handle=handle,
            base_url=base_url,
            label='🌐  Gewinnspiele auf schwarzwaldradio.com',
            params={'mode': 'open_website', 'url': URL_GEWINNSPIELE},
            description='Alle aktuellen Gewinnspiele auf der Website'
        )
        add_directory_item(
            handle=handle,
            base_url=base_url,
            label='🏅  Schwarzwaldtaler Aktionen',
            params={'mode': 'open_website',
                    'url': 'https://www.schwarzwaldradio.com/aktionen/schwarzwaldradio-talerregen/'},
            description='Talerregen und Sonderaktionen'
        )

    xbmcplugin.endOfDirectory(handle)


def _fetch_gewinnspiele():
    """Versucht Gewinnspiele per RSS zu laden."""
    try:
        import xml.etree.ElementTree as ET
        rss_url = f'{BASE_URL}/gewinnspiele/feed/'
        req     = Request(rss_url, headers={'User-Agent': UA})
        resp    = urlopen(req, timeout=8)
        root    = ET.fromstring(resp.read())
        ch      = root.find('channel')
        spiele  = []
        if ch:
            for item in ch.findall('item')[:10]:
                t = item.find('title')
                l = item.find('link')
                d = item.find('description')
                if t is not None and t.text:
                    link = l.text.strip() if l is not None and l.text else URL_GEWINNSPIELE
                    desc = re.sub(r'<[^>]+>', '', d.text or '').strip()[:120] if d is not None else ''
                    spiele.append({'title': t.text.strip(), 'url': link, 'desc': desc})
        return spiele
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Gewinnspiel-Fehler: {e}', xbmc.LOGDEBUG)
        return []


# -----------------------------------------------------------------------
#  HILFSFUNKTIONEN
# -----------------------------------------------------------------------

def _get_cf7_nonce(page_url):
    """
    Lädt eine Website-Seite und extrahiert den WordPress CF7-Nonce/Token
    für CSRF-Schutz bei Formular-Übertragungen.
    """
    try:
        req  = Request(page_url, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=10)
        html = resp.read().decode('utf-8', errors='replace')

        # CF7 Nonce
        patterns = [
            r'"nonce"\s*:\s*"([a-f0-9]+)"',
            r'_wpnonce["\s:=]+([a-f0-9]{10})',
            r'wpcf7\s*=\s*\{[^}]*"nonce"\s*:\s*"([^"]+)"',
        ]
        for pat in patterns:
            m = re.search(pat, html)
            if m:
                return m.group(1)
    except Exception as e:
        xbmc.log(f'[Schwarzwaldradio] Nonce-Fehler für {page_url}: {e}', xbmc.LOGDEBUG)
    return None
