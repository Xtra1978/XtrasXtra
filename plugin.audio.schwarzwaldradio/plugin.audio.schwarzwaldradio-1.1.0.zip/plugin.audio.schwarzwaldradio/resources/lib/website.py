#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Website-Modul: Zugang zu Inhalten von schwarzwaldradio.com
News, Programm, Moderatoren, Kontakt, Social Media etc.
"""

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, quote
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError
    from urllib import urlencode, quote

import xbmc
import xbmcgui
import xbmcplugin
from resources.lib.ui import ADDON_ICON, ADDON_FANART, add_directory_item, build_url

USER_AGENT = 'Mozilla/5.0 (compatible; Kodi Schwarzwaldradio Addon/1.0)'

# Alle bekannten Bereiche der schwarzwaldradio.com-Website
WEBSITE_SECTIONS = [
    {
        'id': 'news',
        'title': '📰 Neuigkeiten & News',
        'url': 'https://www.schwarzwaldradio.com/news/',
        'description': 'Aktuelle Nachrichten und Neuigkeiten von Schwarzwaldradio'
    },
    {
        'id': 'programm',
        'title': '📅 Programm & Sendungen',
        'url': 'https://www.schwarzwaldradio.com/programm/',
        'description': 'Das aktuelle Programm und Sendeschema'
    },
    {
        'id': 'musik',
        'title': '🎵 Musik & Playlist',
        'url': 'https://www.schwarzwaldradio.com/musik/',
        'description': 'Aktuelle Playlist und Musikinformationen'
    },
    {
        'id': 'moderatoren',
        'title': '🎤 Moderatoren & Team',
        'url': 'https://www.schwarzwaldradio.com/moderatoren/',
        'description': 'Das Team hinter Schwarzwaldradio'
    },
    {
        'id': 'mediathek',
        'title': '🎙️ Mediathek / Podcast',
        'url': 'https://www.schwarzwaldradio.com/mediathek/',
        'description': 'Sendungen zum Nachhören'
    },
    {
        'id': 'empfang',
        'title': '📡 Empfang & Frequenzen',
        'url': 'https://www.schwarzwaldradio.com/empfang/',
        'description': 'UKW, DAB+, Kabel, Internet – alle Empfangswege'
    },
    {
        'id': 'schwarzwaldtaler',
        'title': '🏅 Schwarzwaldtaler Bonusprogramm',
        'url': 'https://www.schwarzwaldradio.com/schwarzwaldtaler/',
        'description': 'Das Bonusprogramm von Schwarzwaldradio'
    },
    {
        'id': 'gewinnspiele',
        'title': '🎁 Gewinnspiele',
        'url': 'https://www.schwarzwaldradio.com/gewinnspiele/',
        'description': 'Aktuelle Gewinnspiele'
    },
    {
        'id': 'veranstaltungen',
        'title': '🎪 Veranstaltungen',
        'url': 'https://www.schwarzwaldradio.com/veranstaltungen/',
        'description': 'Events und Veranstaltungen rund um Schwarzwaldradio'
    },
    {
        'id': 'kontakt',
        'title': '📬 Kontakt & Wunschsendung',
        'url': 'https://www.schwarzwaldradio.com/kontakt/',
        'description': 'Kontakt aufnehmen oder einen Musikwunsch senden'
    },
    {
        'id': 'ueber',
        'title': 'ℹ️ Über Schwarzwaldradio',
        'url': 'https://www.schwarzwaldradio.com/ueber-uns/',
        'description': 'Informationen über den Sender'
    },
    {
        'id': 'app',
        'title': '📱 App & Social Media',
        'url': 'https://www.schwarzwaldradio.com/app/',
        'description': 'Die Schwarzwaldradio-App und Social-Media-Kanäle'
    },
]

# Externe Links (Social Media, TuneIn etc.)
EXTERNAL_LINKS = [
    {
        'title': '🎵 Schwarzwaldradio bei TuneIn',
        'url': 'https://tunein.com/radio/Schwarzwaldradio-s96770/'
    },
    {
        'title': '📻 Schwarzwaldradio bei radio.de',
        'url': 'https://www.radio.de/s/schwarzwaldradio'
    },
    {
        'title': '🌍 Schwarzwaldradio auf Wikipedia',
        'url': 'https://de.wikipedia.org/wiki/Schwarzwaldradio'
    },
]


def show_website_menu(base_url, handle, addon):
    """Zeigt das Website-Menü."""
    xbmcplugin.setPluginCategory(handle, 'Website-Inhalte – Schwarzwaldradio')
    xbmcplugin.setContent(handle, 'files')

    for section in WEBSITE_SECTIONS:
        add_directory_item(
            handle=handle,
            base_url=base_url,
            label=section['title'],
            params={
                'mode': 'website_section',
                'section': section['id']
            },
            description=section['description']
        )

    # Externe Links
    add_directory_item(
        handle=handle,
        base_url=base_url,
        label='🔗 Externe Links & Partner',
        params={'mode': 'website_section', 'section': 'external'},
        description='TuneIn, radio.de, Wikipedia und weitere Partner'
    )

    xbmcplugin.endOfDirectory(handle)


def show_section(base_url, handle, addon, section):
    """Zeigt den Inhalt einer Website-Sektion."""
    xbmcplugin.setContent(handle, 'files')

    if section == 'external':
        _show_external_links(base_url, handle)
        return

    # Passende Sektion suchen
    section_data = next((s for s in WEBSITE_SECTIONS if s['id'] == section), None)
    if not section_data:
        xbmcplugin.endOfDirectory(handle)
        return

    xbmcplugin.setPluginCategory(handle, section_data['title'])

    # Versuche Inhalt zu laden und anzuzeigen
    items = _fetch_section_content(section_data)

    if items:
        for item in items:
            li = xbmcgui.ListItem(label=item.get('title', ''))
            li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
            if item.get('description'):
                li.setInfo('video', {'plot': item['description']})

            item_url = build_url(base_url, {
                'mode': 'open_website',
                'url': item.get('url', section_data['url'])
            })
            xbmcplugin.addDirectoryItem(handle=handle, url=item_url, listitem=li, isFolder=False)
    else:
        # Fallback: Nur den direkten Link zur Seite anzeigen
        li = xbmcgui.ListItem(label='🌐 {0} im Browser öffnen'.format(section_data['title']))
        li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
        li.setInfo('video', {'plot': section_data['description']})
        open_url = build_url(base_url, {
            'mode': 'open_website',
            'url': section_data['url']
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=open_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


def _show_external_links(base_url, handle):
    """Zeigt externe Links."""
    xbmcplugin.setPluginCategory(handle, 'Externe Links')
    for link in EXTERNAL_LINKS:
        li = xbmcgui.ListItem(label=link['title'])
        li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
        url = build_url(base_url, {'mode': 'open_website', 'url': link['url']})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)


def _fetch_section_content(section_data):
    """
    Versucht, strukturierten Inhalt einer Website-Sektion zu laden.
    Gibt eine Liste von Items zurück oder eine leere Liste.
    """
    # Für Programm-/Playlist-Seiten: Direktlink bevorzugen
    # Für News: Versuche RSS-Feed
    if section_data['id'] == 'news':
        return _fetch_news_rss()

    # Für andere Sektionen: leere Liste → Fallback auf Browser
    return []


def _fetch_news_rss():
    """Versucht News per RSS zu laden."""
    rss_urls = [
        'https://www.schwarzwaldradio.com/feed/',
        'https://www.schwarzwaldradio.com/news/feed/',
    ]

    try:
        import xml.etree.ElementTree as ET
    except ImportError:
        return []

    for rss_url in rss_urls:
        try:
            req = Request(rss_url, headers={'User-Agent': USER_AGENT})
            response = urlopen(req, timeout=10)
            content = response.read()
            root = ET.fromstring(content)
            channel = root.find('channel')
            if channel is None:
                continue

            items = []
            for item in channel.findall('item')[:20]:
                title_el = item.find('title')
                link_el = item.find('link')
                desc_el = item.find('description')

                title = title_el.text.strip() if title_el is not None and title_el.text else ''
                link = link_el.text.strip() if link_el is not None and link_el.text else ''
                desc = desc_el.text.strip() if desc_el is not None and desc_el.text else ''

                if title and link:
                    import re
                    desc_clean = re.sub(r'<[^>]+>', '', desc).strip()
                    items.append({
                        'title': '📰 {0}'.format(title),
                        'url': link,
                        'description': desc_clean,
                    })

            if items:
                return items

        except Exception as e:
            xbmc.log('[Schwarzwaldradio] News-RSS-Fehler: {0}'.format(str(e)), xbmc.LOGWARNING)

    return []


def open_in_browser(url):
    """Öffnet eine URL im Kodi-internen Browser oder zeigt einen Dialog."""
    try:
        # Versuche xbmc.executebuiltin für den internen Browser
        xbmc.executebuiltin('StartAndroidActivity(com.android.chrome,,, {0})'.format(url))
    except Exception:
        pass

    # Universeller Ansatz: Dialog mit URL
    dialog = xbmcgui.Dialog()
    dialog.ok(
        'Schwarzwaldradio – Website',
        'Bitte öffne folgende URL in deinem Browser:\n\n{0}'.format(url)
    )
