#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
URL-Router für das Schwarzwaldradio Kodi Addon
"""

try:
    from urllib.parse import parse_qsl, urlencode, urlparse
except ImportError:
    from urlparse import parse_qsl, urlparse
    from urllib import urlencode

import xbmcplugin
from resources.lib import ui, streams, mediathek, website, playlist, interactive


def dispatch(base_url, handle, args, addon):
    """Hauptdispatcher: Wertet URL-Parameter aus und ruft passende Handler auf."""
    params = dict(parse_qsl(args.lstrip('?')))
    mode = params.get('mode', 'main')

    if mode == 'main':
        ui.show_main_menu(base_url, handle, addon)

    # ---- Live Streams ----
    elif mode == 'live_streams':
        streams.show_live_streams(base_url, handle, addon)

    elif mode == 'play_stream':
        url = params.get('url', '')
        title = params.get('title', 'Schwarzwaldradio')
        streams.play_stream(handle, url, title, addon)

    # ---- Mediathek ----
    elif mode == 'mediathek':
        mediathek.show_mediathek(base_url, handle, addon)

    elif mode == 'mediathek_category':
        category = params.get('category', '')
        mediathek.show_category(base_url, handle, addon, category)

    elif mode == 'play_podcast':
        url = params.get('url', '')
        title = params.get('title', 'Podcast')
        mediathek.play_podcast(handle, url, title, addon)

    # ---- Playlist / Was läuft gerade ----
    elif mode == 'playlist':
        playlist.show_playlist(base_url, handle, addon)

    # ---- Interaktive Funktionen ----
    elif mode == 'musikwunsch':
        interactive.musikwunsch(base_url, handle, addon)

    elif mode == 'wetter_melden':
        interactive.wetter_melden(base_url, handle, addon)

    elif mode == 'login':
        interactive.show_login_menu(base_url, handle, addon)

    elif mode == 'do_login':
        interactive.do_login(base_url, handle, addon)

    elif mode == 'do_logout':
        interactive.do_logout(base_url, handle, addon)

    elif mode == 'profil':
        interactive.show_profil(base_url, handle, addon)

    elif mode == 'kontakt':
        interactive.kontakt(base_url, handle, addon)

    elif mode == 'gewinnspiel':
        interactive.gewinnspiel(base_url, handle, addon)

    # ---- Website-Inhalte ----
    elif mode == 'website':
        website.show_website_menu(base_url, handle, addon)

    elif mode == 'website_section':
        section = params.get('section', '')
        website.show_section(base_url, handle, addon, section)

    elif mode == 'open_website':
        url = params.get('url', 'https://www.schwarzwaldradio.com')
        website.open_in_browser(url)

    else:
        ui.show_main_menu(base_url, handle, addon)
