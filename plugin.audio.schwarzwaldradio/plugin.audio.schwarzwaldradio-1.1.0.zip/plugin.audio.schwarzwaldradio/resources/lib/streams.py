#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Streams-Modul: Alle bekannten Live-Streams von Schwarzwaldradio
"""

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

import xbmc
import xbmcgui
import xbmcplugin
from resources.lib.ui import ADDON_ICON, ADDON_FANART, add_playable_item

# -----------------------------------------------------------------------
# Alle bekannten Stream-URLs von Schwarzwaldradio
# Quellen: streamonkey.net (offiziell), creacast.com, streamonkey HiFi
# -----------------------------------------------------------------------
LIVE_STREAMS = [
    {
        'title': '🎵 Schwarzwaldradio Live (MP3 – Empfohlen)',
        'url': 'https://frontend.streamonkey.net/fho-schwarzwaldradiolive/stream/mp3',
        'quality': 'MP3 128 kbps',
        'description': 'Offizieller Live-Stream via Streamonkey – MP3 128 kbps'
    },
    {
        'title': '🎵 Schwarzwaldradio Live (AAC HiFi)',
        'url': 'https://frontend.streamonkey.net/fho-schwarzwaldradiohifi',
        'quality': 'AAC HiFi',
        'description': 'Offizieller HiFi-Stream via Streamonkey – höchste Qualität'
    },
    {
        'title': '🎵 Schwarzwaldradio Live (AAC Stream)',
        'url': 'https://frontend.streamonkey.net/fho-schwarzwaldradiolive/aac-stream.m3u',
        'quality': 'AAC VBR 64–128 kbps',
        'description': 'AAC-Stream mit variabler Bitrate (VBR 64–128 kbps)'
    },
    {
        'title': '🎵 Schwarzwaldradio Live (M3U Playlist)',
        'url': 'https://frontend.streamonkey.net/fho-schwarzwaldradiolive/mp3-stream.m3u',
        'quality': 'MP3 Playlist',
        'description': 'Offizieller MP3-Stream als M3U-Playlist'
    },
    {
        'title': '🎵 Schwarzwaldradio (Creacast – Classic)',
        'url': 'http://str0.creacast.com/schwarzwaldradio.m3u',
        'quality': 'MP3',
        'description': 'Alternativer Stream via Creacast'
    },
    {
        'title': '🎵 Schwarzwaldradio (Creacast – Thema)',
        'url': 'http://str31.creacast.com:80/hitradio_ohr_thema1.m3u',
        'quality': 'MP3',
        'description': 'Alternativer Themen-Stream via Creacast'
    },
]


def show_live_streams(base_url, handle, addon):
    """Zeigt alle verfügbaren Live-Streams."""
    xbmcplugin.setPluginCategory(handle, 'Live Streams – Schwarzwaldradio')
    xbmcplugin.setContent(handle, 'songs')

    for stream in LIVE_STREAMS:
        info = {
            'title': stream['title'],
            'artist': 'Schwarzwaldradio',
            'album': 'Live Stream',
            'comment': stream['description'],
            'genre': 'Oldies, Classic Hits',
        }
        add_playable_item(
            handle=handle,
            base_url=base_url,
            label='{0}  [{1}]'.format(stream['title'], stream['quality']),
            params={
                'mode': 'play_stream',
                'url': stream['url'],
                'title': stream['title'],
            },
            info=info,
        )

    xbmcplugin.endOfDirectory(handle)


def play_stream(handle, url, title, addon):
    """Startet die Wiedergabe eines Streams."""
    xbmc.log('[Schwarzwaldradio] Spiele Stream: {0}'.format(url), xbmc.LOGINFO)

    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setArt({
        'icon': ADDON_ICON,
        'thumb': ADDON_ICON,
        'fanart': ADDON_FANART,
    })
    li.setInfo('music', {
        'title': title,
        'artist': 'Schwarzwaldradio',
        'genre': 'Oldies, Classic Hits',
    })
    # Für Radio-Streams: kein Caching
    li.setProperty('inputstream.adaptive.manifest_type', '')

    xbmcplugin.setResolvedUrl(handle, True, li)
