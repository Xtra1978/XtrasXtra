#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UI-Modul: Hauptmenü und Hilfsfunktionen für Listenelemente
"""

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

import xbmcgui
import xbmcplugin

ADDON_ICON = 'special://home/addons/plugin.audio.schwarzwaldradio/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.audio.schwarzwaldradio/resources/media/fanart.jpg'


def build_url(base_url, params):
    """Erstellt eine Plugin-URL aus Base-URL und Parameter-Dict."""
    return '{0}?{1}'.format(base_url, urlencode(params))


def add_directory_item(handle, base_url, label, params, icon=None, fanart=None, description=''):
    """Fügt ein Verzeichnis-Item (Ordner) zur Liste hinzu."""
    url = build_url(base_url, params)
    li = xbmcgui.ListItem(label=label)
    art = {
        'icon': icon or ADDON_ICON,
        'thumb': icon or ADDON_ICON,
        'fanart': fanart or ADDON_FANART,
    }
    li.setArt(art)
    if description:
        li.setInfo('music', {'comment': description})
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)


def add_playable_item(handle, base_url, label, params, icon=None, fanart=None,
                      info=None, content_type='music'):
    """Fügt ein abspielbares Item zur Liste hinzu."""
    url = build_url(base_url, params)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    art = {
        'icon': icon or ADDON_ICON,
        'thumb': icon or ADDON_ICON,
        'fanart': fanart or ADDON_FANART,
    }
    li.setArt(art)
    if info:
        li.setInfo(content_type, info)
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)


def show_main_menu(base_url, handle, addon):
    """Zeigt das Hauptmenü des Addons."""
    xbmcplugin.setPluginCategory(handle, 'Schwarzwaldradio')
    xbmcplugin.setContent(handle, 'songs')

    # Prüfe ob eingeloggt für dynamischen Login-Eintrag
    import xbmcaddon
    _addon = xbmcaddon.Addon()
    is_logged_in = bool(_addon.getSetting('session_cookie'))
    username = _addon.getSetting('username') or ''
    login_label = f'👤  Profil ({username})' if is_logged_in else '🔑  Schwarzwaldtaler Login'

    menu_items = [
        {
            'label': '📻  Live Stream hören',
            'params': {'mode': 'live_streams'},
            'description': 'Alle verfügbaren Live-Streams von Schwarzwaldradio'
        },
        {
            'label': '🎵  Was läuft gerade? (Playlist)',
            'params': {'mode': 'playlist'},
            'description': 'Aktuelle und vergangene Titel im Überblick'
        },
        {
            'label': '🎙️  Mediathek & Podcasts',
            'params': {'mode': 'mediathek'},
            'description': 'Vergangene Sendungen, Sondersendungen und Podcasts'
        },
        {
            'label': '🎶  Musikwunsch senden',
            'params': {'mode': 'musikwunsch'},
            'description': 'Deinen Lieblingstitel für die Sendung wünschen'
        },
        {
            'label': '🌤️  Wetter melden',
            'params': {'mode': 'wetter_melden'},
            'description': 'Dein lokales Wetter an Schwarzwaldradio melden'
        },
        {
            'label': login_label,
            'params': {'mode': 'login'},
            'description': 'Schwarzwaldtaler-Konto verwalten und Punkte sammeln'
        },
        {
            'label': '✉️  Kontakt & Grüße',
            'params': {'mode': 'kontakt'},
            'description': 'Nachricht oder Gruß ans Studio senden'
        },
        {
            'label': '🎁  Gewinnspiele',
            'params': {'mode': 'gewinnspiel'},
            'description': 'Aktuelle Gewinnspiele ansehen und mitmachen'
        },
        {
            'label': '🌐  Website-Inhalte',
            'params': {'mode': 'website'},
            'description': 'Neuigkeiten, Programm, Moderatoren und mehr'
        },
    ]

    for item in menu_items:
        add_directory_item(
            handle=handle,
            base_url=base_url,
            label=item['label'],
            params=item['params'],
            description=item.get('description', '')
        )

    xbmcplugin.endOfDirectory(handle)
