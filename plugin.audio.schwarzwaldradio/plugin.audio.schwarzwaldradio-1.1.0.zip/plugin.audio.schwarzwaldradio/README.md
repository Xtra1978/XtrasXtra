# 🎵 Schwarzwaldradio – Kodi Addon

**plugin.audio.schwarzwaldradio** · Version 1.0.0

Dieses Kodi-Addon macht **Schwarzwaldradio** – Deutschlands bundesweiten Oldiesender –
vollständig in Kodi zugänglich. Musik von den 60ern bis 90ern, Sondersendungen, Podcasts
und alle Inhalte der offiziellen Website.

---

## 📦 Installation

### Manuelle Installation (empfohlen für Entwickler)

1. Den Ordner `plugin.audio.schwarzwaldradio` in dein Kodi-Addons-Verzeichnis kopieren:
   - **Linux:** `~/.kodi/addons/`
   - **Windows:** `%APPDATA%\Kodi\addons\`
   - **macOS:** `~/Library/Application Support/Kodi/addons/`
   - **Android:** `/Android/data/org.xbmc.kodi/files/.kodi/addons/`
   - **Raspberry Pi / LibreELEC:** `/storage/.kodi/addons/`

2. Kodi neu starten oder unter **Addons → Aus ZIP-Datei installieren** die ZIP nutzen.

3. Das Addon unter **Addons → Meine Addons → Audio-Addons** aktivieren.

### Als ZIP installieren

```bash
cd /pfad/zum/addon-ordner
zip -r plugin.audio.schwarzwaldradio.zip plugin.audio.schwarzwaldradio/
```
Dann in Kodi: **Addons → Aus ZIP-Datei installieren**.

---

## 🎛️ Funktionen

### 📻 Live Streams
Alle bekannten Live-Streams von Schwarzwaldradio in verschiedenen Qualitätsstufen:

| Stream | Format | Qualität | Quelle |
|--------|--------|----------|--------|
| Live (MP3, empfohlen) | MP3 | 128 kbps | Streamonkey (offiziell) |
| Live (AAC HiFi) | AAC | HiFi/VBR | Streamonkey (offiziell) |
| Live (AAC Stream) | AAC | VBR 64–128 kbps | Streamonkey (offiziell) |
| Live (M3U Playlist) | MP3 | 128 kbps | Streamonkey (offiziell) |
| Creacast Classic | MP3 | variabel | Creacast (alternativ) |
| Creacast Thema | MP3 | variabel | Creacast (alternativ) |

### 🎙️ Mediathek & Podcasts
- Alle Sendungen aus der Schwarzwaldradio-Mediathek
- Automatischer RSS-Feed-Abruf (falls verfügbar)
- Sendungsformate-Übersicht (Tanzparty, Frauenquote, Sondersendungen, …)
- Moderatoren-Liste

### 🌐 Website-Inhalte
Direktzugang zu allen Bereichen von schwarzwaldradio.com:
- 📰 News & Neuigkeiten (via RSS)
- 📅 Programm & Sendeschema
- 🎵 Musik & Playlist
- 🎤 Moderatoren & Team
- 📡 Empfang & Frequenzen (DAB+, UKW 93,0 MHz, Kabel, Internet)
- 🏅 Schwarzwaldtaler Bonusprogramm
- 🎁 Gewinnspiele
- 🎪 Veranstaltungen
- 📬 Kontakt & Wunschsendung

---

## 🗂️ Addon-Struktur

```
plugin.audio.schwarzwaldradio/
├── addon.xml                    # Kodi Addon-Manifest
├── addon.py                     # Einstiegspunkt
├── README.md                    # Diese Datei
└── resources/
    ├── settings.xml             # Addon-Einstellungen
    ├── media/
    │   ├── icon.png             # Addon-Icon (256×256 px)
    │   └── fanart.jpg           # Hintergrundbild (1920×1080 px)
    ├── language/
    │   └── resource.language.de_de/
    │       └── strings.po       # Deutsche Lokalisierung
    └── lib/
        ├── __init__.py
        ├── router.py            # URL-Routing
        ├── ui.py                # Menüs & UI-Hilfsfunktionen
        ├── streams.py           # Live-Stream-Verwaltung
        ├── mediathek.py         # Podcast/Mediathek-Integration
        └── website.py           # Website-Inhalte & News
```

---

## 📻 Stream-URLs (auch für andere Player)

Falls du die Streams direkt in anderen Playern nutzen möchtest:

```
# MP3 128 kbps (empfohlen)
https://frontend.streamonkey.net/fho-schwarzwaldradiolive/stream/mp3

# AAC HiFi
https://frontend.streamonkey.net/fho-schwarzwaldradiohifi

# M3U Playlist
https://frontend.streamonkey.net/fho-schwarzwaldradiolive/mp3-stream.m3u

# AAC M3U
https://frontend.streamonkey.net/fho-schwarzwaldradiolive/aac-stream.m3u

# Creacast (alternativ)
http://str0.creacast.com/schwarzwaldradio.m3u
```

---

## 🖼️ Icons

Lege eigene Icons ab unter:
- `resources/media/icon.png` – 256×256 px, PNG
- `resources/media/fanart.jpg` – 1920×1080 px, JPEG

Du kannst offizielle Grafiken von schwarzwaldradio.com verwenden
(bitte Urheberrecht beachten).

---

## 🛠️ Entwicklung & Fehler

- **Kodi-Log:** `~/.kodi/temp/kodi.log` – Alle Addon-Meldungen beginnen mit `[Schwarzwaldradio]`
- **Python-Kompatibilität:** Python 3 (Kodi 19+), Fallback auf Python 2 (Kodi 18)
- **Getestete Kodi-Versionen:** Matrix (19), Nexus (20), Omega (21)

### Häufige Probleme

| Problem | Lösung |
|---------|--------|
| Stream spielt nicht ab | Anderen Stream-Eintrag wählen, ggf. Firewall prüfen |
| Mediathek leer | RSS-Feed temporär nicht erreichbar – Internetverbindung prüfen |
| Website-Links öffnen sich nicht | Kodi-internen Browser oder externen Browser nutzen |

---

## ⚖️ Hinweise

- Dieses Addon ist ein inoffizielles Fan-Projekt und steht in keiner Verbindung
  zu Schwarzwaldradio / Privater Rundfunkgesellschaft Ortenau GmbH & Co. KG.
- Alle Streams und Inhalte sind Eigentum von Schwarzwaldradio.
- Bitte die [Nutzungsbedingungen von Schwarzwaldradio](https://www.schwarzwaldradio.com) beachten.

---

## 📡 Über Schwarzwaldradio

Schwarzwaldradio ist ein bundesweit empfangbares privates Hörfunkprogramm aus
Baden-Württemberg (Offenburg). Musik von den 50ern bis zur Jahrtausendwende,
Sondersendungen zu Soul, Rock, Disco, Country und mehr.

- **UKW:** 93,0 MHz (Kinzigtal)
- **DAB+:** Bundesweit, Kanal 5C
- **Kabel:** Bundesweit
- **Web:** [schwarzwaldradio.com](https://www.schwarzwaldradio.com)
