# -*- coding: utf-8 -*-
"""Kanal- und Qualitätstabelle. Abweichungen vom URL-Muster hier als Ausnahme eintragen."""

BASE = 'http://stream.radioparadise.com/'

# (key, label)
QUALITIES = [
    ('32', '32k AAC+'),
    ('64', '64k AAC+'),
    ('128', '128k AAC'),
    ('192', '192k MP3'),
    ('320', '320k AAC'),
    ('flac', 'FLAC'),
    ('flacm', 'FLAC + Metadata'),
]

# (id, Name, Slug, API-Kanal-ID oder None)
CHANNELS = [
    ('main', 'Main Mix', None, 0),
    ('mellow', 'Mellow Mix', 'mellow', 1),
    ('rock', 'Rock Mix', 'rock', 2),
    ('global', 'Global Mix', 'global', 3),
    ('beyond', 'Beyond...', 'beyond', None),
    ('serenity', 'Serenity', 'serenity', None),
    ('radio2050', 'Radio 2050', 'radio2050', None),
    ('kfat', 'KFAT', 'kfat', None),
]

# Main Mix hat kein Präfix und eigene Namen für AAC/MP3
_MAIN = {
    '32': 'aac-32', '64': 'aac-64', '128': 'aac-128',
    '192': 'mp3-192', '320': 'aac-320', 'flac': 'flac', 'flacm': 'flacm',
}


# Kanäle mit eingeschränkten Qualitäten: Qualität -> kompletter Stream-Name
LIMITED = {
    'serenity': {'64': 'serenity', 'flac': 'serenity-flac'},
}


def available_qualities(cid):
    """Liste der (key, label) Qualitäten, die der Kanal wirklich anbietet."""
    if cid in LIMITED:
        return [q for q in QUALITIES if q[0] in LIMITED[cid]]
    return list(QUALITIES)


def resolve_quality(cid, quality):
    """Gewünschte Qualität oder, falls nicht verfügbar, die nächstliegende."""
    avail = [k for k, _l in available_qualities(cid)]
    if quality in avail:
        return quality
    order = [k for k, _l in QUALITIES]
    want = order.index(quality) if quality in order else 2
    return min(avail, key=lambda k: abs(order.index(k) - want))


def get_channel(cid):
    for c in CHANNELS:
        if c[0] == cid:
            return c
    return None


def stream_url(cid, quality):
    c = get_channel(cid)
    if not c:
        return None
    quality = resolve_quality(cid, quality)
    if cid in LIMITED:
        return BASE + LIMITED[cid][quality]
    if cid == 'main':
        return BASE + _MAIN[quality]
    return '%s%s-%s' % (BASE, c[2], quality)


def quality_label(key):
    for k, label in QUALITIES:
        if k == key:
            return label
    return key


def channel_from_url(url):
    """Kanal-ID zu einer abgespielten Stream-URL (oder None)."""
    if not url:
        return None
    base = url.split('?')[0]
    for c in CHANNELS:
        for q, _l in available_qualities(c[0]):
            if stream_url(c[0], q) == base:
                return c[0]
    return None
