# -*- coding: utf-8 -*-
import json
import xbmc

from urllib.request import urlopen, Request

API = 'https://api.radioparadise.com/api/now_playing?chan=%d'
IMG_BASE = 'https://img.radioparadise.com/'


def _cover(url):
    if not url:
        return ''
    if url.startswith('http'):
        return url
    return IMG_BASE + url.lstrip('/')


def fetch(chan_id):
    """Gibt dict(artist, title, album, cover) zurück oder None. Fehler werden nur geloggt."""
    if chan_id is None:
        return None
    try:
        req = Request(API % chan_id, headers={'User-Agent': 'Kodi/plugin.audio.radioparadise'})
        data = json.loads(urlopen(req, timeout=5).read().decode('utf-8'))
        return {
            'artist': data.get('artist') or '',
            'title': data.get('title') or '',
            'album': data.get('album') or '',
            'cover': _cover(data.get('cover')),
        }
    except Exception as exc:
        xbmc.log('[plugin.audio.radioparadise] nowplaying failed: %s' % exc, xbmc.LOGINFO)
        return None
