# -*- coding: utf-8 -*-
"""Hintergrunddienst: aktualisiert Titel/Cover während ein Radio-Paradise-Stream läuft."""
import xbmc
import xbmcaddon
import xbmcgui

from . import channels, nowplaying
from .router import _set_music

POLL = 15  # Sekunden


def _log(msg):
    xbmc.log('[plugin.audio.radioparadise] service: %s' % msg, xbmc.LOGINFO)


def _update(player, cid, np, addon):
    ch = channels.get_channel(cid)
    li = xbmcgui.ListItem(label=np['title'])
    _set_music(li, np['title'], np['artist'] or 'Radio Paradise', np['album'] or ch[1])
    icon = addon.getAddonInfo('icon')
    li.setArt({'thumb': np['cover'] or icon, 'icon': icon, 'fanart': addon.getAddonInfo('fanart')})
    player.updateInfoTag(li)


def run():
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    last = (None, None)  # (url, (artist, title))
    while not monitor.waitForAbort(POLL):
        try:
            if not player.isPlayingAudio():
                last = (None, None)
                continue
            addon = xbmcaddon.Addon()
            if not (addon.getSettingBool('show_nowplaying') and addon.getSettingBool('live_update')):
                continue
            url = player.getPlayingFile()
            cid = channels.channel_from_url(url)
            ch = channels.get_channel(cid) if cid else None
            if not ch or ch[3] is None:
                continue
            np = nowplaying.fetch(ch[3])
            if not np or not np['title']:
                continue
            key = (np['artist'], np['title'])
            if last == (url, key):
                continue
            _update(player, cid, np, addon)
            last = (url, key)
        except Exception as exc:
            _log('loop error: %s' % exc)
