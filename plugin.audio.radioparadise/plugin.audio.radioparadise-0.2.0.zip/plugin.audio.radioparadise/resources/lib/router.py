# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from urllib.parse import urlencode, parse_qsl

from . import channels, nowplaying

ADDON = xbmcaddon.Addon()
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
S_CHOOSE_Q = 30001
S_SELECT_Q = 30003


def _url(base, **params):
    return '%s?%s' % (base, urlencode(params))


def _art(li, thumb=None):
    li.setArt({'thumb': thumb or ICON, 'icon': ICON, 'fanart': FANART})


def _set_music(li, title, artist, album=''):
    tag = li.getMusicInfoTag() if hasattr(li, 'getMusicInfoTag') else None
    if tag is not None and hasattr(tag, 'setTitle'):  # Kodi 20+
        tag.setTitle(title)
        tag.setArtist(artist)
        if album:
            tag.setAlbum(album)
    else:  # Kodi 19
        info = {'title': title, 'artist': artist}
        if album:
            info['album'] = album
        li.setInfo('music', info)


def _default_quality():
    try:
        idx = int(ADDON.getSetting('quality'))
    except ValueError:
        idx = 2
    idx = max(0, min(idx, len(channels.QUALITIES) - 1))
    return channels.QUALITIES[idx][0]


def _build_item(cid, quality):
    ch = channels.get_channel(cid)
    quality = channels.resolve_quality(cid, quality)
    url = channels.stream_url(cid, quality)
    label = ch[1]
    li = xbmcgui.ListItem(label=label, path=url)
    thumb = ICON
    title, artist, album = label, 'Radio Paradise', channels.quality_label(quality)
    if ADDON.getSettingBool('show_nowplaying'):
        np = nowplaying.fetch(ch[3])
        if np and np['title']:
            title = np['title']
            artist = np['artist'] or artist
            album = np['album'] or label
            if np['cover']:
                thumb = np['cover']
    _set_music(li, title, artist, album)
    _art(li, thumb)
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('audio/flac' if quality in ('flac', 'flacm') else 'audio/aac')
    li.setContentLookup(False)
    return li, url


def list_channels(base, handle):
    xbmcplugin.setPluginCategory(handle, 'Radio Paradise')
    xbmcplugin.setContent(handle, 'songs')
    for cid, name, _slug, _chan in channels.CHANNELS:
        li = xbmcgui.ListItem(label=name)
        _set_music(li, name, 'Radio Paradise')
        _art(li)
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([
            (ADDON.getLocalizedString(S_CHOOSE_Q),
             'RunPlugin(%s)' % _url(base, action='choose', channel=cid)),
        ])
        xbmcplugin.addDirectoryItem(handle, _url(base, action='play', channel=cid), li, False)
    xbmcplugin.endOfDirectory(handle)


def play(handle, cid, quality=None):
    li, _u = _build_item(cid, quality or _default_quality())
    xbmcplugin.setResolvedUrl(handle, True, li)


def choose(cid):
    avail = channels.available_qualities(cid)
    keys = [k for k, _l in avail]
    labels = [l for _k, l in avail]
    sel = xbmcgui.Dialog().select(ADDON.getLocalizedString(S_SELECT_Q), labels,
                                  preselect=keys.index(channels.resolve_quality(cid, _default_quality())))
    if sel < 0:
        return
    li, url = _build_item(cid, keys[sel])
    xbmc.Player().play(url, li)


def run(argv):
    base = argv[0]
    handle = int(argv[1])
    params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 else {}
    action = params.get('action')
    if action == 'play':
        play(handle, params.get('channel'), params.get('quality'))
    elif action == 'choose':
        choose(params.get('channel'))
    else:
        list_channels(base, handle)
