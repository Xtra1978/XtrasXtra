#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API-Modul: LibriVox Kodi Addon.

Quellen:
  1. LibriVox API  – https://librivox.org/api/feed/audiobooks/
     Liefert Metadaten, Autoren, Genres, Kapitel-URLs
  2. Internet Archive – collection:librivoxaudio
     Direkte MP3-Stream-URLs, Cover-Thumbnails

LibriVox API Endpunkte:
  /api/feed/audiobooks/          – Buchsuche
  /api/feed/audiobooks/id/{id}   – Einzelbuch
  /api/feed/authors/             – Autorensuche
  /api/feed/audiobooks/genre     – nach Genre (nicht offiziell, via subject)
"""

import json
import re
import time
import xbmc
import xbmcaddon
from urllib.request import urlopen, Request
from urllib.parse   import urlencode, quote
from urllib.error   import HTTPError, URLError

LV_API   = 'https://librivox.org/api/feed'
IA_SEARCH = 'https://archive.org/advancedsearch.php'
IA_META   = 'https://archive.org/metadata/{id}'
LV_RSS    = 'https://librivox.org/rss/podcast'
UA        = 'Mozilla/5.0 (compatible; KodiLibriVox/1.0; kodi.tv)'
TIMEOUT   = 20


def _addon():
    return xbmcaddon.Addon()

def _str(sid):
    try:
        return _addon().getLocalizedString(sid)
    except Exception:
        return str(sid)

def _setting(key, default=''):
    try:
        return _addon().getSetting(key) or default
    except Exception:
        return default

def _log(msg, level=xbmc.LOGDEBUG):
    try:
        if _setting('logging_enabled') != 'true' and level == xbmc.LOGDEBUG:
            return
        log_level = _setting('log_level', '30311')
        if log_level == '30310' and level not in (xbmc.LOGERROR, xbmc.LOGWARNING):
            return
        xbmc.log(f'[LibriVox] {msg}', level)
    except Exception:
        xbmc.log(f'[LibriVox] {msg}', level)

def _per_page():
    try:
        return int(_setting('per_page', '25'))
    except (ValueError, TypeError):
        return 25

def _sort_lv():
    val = _setting('sort_order', '30110')
    return {
        '30110': ('catalog_date', 'desc'),
        '30111': ('catalog_date', 'asc'),
        '30112': ('title',        'asc'),
        '30113': ('num_sections', 'desc'),
    }.get(val, ('catalog_date', 'desc'))

def _lang_filter():
    val = _setting('language', '30120')
    return {
        '30120': '',
        '30121': 'english',
        '30122': 'german',
        '30123': 'french',
        '30124': 'spanish',
        '30125': 'italian',
        '30126': 'dutch',
    }.get(val, '')

def _solo_only():
    return _setting('show_solo_only', 'false') == 'true'

def _warmup_enabled():
    return _setting('warmup', 'true') == 'true'


# -----------------------------------------------------------------------
# Genre-Definitionen – label verweist auf String-ID
# -----------------------------------------------------------------------

GENRES = [
    {'id': 'action_adventure',  'label': 30040, 'lv_genre': 'Action & Adventure',    'icon': 'genre_adventure.png'},
    {'id': 'art',               'label': 30041, 'lv_genre': 'Art',                   'icon': 'genre_art.png'},
    {'id': 'biography',         'label': 30042, 'lv_genre': 'Biography & Autobiography','icon': 'genre_biography.png'},
    {'id': 'children',          'label': 30043, 'lv_genre': "Children's Fiction",    'icon': 'genre_children.png'},
    {'id': 'comedy',            'label': 30044, 'lv_genre': 'Humorous Fiction',       'icon': 'genre_comedy.png'},
    {'id': 'crime',             'label': 30045, 'lv_genre': 'Crime & Mystery Fiction','icon': 'genre_crime.png'},
    {'id': 'drama',             'label': 30046, 'lv_genre': 'Plays',                  'icon': 'genre_drama.png'},
    {'id': 'fairy_tales',       'label': 30047, 'lv_genre': 'Fairy Tales',            'icon': 'genre_fairytales.png'},
    {'id': 'fantasy',           'label': 30048, 'lv_genre': 'Fantasy Fiction',        'icon': 'genre_fantasy.png'},
    {'id': 'history',           'label': 30049, 'lv_genre': 'History',                'icon': 'genre_history.png'},
    {'id': 'horror',            'label': 30050, 'lv_genre': 'Horror & Supernatural Fiction','icon': 'genre_horror.png'},
    {'id': 'humour',            'label': 30051, 'lv_genre': 'Humorous Fiction',       'icon': 'genre_humour.png'},
    {'id': 'philosophy',        'label': 30052, 'lv_genre': 'Philosophy',             'icon': 'genre_philosophy.png'},
    {'id': 'poetry',            'label': 30053, 'lv_genre': 'Poetry',                 'icon': 'genre_poetry.png'},
    {'id': 'romance',           'label': 30054, 'lv_genre': 'Romance',                'icon': 'genre_romance.png'},
    {'id': 'scifi',             'label': 30055, 'lv_genre': 'Science Fiction',        'icon': 'genre_scifi.png'},
    {'id': 'travel',            'label': 30056, 'lv_genre': 'Travel & Geography',     'icon': 'genre_travel.png'},
    {'id': 'war',               'label': 30057, 'lv_genre': 'War & Military',         'icon': 'genre_war.png'},
]

LANGUAGES = [
    {'id': 'english',  'label': 30121, 'icon': 'lang_en.png'},
    {'id': 'german',   'label': 30122, 'icon': 'lang_de.png'},
    {'id': 'french',   'label': 30123, 'icon': 'lang_fr.png'},
    {'id': 'spanish',  'label': 30124, 'icon': 'lang_es.png'},
    {'id': 'italian',  'label': 30125, 'icon': 'lang_it.png'},
    {'id': 'dutch',    'label': 30126, 'icon': 'lang_nl.png'},
    {'id': 'latin',    'label': 30120, 'icon': 'lang_la.png'},
]


def get_genre_by_id(genre_id):
    for g in GENRES:
        if g['id'] == genre_id:
            return g
    return None


# -----------------------------------------------------------------------
# LibriVox API – Buecher abrufen
# -----------------------------------------------------------------------

def get_new_arrivals(page=1):
    return _lv_books(page=page, order='catalog_date', direction='desc')

def get_most_listened(page=1):
    """Internet Archive: meistgeladene LibriVox-Buecher."""
    return _ia_librivox(query='', page=page, sort='downloads desc')

def get_books_by_genre(lv_genre, page=1):
    return _lv_books(page=page, genre=lv_genre)

def get_books_by_language(language, page=1):
    return _lv_books(page=page, language=language)

def get_books_by_author(author_id, page=1):
    return _lv_books(page=page, author_id=author_id)

def search_books(query, page=1):
    """Sucht Buecher nach Titel oder Autor."""
    results = _lv_books(page=page, title=query)
    if not results[0]:
        results = _lv_books(page=page, author=query)
    return results

def search_authors(query):
    """Sucht Autoren."""
    params = {
        'simple': 1,
        'last_name': query,
        'format': 'json',
    }
    url  = f'{LV_API}/authors?{urlencode(params)}'
    data = _get(url)
    if not data or not data.get('authors'):
        return []
    return [_parse_author(a) for a in data['authors']]


def _lv_books(page=1, title='', author='', author_id='',
              genre='', language='', order='', direction=''):
    per_page = _per_page()
    sort_col, sort_dir = _sort_lv()
    if order:     sort_col = order
    if direction: sort_dir = direction

    # Sprach-Filter aus Settings wenn nicht explizit angegeben
    if not language:
        language = _lang_filter()

    params = {
        'format':   'json',
        'extended': 1,
        'limit':    per_page,
        'offset':   (page - 1) * per_page,
        'fields':   'id,title,url_text_source,language,copyright_year,'
                    'num_sections,url_rss,url_zip_file,url_project,url_librivox,'
                    'totaltime,authors,genres,description',
    }
    if title:     params['title']     = title
    if author:    params['author']    = author
    if author_id: params['author_id'] = author_id
    if genre:     params['genre']     = genre
    if language:  params['language']  = language
    if sort_col:  params['sort_order'] = sort_col
    if sort_dir:  params['sort_dir']   = sort_dir

    # Solo-only Filter
    if _solo_only():
        params['solo_project'] = 1

    url  = f'{LV_API}/audiobooks?{urlencode(params)}'
    if _setting('log_api') == 'true':
        _log(f'LV API: {url[:120]}', xbmc.LOGDEBUG)

    data = _get(url)
    if not data or not data.get('books'):
        _log(f'Keine Buecher: {url[:80]}', xbmc.LOGWARNING)
        return [], 0

    books = [_parse_book(b) for b in data['books']]
    books = [b for b in books if b]
    total = len(books)  # LibriVox API liefert kein total – Pagination via offset
    _log(f'Buecher geladen: {len(books)}', xbmc.LOGINFO)
    return books, total


def _parse_book(b):
    if not b:
        return None

    book_id  = str(b.get('id', ''))
    title    = b.get('title', 'Unknown')
    language = b.get('language', '')
    year     = str(b.get('copyright_year', ''))
    sections = str(b.get('num_sections', '0'))
    url_lv   = b.get('url_librivox', '')
    url_rss  = b.get('url_rss', '')
    url_zip  = b.get('url_zip_file', '')
    total_t  = b.get('totaltime', '')
    desc     = b.get('description', '')

    # Autoren
    authors = b.get('authors', []) or []
    if isinstance(authors, dict):
        authors = [authors]
    author_str = ', '.join(
        f'{a.get("first_name","")} {a.get("last_name","")}'.strip()
        for a in authors if a
    )

    # Genre
    genres = b.get('genres', []) or []
    if isinstance(genres, dict):
        genres = [genres]
    genre_str = ', '.join(
        g.get('name', '') for g in genres if g
    )

    # Thumbnail via Internet Archive
    ia_id = _ia_id_from_lv(book_id, title)
    thumb = f'https://archive.org/services/img/{ia_id}' if ia_id else ''

    return {
        'id':       book_id,
        'ia_id':    ia_id,
        'title':    str(title),
        'author':   author_str,
        'language': str(language),
        'year':     year,
        'sections': sections,
        'genre':    genre_str,
        'desc':     _clean(str(desc)),
        'url_lv':   url_lv,
        'url_rss':  url_rss,
        'url_zip':  url_zip,
        'duration': total_t,
        'thumb':    thumb,
    }


def _parse_author(a):
    return {
        'id':         str(a.get('id', '')),
        'first_name': a.get('first_name', ''),
        'last_name':  a.get('last_name', ''),
        'dob':        a.get('dob', ''),
        'dod':        a.get('dod', ''),
        'display':    f'{a.get("first_name","")} {a.get("last_name","")}'.strip(),
    }


# -----------------------------------------------------------------------
# Kapitel / Sections eines Buches
# -----------------------------------------------------------------------

def get_chapters(book_id):
    """
    Laedt alle Kapitel eines Buches.
    LibriVox liefert direkte MP3-URLs in der RSS-Section.
    """
    params = {
        'format':   'json',
        'extended': 1,
        'limit':    1,
        'id':       book_id,
        'fields':   'url_rss,url_zip_file,id,title,sections',
    }
    url  = f'{LV_API}/audiobooks?{urlencode(params)}'
    data = _get(url)
    if not data or not data.get('books'):
        return []

    book    = data['books'][0]
    url_rss = book.get('url_rss', '')
    if not url_rss:
        return []

    return _parse_rss_chapters(url_rss)


def _parse_rss_chapters(rss_url):
    """Parst den RSS-Feed eines Buches und extrahiert Kapitel-MP3-URLs."""
    try:
        req  = Request(rss_url, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=TIMEOUT)
        raw  = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        _log(f'RSS Fehler: {e}', xbmc.LOGWARNING)
        return []

    chapters = []
    # Kapitel per Regex aus RSS extrahieren
    items = re.findall(r'<item>(.*?)</item>', raw, re.DOTALL)
    for i, item in enumerate(items):
        title_m = re.search(r'<title>(.*?)</title>', item)
        url_m   = re.search(r'<enclosure[^>]+url="([^"]+)"', item)
        dur_m   = re.search(r'<itunes:duration>(.*?)</itunes:duration>', item)
        reader_m= re.search(r'<itunes:author>(.*?)</itunes:author>', item)

        title   = _unescape(title_m.group(1)) if title_m else f'Chapter {i+1}'
        mp3_url = url_m.group(1) if url_m else ''
        dur     = dur_m.group(1).strip() if dur_m else ''
        reader  = _unescape(reader_m.group(1)) if reader_m else ''

        if mp3_url:
            chapters.append({
                'num':    i + 1,
                'title':  title,
                'url':    mp3_url,
                'dur':    dur,
                'reader': reader,
            })

    _log(f'Kapitel geladen: {len(chapters)}', xbmc.LOGINFO)
    return chapters


# -----------------------------------------------------------------------
# Internet Archive – Thumbnails und Meistgehoert
# -----------------------------------------------------------------------

def _ia_id_from_lv(book_id, title=''):
    """
    Versucht die IA-ID fuer ein LibriVox-Buch zu ermitteln.
    Format: LibriVox_{book_id} oder Suche nach Titel.
    """
    # Standard-Format das LibriVox bei IA nutzt
    return f'LibriVox_{book_id}'


def _ia_librivox(query='', page=1, sort='downloads desc'):
    per_page = _per_page()
    lang     = _lang_filter()
    q_parts  = ['collection:librivoxaudio', 'mediatype:audio']
    if query:    q_parts.append(f'({query})')
    if lang:     q_parts.append(f'language:{lang}')

    params = {
        'q':      ' AND '.join(q_parts),
        'fl[]':   ['identifier', 'title', 'creator', 'date',
                   'description', 'language', 'downloads'],
        'rows':   per_page,
        'page':   page,
        'output': 'json',
        'sort[]': sort,
    }
    url  = f'{IA_SEARCH}?{urlencode(params, doseq=True)}'
    data = _get(url)
    if not data:
        return [], 0
    docs  = data.get('response', {}).get('docs', [])
    total = data.get('response', {}).get('numFound', 0)
    books = [_parse_ia_doc(d) for d in docs if d.get('identifier')]
    return [b for b in books if b], total


def _parse_ia_doc(doc):
    ia_id    = doc.get('identifier', '')
    title    = _first(doc.get('title',    ia_id))
    creator  = _first(doc.get('creator',  ''))
    language = _first(doc.get('language', ''))
    desc     = _first(doc.get('description', ''))
    return {
        'id':       ia_id,
        'ia_id':    ia_id,
        'title':    str(title),
        'author':   str(creator),
        'language': str(language),
        'year':     '',
        'sections': '?',
        'genre':    '',
        'desc':     _clean(str(desc)),
        'url_lv':   '',
        'url_rss':  '',
        'url_zip':  '',
        'duration': '',
        'thumb':    f'https://archive.org/services/img/{ia_id}',
    }


def get_ia_chapters(ia_id):
    """Laedt MP3-Dateien direkt aus IA-Metadata."""
    data = _get(IA_META.format(id=ia_id))
    if not data:
        return []
    files    = data.get('files', [])
    chapters = []
    for f in files:
        fname = f.get('name', '')
        fmtl  = f.get('format', '').lower()
        if not (fname.lower().endswith('.mp3') or 'mp3' in fmtl):
            continue
        if any(x in fname.lower() for x in ['_64kb', '_128kb']):
            continue
        try:
            size_mb  = int(f.get('size', 0)) // 1024 // 1024
            size_str = f'{size_mb} MB' if size_mb else ''
        except (ValueError, TypeError):
            size_str = ''
        chapters.append({
            'num':    len(chapters) + 1,
            'title':  fname.replace('.mp3', '').replace('_', ' '),
            'url':    f'https://archive.org/download/{ia_id}/{quote(fname)}',
            'dur':    size_str,
            'reader': '',
        })
    chapters.sort(key=lambda c: c['title'])
    return chapters


# -----------------------------------------------------------------------
# Podcast
# -----------------------------------------------------------------------

def get_podcast_episodes(limit=50):
    """Laedt den LibriVox-Podcast-Feed."""
    try:
        req  = Request(LV_RSS, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=TIMEOUT)
        raw  = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        _log(f'Podcast RSS Fehler: {e}', xbmc.LOGWARNING)
        return []

    episodes = []
    items    = re.findall(r'<item>(.*?)</item>', raw, re.DOTALL)
    for i, item in enumerate(items[:limit]):
        title_m = re.search(r'<title>(.*?)</title>', item)
        url_m   = re.search(r'<enclosure[^>]+url="([^"]+)"', item)
        desc_m  = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        date_m  = re.search(r'<pubDate>(.*?)</pubDate>', item)
        dur_m   = re.search(r'<itunes:duration>(.*?)</itunes:duration>', item)

        title   = _unescape(title_m.group(1)) if title_m else f'Episode {i+1}'
        mp3_url = url_m.group(1) if url_m else ''
        desc    = _clean(_unescape(desc_m.group(1))) if desc_m else ''
        date    = date_m.group(1).strip() if date_m else ''
        dur     = dur_m.group(1).strip() if dur_m else ''

        if mp3_url:
            episodes.append({
                'title': title,
                'url':   mp3_url,
                'desc':  desc,
                'date':  date,
                'dur':   dur,
            })

    _log(f'Podcast-Episoden: {len(episodes)}', xbmc.LOGINFO)
    return episodes


# -----------------------------------------------------------------------
# Hilfsfunktionen
# -----------------------------------------------------------------------

def _get(url, retries=2):
    if _setting('log_api') == 'true':
        _log(f'GET {url[:100]}', xbmc.LOGDEBUG)
    for attempt in range(retries):
        try:
            req  = Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'})
            resp = urlopen(req, timeout=TIMEOUT)
            raw  = resp.read().decode('utf-8', errors='replace')
            return json.loads(raw)
        except HTTPError as e:
            if e.code == 429 and attempt < retries - 1:
                time.sleep(3)
            else:
                _log(f'HTTP {e.code}: {url[:80]}', xbmc.LOGWARNING)
                return None
        except Exception as e:
            _log(f'Error: {e}', xbmc.LOGWARNING)
            return None
    return None


def _first(val, default=''):
    if isinstance(val, list):
        return val[0] if val else default
    return val or default


def _clean(text):
    """Bereinigt HTML-Tags, bricht an Wortgrenze bei ~400 Zeichen."""
    if not text:
        return ''
    text = re.sub(r'<[^>]+>', '', str(text)).strip()
    text = re.sub(r'\s+', ' ', text)
    if len(text) <= 400:
        return text
    pos = text.rfind(' ', 0, 400)
    return text[:pos] + '...' if pos > 0 else text[:400] + '...'


def _unescape(text):
    """Einfaches HTML-Unescape."""
    if not text:
        return ''
    return (text.replace('&amp;', '&')
                .replace('&lt;',  '<')
                .replace('&gt;',  '>')
                .replace('&quot;','\"')
                .replace('&#39;', "'")
                .strip())
