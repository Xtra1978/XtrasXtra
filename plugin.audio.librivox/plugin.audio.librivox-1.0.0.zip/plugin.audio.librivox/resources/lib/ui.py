#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI-Modul fuer LibriVox – alle Strings aus strings.po."""

from urllib.parse import urlencode
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib import api
from resources.lib.api import GENRES, LANGUAGES

ADDON_ICON   = 'special://home/addons/plugin.audio.librivox/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.audio.librivox/resources/media/fanart.jpg'
ICON_DIR     = 'special://home/addons/plugin.audio.librivox/resources/media/icons/'


def _str(sid):
    try:
        return xbmcaddon.Addon().getLocalizedString(sid)
    except Exception:
        return str(sid)


def build_url(base_url, params):
    return '{0}?{1}'.format(base_url, urlencode(params))


def _li(label, thumb='', info=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        'icon':   thumb or ADDON_ICON,
        'thumb':  thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
        'poster': thumb or ADDON_ICON,
    })
    if info:
        li.setInfo('music', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _end(handle, content='albums'):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def _notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification('LibriVox', msg, icon, 4000)


# -----------------------------------------------------------------------
# Hauptmenue
# -----------------------------------------------------------------------

def show_main_menu(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, _str(30000))

    entries = [
        (30001, 'new_arrivals',  {'mode': 'new_arrivals'},  'icon_new.png'),
        (30002, 'most_listened', {'mode': 'most_listened'}, 'icon_star.png'),
        (30003, 'genres',        {'mode': 'genres'},        'icon_genre.png'),
        (30004, 'languages',     {'mode': 'languages'},     'icon_language.png'),
        (30005, 'authors',       {'mode': 'authors'},       'icon_author.png'),
        (30006, 'podcast',       {'mode': 'podcast'},       'icon_podcast.png'),
        (30007, 'search',        {'mode': 'search'},        'icon_search.png'),
    ]

    for label_id, _, params, icon in entries:
        url = build_url(base_url, params)
        xbmcplugin.addDirectoryItem(
            handle=handle, url=url,
            listitem=_li(_str(label_id), thumb=ICON_DIR + icon),
            isFolder=True)

    _end(handle, 'files')


# -----------------------------------------------------------------------
# Buch-Liste (generisch fuer alle Kategorien)
# -----------------------------------------------------------------------

def show_book_list(base_url, handle, addon, title_id,
                   fetch_fn, page=1, mode=None, extra=None):
    xbmcplugin.setPluginCategory(handle, f'LibriVox – {_str(title_id)}')

    books, total = fetch_fn(page)

    if not books:
        _notify(_str(30015))
        _end(handle)
        return

    for book in books:
        _add_book_item(base_url, handle, book)

    # Naechste Seite (LibriVox liefert per_page Ergebnisse wenn mehr vorhanden)
    per_page = api._per_page()
    if len(books) >= per_page:
        next_params = {'mode': mode or 'new_arrivals', 'page': page + 1}
        if extra:
            next_params.update(extra)
        next_url = build_url(base_url, next_params)
        xbmcplugin.addDirectoryItem(
            handle=handle, url=next_url,
            listitem=_li(f'{_str(30018)}  ({page + 1})'),
            isFolder=True)

    _end(handle, 'albums')


# -----------------------------------------------------------------------
# Buch-Item
# -----------------------------------------------------------------------

def _add_book_item(base_url, handle, book):
    book_id   = book.get('id', '')
    ia_id     = book.get('ia_id', '')
    title     = book.get('title', 'Unknown')
    author    = book.get('author', '')
    language  = book.get('language', '')
    sections  = book.get('sections', '?')
    duration  = book.get('duration', '')
    genre     = book.get('genre', '')
    desc      = book.get('desc', '')
    thumb     = book.get('thumb', '')
    url_lv    = book.get('url_lv', '')
    url_rss   = book.get('url_rss', '')

    display = title
    if author:
        display += f'  – {author}'
    if language:
        display += f'  [{language}]'

    # Plot zusammenbauen
    plot_parts = []
    if author:   plot_parts.append(f'{_str(30020)}: {author}')
    if language: plot_parts.append(f'{_str(30021)}: {language}')
    if genre:    plot_parts.append(f'{_str(30022)}: {genre}')
    if sections: plot_parts.append(f'{_str(30023)}: {sections}')
    if duration: plot_parts.append(f'{_str(30013)}: {duration}')
    if desc:     plot_parts.append(f'\n{desc}')

    info = {
        'title':  title,
        'artist': author,
        'album':  genre,
        'comment':'\n'.join(plot_parts),
    }

    url = build_url(base_url, {
        'mode':     'book_detail',
        'book_id':  book_id,
        'ia_id':    ia_id,
        'title':    title,
        'thumb':    thumb,
        'url_rss':  url_rss,
    })
    li = _li(display, thumb=thumb, info=info)

    # Kontextmenue: Website
    if url_lv:
        li.addContextMenuItems([
            (_str(30019),
             f'RunPlugin({build_url(base_url, {"mode": "open_web", "url": url_lv})})')
        ])

    xbmcplugin.addDirectoryItem(handle=handle, url=url,
                                 listitem=li, isFolder=True)


# -----------------------------------------------------------------------
# Buch-Detail (Kapitel-Liste)
# -----------------------------------------------------------------------

def show_book_detail(base_url, handle, addon,
                     book_id, ia_id, title, thumb, url_rss):
    xbmcplugin.setPluginCategory(handle, title)

    # Kapitel laden: erst via LibriVox RSS, dann via Internet Archive
    chapters = []
    if url_rss:
        chapters = api._parse_rss_chapters(url_rss)
    if not chapters and ia_id:
        chapters = api.get_ia_chapters(ia_id)

    if not chapters:
        _notify(_str(30014))
        _end(handle, 'songs')
        return

    # "Alle abspielen" Eintrag
    if len(chapters) > 1:
        all_url = build_url(base_url, {
            'mode':       'play',
            'url':        chapters[0]['url'],
            'title':      f'{_str(30010)} – {title}',
            'thumb':      thumb,
            'book_title': title,
        })
        li_all = _li(_str(30010), thumb=thumb, playable=True)
        xbmcplugin.addDirectoryItem(handle=handle, url=all_url,
                                     listitem=li_all, isFolder=False)

    # Einzelne Kapitel
    for ch in chapters:
        num     = ch.get('num', '')
        ch_title = ch.get('title', f'{_str(30011)} {num}')
        url_mp3 = ch.get('url', '')
        dur     = ch.get('dur', '')
        reader  = ch.get('reader', '')

        display = ch_title
        if dur:    display += f'  [{dur}]'
        if reader: display += f'  – {reader}'

        info = {
            'title':       ch_title,
            'album':       title,
            'tracknumber': num,
            'duration':    _dur_to_sec(dur),
            'comment':     f'{_str(30012)}: {reader}' if reader else '',
        }

        params = {
            'mode':       'play',
            'url':        url_mp3,
            'title':      ch_title,
            'thumb':      thumb,
            'book_title': title,
        }
        url = build_url(base_url, params)
        li  = _li(display, thumb=thumb, info=info, playable=True)
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
                                     listitem=li, isFolder=False)

    _end(handle, 'songs')


# -----------------------------------------------------------------------
# Genres
# -----------------------------------------------------------------------

def show_genres(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, f'LibriVox – {_str(30003)}')
    for genre in GENRES:
        label = _str(genre['label'])
        icon  = ICON_DIR + genre.get('icon', 'icon_genre.png')
        url   = build_url(base_url, {
            'mode':     'genre',
            'genre_id': genre['id'],
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
            listitem=_li(label, thumb=icon), isFolder=True)
    _end(handle, 'files')


# -----------------------------------------------------------------------
# Sprachen
# -----------------------------------------------------------------------

def show_languages(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, f'LibriVox – {_str(30004)}')
    for lang in LANGUAGES:
        label = _str(lang['label'])
        icon  = ICON_DIR + lang.get('icon', 'icon_language.png')
        url   = build_url(base_url, {
            'mode': 'language',
            'lang': lang['id'],
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
            listitem=_li(label, thumb=icon), isFolder=True)
    _end(handle, 'files')


# -----------------------------------------------------------------------
# Autoren
# -----------------------------------------------------------------------

def show_author_search(base_url, handle, addon):
    query = xbmcgui.Dialog().input(
        f'LibriVox – {_str(30005)}', type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    xbmcplugin.setPluginCategory(handle, f'LibriVox – {_str(30005)}: {query}')
    authors = api.search_authors(query)

    if not authors:
        _notify(_str(30015))
        _end(handle, 'files')
        return

    for author in authors:
        display = author['display']
        dob     = author.get('dob', '')
        dod     = author.get('dod', '')
        if dob or dod:
            display += f'  ({dob}–{dod})'
        url = build_url(base_url, {
            'mode':        'author_books',
            'author_id':   author['id'],
            'author_name': author['display'],
        })
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
            listitem=_li(display, thumb=ICON_DIR+'icon_author.png'),
            isFolder=True)

    _end(handle, 'files')


# -----------------------------------------------------------------------
# Suche
# -----------------------------------------------------------------------

def ask_search(addon):
    return xbmcgui.Dialog().input(_str(30017), type=xbmcgui.INPUT_ALPHANUM)


def show_search_results(base_url, handle, addon, query, page=1):
    xbmcplugin.setPluginCategory(handle, f'LibriVox – {_str(30007)}: {query}')
    books, total = api.search_books(query, page=page)
    if not books:
        _notify(_str(30015))
        _end(handle)
        return
    for book in books:
        _add_book_item(base_url, handle, book)
    per_page = api._per_page()
    if len(books) >= per_page:
        next_url = build_url(base_url, {
            'mode': 'search', 'query': query, 'page': page + 1})
        xbmcplugin.addDirectoryItem(
            handle=handle, url=next_url,
            listitem=_li(f'{_str(30018)}  ({page + 1})'),
            isFolder=True)
    _end(handle, 'albums')


# -----------------------------------------------------------------------
# Podcast
# -----------------------------------------------------------------------

def show_podcast(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, f'LibriVox – {_str(30006)}')
    episodes = api.get_podcast_episodes()
    if not episodes:
        _notify(_str(30015))
        _end(handle, 'songs')
        return
    for ep in episodes:
        title = ep.get('title', '')
        url   = ep.get('url', '')
        desc  = ep.get('desc', '')
        date  = ep.get('date', '')
        dur   = ep.get('dur', '')

        display = title
        if date: display += f'  [{date[:16]}]'

        info = {
            'title':   title,
            'comment': desc,
            'album':   'LibriVox Podcast',
        }
        params = {
            'mode':  'play',
            'url':   url,
            'title': title,
            'thumb': ADDON_ICON,
        }
        li = _li(display, thumb=ICON_DIR+'icon_podcast.png',
                 info=info, playable=True)
        xbmcplugin.addDirectoryItem(
            handle=handle, url=build_url(base_url, params),
            listitem=li, isFolder=False)

    _end(handle, 'songs')


# -----------------------------------------------------------------------
# Hilfsfunktionen
# -----------------------------------------------------------------------

def _dur_to_sec(dur_str):
    """Konvertiert HH:MM:SS oder MM:SS in Sekunden."""
    if not dur_str:
        return 0
    try:
        parts = [int(x) for x in dur_str.strip().split(':')]
        if len(parts) == 3:
            return parts[0]*3600 + parts[1]*60 + parts[2]
        elif len(parts) == 2:
            return parts[0]*60 + parts[1]
        return int(parts[0])
    except Exception:
        return 0
