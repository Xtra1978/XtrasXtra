#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""URL-Router fuer LibriVox Addon."""

from urllib.parse import parse_qsl
from resources.lib import ui, player, api
import xbmc
import xbmcplugin
import xbmcgui


def dispatch(base_url, handle, args, addon):
    params = dict(parse_qsl(args.lstrip('?')))
    mode   = params.get('mode', 'main')

    if mode == 'main':
        ui.show_main_menu(base_url, handle, addon)

    elif mode == 'new_arrivals':
        ui.show_book_list(base_url, handle, addon,
                          title_id=30001,
                          fetch_fn=lambda page: api.get_new_arrivals(page),
                          page=int(params.get('page', 1)))

    elif mode == 'most_listened':
        ui.show_book_list(base_url, handle, addon,
                          title_id=30002,
                          fetch_fn=lambda page: api.get_most_listened(page),
                          page=int(params.get('page', 1)))

    elif mode == 'genres':
        ui.show_genres(base_url, handle, addon)

    elif mode == 'genre':
        genre_id = params.get('genre_id', '')
        page     = int(params.get('page', 1))
        genre    = api.get_genre_by_id(genre_id)
        if genre:
            ui.show_book_list(base_url, handle, addon,
                              title_id=genre['label'],
                              fetch_fn=lambda p, g=genre['lv_genre']:
                                  api.get_books_by_genre(g, p),
                              page=page,
                              mode='genre', extra={'genre_id': genre_id})

    elif mode == 'languages':
        ui.show_languages(base_url, handle, addon)

    elif mode == 'language':
        lang = params.get('lang', '')
        page = int(params.get('page', 1))
        ui.show_book_list(base_url, handle, addon,
                          title_id=30004,
                          fetch_fn=lambda p, l=lang:
                              api.get_books_by_language(l, p),
                          page=page,
                          mode='language', extra={'lang': lang})

    elif mode == 'authors':
        ui.show_author_search(base_url, handle, addon)

    elif mode == 'author_books':
        author_id   = params.get('author_id', '')
        author_name = params.get('author_name', '')
        page        = int(params.get('page', 1))
        ui.show_book_list(base_url, handle, addon,
                          title_id=30005,
                          fetch_fn=lambda p, aid=author_id:
                              api.get_books_by_author(aid, p),
                          page=page,
                          mode='author_books',
                          extra={'author_id': author_id,
                                 'author_name': author_name})

    elif mode == 'search':
        query = params.get('query', '') or ui.ask_search(addon)
        if query:
            ui.show_search_results(base_url, handle, addon, query,
                                   int(params.get('page', 1)))

    elif mode == 'book_detail':
        ui.show_book_detail(base_url, handle, addon,
                            params.get('book_id', ''),
                            params.get('ia_id', ''),
                            params.get('title', ''),
                            params.get('thumb', ''),
                            params.get('url_rss', ''))

    elif mode == 'play':
        player.play(
            handle=handle,
            url=params.get('url', ''),
            title=params.get('title', ''),
            thumb=params.get('thumb', ''),
            book_title=params.get('book_title', ''),
            author=params.get('author', ''),
            addon=addon,
        )

    elif mode == 'podcast':
        ui.show_podcast(base_url, handle, addon)

    elif mode == 'open_web':
        url = params.get('url', '')
        if url:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{url})')
        xbmcplugin.endOfDirectory(handle, succeeded=False)

    else:
        ui.show_main_menu(base_url, handle, addon)
