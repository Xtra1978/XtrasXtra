#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Player fuer LibriVox – MP3 Audiobook Streams."""

import xbmc
import xbmcgui
import xbmcplugin
from urllib.request import urlopen, Request

ADDON_ICON   = 'special://home/addons/plugin.audio.librivox/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.audio.librivox/resources/media/fanart.jpg'
UA           = 'KodiLibriVox/1.0 (kodi.tv)'


def play(handle, url, title, thumb, book_title='', author='', addon=None):
    if not url:
        msg = addon.getLocalizedString(30016) if addon else 'No stream available.'
        xbmcgui.Dialog().notification('LibriVox', msg,
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    xbmc.log(f'[LibriVox] Play: {title[:60]} | {url[:80]}', xbmc.LOGINFO)

    # Warmup gemaess Setting
    warmup = addon.getSetting('warmup') == 'true' if addon else True
    if warmup:
        try:
            req = Request(url, method='HEAD',
                          headers={'User-Agent': UA, 'Range': 'bytes=0-1023'})
            urlopen(req, timeout=5)
        except Exception:
            pass

    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setArt({
        'thumb':  thumb or ADDON_ICON,
        'icon':   thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
    })
    li.setInfo('music', {
        'title':  title,
        'artist': author,
        'album':  book_title,
    })
    li.setMimeType('audio/mpeg')
    li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(handle, True, li)
