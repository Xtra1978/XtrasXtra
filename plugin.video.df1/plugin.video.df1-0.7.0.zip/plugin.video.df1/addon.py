# -*- coding: utf-8 -*-
"""DF1 video addon 0.4.0 - Kodi Omega/Python 3."""
import sys, json, re, html as htmlmod
from urllib.parse import parse_qs, urlencode
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
try:
    import requests
except ImportError:
    requests = None
HANDLE=int(sys.argv[1]); ADDON=xbmcaddon.Addon()
BASE="https://df1.de"; UA="Mozilla/5.0 (Kodi; DF1 addon)"
API=BASE+"/wp-json/wp/v2/pages/?per_page=99"
PREROLL_API=BASE+"/wp-json/wp/v2/prerolls/?per_page=99"
OPTIONS_API=BASE+"/wp-json/wp/v2/options/all"
ART=str(__import__("xbmcaddon").Addon().getAddonInfo("path"))+"/resources/media/"
LIVE_FALLBACK="https://d287776cjxyfeq.cloudfront.net/out/v1/08823cd7fba74508a5a577fd51dc41f6/index.m3u8"
STATIC=[("Terra Mater","https://vod.df1.cinepost.de/A04550240-T0118-EP3/h264/main.m3u8"),("MotoGP San Marino","https://vod.df1.cinepost.de/a492dca4_p01203_mgp_sanmarino_40_datum_web/h264/main.m3u8"),("Total Cup Buchbach","https://vod.df1.cinepost.de/f22cd88f_totocup_60_buchbach_010926/h264/main.m3u8"),("Ikarus – Tim Raue in Salzburg","https://vod.df1.cinepost.de/1325257667207-1814868953/h264/main.m3u8")]
def get(url):
 try:
  if requests:
   r=requests.get(url,headers={"User-Agent":UA,"Accept":"application/json,text/plain,*/*"},timeout=20); r.raise_for_status(); return r.json()
  return json.loads(__import__('urllib.request').request.urlopen(__import__('urllib.request').request.Request(url,headers={"User-Agent":UA}),timeout=20).read().decode())
 except Exception as e: xbmc.log("DF1 API: %s"%e,xbmc.LOGERROR); return None
def qurl(action,**kw): return sys.argv[0]+"?"+urlencode(dict(action=action,**kw))
def item(label,url,is_folder=False,thumb="",info=None):
 li=xbmcgui.ListItem(label=label); li.setArt({"thumb":thumb,"icon":thumb,"fanart":thumb})
 tag=li.getVideoInfoTag(); tag.setTitle(label)
 if info:
  if info.get('plot'): tag.setPlot(info['plot'])
  if info.get('genre'): tag.setGenres([info['genre']])
 xbmcplugin.addDirectoryItem(HANDLE,url,li,isFolder=is_folder)
def walk(o,out,seen):
 if isinstance(o,dict):
  acf=o.get('acf') if isinstance(o.get('acf'),dict) else {}
  src=acf.get('source_url')
  if isinstance(src,str) and ('.m3u8' in src or '.mpd' in src):
   title=acf.get('video_display_title') or o.get('title',{}).get('rendered') or o.get('post_title') or 'DF1 Video'
   title=htmlmod.unescape(re.sub('<[^>]+>','',str(title))).strip()
   cats=acf.get('video_category') or []
   cat=', '.join([str(x.get('label') if isinstance(x,dict) else x) for x in cats]) or 'Weitere Videos'
   img=''
   ti=acf.get('teaser_image')
   if isinstance(ti,dict): img=ti.get('url') or ti.get('source_url') or ''
   key=(title,src)
   if key not in seen: out.append({'title':title,'stream':src,'category':cat,'thumb':img,'plot':acf.get('video_description') or acf.get('video_short_desciption',''),'genre':cat}); seen.add(key)
  for v in o.values(): walk(v,out,seen)
 elif isinstance(o,list):
  for v in o: walk(v,out,seen)
def videos():
 out=[]; seen=set(); data=get(API)
 if data: walk(data,out,seen)
 for title,src in STATIC:
  if not any(v['stream']==src for v in out): out.append({'title':title,'stream':src,'category':'Weitere Videos','thumb':'','plot':'','genre':''})
 return out
def prerolls():
 data=get(PREROLL_API); out=[]
 if isinstance(data,list):
  for x in data:
   a=x.get('acf',{}) if isinstance(x,dict) else {}; s=a.get('source_url')
   if s and '/prerolls/' in s: out.append(s)
 return out
def setting_bool(name, default=False):
    try:
        value=ADDON.getSetting(name)
        if value is None or value == "": return default
        return str(value).lower() in ("true", "1", "yes", "on")
    except Exception:
        return default

def setting_text(name, default=""):
    try:
        value=ADDON.getSetting(name)
        return value if value else default
    except Exception:
        return default

def play(src,title):
    # Live/HLS direkt an den Kodi-VideoPlayer übergeben. Keine erzwungene
    # inputstream.adaptive-Konfiguration, da sie auf älterer Intel-Hardware
    # beim Cloudfront-Livestream einen Kodi-Absturz auslösen kann.
    trailer=setting_bool("trailer", False)
    quality=setting_text("quality", "Auto")
    debug=setting_bool("debug", False)
    if debug: xbmc.log("DF1: play=%s trailer=%s quality=%s"%(title,trailer,quality),xbmc.LOGINFO)
    if trailer:
        pl=xbmc.PlayList(xbmc.PLAYLIST_VIDEO); pl.clear()
        for p in prerolls()[:1]: pl.add(p, xbmcgui.ListItem(label="DF1 Trailer"))
        li=xbmcgui.ListItem(label=title); li.setPath(src)
        pl.add(src,li); xbmc.Player().play(pl)
    else:
        li=xbmcgui.ListItem(label=title); li.setPath(src)
        li.setMimeType("application/vnd.apple.mpegurl")
        xbmc.Player().play(src, li)

def main():
 args=parse_qs(sys.argv[2][1:]) if len(sys.argv)>2 else {}; a=args.get('action',[''])[0]
 if a=='play': play(args.get('stream',[''])[0],args.get('title',['DF1 Video'])[0]); return
 if a=='live': play(LIVE_FALLBACK,'DF1 Live'); return
 if a=='settings': ADDON.openSettings(); return
 if a=='cat':
  cat=args.get('category',[''])[0]; vs=[v for v in videos() if v['category']==cat]
  for v in vs: item(v['title'],qurl('play',stream=v['stream'],title=v['title']),False,v['thumb'],v)
  xbmcplugin.endOfDirectory(HANDLE); return
 if a=='mediathek':
  vs=videos(); cats=[]
  for v in vs:
   if v['category'] not in cats: cats.append(v['category'])
  for c in cats: item(c,qurl('cat',category=c),True)
  xbmcplugin.endOfDirectory(HANDLE); return
 item('Startseite',qurl('mediathek'),True,ART+'background.jpg'); item('Mediathek',qurl('mediathek'),True,ART+'mediathek.jpg'); item('Live',qurl('live'),False,ART+'live.jpg'); item('Einstellungen',qurl('settings'),False,ART+'settings.jpg'); xbmcplugin.endOfDirectory(HANDLE)
main()
