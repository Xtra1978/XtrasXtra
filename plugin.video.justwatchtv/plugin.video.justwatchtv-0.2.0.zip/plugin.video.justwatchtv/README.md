# JustWatch TV Free — Kodi prototype (0.1.0)

Unofficial proof-of-concept Kodi video plugin based on the supplied JustWatch HAR captures.

## Included
- Browses popular free titles, separate movie/series catalogues, search, and show → season → episode navigation.
- Uses country, language, provider code, API endpoint, and page size from Kodi settings.
- Passes through HTTPS HLS (`.m3u8`) or MP4 streams returned by the API; it does not download, decrypt, or bypass DRM.
- English and German UI strings, optional debug logging, and empty future username/password settings.
- Does not contain embedded title IDs, offer IDs, or captured signed stream URLs.

## Important limitations
- The public GraphQL endpoint/schema is an observed web interface, not a documented or guaranteed addon API; it can change or reject native clients.
- Season and episode navigation now uses the observed JustWatch title-detail and season/episode API fields. The API is undocumented and may change; episode playback is offered only when the selected free offer yields a supported HTTPS HLS/MP4 stream. No DRM circumvention is attempted.
- Login fields are placeholders only and are not sent by the addon. Kodi persists settings in its addon profile; do not enter real credentials until login support is implemented.
- DRM streams are not handled. Playback depends on what Kodi supports on the target device and on the stream's signed URL lifetime.
- Use only where permitted by JustWatch and the relevant content rights holders. This project does not imply endorsement or official support.

## Install
1. In Kodi, install the ZIP via **Add-ons → Install from zip file** (enable unknown sources if needed).
2. Open **Video add-ons → JustWatch TV Free**.
3. Use **Settings** to change the country/language/provider code or enable debug logging.

## Debug
Kodi's log receives prefixed diagnostic messages when the Debug setting is enabled. The addon deliberately avoids logging full URLs, query tokens, cookies, credentials, or response payloads.
