# -*- coding: utf-8 -*-
"""Unofficial Kodi prototype for free JustWatch TV offers."""
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]

POPULAR_QUERY = """
query GetPopularTitles($country: Country!, $first: Int!, $language: Language!, $offset: Int!, $popularTitlesFilter: TitleFilter!, $watchNowFilter: WatchNowOfferFilter!) {
  popularTitles(country: $country, filter: $popularTitlesFilter, first: $first, sortBy: POPULAR, offset: $offset) {
    edges { node {
      __typename id objectType
      content(country: $country, language: $language) {
        title fullPath originalReleaseYear posterUrl(profile: S718)
      }
      watchNowOffer(country: $country, platform: WEB, filter: $watchNowFilter) {
        id standardWebURL streamUrlExternalPlayer streamUrl monetizationType
        package { clearName shortName technicalName }
      }
    } }
    pageInfo { hasNextPage }
    totalCount
  }
}
"""

SHOW_SEASONS_QUERY = """
query GetShowSeasons($fullPath: String!, $country: Country!, $language: Language!, $provider: String!) {
  urlV2(fullPath: $fullPath, site: "www") {
    node {
      __typename id
      ... on Show {
        content(country: $country, language: $language) { title }
        seasons(sortDirection: DESC) {
          id
          content(country: $country, language: $language) {
            title seasonNumber fullPath posterUrl
          }
          offers(country: $country, platform: WEB, filter: {packages: [$provider]}) {
            id monetizationType package { technicalName clearName }
          }
        }
      }
    }
  }
}
"""

SEASON_EPISODES_QUERY = """
query GetSeasonEpisodes($seasonId: ID!, $country: Country!, $language: Language!, $provider: String!, $limit: Int!) {
  node(id: $seasonId) {
    __typename id
    ... on Season {
      content(country: $country, language: $language) { title seasonNumber }
      episodes(limit: $limit) {
        id
        content(country: $country, language: $language) {
          title seasonNumber episodeNumber shortDescription runtime
        }
        offers(country: $country, platform: WEB,
          filter: {packages: [$provider], monetizationTypes: [FREE], bestOnly: true}) {
          id streamUrlExternalPlayer streamUrl monetizationType
          package { clearName shortName technicalName }
        }
      }
    }
  }
}
"""

PLAY_INFORMATION_QUERY = """
mutation GetPlayInformation($input: GetPlayInformationInput!) {
  getPlayInformation(input: $input) {
    errorCode
    streams { url encodingType drmType manifestContent }
    offer { id streamUrlExternalPlayer streamUrl }
  }
}
"""


def setting(key, default=""):
    value = ADDON.getSetting(key)
    return value if value != "" else default


def log(message, level=xbmc.LOGINFO):
    if setting("debug") == "true" or level >= xbmc.LOGWARNING:
        xbmc.log("[JustWatchTV] " + str(message), level)


def tr(msgid, fallback):
    try:
        return ADDON.getLocalizedString(msgid) or fallback
    except Exception:
        return fallback


def notify(message, heading=None):
    xbmcgui.Dialog().notification(heading or "JustWatch TV", message, xbmcgui.NOTIFICATION_INFO, 5000)


def api_call(operation, query, variables):
    endpoint = setting("api_endpoint", "https://apis.justwatch.com/graphql").strip()
    if not endpoint.startswith("https://"):
        raise ValueError("API-Endpunkt muss HTTPS verwenden")
    payload = json.dumps({"operationName": operation, "query": query,
                          "variables": variables}, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(endpoint, data=payload, headers={
        "Accept": "application/json", "Content-Type": "application/json",
        "Origin": "https://www.justwatch.com", "Referer": "https://www.justwatch.com/",
        "User-Agent": "Kodi JustWatchTV addon/0.2.0",
    }, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            raw = response.read(8 * 1024 * 1024 + 1)
        if len(raw) > 8 * 1024 * 1024:
            raise ValueError("API-Antwort ist unerwartet groß")
        data = json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        log("API HTTP-Fehler: %s" % exc.code, xbmc.LOGWARNING)
        raise RuntimeError("JustWatch-API antwortet mit HTTP %s" % exc.code)
    except Exception as exc:
        log("API-Aufruf fehlgeschlagen: %s" % type(exc).__name__, xbmc.LOGWARNING)
        raise RuntimeError("JustWatch-API ist derzeit nicht erreichbar")
    if data.get("errors"):
        log("GraphQL %s meldet %d Fehler" % (operation, len(data["errors"])), xbmc.LOGWARNING)
        raise RuntimeError("JustWatch hat die Anfrage abgelehnt (API kann geändert worden sein)")
    return data.get("data", {})


def api_context():
    return setting("country", "DE").strip().upper(), setting("language", "de").strip().lower(), setting("provider_code", "jwt").strip()


def plugin_url(params):
    return BASE + "?" + urllib.parse.urlencode(params)


def end_directory():
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_catalog(search_text="", offset=0, object_type=""):
    country, language, provider = api_context()
    try:
        size = max(5, min(100, int(setting("page_size", "30"))))
    except ValueError:
        size = 30
    filter_value = {
        "packages": [provider] if provider else [], "monetizationTypes": ["FREE"],
        "ageCertifications": [], "excludeGenres": [], "excludeProductionCountries": [],
        "objectTypes": [object_type] if object_type else [], "productionCountries": [],
        "subgenres": [], "genres": [], "excludeIrrelevantTitles": False,
        "presentationTypes": [], "searchQuery": search_text,
    }
    watch_filter = {"packages": [provider] if provider else [], "monetizationTypes": ["FREE"]}
    result = api_call("GetPopularTitles", POPULAR_QUERY, {
        "country": country, "language": language, "first": size, "offset": offset,
        "popularTitlesFilter": filter_value, "watchNowFilter": watch_filter,
    })
    listing = result.get("popularTitles") or {}
    for edge in listing.get("edges") or []:
        node = (edge or {}).get("node") or {}
        content = node.get("content") or {}
        offer = node.get("watchNowOffer") or {}
        title = content.get("title") or tr(30040, "Unbenannter Titel")
        year = content.get("originalReleaseYear")
        show = node.get("__typename") == "Show" or node.get("objectType") == "SHOW"
        label = "%s (%s)" % (title, year) if year else title
        stream = offer.get("streamUrlExternalPlayer") or offer.get("streamUrl") or ""
        poster = content.get("posterUrl") or ""
        item = xbmcgui.ListItem(label=label)
        item.setArt({"thumb": poster, "icon": poster})
        info = {"title": title, "mediatype": "tvshow" if show else "movie"}
        if year:
            info["year"] = year
        item.setInfo("video", info)
        item.setProperty("IsPlayable", "false" if show else "true" if stream else "false")
        if show:
            route = {"action": "seasons", "fullpath": content.get("fullPath", ""), "title": title}
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url(route), item, isFolder=True)
        elif stream:
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({"action": "play", "url": stream, "title": title}), item, isFolder=False)
        elif offer.get("id"):
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({"action": "play_offer", "offer_id": offer["id"], "title": title}), item, isFolder=False)
        else:
            item.setLabel(label + " — " + tr(30048, "kein Stream verfügbar"))
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({"action": "unavailable"}), item, isFolder=False)
    if listing.get("pageInfo", {}).get("hasNextPage"):
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({
            "action": "more", "offset": offset + size, "search": search_text,
            "object_type": object_type,
        }), xbmcgui.ListItem(tr(30041, "Weitere Ergebnisse …")), True)
    end_directory()


def show_seasons(fullpath, show_title):
    country, language, provider = api_context()
    if not fullpath:
        notify(tr(30049, "Für diese Serie fehlt der JustWatch-Pfad."))
        end_directory()
        return
    data = api_call("GetShowSeasons", SHOW_SEASONS_QUERY, {
        "fullPath": fullpath, "country": country, "language": language, "provider": provider,
    })
    node = ((data.get("urlV2") or {}).get("node") or {})
    seasons = node.get("seasons") or []
    if not seasons:
        notify(tr(30050, "Keine Staffeln gefunden."))
    for season in seasons:
        content = season.get("content") or {}
        number = content.get("seasonNumber")
        label = content.get("title") or (tr(30051, "Staffel") + " %s" % number if number else tr(30051, "Staffel"))
        item = xbmcgui.ListItem(label=label)
        poster = content.get("posterUrl") or ""
        item.setArt({"thumb": poster, "icon": poster})
        item.setInfo("video", {"title": label, "tvshowtitle": show_title, "mediatype": "season", "season": number or 0})
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({
            "action": "episodes", "season_id": season.get("id", ""),
            "season_title": label, "show_title": show_title,
        }), item, isFolder=True)
    end_directory()


def season_episodes(season_id, season_title, show_title):
    country, language, provider = api_context()
    if not season_id:
        notify(tr(30052, "Die Staffel-ID fehlt."))
        end_directory()
        return
    result = api_call("GetSeasonEpisodes", SEASON_EPISODES_QUERY, {
        "seasonId": season_id, "country": country, "language": language,
        "provider": provider, "limit": 100,
    })
    node = result.get("node") or {}
    episodes = node.get("episodes") or []
    added = 0
    for episode in episodes:
        content = episode.get("content") or {}
        offers = episode.get("offers") or []
        offer = next((o for o in offers if o and o.get("id")), {})
        if not offer:
            continue
        number = content.get("episodeNumber")
        label = ("E%02d — " % number if isinstance(number, int) else "") + (content.get("title") or tr(30053, "Folge"))
        stream = offer.get("streamUrlExternalPlayer") or offer.get("streamUrl") or ""
        item = xbmcgui.ListItem(label=label)
        item.setInfo("video", {
            "title": content.get("title") or label, "tvshowtitle": show_title,
            "season": content.get("seasonNumber") or 0, "episode": number or 0,
            "mediatype": "episode", "plot": content.get("shortDescription") or "",
            "duration": content.get("runtime") or 0,
        })
        item.setProperty("IsPlayable", "true")
        if stream:
            route = {"action": "play", "url": stream, "title": label}
        else:
            route = {"action": "play_offer", "offer_id": offer["id"], "title": label}
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(route), item, isFolder=False)
        added += 1
    if not added:
        notify(tr(30054, "Für diese Staffel wurden keine kostenlosen JustWatch-TV-Folgen gefunden."))
    end_directory()


def play_offer(offer_id, title):
    if not offer_id:
        notify(tr(30042, "Kein unterstützbarer Stream für diesen Titel gefunden."))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    result = api_call("GetPlayInformation", PLAY_INFORMATION_QUERY, {
        "input": {"offerId": offer_id, "drmType": "playready", "deviceOs": "windows"},
    })
    info = result.get("getPlayInformation") or {}
    offer = info.get("offer") or {}
    stream = offer.get("streamUrlExternalPlayer") or offer.get("streamUrl") or ""
    if not stream:
        for variant in info.get("streams") or []:
            stream = variant.get("url") or ""
            if stream:
                break
    if stream:
        play(stream, title)
    else:
        log("PlayInformation lieferte keinen unterstützten Stream (Fehlercode %s)" % info.get("errorCode"), xbmc.LOGWARNING)
        notify(tr(30042, "Kein unterstützbarer Stream für diesen Titel gefunden."))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def play(url, title):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or not parsed.path.lower().endswith((".m3u8", ".mp4")):
        notify(tr(30042, "Kein unterstützbarer HTTPS-Stream für diesen Titel gefunden."))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    item = xbmcgui.ListItem(path=url)
    item.setInfo("video", {"title": title})
    if parsed.path.lower().endswith(".m3u8"):
        item.setMimeType("application/vnd.apple.mpegurl")
    item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def media_menu():
    for label_id, action, fallback in [
        (30055, "movies", "Filme"), (30056, "series", "Serien"),
    ]:
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({"action": action}), xbmcgui.ListItem(tr(label_id, fallback)), True)
    end_directory()


def root_menu():
    rows = [
        (tr(30043, "Beliebte kostenlose Titel"), {"action": "list"}),
        (tr(30057, "Filme & Serien"), {"action": "media_menu"}),
        (tr(30044, "Suchen"), {"action": "search"}),
        (tr(30045, "Einstellungen"), {"action": "settings"}),
    ]
    for label, params in rows:
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), xbmcgui.ListItem(label), True)
    end_directory()


def run():
    params = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(sys.argv[2] if len(sys.argv) > 2 else "").query))
    action = params.get("action", "root")
    try:
        if action == "root":
            root_menu()
        elif action == "media_menu":
            media_menu()
        elif action in ("list", "more", "movies", "series"):
            requested = params.get("object_type", "")
            if action == "movies": requested = "MOVIE"
            if action == "series": requested = "SHOW"
            list_catalog(params.get("search", ""), int(params.get("offset", "0")), requested)
        elif action == "search":
            text = xbmcgui.Dialog().input(tr(30046, "Titel suchen"), type=xbmcgui.INPUT_ALPHANUM)
            if text: list_catalog(text)
            else: end_directory()
        elif action == "seasons":
            show_seasons(params.get("fullpath", ""), params.get("title", ""))
        elif action == "episodes":
            season_episodes(params.get("season_id", ""), params.get("season_title", ""), params.get("show_title", ""))
        elif action == "play":
            play(params.get("url", ""), params.get("title", ""))
        elif action == "play_offer":
            play_offer(params.get("offer_id", ""), params.get("title", ""))
        elif action == "settings":
            ADDON.openSettings()
            end_directory()
        elif action == "unavailable":
            notify(tr(30058, "Dieser Titel ist derzeit nicht direkt abspielbar."))
            end_directory()
        else:
            root_menu()
    except Exception as exc:
        log("Aktion fehlgeschlagen: %s" % type(exc).__name__, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("JustWatch TV", str(exc))
        end_directory()


if __name__ == "__main__":
    run()
