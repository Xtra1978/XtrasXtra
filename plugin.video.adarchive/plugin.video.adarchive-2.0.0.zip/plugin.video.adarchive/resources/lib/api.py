#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API-Modul: Internet Archive Werbefilm-Collections.
- Keine hartcodierten UI-Strings
- Alle Settings per addon.getSetting()
- Echte Stream-URLs per Metadata-Aufloesung (kein 404-Problem)
- _clean() mit Wortgrenze
"""

import json
import re
import time
import xbmc
import xbmcaddon
from urllib.request import urlopen, Request
from urllib.parse   import urlencode, quote
from urllib.error   import HTTPError, URLError

IA_SEARCH = 'https://archive.org/advancedsearch.php'
IA_META   = 'https://archive.org/metadata/{id}'
UA        = 'Mozilla/5.0 (compatible; KodiAdArchive/2.0; kodi.tv)'
TIMEOUT   = 20


def _addon():
    return xbmcaddon.Addon()

def _str(sid):
    """Lokalisierter String aus strings.po."""
    try:
        return _addon().getLocalizedString(sid)
    except Exception:
        return str(sid)

def _setting(key, default=''):
    try:
        return _addon().getSetting(key) or default
    except Exception:
        return default

def _log(msg, level=xbmc.LOGDEBUG):
    """Logging mit Respekt fuer Log-Level-Einstellung."""
    try:
        if _setting('logging_enabled') != 'true' and level == xbmc.LOGDEBUG:
            return
        log_level = _setting('log_level', '30311')
        if log_level == '30310' and level not in (xbmc.LOGERROR, xbmc.LOGWARNING):
            return
        xbmc.log(f'[AdArchive] {msg}', level)
    except Exception:
        xbmc.log(f'[AdArchive] {msg}', level)

def _per_page():
    try:
        return int(_setting('per_page', '30'))
    except (ValueError, TypeError):
        return 30

def _sort_ia():
    val = _setting('sort_order', '30110')
    return {'30110': 'downloads desc',
            '30111': 'date desc',
            '30112': 'date asc'}.get(val, 'downloads desc')

def _quality():
    """0=auto/best, 1=high, 2=low"""
    val = _setting('quality', '30113')
    return {'30113': 0, '30114': 1, '30115': 2}.get(val, 0)

def _warmup_enabled():
    return _setting('warmup', 'true') == 'true'

def _skip_nofile():
    return _setting('skip_nofile', 'false') == 'true'


# -----------------------------------------------------------------------
# Sammlungen – label verweist auf String-ID (kein hartcodierter Text)
# -----------------------------------------------------------------------

COLLECTIONS = [
    {
        'id':      'duke_adviews',
        'label':   30020,
        'desc':    '8,800+ US TV spots from the 1950s to 1980s. '
                   'D\'Arcy Masius Benton & Bowles archive at Duke University.',
        'query':   'collection:duke_adviews',
        'icon':    'duke.png',
        'country': 'USA',
        'era':     '1950-1980',
    },
    {
        'id':      'prelinger',
        'label':   30021,
        'desc':    '6,000+ advertising, industrial and educational films.',
        'query':   'collection:prelinger AND (subject:advertising OR subject:commercial OR subject:industrial)',
        'icon':    'prelinger.png',
        'country': 'USA',
        'era':     '1920-1980',
    },
    {
        'id':      'classic_tv',
        'label':   30022,
        'desc':    'Classic US television commercials from the golden TV era.',
        'query':   'collection:classic_tv_commercials',
        'icon':    'classic_tv.png',
        'country': 'USA',
        'era':     '1950-1970',
    },
    {
        'id':      'ad_council',
        'label':   30023,
        'desc':    'Public service announcements. Smokey Bear, "Just Say No" and more.',
        'query':   'subject:"ad council" OR subject:"public service announcement" AND mediatype:movies',
        'icon':    'adcouncil.png',
        'country': 'USA',
        'era':     '1940-2000',
    },
    {
        'id':      'avgeeks',
        'label':   30024,
        'desc':    'Skip Elsheimer\'s collection of industrial and advertising films.',
        'query':   'collection:avisualarchive AND mediatype:movies',
        'icon':    'avgeeks.png',
        'country': 'USA',
        'era':     '1930-1980',
    },
    {
        'id':      'ddr_werbung',
        'label':   30025,
        'desc':    'East German advertising – DEWAG, Exquisit, Delikat and more.',
        'query':   '(subject:"DDR Werbung" OR subject:"DDR Werbefilm" OR subject:"GDR commercial" OR subject:DEWAG) AND mediatype:movies',
        'icon':    'ddr.png',
        'country': 'GDR',
        'era':     '1950-1989',
    },
    {
        'id':      'ephemeral',
        'label':   30026,
        'desc':    'Ephemeral advertising and industrial films.',
        'query':   'collection:ephemeral AND (subject:advertising OR subject:commercial) AND mediatype:movies',
        'icon':    'ephemeral.png',
        'country': 'USA/INT',
        'era':     '1920-1980',
    },
    {
        'id':      'vintage_commercials',
        'label':   30027,
        'desc':    'International television advertising from around the world.',
        'query':   '(subject:"television commercial" OR subject:"TV commercial" OR subject:"TV spot") AND mediatype:movies',
        'icon':    'international.png',
        'country': 'INT',
        'era':     '1950-2000',
    },
    {
        'id':      'political_ads',
        'label':   30028,
        'desc':    'Historic US presidential and political campaign spots.',
        'query':   '(subject:"political advertising" OR subject:"campaign commercial" OR subject:"presidential campaign") AND mediatype:movies',
        'icon':    'political.png',
        'country': 'USA',
        'era':     '1952-2000',
    },
    {
        'id':      'uk_commercials',
        'label':   30029,
        'desc':    'British TV spots – Cadbury, Guinness, Bovril and more.',
        'query':   '(subject:"British commercial" OR subject:"UK advertising" OR subject:"ITV commercial") AND mediatype:movies',
        'icon':    'uk.png',
        'country': 'UK',
        'era':     '1955-1990',
    },
    {
        'id':      'xmas_ads',
        'label':   30030,
        'desc':    'Historic Christmas and holiday advertising.',
        'query':   '(subject:Christmas OR subject:Weihnachten) AND (subject:commercial OR subject:advertising) AND mediatype:movies',
        'icon':    'weihnachten.png',
        'country': 'INT',
        'era':     '1950-2000',
    },
    {
        'id':      'cigarette_ads',
        'label':   30031,
        'desc':    'Historic tobacco spots – Marlboro, Lucky Strike, Camel.',
        'query':   '(subject:cigarette OR subject:tobacco OR subject:Marlboro OR subject:"Lucky Strike") AND (subject:commercial OR subject:advertising) AND mediatype:movies',
        'icon':    'tabak.png',
        'country': 'USA/INT',
        'era':     '1950-1970',
    },
    {
        'id':      'food_ads',
        'label':   30032,
        'desc':    'Food, beverage and restaurant advertising. Coca-Cola, Kellogg\'s and more.',
        'query':   '(subject:"food commercial" OR subject:"beverage advertising" OR subject:"Coca-Cola" OR subject:Kellogg) AND mediatype:movies AND (subject:commercial OR subject:advertising)',
        'icon':    'food.png',
        'country': 'INT',
        'era':     '1950-2000',
    },
    {
        'id':      'auto_ads',
        'label':   30033,
        'desc':    'Classic car spots – Ford, Chevrolet, Volkswagen, BMW.',
        'query':   '(subject:"automobile advertising" OR subject:"car commercial" OR subject:Ford OR subject:Chevrolet OR subject:Volkswagen) AND mediatype:movies AND (subject:commercial OR subject:advertising)',
        'icon':    'auto.png',
        'country': 'INT',
        'era':     '1950-1990',
    },
]


def get_collection_by_id(col_id):
    for col in COLLECTIONS:
        if col['id'] == col_id:
            return col
    return None


# -----------------------------------------------------------------------
# Suche
# -----------------------------------------------------------------------

def search_collection(col_id, page=1):
    col = get_collection_by_id(col_id)
    if not col:
        return [], 0
    return _ia_search(col['query'], page, _per_page(), _sort_ia())


def search_all(query, page=1):
    base_q = (
        f'({query}) AND mediatype:movies AND '
        f'(subject:advertising OR subject:commercial OR subject:"TV spot" '
        f'OR subject:Werbung OR collection:duke_adviews OR collection:prelinger)'
    )
    return _ia_search(base_q, page, _per_page(), _sort_ia())


def _ia_search(query, page, per_page, sort):
    params = {
        'q':      query,
        'fl[]':   ['identifier', 'title', 'creator', 'date',
                   'description', 'subject', 'downloads', 'collection'],
        'rows':   per_page,
        'page':   page,
        'output': 'json',
        'sort[]': sort,
    }
    url  = f'{IA_SEARCH}?{urlencode(params, doseq=True)}'
    if _setting('log_api') == 'true':
        _log(f'Search: {url[:100]}', xbmc.LOGDEBUG)
    data = _get(url)
    if not data:
        return [], 0
    docs  = data.get('response', {}).get('docs', [])
    total = data.get('response', {}).get('numFound', 0)
    items = [_parse_doc(d) for d in docs if d.get('identifier')]
    items = [i for i in items if i]
    _log(f'Search results: {len(items)} (total={total})', xbmc.LOGINFO)
    return items, total


def _parse_doc(doc):
    ia_id    = doc.get('identifier', '')
    title    = _first(doc.get('title',       ia_id))
    creator  = _first(doc.get('creator',     ''))
    date_raw = _first(doc.get('date',        ''))
    desc     = _first(doc.get('description', ''))
    year     = str(date_raw)[:4] if date_raw else ''
    col      = _first(doc.get('collection',  ''))
    return {
        'id':       ia_id,
        'title':    str(title),
        'year':     year,
        'desc':     _clean(str(desc)),
        'creator':  str(creator),
        'source':   _collection_label(col),
        'thumb':    f'https://archive.org/services/img/{ia_id}',
        'page_url': f'https://archive.org/details/{ia_id}',
    }


# -----------------------------------------------------------------------
# Stream-URL aufloesen (echte Dateinamen per Metadata)
# -----------------------------------------------------------------------

def resolve_stream(ia_id):
    """
    Laedt Metadata und gibt beste verfuegbare Video-URL zurueck.
    Loest das 404-Problem: ia_id/ia_id.mp4 existiert meist nicht.
    """
    _log(f'Resolving stream: {ia_id}', xbmc.LOGINFO)
    data = _get(IA_META.format(id=ia_id))
    if not data:
        return None, 'video/mp4'

    files     = data.get('files', [])
    quality   = _quality()
    skip      = _skip_nofile()
    candidates = []

    for f in files:
        fname = f.get('name', '')
        fmtl  = f.get('format', '').lower()
        fname_lower = fname.lower()

        # Unerwuenschte Dateien ausschliessen
        if any(x in fname_lower for x in [
            'thumb', 'sample', '512kb', 'gif', 'png', 'jpg', 'jpeg',
            'sqlite', 'xml', 'json', 'txt', '_meta', 'torrent', 'asr', 'srt'
        ]):
            continue

        mime = ''
        if fname_lower.endswith('.mp4') or 'mp4' in fmtl or 'mpeg4' in fmtl or 'h.264' in fmtl:
            mime = 'video/mp4'
        elif fname_lower.endswith('.ogv') or 'ogg' in fmtl:
            mime = 'video/ogg'
        elif fname_lower.endswith('.webm') or 'webm' in fmtl:
            mime = 'video/webm'
        elif fname_lower.endswith('.mpeg') or fname_lower.endswith('.mpg'):
            mime = 'video/mpeg'
        elif fname_lower.endswith('.avi'):
            mime = 'video/x-msvideo'
        elif fname_lower.endswith('.mov'):
            mime = 'video/quicktime'

        if not mime:
            continue

        try:
            size = int(f.get('size', 0))
        except (ValueError, TypeError):
            size = 0

        fmt_priority = {
            'video/mp4': 4, 'video/ogg': 3, 'video/webm': 2,
            'video/mpeg': 1, 'video/x-msvideo': 0, 'video/quicktime': 0
        }
        candidates.append({
            'url':      f'https://archive.org/download/{ia_id}/{quote(fname)}',
            'mime':     mime,
            'size':     size,
            'priority': fmt_priority.get(mime, 0),
        })

    if not candidates:
        if skip:
            return None, 'video/mp4'
        _log(f'No video files found for {ia_id}', xbmc.LOGWARNING)
        return None, 'video/mp4'

    if quality == 2:
        # Niedrig: kleinste Datei
        candidates.sort(key=lambda c: c['size'] if c['size'] > 0 else 999999999)
    else:
        # Auto/Hoch: beste Qualitaet (Format-Prioritaet + groesste Datei)
        candidates.sort(key=lambda c: (c['priority'], c['size']), reverse=True)

    best = candidates[0]
    _log(f'Best stream: {best["url"][-40:]} ({best["mime"]})', xbmc.LOGINFO)
    return best['url'], best['mime']


def get_all_streams(ia_id):
    """Alle verfuegbaren Streams eines Items (fuer Detail-Ansicht)."""
    data = _get(IA_META.format(id=ia_id))
    if not data:
        return []
    files   = data.get('files', [])
    streams = []
    for f in files:
        fname       = f.get('name', '')
        fmtl        = f.get('format', '').lower()
        fname_lower = fname.lower()
        if any(x in fname_lower for x in [
            'thumb', 'sample', 'sqlite', 'xml', 'json',
            'txt', '_meta', 'torrent', 'gif', 'png', 'jpg', 'jpeg', 'asr', 'srt'
        ]):
            continue
        mime = ''
        if fname_lower.endswith('.mp4') or 'mp4' in fmtl or 'mpeg4' in fmtl:
            mime = 'video/mp4'
        elif fname_lower.endswith('.ogv') or 'ogg' in fmtl:
            mime = 'video/ogg'
        elif fname_lower.endswith('.webm') or 'webm' in fmtl:
            mime = 'video/webm'
        elif fname_lower.endswith('.mpeg') or fname_lower.endswith('.mpg'):
            mime = 'video/mpeg'
        elif fname_lower.endswith('.avi'):
            mime = 'video/x-msvideo'
        if not mime:
            continue
        try:
            size_mb  = int(f.get('size', 0)) // 1024 // 1024
            size_str = f'{size_mb} MB' if size_mb else ''
        except (ValueError, TypeError):
            size_str = ''
        streams.append({
            'url':   f'https://archive.org/download/{ia_id}/{quote(fname)}',
            'mime':  mime,
            'label': f'{fname}{" – " + size_str if size_str else ""}',
        })
    fmt_order = {'video/mp4': 0, 'video/ogg': 1,
                 'video/webm': 2, 'video/mpeg': 3, 'video/x-msvideo': 4}
    streams.sort(key=lambda s: fmt_order.get(s['mime'], 5))
    return streams


def get_item_title(ia_id):
    data = _get(IA_META.format(id=ia_id))
    if not data:
        return ia_id
    meta  = data.get('metadata', {})
    title = meta.get('title', ia_id)
    return title[0] if isinstance(title, list) else str(title)


# -----------------------------------------------------------------------
# Hilfsfunktionen
# -----------------------------------------------------------------------

def _get(url, retries=2):
    for attempt in range(retries):
        try:
            req  = Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'})
            resp = urlopen(req, timeout=TIMEOUT)
            return json.loads(resp.read().decode('utf-8', errors='replace'))
        except HTTPError as e:
            if e.code == 429 and attempt < retries - 1:
                time.sleep(3)
            else:
                _log(f'HTTP {e.code}: {url[:80]}', xbmc.LOGWARNING)
                return None
        except Exception as e:
            _log(f'Error: {e}', xbmc.LOGWARNING)
            return None
    return None


def _collection_label(col_id):
    labels = {
        'duke_adviews':           'Duke AdViews',
        'prelinger':              'Prelinger Archives',
        'classic_tv_commercials': 'Classic TV',
        'avisualarchive':         'A/V Geeks',
        'ephemeral':              'Ephemeral Films',
    }
    return labels.get(col_id, col_id or 'Internet Archive')


def _first(val, default=''):
    if isinstance(val, list):
        return val[0] if val else default
    return val or default


def _clean(text):
    """Bereinigt HTML-Tags, bricht an Wortgrenze bei ~400 Zeichen."""
    if not text:
        return ''
    text = re.sub(r'<[^>]+>', '', str(text)).strip()
    if len(text) <= 400:
        return text
    # Wortgrenze finden
    pos = text.rfind(' ', 0, 400)
    return text[:pos] + '...' if pos > 0 else text[:400] + '...'
