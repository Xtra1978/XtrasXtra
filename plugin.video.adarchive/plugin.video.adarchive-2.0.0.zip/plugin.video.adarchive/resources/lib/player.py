#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Player fuer Ad Archive."""

import xbmc
import xbmcgui
import xbmcplugin
from urllib.request import urlopen, Request

ADDON_ICON   = 'special://home/addons/plugin.video.adarchive/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.video.adarchive/resources/media/fanart.jpg'
UA           = 'KodiAdArchive/2.0 (kodi.tv)'


def play(handle, url, title, thumb, mime='video/mp4', addon=None):
    if not url:
        xbmcgui.Dialog().notification(
            'Ad Archive',
            addon.getLocalizedString(30004) if addon else 'No stream available.',
            xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    xbmc.log(f'[AdArchive] Play: {title[:50]} | {url[:80]} | {mime}', xbmc.LOGINFO)

    # Warmup gemaess Setting
    try:
        warmup = addon.getSetting('warmup') == 'true' if addon else True
    except Exception:
        warmup = True

    if warmup:
        try:
            req = Request(url, method='HEAD',
                          headers={'User-Agent': UA, 'Range': 'bytes=0-1023'})
            urlopen(req, timeout=5)
        except Exception:
            pass

    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setArt({
        'thumb':  thumb or ADDON_ICON,
        'icon':   thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
        'poster': thumb or ADDON_ICON,
    })
    li.setInfo('video', {'title': title, 'mediatype': 'video'})

    mime_lower = mime.lower()
    if 'mp4'       in mime_lower: li.setMimeType('video/mp4')
    elif 'webm'    in mime_lower: li.setMimeType('video/webm')
    elif 'ogg'     in mime_lower: li.setMimeType('video/ogg')
    elif 'mpeg'    in mime_lower: li.setMimeType('video/mpeg')
    elif 'msvideo' in mime_lower: li.setMimeType('video/x-msvideo')
    elif 'mpegurl' in mime_lower:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setMimeType('application/x-mpegURL')
    else:
        li.setMimeType('video/mp4')
    li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(handle, True, li)
