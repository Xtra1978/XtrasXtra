#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI-Modul fuer Ad Archive – alle Strings aus strings.po."""

from urllib.parse import urlencode
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib import api
from resources.lib.api import COLLECTIONS

ADDON_ICON   = 'special://home/addons/plugin.video.adarchive/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.video.adarchive/resources/media/fanart.jpg'
ICON_DIR     = 'special://home/addons/plugin.video.adarchive/resources/media/icons/'


def _str(sid):
    try:
        return xbmcaddon.Addon().getLocalizedString(sid)
    except Exception:
        return str(sid)


def build_url(base_url, params):
    return '{0}?{1}'.format(base_url, urlencode(params))


def _li(label, thumb='', info=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        'icon':   thumb or ADDON_ICON,
        'thumb':  thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
        'poster': thumb or ADDON_ICON,
    })
    if info:
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _end(handle, content='movies'):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def _notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification('Ad Archive', msg, icon, 4000)


# -----------------------------------------------------------------------
# Hauptmenue
# -----------------------------------------------------------------------

def show_main_menu(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, _str(30000))

    # Suche
    url = build_url(base_url, {'mode': 'search'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url,
        listitem=_li(_str(30001), thumb=ICON_DIR + 'search.png'),
        isFolder=True)

    # Sammlungen – Label aus strings.po via label-ID
    for col in COLLECTIONS:
        label   = _str(col['label'])
        era     = col.get('era', '')
        country = col.get('country', '')
        display = f'{label}  [{country}  {era}]'.strip() if (era or country) else label
        icon    = ICON_DIR + col.get('icon', 'default.png')
        li      = _li(display, thumb=icon)
        li.setInfo('video', {'plot': col.get('desc', ''), 'mediatype': 'video'})
        url = build_url(base_url, {'mode': 'collection', 'col_id': col['id']})
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
                                    listitem=li, isFolder=True)

    _end(handle, 'files')


# -----------------------------------------------------------------------
# Sammlung
# -----------------------------------------------------------------------

def show_collection(base_url, handle, addon, col_id, page=1):
    col = api.get_collection_by_id(col_id)
    if not col:
        _notify(_str(30003), error=True)
        _end(handle)
        return

    label = _str(col['label'])
    xbmcplugin.setPluginCategory(handle, f'Ad Archive – {label}')

    items, total = api.search_collection(col_id, page=page)

    if not items:
        _notify(_str(30003))
        _end(handle)
        return

    for item in items:
        _add_item(base_url, handle, item)

    # Naechste Seite
    per_page = api._per_page()
    if page * per_page < total:
        pages_total = (total // per_page) + 1
        next_url    = build_url(base_url, {
            'mode':   'collection',
            'col_id': col_id,
            'page':   page + 1,
        })
        xbmcplugin.addDirectoryItem(
            handle=handle, url=next_url,
            listitem=_li(f'{_str(30002)}  ({page + 1}/{pages_total})'),
            isFolder=True)

    _end(handle)


# -----------------------------------------------------------------------
# Item
# -----------------------------------------------------------------------

def _add_item(base_url, handle, item):
    ia_id   = item.get('id', '')
    title   = item.get('title', 'Unknown')
    year    = item.get('year', '')
    thumb   = item.get('thumb', '')
    desc    = item.get('desc', '')
    creator = item.get('creator', '')
    source  = item.get('source', '')

    display = f'{title}  [{year}]' if year else title
    if source:
        display += f'  – {source}'

    info = {
        'title':     title,
        'year':      int(year) if str(year).isdigit() else 0,
        'plot':      f'{desc}\n\n{_str(30009)}: {source}' if source else desc,
        'director':  creator,
        'mediatype': 'video',
    }

    # Abspielen via resolve_and_play (laedt echte URL erst beim Klick)
    params = {
        'mode':  'resolve_and_play',
        'ia_id': ia_id,
        'title': title,
        'thumb': thumb,
    }
    url = build_url(base_url, params)
    li  = _li(display, thumb=thumb, info=info, playable=True)

    # Kontextmenue: Detail mit allen Qualitaeten
    detail_url = build_url(base_url, {'mode': 'item_detail', 'ia_id': ia_id})
    li.addContextMenuItems([
        (_str(30005), f'Container.Update({detail_url})')
    ])
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)


# -----------------------------------------------------------------------
# Detail-Ansicht (alle Stream-Qualitaeten)
# -----------------------------------------------------------------------

def show_item_detail(base_url, handle, addon, ia_id):
    streams = api.get_all_streams(ia_id)
    title   = api.get_item_title(ia_id)
    thumb   = f'https://archive.org/services/img/{ia_id}'

    xbmcplugin.setPluginCategory(handle, title)

    if not streams:
        _notify(_str(30004), error=True)
        _end(handle)
        return

    for i, s in enumerate(streams):
        label  = f'{_str(30007) if i == 0 else "▶"}  –  {s["label"]}'
        info   = {'title': title, 'mediatype': 'video'}
        params = {
            'mode':  'play',
            'url':   s['url'],
            'title': title,
            'thumb': thumb,
            'mime':  s['mime'],
        }
        url = build_url(base_url, params)
        li  = _li(label, thumb=thumb, info=info, playable=True)
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
                                    listitem=li, isFolder=False)

    # Link zu archive.org
    web_url = build_url(base_url, {
        'mode': 'open_web',
        'url':  f'https://archive.org/details/{ia_id}',
    })
    xbmcplugin.addDirectoryItem(handle=handle, url=web_url,
        listitem=_li(_str(30006)), isFolder=True)

    _end(handle)


# -----------------------------------------------------------------------
# Suche
# -----------------------------------------------------------------------

def ask_search(addon):
    return xbmcgui.Dialog().input(_str(30008), type=xbmcgui.INPUT_ALPHANUM)


def show_search_results(base_url, handle, addon, query):
    xbmcplugin.setPluginCategory(handle, f'Ad Archive – {_str(30001)}: {query}')

    items, total = api.search_all(query, page=1)

    if not items:
        _notify(_str(30003))
    else:
        for item in items:
            _add_item(base_url, handle, item)

    _end(handle)
