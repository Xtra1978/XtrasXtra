#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""URL-Router fuer Ad Archive."""

from urllib.parse import parse_qsl
from resources.lib import ui, player, api
import xbmc
import xbmcplugin
import xbmcgui


def dispatch(base_url, handle, args, addon):
    params = dict(parse_qsl(args.lstrip('?')))
    mode   = params.get('mode', 'main')

    if mode == 'main':
        ui.show_main_menu(base_url, handle, addon)

    elif mode == 'collection':
        ui.show_collection(base_url, handle, addon,
                           params.get('col_id', ''),
                           int(params.get('page', 1)))

    elif mode == 'search':
        query = params.get('query', '') or ui.ask_search(addon)
        if query:
            ui.show_search_results(base_url, handle, addon, query)

    elif mode == 'item_detail':
        ui.show_item_detail(base_url, handle, addon,
                            params.get('ia_id', ''))

    elif mode == 'resolve_and_play':
        # Echte Stream-URL per Metadata aufloesen
        ia_id = params.get('ia_id', '')
        title = params.get('title', ia_id)
        thumb = params.get('thumb', '')
        if not ia_id:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        stream_url, mime = api.resolve_stream(ia_id)
        if not stream_url:
            xbmcgui.Dialog().notification(
                'Ad Archive', addon.getLocalizedString(30004),
                xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        player.play(handle, url=stream_url, title=title,
                    thumb=thumb, mime=mime, addon=addon)

    elif mode == 'play':
        player.play(
            handle=handle,
            url=params.get('url', ''),
            title=params.get('title', ''),
            thumb=params.get('thumb', ''),
            mime=params.get('mime', 'video/mp4'),
            addon=addon,
        )

    elif mode == 'open_web':
        url = params.get('url', '')
        if url:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{url})')
        xbmcplugin.endOfDirectory(handle, succeeded=False)

    else:
        ui.show_main_menu(base_url, handle, addon)
