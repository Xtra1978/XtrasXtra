# -*- coding: utf-8 -*-
"""WedoTV (https://www.wedotv.com) – kostenlose Live-FAST-Kanäle und Mediathek (DE).

Eigene Plattform ohne Konto und ohne DRM:
  Live:  /api/getEpg.php          -> Kanäle mit HLS-Link und Programm
  VOD:   /de-de/movies|series|sports (HTML) -> Reihen (data-playlist_id)
         /api/getPlaylist.php     -> Titel einer Reihe (seitenweise)
         /de-de/<titel>           -> Staffeln und Episoden (data-video-id)
         /api/player.get_video.php?video_id=...  -> HLS-Stream und Untertitel
"""
import html as htmllib
import re
import time
import urllib.parse

from .. import util

SITE = 'https://www.wedotv.com'
REGIONS = ('de-at', 'de-de', 'de-ch')
PAGE_LIMIT = 24
GENRES = (('action', 'Action'), ('adventure', 'Abenteuer'), ('animation', 'Animation'), ('christmas', 'Weihnachten'),
          ('comedy', 'Komödie'), ('crime', 'Krimi'), ('documentary', 'Dokumentation'), ('drama', 'Drama'),
          ('family', 'Familie'), ('fantasy', 'Fantasy'), ('history', 'Geschichte'), ('horror', 'Horror'),
          ('music', 'Musik'), ('romance', 'Romantik'), ('sci-fi', 'Science-Fiction'), ('sports', 'Sport'),
          ('thriller', 'Thriller'))
COLLECTIONS = {
    'movies': (('new-movies-on-wedotv', 'Neue Filme'), ('unsere-empfehlungen', 'Unsere Empfehlungen'),
               ('stars', 'Stars'), ('action-movies', 'Actionfilme'), ('comedy-movies', 'Komödien'),
               ('romcom-movies', 'Romantische Komödien'), ('romance-movies', 'Romantik'),
               ('horror-movies', 'Horror'), ('western-movies', 'Western'), ('familien-filme', 'Familienfilme'),
               ('film-klassiker', 'Filmklassiker'), ('deutsche-filme', 'Deutsche Filme'),
               ('documentary-movies', 'Dokumentarfilme'), ('royale-dokus-und-filme', 'Royale Dokus und Filme'),
               ('kings-and-queens', 'Kings and Queens'), ('shark-movies', 'Hai-Filme'),
               ('miese-movies', 'Miese Movies'), ('miese-movies-desaster', 'Miese Movies: Desaster'),
               ('taste-of-love', 'Taste of Love'), ('soundtrack-des-lebens', 'Soundtrack des Lebens'),
               ('young-and-restless', 'Young and Restless'), ('young-gun-movies', 'Young Gun Movies'),
               ('tierisch-gut', 'Tierisch gut')),
    'series': (('serien-highlights', 'Serien-Highlights'), ('series-selection', 'Serien-Auswahl'),
               ('v2_series_nature', 'Natur und Dokus')),
}
SECTIONS = (('_home', 30063, 'home'), ('movies', 30041, 'movies'), ('series', 30042, 'series'), ('sports', 30043, 'sports'))


def _clean(text):
    return htmllib.unescape(re.sub(r'<[^>]+>', '', text or '')).strip()


def lang():
    """Region/Sprache der WedoTV-Seite (bestimmt Katalog und Link-Präfix)."""
    idx = util.setting_int('wedo_region', 0)
    return REGIONS[idx] if 0 <= idx < len(REGIONS) else REGIONS[0]


class Provider(object):
    id = 'wedotv'
    label = 30040
    icon = 'wedotv.png'
    available = True
    areas = ('live', 'vod')

    # ------------------------------------------------------------------ Live
    def _epg(self):
        key = 'wedotv:epg:%s' % lang()
        data = util.cache_get(key, 15 * 60)
        if data is None:
            channels, genres, offset = [], [], 0
            today = util.berlin_now().strftime('%Y-%m-%d')
            for _ in range(10):  # Sicherheitsgrenze gegen Endlosschleifen
                url = '%s/api/getEpg.php?%s' % (SITE, urllib.parse.urlencode(
                    {'offset': offset, 'limit': 50, 'date': today, 'genre': 'all'}))
                page = util.http_json(url, {'Accept': '*/*', 'Referer': '%s/%s/channels' % (SITE, lang())})
                genres = page.get('genres') or genres
                got = page.get('channels') or []
                channels.extend(got)
                if not got or not page.get('hasMore'):
                    break
                offset += len(got)
            playable = [c for c in channels if str(c.get('hls') or '').startswith('http')]
            if len(playable) < len(channels):
                util.log('WedoTV: %d von %d Kanälen ohne Stream-URL (Platzhalter "#", vermutlich nicht in dieser Region verfügbar)'
                         % (len(channels) - len(playable), len(channels)))
            data = {'genres': genres, 'channels': playable}
            if playable:
                util.cache_set(key, data)
        return data

    @staticmethod
    def _channel_tags(ch):
        tags = ch.get('tags')
        return tags if isinstance(tags, list) else re.findall(r"'([^']+)'", str(tags or ''))

    @staticmethod
    def _now_next(epg):
        now = time.time()
        current = upcoming = None
        for entry in epg or []:
            try:
                start, end, title = float(entry[0]), float(entry[1]), entry[2]
            except (TypeError, ValueError, IndexError):
                continue
            if start <= now < end:
                current = title
            elif start >= now and upcoming is None:
                upcoming = title
        return current, upcoming

    def _list_live(self, path):
        data = self._epg()
        if not path:
            items = [{'label': util.S(30007), 'folder': True, 'params': {'path': 'all'},
                      'art': {'icon': util.media('wedotv.png')}}]
            used = set(tag for ch in data['channels'] for tag in self._channel_tags(ch))
            for genre in data['genres']:
                if genre not in used:
                    continue
                items.append({'label': genre, 'folder': True, 'params': {'path': 'g:%s' % genre},
                              'art': {'icon': util.media('wedotv.png')}})
            return items
        wanted = path[2:] if path.startswith('g:') else None
        items = []
        for ch in sorted(data['channels'], key=lambda c: (c.get('name') or '').lower()):
            if wanted is not None and wanted not in self._channel_tags(ch):
                continue
            now, nxt = self._now_next(ch.get('epg'))
            plot = []
            if now:
                plot.append(util.S(30022) % now)
            if nxt:
                plot.append(util.S(30023) % nxt)
            items.append({'label': ch.get('name', '?'), 'folder': False, 'playable': True,
                          'params': {'action': 'play', 'kind': 'live', 'id': ch.get('id'), 'title': ch.get('name', '')},
                          'art': {'thumb': ch.get('logo'), 'icon': ch.get('logo')},
                          'info': {'title': ch.get('name'), 'plot': '\n'.join(plot)}})
        return items

    # ------------------------------------------------------------------ VOD
    def _sections(self, slug):
        key = 'wedotv:sections:%s:%s' % (lang(), slug)
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            page = util.http_get('%s/%s/%s' % (SITE, lang(), '' if slug == '_home' else slug), {'Accept': 'text/html'}, timeout=40)
            data = []
            for block in re.findall(r'<section class="carousel-section">(.*?)</section>', page, re.S):
                title = re.search(r'carousel-title">(.*?)<', block, re.S)
                pid = re.search(r'data-playlist_id="(\d+)"', block)
                fmt = re.search(r'js-carousel-(landscape|portrait)', block)
                if title and pid and _clean(title.group(1)) != 'Live-TV':
                    data.append({'title': _clean(title.group(1)), 'id': pid.group(1),
                                 'format': fmt.group(1) if fmt else 'portrait'})
            if data:
                util.cache_set(key, data)
        return data

    def _playlist(self, row, fmt, page):
        key = 'wedotv:playlist:%s:%s:%s:%d' % (lang(), row, fmt, page)
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            url = '%s/api/getPlaylist.php?%s' % (SITE, urllib.parse.urlencode(
                {'row': row, 'poster_format': fmt, 'page': page, 'limit': PAGE_LIMIT}))
            data = util.http_json(url, {'Accept': '*/*', 'Referer': '%s/%s/movies' % (SITE, lang())})
            util.cache_set(key, data)
        return data

    def _movies(self, genre, page):
        key = 'wedotv:movies:%s:%s:%d' % (lang(), genre, page)
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            url = '%s/api/getMovies.php?%s' % (SITE, urllib.parse.urlencode(
                {'genre': genre, 'page': page, 'limit': 25, 'poster_format': 'portrait'}))
            data = util.http_json(url, {'Accept': '*/*', 'Referer': '%s/%s/movies/%s' % (SITE, lang(), genre)})
            util.cache_set(key, data)
        return data

    def _episodes(self, link):
        key = 'wedotv:series:%s' % link
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            page = util.http_get(SITE + link, {'Accept': 'text/html', 'Referer': '%s/%s/series' % (SITE, lang())}, timeout=40)
            title = re.search(r'<h1 class="hero-title">(.*?)</h1>', page, re.S)
            seasons = {}
            for card in re.findall(r'<a [^>]*class="episode-card".*?</a>', page, re.S):
                season = re.search(r'data-season="(\d+)"', card)
                vid = re.search(r'data-video-id="(\d+)"', card)
                if not season or not vid:
                    continue
                name = re.search(r'<h4[^>]*>(.*?)</h4>', card, re.S)
                plot = re.search(r'<p[^>]*>(.*?)</p>', card, re.S)
                thumb = re.search(r"background-image:\s*url\('([^']+)'\)", card)
                seasons.setdefault(int(season.group(1)), []).append(
                    {'vid': vid.group(1), 'title': _clean(name.group(1)) if name else vid.group(1),
                     'plot': _clean(plot.group(1)) if plot else '', 'thumb': thumb.group(1) if thumb else ''})
            data = {'title': _clean(title.group(1)) if title else link,
                    'seasons': [{'number': n, 'episodes': seasons[n]} for n in sorted(seasons)]}
            if data['seasons']:
                util.cache_set(key, data)
        return data

    def _list_vod(self, path):
        icon = {'icon': util.media('wedotv.png')}
        if not path:
            return [{'label': util.S(label), 'folder': True, 'params': {'path': 'cat:%s' % slug}, 'art': icon}
                    for slug, label, _ in SECTIONS]
        if path.startswith('cat:'):
            slug = path[4:]
            items = []
            if slug == 'movies':
                items.append({'label': util.S(30060), 'folder': True, 'params': {'path': 'gen:all:1'}, 'art': icon})
                items.append({'label': util.S(30061), 'folder': True, 'params': {'path': 'genres'}, 'art': icon})
            if slug in COLLECTIONS:
                items.append({'label': util.S(30062), 'folder': True, 'params': {'path': 'col:%s' % slug}, 'art': icon})
            items.extend({'label': sec['title'], 'folder': True,
                          'params': {'path': 'row:%s:%s:1' % (sec['id'], sec['format'])}, 'art': icon}
                         for sec in self._sections(slug))
            return items
        if path == 'genres':
            return [{'label': name, 'folder': True, 'params': {'path': 'gen:%s:1' % slug}, 'art': icon}
                    for slug, name in GENRES]
        if path.startswith('col:'):
            return [{'label': name, 'folder': True, 'params': {'path': 'cat:%s' % slug}, 'art': icon}
                    for slug, name in COLLECTIONS.get(path[4:], ())]
        if path.startswith('gen:'):
            _, genre, page = path.split(':')
            page = max(1, int(page))
            data = self._movies(genre, page)
            items = []
            for it in data.get('movies') or []:
                link = it.get('link') or it.get('url_handler')
                if link:
                    items.append({'label': it.get('title', '?'), 'folder': False, 'playable': True,
                                  'params': {'action': 'play', 'kind': 'movie', 'link': link, 'title': it.get('title', '')},
                                  'art': {'thumb': it.get('portrait') or it.get('image_placeholder'),
                                          'poster': it.get('portrait'), 'fanart': it.get('image_placeholder')},
                                  'info': {'title': it.get('title')}})
            if data.get('hasMore'):
                items.append({'label': util.S(30027), 'folder': True,
                              'params': {'path': 'gen:%s:%d' % (genre, page + 1)}, 'art': icon})
            return items
        if path.startswith('row:'):
            _, row, fmt, page = path.split(':')
            page = max(1, int(page))
            data = self._playlist(row, fmt, page)
            items = []
            for it in data.get('items') or data.get('movies') or []:
                link = it.get('link') or it.get('url_handler')
                if not link:
                    continue
                art = {'thumb': it.get('portrait') or it.get('image_placeholder'),
                       'poster': it.get('portrait'), 'fanart': it.get('image_placeholder')}
                info = {'title': it.get('title')}
                if it.get('category') == 'movie':
                    items.append({'label': it.get('title', '?'), 'folder': False, 'playable': True,
                                  'params': {'action': 'play', 'kind': 'movie', 'link': link,
                                             'title': it.get('title', '')},
                                  'art': art, 'info': info})
                else:
                    items.append({'label': it.get('title', '?'), 'folder': True,
                                  'params': {'path': 'ser:%s' % link}, 'art': art, 'info': info})
            if data.get('hasMore'):
                items.append({'label': util.S(30027), 'folder': True,
                              'params': {'path': 'row:%s:%s:%d' % (row, fmt, page + 1)}, 'art': icon})
            return items
        if path.startswith('ser:'):
            parts = path.split(':')
            link, season_no = parts[1], (int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None)
            data = self._episodes(link)
            seasons = data['seasons']
            if season_no is None and len(seasons) > 1:
                return [{'label': '%s %d' % (util.S(30044), se['number']), 'folder': True,
                         'params': {'path': 'ser:%s:%d' % (link, se['number'])}, 'art': icon} for se in seasons]
            season = next((se for se in seasons if se['number'] == season_no), seasons[0] if seasons else None)
            return [{'label': ep['title'], 'folder': False, 'playable': True,
                     'params': {'action': 'play', 'kind': 'video', 'vid': ep['vid'], 'title': ep['title']},
                     'art': {'thumb': ep['thumb'], 'fanart': ep['thumb']},
                     'info': {'title': ep['title'], 'plot': ep['plot'], 'tvshowtitle': data['title']}}
                    for ep in (season['episodes'] if season else [])]
        return []

    def list(self, area, path, params):
        return self._list_live(path) if area == 'live' else self._list_vod(path)

    # ------------------------------------------------------------------ Wiedergabe
    def resolve(self, params):
        kind = params.get('kind')
        if kind == 'live':
            for ch in self._epg()['channels']:
                if str(ch.get('id')) == str(params.get('id')) and ch.get('hls'):
                    return {'url': ch['hls'], 'hls': True, 'live': True,
                            'label': ch.get('name') or params.get('title'), 'art': {'thumb': ch.get('logo')}}
            return None
        vid = params.get('vid')
        if kind == 'movie':
            page = util.http_get(SITE + params.get('link', ''), {'Accept': 'text/html', 'Referer': '%s/%s/movies' % (SITE, lang())}, timeout=40)
            match = re.search(r'data-video-id="(\d+)"', page)
            if not match:
                util.log('WedoTV: keine video_id auf %s gefunden' % params.get('link'), 'ERROR')
                return None
            vid = match.group(1)
        if not vid:
            return None
        video = util.http_json('%s/api/player.get_video.php?%s' % (SITE, urllib.parse.urlencode(
            {'video_id': vid, '_cb': int(time.time() * 1000)})), {'Accept': '*/*', 'Referer': SITE + '/'})
        source = video.get('video_source')
        if not source:
            util.log('WedoTV: keine video_source für %s' % vid, 'ERROR')
            return None
        subs = [s['src'] for s in video.get('subtitles') or [] if isinstance(s, dict) and s.get('src')]
        return {'url': source, 'hls': True, 'live': False, 'subtitles': subs,
                'label': video.get('title') or params.get('title')}
