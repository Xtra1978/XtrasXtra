# -*- coding: utf-8 -*-
"""FreeLiveSportsTV (https://freelivesports.tv) – Live-Kanäle und Mediathek.

Ablauf wie im Web-Client, anonym als Gast:
  account/authenticate -> Gast-Token
  schedule/fastchannelsv2 -> Kanäle + EPG,  fastchannel/details/<id> -> Live-Link
  v2/home -> Theken,  v2/video/details -> Video,  playlistV2/generateToken + playlist.m3u8
Kein Login, keine Paywall, keine Umgehung.
"""
import base64
import json
import re
import time
import uuid
from urllib.parse import quote, urlencode, urljoin

from .. import util

BASE = 'https://api.gizmott.com'
SITE = 'https://freelivesports.tv'
PUBID = '50183'
CHANNELID = '516'
SESSION_FILE = 'fls_session.json'


def _jwt_exp(token):
    try:
        body = token.split('.')[1]
        body += '=' * (-len(body) % 4)
        return int(json.loads(base64.urlsafe_b64decode(body.encode()).decode())['exp'])
    except Exception:
        return 0


class Provider(object):
    id = 'fls'
    label = 30010
    icon = 'fls.png'
    available = True
    areas = ('live', 'vod')

    # ------------------------------------------------------------------ Session
    def _device(self):
        dev = util.store_load('fls_device.json', {}) or {}
        if not dev.get('dev_id'):
            dev['dev_id'] = uuid.uuid4().hex
            util.store_save('fls_device.json', dev)
        return dev

    def _base_headers(self):
        return {'Origin': SITE, 'Referer': SITE + '/', 'Accept': 'application/json',
                'pubid': PUBID, 'channelid': CHANNELID, 'device_type': 'web',
                'crossorigin': 'true', 'access-control-allow-origin': 'true'}

    def _authenticate(self):
        dev = self._device()
        country, ip = 'DE', ''
        try:
            info = util.http_json(BASE + '/api/v1/ipinfo', {'Origin': SITE, 'Referer': SITE + '/'})
            country = info.get('countryCode') or country
            ip = info.get('query') or ''
        except util.HttpError as exc:
            util.log('FLS ipinfo fehlgeschlagen: %s' % exc, 'DEBUG')
        headers = self._base_headers()
        headers.update({'dev_id': dev['dev_id'], 'country_code': country, 'ip': ip})
        if not dev.get('uid'):
            # Neues Gerät: der Web-Client legt zuerst einen Gast an (account/register/guest).
            reg_headers = {'pubid': PUBID, 'channelid': CHANNELID, 'country_code': country,
                           'device_type': 'web', 'dev_id': dev['dev_id'], 'ip': ip,
                           'ua': util.UA, 'Origin': SITE, 'Referer': SITE + '/'}
            try:
                reg = util.http_post_json(BASE + '/api/v1/account/register/guest', reg_headers)
            except util.HttpError as exc:
                util.log('FLS register/guest HTTP-Fehler: %s' % exc, 'ERROR')
                raise
            if not reg.get('user_id'):
                util.log('FLS register/guest ohne user_id: Felder=%s message=%s' % (
                    sorted(reg.keys()), str(reg.get('message', ''))[:200]), 'ERROR')
                raise util.HttpError(0, 'register/guest ohne user_id')
            dev['uid'] = reg['user_id']
            util.store_save('fls_device.json', dev)
            util.log('FLS neuer Gast angelegt')
        headers['uid'] = str(dev['uid'])
        # Der Web-Client ruft vor der Anmeldung die Konfiguration ab – gleiche Reihenfolge.
        try:
            util.http_get(BASE + '/api/v1/config', {'website': SITE, 'Origin': SITE, 'Referer': SITE + '/'})
        except util.HttpError as exc:
            util.log('FLS config fehlgeschlagen: %s' % exc)
        util.log('FLS authenticate: land=%s ip=%s uid=%s' % (country, 'ja' if ip else 'nein', 'ja' if dev.get('uid') else 'nein'))
        try:
            data = util.http_json(BASE + '/api/v1/account/authenticate', headers)
        except util.HttpError as exc:
            util.log('FLS authenticate HTTP-Fehler: %s' % exc, 'ERROR')
            raise
        if isinstance(data, dict) and data.get('message') == 'Invalid user' and dev.get('uid'):
            dev.pop('uid', None)
            util.store_save('fls_device.json', dev)
            util.log('FLS: Gast ungültig, lege neuen an')
            return self._authenticate()
        token = data.get('token') if isinstance(data, dict) else None
        if not token:
            keys = sorted(data.keys()) if isinstance(data, dict) else type(data).__name__
            msg = str(data.get('message', ''))[:200] if isinstance(data, dict) else ''
            util.log('FLS authenticate ohne Token: Felder=%s message=%s' % (keys, msg), 'ERROR')
            raise util.HttpError(0, 'authenticate ohne Token')
        if data.get('user_id'):
            dev['uid'] = data['user_id']
            util.store_save('fls_device.json', dev)
        session = {'token': token, 'country': country, 'ip': ip, 'uid': data.get('user_id'),
                   'exp': _jwt_exp(token) or (time.time() + 3600),
                   'guest': bool(data.get('is_guest', True))}
        util.store_save(SESSION_FILE, session)
        util.log('FLS Gast-Sitzung erstellt (guest=%s)' % session['guest'])
        return session

    def _session(self, force=False):
        session = None if force else util.store_load(SESSION_FILE)
        if not session or session.get('exp', 0) < time.time() + 120:
            session = self._authenticate()
        return session

    def _api(self, path, params=None, retry=True):
        session = self._session()
        headers = self._base_headers()
        dev = self._device()
        headers.update({'access-token': session['token'], 'dev_id': dev['dev_id'],
                        'country_code': session.get('country', 'DE'), 'ip': session.get('ip', '')})
        if session.get('uid'):
            headers['uid'] = str(session['uid'])
        url = BASE + path + (('?' + urlencode(params)) if params else '')
        try:
            data = util.http_json(url, headers)
        except util.HttpError as exc:
            if retry and exc.status in (400, 401, 403):
                self._session(force=True)
                return self._api(path, params, retry=False)
            raise
        if retry and isinstance(data, dict) and (data.get('session_expired') or data.get('forcibleLogout')):
            self._session(force=True)
            return self._api(path, params, retry=False)
        return data

    # ------------------------------------------------------------------ Daten
    def _schedule(self):
        key = 'fls:schedule'
        data = util.cache_get(key, 15 * 60)
        if data is None:
            raw = self._api('/api/v1/schedule/fastchannelsv2', {'timezone': 'Europe/Berlin'})
            payload = raw.get('data', {})
            by_channel = {}
            for sch in payload.get('schedules', []):
                by_channel.setdefault(str(sch.get('channel_id')), []).append(
                    [sch.get('start'), sch.get('end'), sch.get('title')])
            data = {'channels': payload.get('channels', []),
                    'categories': payload.get('categories', []),
                    'schedules': by_channel}
            util.cache_set(key, data)
        return data

    def _home(self):
        key = 'fls:home'
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            raw = self._api('/api/v2/home')
            data = [r for r in raw.get('data', []) if r.get('type') != 'FASTCHANNELS']
            util.cache_set(key, data)
        return data

    @staticmethod
    def _now_next(schedule, channel_id):
        now = util.berlin_now()
        current = upcoming = None
        for start, end, title in schedule.get(str(channel_id), []):
            s, e = util.parse_iso(start or ''), util.parse_iso(end or '')
            if not s or not e:
                continue
            if s <= now < e:
                current = title
            elif s >= now and upcoming is None:
                upcoming = title
        return current, upcoming

    # ------------------------------------------------------------------ Menüs
    def list(self, area, path, params):
        if area == 'live':
            return self._list_live(path)
        return self._list_vod(path)

    def _list_live(self, path):
        data = self._schedule()
        if not path:
            items = [{'label': util.S(30007), 'folder': True, 'params': {'path': 'all'},
                      'art': {'icon': util.media('fls.png')}}]
            for cat in sorted(data['categories'], key=lambda c: (c.get('category_name') or '').lower()):
                if (cat.get('category_name') or '').strip().lower() == 'all':
                    continue
                items.append({'label': cat.get('category_name', '?'), 'folder': True,
                              'params': {'path': 'cat:%s' % cat.get('category_id')},
                              'art': {'icon': util.media('fls.png')}})
            return items
        wanted = None
        if path.startswith('cat:'):
            wanted = path[4:]
        items = []
        for ch in sorted(data['channels'], key=lambda c: (c.get('channel_name') or '').lower()):
            if ch.get('is_locked'):
                continue
            if wanted is not None and wanted not in [str(c.get('category_id')) for c in ch.get('categories', [])]:
                continue
            now, nxt = self._now_next(data['schedules'], ch.get('id'))
            plot = []
            if now:
                plot.append(util.S(30022) % now)
            if nxt:
                plot.append(util.S(30023) % nxt)
            items.append({'label': ch.get('channel_name', '?'), 'folder': False, 'playable': True,
                          'params': {'action': 'play', 'kind': 'live', 'id': ch.get('id'),
                                     'title': ch.get('channel_name', '')},
                          'art': {'thumb': ch.get('logo'), 'icon': ch.get('logo'), 'fanart': ch.get('hero_image')},
                          'info': {'title': ch.get('channel_name'), 'plot': '\n'.join(plot)}})
        return items

    def _list_vod(self, path):
        rows = self._home()
        if not path:
            return [{'label': '%s (%s)' % (r.get('category_name', '?'), r.get('shows_count', len(r.get('shows', [])))),
                     'folder': True, 'params': {'path': 'row:%s' % r.get('category_id')},
                     'art': {'icon': util.media('fls.png')}}
                    for r in rows if r.get('shows')]
        row_id = path[4:] if path.startswith('row:') else path
        row = next((r for r in rows if str(r.get('category_id')) == row_id), None)
        if not row:
            return []
        items = []
        for show in row.get('shows', []):
            vanity = show.get('vanity_url')
            if not vanity or show.get('is_locked'):
                continue
            art_img = show.get('hero_image') or show.get('logo') or show.get('banner')
            items.append({'label': show.get('show_name', '?'), 'folder': False, 'playable': True,
                          'params': {'action': 'play', 'kind': 'vod', 'vanity': vanity,
                                     'sid': show.get('show_id'), 'title': show.get('show_name', '')},
                          'art': {'thumb': art_img, 'poster': show.get('logo') or art_img, 'fanart': art_img},
                          'info': {'title': show.get('show_name'), 'plot': show.get('synopsis') or '',
                                   'mpaa': show.get('rating') or ''}})
        shown = len(row.get('shows', []))
        total = int(row.get('shows_count') or shown)
        if row.get('show_all_needed') and total > shown:
            items.append({'label': util.S(30024) % shown, 'folder': False, 'playable': False,
                          'params': {'action': 'noop'}, 'art': {'icon': util.media('fls.png')}})
        return items

    # ------------------------------------------------------------------ Wiedergabe
    def resolve(self, params):
        kind = params.get('kind')
        if kind == 'live':
            return self._resolve_live(params)
        return self._resolve_vod(params)

    def _resolve_live(self, params):
        raw = self._api('/api/v1/fastchannel/details/%s' % params.get('id'))
        details = (raw.get('data') or [{}])[0]
        url = details.get('live_link_hd') or details.get('live_link')
        if details.get('ssai_enabled') and details.get('ssai_link'):
            url = details['ssai_link']
        if not url:
            return None
        return {'url': util.play_headers(url, SITE + '/'), 'hls': True, 'live': True,
                'label': details.get('channel_name') or params.get('title'),
                'art': {'thumb': details.get('logo'), 'icon': details.get('logo')}}

    def _resolve_vod(self, params):
        vanity = params.get('vanity')
        raw = self._api('/api/v2/video/details/%s' % quote(vanity, safe=''), {'show_id': params.get('sid')})
        video = raw.get('data') or {}
        source = video.get('video_name') or ''
        if not source.startswith('http'):
            util.log('FLS: keine abspielbare Quelle für %s (files=%s)' % (vanity, video.get('files')))
            return None
        token = self._api('/api/v1/playlistV2/generateToken', {'id': source}).get('data')
        if not token:
            util.log('FLS: generateToken lieferte kein Token')
            return None
        playlist_url = '%s/api/v1/playlistV2/playlist.m3u8?%s' % (
            BASE, urlencode({'id': source, 'token': token, 'type': 'video', 'pubid': PUBID}))
        headers = self._base_headers()
        headers['access-token'] = self._session()['token']
        master = util.http_get(playlist_url, headers)
        url = self._pick_variant(master, playlist_url)
        return {'url': util.play_headers(url, SITE + '/'), 'hls': True, 'live': False,
                'label': video.get('show_name') or params.get('title'),
                'art': {'thumb': video.get('thumbnail')}}

    @staticmethod
    def _pick_variant(master, base_url):
        """Wählt je nach Einstellung eine Qualitätsstufe aus der Master-Playlist."""
        cap = {0: 100000, 1: 720, 2: 480}.get(util.setting_int('quality', 0), 100000)
        variants = []
        lines = master.splitlines()
        for idx, line in enumerate(lines):
            if line.startswith('#EXT-X-STREAM-INF') and idx + 1 < len(lines):
                bw = re.search(r'BANDWIDTH=(\d+)', line)
                res = re.search(r'RESOLUTION=\d+x(\d+)', line)
                variants.append((int(res.group(1)) if res else 0, int(bw.group(1)) if bw else 0,
                                 urljoin(base_url, lines[idx + 1].strip())))
        if not variants:
            return base_url
        allowed = [v for v in variants if v[0] <= cap] or [min(variants)]
        return max(allowed)[2]
