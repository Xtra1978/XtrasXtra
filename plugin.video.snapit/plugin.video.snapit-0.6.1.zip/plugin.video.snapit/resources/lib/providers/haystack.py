# -*- coding: utf-8 -*-
"""Haystack News (https://www.haystack.tv) – lokale und weltweite Nachrichtenkanäle.

Die Seite ist SvelteKit: Kanalübersicht als HTML, Clips je Kanal als <slug>/__data.json.
Streams sind offene HLS-Master-Playlists ohne Login, Token oder DRM.
Haystack liefert Clips (On-Demand). Unter "Live-TV" läuft ein Kanal deshalb als
fortlaufende Clip-Playlist, unter "VOD" lassen sich die Clips einzeln wählen.
"""
import html as htmllib
import json
import re

from .. import util

SITE = 'https://www.haystack.tv'
DATA_PARAM = 'x-sveltekit-invalidated=011'
MAX_PLAYLIST = 25


def _devalue(flat):
    """Entpackt das flache SvelteKit-devalue-Format in normale Python-Objekte."""
    memo = {}

    def build(idx):
        if idx in memo:
            return memo[idx]
        val = flat[idx]
        if isinstance(val, dict):
            out = {}
            memo[idx] = out
            for key, ref in val.items():
                out[key] = build(ref) if isinstance(ref, int) and ref >= 0 else None
            return out
        if isinstance(val, list):
            if val and isinstance(val[0], str) and val[0] in ('Date', 'Set', 'Map', 'RegExp', 'BigInt', 'Reactive'):
                memo[idx] = None
                return None
            out = []
            memo[idx] = out
            for ref in val:
                out.append(build(ref) if isinstance(ref, int) and ref >= 0 else None)
            return out
        memo[idx] = val
        return val

    return build(0)


class Provider(object):
    id = 'haystack'
    label = 30011
    icon = 'haystack.png'
    available = True
    areas = ('live', 'vod')

    # ------------------------------------------------------------------ Daten
    def _channels(self):
        key = 'haystack:channels'
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            page = util.http_get(SITE + '/channels', {'Accept': 'text/html'}, timeout=40)
            data, seen = [], set()
            for match in re.finditer(r'<a href="/channel/([^"/?#]+)"[^>]*>(.*?)</a>', page, re.S):
                slug, inner = match.group(1), match.group(2)
                if slug in seen:
                    continue
                title = re.search(r'<h4[^>]*>(.*?)</h4>', inner, re.S)
                sub = re.search(r'<span[^>]*>(.*?)</span>', inner, re.S)
                img = re.search(r'<img[^>]+src="([^"]+)"', inner)
                if not title:
                    continue
                seen.add(slug)
                data.append({'slug': slug,
                             'title': htmllib.unescape(re.sub(r'<[^>]+>', '', title.group(1))).strip(),
                             'sub': htmllib.unescape(re.sub(r'<[^>]+>', '', sub.group(1))).strip() if sub else '',
                             'thumb': htmllib.unescape(img.group(1)) if img else ''})
            if data:
                util.cache_set(key, data)
        return data

    def _streams(self, slug):
        key = 'haystack:streams:%s' % slug
        data = util.cache_get(key, 15 * 60)
        if data is None:
            url = '%s/channel/%s/__data.json?%s' % (SITE, slug, DATA_PARAM)
            payload = util.http_json(url, {'Accept': 'application/json', 'Referer': SITE + '/channels'}, timeout=30)
            data = []
            for node in reversed(payload.get('nodes', [])):
                if not node or node.get('type') != 'data':
                    continue
                obj = _devalue(node['data'])
                streams = ((obj or {}).get('playlist') or {}).get('streams') if isinstance(obj, dict) else None
                if streams:
                    for st in streams:
                        media = (st.get('mediaFiles') or {}).get('adaptive') or {}
                        if not media.get('url'):
                            continue
                        data.append({'url': media['url'], 'title': st.get('title') or '',
                                     'duration': st.get('duration') or 0,
                                     'status': st.get('status') or '',
                                     'thumb': st.get('snapshot720Url') or st.get('snapshotUrl') or '',
                                     'published': (st.get('publishedDate') or '')[:10]})
                    break
            util.cache_set(key, data)
        return data

    # ------------------------------------------------------------------ Menüs
    def list(self, area, path, params):
        if not path:
            return self._channel_items(area)
        if path.startswith('ch:') and area == 'vod':
            slug = path[3:]
            items = []
            for st in self._streams(slug):
                items.append({'label': st['title'] or slug, 'folder': False, 'playable': True,
                              'params': {'action': 'play', 'kind': 'clip', 'u': st['url'],
                                         'title': st['title'], 'thumb': st['thumb']},
                              'art': {'thumb': st['thumb'], 'fanart': st['thumb']},
                              'info': {'title': st['title'], 'duration': int(st['duration'] or 0),
                                       'plot': st['published']}})
            return items
        return []

    def _channel_items(self, area):
        items = []
        for ch in self._channels():
            if area == 'live':
                params = {'action': 'play', 'kind': 'channel', 'slug': ch['slug'], 'title': ch['title']}
                item = {'label': ch['title'], 'folder': False, 'playable': True, 'params': params}
            else:
                item = {'label': ch['title'], 'folder': True, 'params': {'path': 'ch:%s' % ch['slug']}}
            item['art'] = {'thumb': ch['thumb'] or util.media('haystack.png'),
                           'icon': ch['thumb'] or util.media('haystack.png')}
            item['info'] = {'title': ch['title'], 'plot': ch['sub']}
            items.append(item)
        return items

    # ------------------------------------------------------------------ Wiedergabe
    def resolve(self, params):
        kind = params.get('kind')
        if kind == 'clip':
            return {'url': util.play_headers(params['u'], SITE + '/'), 'hls': True, 'live': False,
                    'label': params.get('title'), 'art': {'thumb': params.get('thumb')}}
        if kind == 'channel':
            streams = self._streams(params.get('slug'))[:MAX_PLAYLIST]
            if not streams:
                return None
            entries = [{'url': util.play_headers(s['url'], SITE + '/'), 'label': s['title'],
                        'art': {'thumb': s['thumb']}} for s in streams]
            first = entries[0]
            return {'url': first['url'], 'hls': True, 'live': False, 'label': first['label'],
                    'art': first['art'], 'queue': entries[1:]}
        return None
