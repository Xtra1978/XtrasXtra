# -*- coding: utf-8 -*-
"""Wocoo (https://wocoo.tv) – freie Filme und Kurzfilme.

Wie im Web-Client, ohne Konto:
  GET  /de/library              -> XSRF-Cookie (normaler Laravel-Ablauf)
  POST /api/library/filter/20/N -> Titelliste (neueste zuerst)
  GET  /api/movie/<slug>        -> Streamdaten (DASH + Widevine-Lizenz wie im Web-Player)
Serien: Die Serienseite (/de/series/watch/<slug>) enthält die Staffeln und Episoden als
eingebettetes JSON (blade-serie), die Episodenseite den Stream (blade-episode).
Es werden keine Zugangsbeschränkungen umgangen: Wiedergabe über den regulären DASH-Stream
und den offiziellen Lizenzserver, genau wie im Browser. Live-Kanäle hat Wocoo nicht mehr.
"""
import gzip
import html as htmllib
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar

from .. import util

SITE = 'https://wocoo.tv'
LIB_PAGE = SITE + '/de/library'
PER_PAGE = 20
LICENSE_URL = 'https://widevine-dash.ezdrm.com/proxy?pX=126D07'


class Provider(object):
    id = 'wocoo'
    label = 30009
    icon = 'wocoo.png'
    available = True
    areas = ('vod',)  # Wocoo hat keine Live-Kanäle mehr

    # ------------------------------------------------------------------ HTTP (mit Cookies für XSRF)
    def _library_request(self, page, format_id=0):
        jar = CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        base = [('User-Agent', util.UA), ('Accept-Language', 'de,en;q=0.8')]
        opener.addheaders = base
        try:
            opener.open(LIB_PAGE, timeout=25).read()
        except urllib.error.URLError as exc:
            raise util.HttpError(0, str(exc))
        xsrf = next((urllib.parse.unquote(c.value) for c in jar if c.name == 'XSRF-TOKEN'), '')
        if not xsrf:
            util.log('Wocoo: kein XSRF-Cookie erhalten', 'ERROR')
        body = json.dumps({'genre_ids': [], 'format_ids': [format_id] if format_id else [], 'audio_language_codes': [],
                           'subtitle_language_codes': [], 'sort': 'newest'}).encode('utf-8')
        req = urllib.request.Request(
            '%s/api/library/filter/%d/%d' % (SITE, PER_PAGE, page), data=body, method='POST',
            headers={'Content-Type': 'application/json', 'Accept': 'application/json, text/plain, */*',
                     'X-Requested-With': 'XMLHttpRequest', 'X-XSRF-TOKEN': xsrf,
                     'Origin': SITE, 'Referer': LIB_PAGE})
        try:
            with opener.open(req, timeout=25) as resp:
                raw = resp.read()
                if resp.headers.get('Content-Encoding') == 'gzip':
                    raw = gzip.decompress(raw)
                return json.loads(raw.decode('utf-8', errors='replace'))
        except urllib.error.HTTPError as exc:
            raise util.HttpError(exc.code, exc.reason)
        except urllib.error.URLError as exc:
            raise util.HttpError(0, str(exc))

    # ------------------------------------------------------------------ Daten
    def _page(self, page, format_id=0):
        key = 'wocoo:library:%d:%d' % (format_id, page)
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            raw = self._library_request(page, format_id)
            message = raw.get('message')
            rows = message.get('data', []) if isinstance(message, dict) else (message or [])
            meta = raw.get('meta') or (message.get('meta') if isinstance(message, dict) else {}) or {}
            items = []
            for row in rows:
                if row.get('is_episode'):
                    continue
                synopsis = row.get('synopsis') or ''
                translations = row.get('translations')
                if isinstance(translations, dict):
                    german = (translations.get('synopsis') or {}).get('de')
                    if isinstance(german, str) and german:
                        synopsis = german
                elif isinstance(translations, list):
                    for tr in translations:
                        if isinstance(tr, dict) and tr.get('field') == 'synopsis' \
                                and tr.get('locale') == 'de' and tr.get('value'):
                            synopsis = tr['value']
                items.append({'slug': row.get('slug'), 'is_series': str(row.get('is_series')).lower() in ('true', '1'),
                              'title': row.get('title') or '?',
                              'year': row.get('year'), 'thumb': row.get('image_url'),
                              'fanart': row.get('screenshot_url'), 'plot': synopsis})
            data = {'items': items, 'last_page': int(meta.get('last_page') or page)}
            util.cache_set(key, data)
        return data

    # ------------------------------------------------------------------ Serien (eingebettetes JSON)
    @staticmethod
    def _blade(page_html, attr):
        match = re.search(r'%s="([^"]*)"' % re.escape(attr), page_html)
        if not match:
            return None
        try:
            return json.loads(htmllib.unescape(match.group(1)))
        except ValueError:
            return None

    def _series(self, slug):
        key = 'wocoo:series:%s' % slug
        data = util.cache_get(key, util.cache_hours_seconds())
        if data is None:
            page = util.http_get('%s/de/series/watch/%s' % (SITE, urllib.parse.quote(slug, safe='')),
                                 {'Accept': 'text/html', 'Referer': LIB_PAGE}, timeout=40)
            serie = self._blade(page, 'blade-serie') or {}
            seasons = []
            for season in serie.get('seasons') or []:
                episodes = []
                for ep in season.get('episodes') or []:
                    episodes.append({'slug': ep.get('slug'), 'title': ep.get('title') or '?',
                                     'num': ep.get('episode_num'), 'plot': ep.get('synopsis') or '',
                                     'thumb': ep.get('image_url'), 'fanart': ep.get('screenshot_url')})
                seasons.append({'name': season.get('name') or '', 'episodes': episodes})
            data = {'title': serie.get('title') or slug, 'seasons': seasons}
            if seasons:
                util.cache_set(key, data)
        return data

    # ------------------------------------------------------------------ Menüs
    def list(self, area, path, params):
        if area == 'live':
            return []
        icon = {'icon': util.media('wocoo.png')}
        if not path:
            return [{'label': util.S(30026), 'folder': True, 'params': {'path': 'lib:0:1'}, 'art': icon},
                    {'label': util.S(30031), 'folder': True, 'params': {'path': 'lib:1:1'}, 'art': icon},
                    {'label': util.S(30032), 'folder': True, 'params': {'path': 'lib:2:1'}, 'art': icon},
                    {'label': util.S(30033), 'folder': True, 'params': {'path': 'lib:3:1'}, 'art': icon}]
        if path.startswith('lib:'):
            return self._list_library(path)
        if path.startswith('ser:'):
            return self._list_series(path)
        return []

    def _list_library(self, path):
        try:
            _, fid, page = path.split(':')
            fid, page = int(fid), max(1, int(page))
        except ValueError:
            return []
        data = self._page(page, fid)
        items = []
        for it in data['items']:
            art = {'thumb': it['thumb'], 'poster': it['thumb'], 'fanart': it['fanart'] or it['thumb']}
            year = int(it['year']) if str(it.get('year') or '').isdigit() else None
            info = {'title': it['title'], 'plot': it['plot'], 'year': year}
            if it.get('is_series'):
                items.append({'label': it['title'], 'folder': True, 'params': {'path': 'ser:%s' % it['slug']},
                              'art': art, 'info': info})
            else:
                items.append({'label': it['title'], 'folder': False, 'playable': True,
                              'params': {'action': 'play', 'kind': 'vod', 'slug': it['slug'], 'title': it['title']},
                              'art': art, 'info': info})
        if page < data['last_page']:
            items.append({'label': util.S(30027), 'folder': True,
                          'params': {'path': 'lib:%d:%d' % (fid, page + 1)},
                          'art': {'icon': util.media('wocoo.png')}})
        return items

    def _list_series(self, path):
        parts = path.split(':')
        slug = parts[1]
        season_idx = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None
        data = self._series(slug)
        seasons = data['seasons']
        if season_idx is None and len(seasons) > 1:
            return [{'label': se['name'] or ('%d' % (i + 1)), 'folder': True,
                     'params': {'path': 'ser:%s:%d' % (slug, i)}, 'art': {'icon': util.media('wocoo.png')}}
                    for i, se in enumerate(seasons)]
        season = seasons[season_idx or 0] if seasons else {'episodes': []}
        items = []
        for ep in season['episodes']:
            label = ('%s. %s' % (ep['num'], ep['title'])) if ep.get('num') else ep['title']
            items.append({'label': label, 'folder': False, 'playable': True,
                          'params': {'action': 'play', 'kind': 'episode', 'serie': slug, 'ep': ep['slug'],
                                     'title': ep['title']},
                          'art': {'thumb': ep['thumb'], 'fanart': ep['fanart'] or ep['thumb']},
                          'info': {'title': ep['title'], 'plot': ep['plot'], 'tvshowtitle': data['title']}})
        return items

    # ------------------------------------------------------------------ Untertitel
    @staticmethod
    def _find_subtitles(mpd, audio_language):
        """Wocoo legt Untertitel neben den Stream: <ordner>/sub/<name>_<sprache>.srt.
        Es werden nur Dateien eingebunden, die tatsächlich vorhanden sind."""
        folder = mpd.rsplit('/', 1)[0]
        base = folder.rsplit('/', 1)[-1]
        if base.endswith('_output'):
            base = base[:-len('_output')]
        langs = []
        for code in (audio_language, 'de'):
            code = (code or '').split('-')[0].lower()
            if code and code not in langs:
                langs.append(code)
        found = []
        for code in langs:
            url = '%s/sub/%s_%s.srt' % (folder, base, code)
            if util.url_exists(url, {'Referer': SITE + '/', 'Origin': SITE}):
                found.append(url)
        util.log('Wocoo Untertitel gefunden: %s' % [u.rsplit('_', 1)[-1] for u in found], 'DEBUG')
        return found

    # ------------------------------------------------------------------ Wiedergabe
    def resolve(self, params):
        if params.get('kind') == 'episode':
            page = util.http_get('%s/de/series/watch/%s/episode/%s' % (
                SITE, urllib.parse.quote(params.get('serie') or '', safe=''),
                urllib.parse.quote(params.get('ep') or '', safe='')),
                {'Accept': 'text/html', 'Referer': LIB_PAGE}, timeout=40)
            movie = self._blade(page, 'blade-episode') or {}
            slug = params.get('ep')
        else:
            slug = params.get('slug')
            data = util.http_json('%s/api/movie/%s' % (SITE, urllib.parse.quote(slug or '', safe='')),
                                  {'Accept': 'application/json', 'Referer': SITE + '/de/watch/' + (slug or '')})
            movie = data.get('message') or {}
        mpd = movie.get('url')
        if not mpd:
            util.log('Wocoo: keine Stream-URL für %s' % slug, 'ERROR')
            return None
        subs = []
        for sub in movie.get('subtitles') or []:
            if isinstance(sub, dict) and sub.get('url'):
                subs.append(sub['url'])
        if not subs:
            subs = self._find_subtitles(mpd, movie.get('audio_language'))
        image = movie.get('image')
        return {'url': mpd, 'dash': True, 'live': False,
                'license_url': LICENSE_URL,
                'license_headers': {'Content-Type': 'application/octet-stream',
                                    'Origin': SITE, 'Referer': SITE + '/', 'User-Agent': util.UA},
                'stream_headers': {'Origin': SITE, 'Referer': SITE + '/', 'User-Agent': util.UA},
                'subtitles': subs, 'label': movie.get('title') or params.get('title'),
                'art': {'thumb': '%s/storage/media/images/%s' % (SITE, image) if image else None}}
