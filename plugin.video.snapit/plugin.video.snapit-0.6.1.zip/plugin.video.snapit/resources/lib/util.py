# -*- coding: utf-8 -*-
"""Gemeinsame Hilfen: Log, Strings, HTTP, Cache, Zuletzt gesehen."""
import gzip
import hashlib
import io
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DIR = os.path.join(PROFILE, 'cache')
LOG_FILE = os.path.join(PROFILE, 'snapit.log')
RECENT_FILE = os.path.join(PROFILE, 'recent.json')
MEDIA = os.path.join(ADDON_PATH, 'resources', 'media')
ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36')
LOG_MAX = 256 * 1024


class HttpError(Exception):
    def __init__(self, status, message=''):
        Exception.__init__(self, '%s %s' % (status, message))
        self.status = status


def _ensure_dirs():
    for d in (PROFILE, CACHE_DIR):
        if not xbmcvfs.exists(d + os.sep):
            xbmcvfs.mkdirs(d)


# --------------------------------------------------------------------------
# Einstellungen / Strings
# --------------------------------------------------------------------------
def S(string_id):
    return ADDON.getLocalizedString(string_id)


def setting_int(key, default=0):
    try:
        return ADDON.getSettingInt(key)
    except Exception:
        return default


def setting_bool(key, default=False):
    try:
        return ADDON.getSettingBool(key)
    except Exception:
        return default


def media(name):
    return os.path.join(MEDIA, name)


# --------------------------------------------------------------------------
# Addon-eigenes Log (getrennt von kodi.log)
# --------------------------------------------------------------------------
def log(message, level='INFO'):
    if level == 'DEBUG' and not setting_bool('debug'):
        return
    try:
        _ensure_dirs()
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX:
            with io.open(LOG_FILE, 'r', encoding='utf-8', errors='replace') as fh:
                tail = fh.read()[-LOG_MAX // 3:]
            with io.open(LOG_FILE, 'w', encoding='utf-8') as fh:
                fh.write(tail)
        stamp = time.strftime('%Y-%m-%d %H:%M:%S')
        with io.open(LOG_FILE, 'a', encoding='utf-8') as fh:
            fh.write(u'%s [%s] %s\n' % (stamp, level, message))
    except Exception:
        pass
    xbmc.log('[%s] %s' % (ADDON_ID, message),
             xbmc.LOGDEBUG if level == 'DEBUG' else xbmc.LOGINFO)


def log_read(max_chars=20000):
    if not os.path.exists(LOG_FILE):
        return ''
    with io.open(LOG_FILE, 'r', encoding='utf-8', errors='replace') as fh:
        return fh.read()[-max_chars:]


def log_clear():
    try:
        with io.open(LOG_FILE, 'w', encoding='utf-8') as fh:
            fh.write(u'')
    except Exception:
        pass


def notify(message, error=False):
    xbmcgui.Dialog().notification(
        ADDON_NAME, message,
        xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 4000)


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
def http_get(url, headers=None, timeout=20):
    """Gibt den Antworttext (str) zurück. Wirft HttpError."""
    hdrs = {'User-Agent': UA, 'Accept-Encoding': 'gzip'}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = gzip.decompress(raw)
            return raw.decode('utf-8', errors='replace')
    except urllib.error.HTTPError as exc:
        raise HttpError(exc.code, exc.reason)
    except Exception as exc:
        raise HttpError(0, str(exc))


def http_json(url, headers=None, timeout=20):
    return json.loads(http_get(url, headers, timeout))


def url_exists(url, headers=None, timeout=10):
    """Prüft per HEAD, ob eine Datei existiert (z. B. Untertitel)."""
    hdrs = {'User-Agent': UA}
    if headers:
        hdrs.update(headers)
    try:
        req = urllib.request.Request(url, headers=hdrs, method='HEAD')
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False


def http_post_json(url, headers=None, body=b'', timeout=20):
    hdrs = {'User-Agent': UA, 'Accept-Encoding': 'gzip'}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=body, headers=hdrs, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = gzip.decompress(raw)
            return json.loads(raw.decode('utf-8', errors='replace'))
    except urllib.error.HTTPError as exc:
        raise HttpError(exc.code, exc.reason)
    except Exception as exc:
        raise HttpError(0, str(exc))


def play_headers(url, referer):
    """Hängt (optional) Kodi-Header an die Wiedergabe-URL an."""
    if not setting_bool('send_referer') or not referer:
        return url
    return '%s|%s' % (url, urllib.parse.urlencode({'Referer': referer, 'User-Agent': UA}))


# --------------------------------------------------------------------------
# Cache (JSON-Dateien im Profilordner)
# --------------------------------------------------------------------------
def _cache_path(key):
    return os.path.join(CACHE_DIR, hashlib.sha1(key.encode('utf-8')).hexdigest() + '.json')


def cache_get(key, ttl_seconds):
    path = _cache_path(key)
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < ttl_seconds:
            with io.open(path, 'r', encoding='utf-8') as fh:
                return json.load(fh)
    except Exception as exc:
        log('Cache lesen fehlgeschlagen: %s' % exc, 'DEBUG')
    return None


def cache_set(key, data):
    try:
        _ensure_dirs()
        with io.open(_cache_path(key), 'w', encoding='utf-8') as fh:
            json.dump(data, fh)
    except Exception as exc:
        log('Cache schreiben fehlgeschlagen: %s' % exc)


def cache_hours_seconds():
    return max(1, setting_int('cache_hours', 6)) * 3600


def cache_size():
    total = 0
    if os.path.isdir(CACHE_DIR):
        for name in os.listdir(CACHE_DIR):
            try:
                total += os.path.getsize(os.path.join(CACHE_DIR, name))
            except OSError:
                pass
    return total


def cache_clear():
    if os.path.isdir(CACHE_DIR):
        for name in os.listdir(CACHE_DIR):
            try:
                os.remove(os.path.join(CACHE_DIR, name))
            except OSError:
                pass


def human_size(num):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if num < 1024 or unit == 'GB':
            return ('%d %s' % (num, unit)) if unit == 'B' else ('%.1f %s' % (num, unit))
        num /= 1024.0


# --------------------------------------------------------------------------
# Eigene kleine JSON-Dateien (Session, Geräte-ID, Zuletzt gesehen)
# --------------------------------------------------------------------------
def store_load(name, default=None):
    path = os.path.join(PROFILE, name)
    try:
        with io.open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return default


def store_save(name, data):
    try:
        _ensure_dirs()
        with io.open(os.path.join(PROFILE, name), 'w', encoding='utf-8') as fh:
            json.dump(data, fh)
    except Exception as exc:
        log('Speichern von %s fehlgeschlagen: %s' % (name, exc))


def recent_add(entry, limit=30):
    items = store_load('recent.json', []) or []
    items = [i for i in items if i.get('params') != entry.get('params')]
    items.insert(0, entry)
    store_save('recent.json', items[:limit])


def recent_list():
    return store_load('recent.json', []) or []


# --------------------------------------------------------------------------
# Favoriten (eigene JSON-Liste, unabhängig von Kodis Favoriten)
# --------------------------------------------------------------------------
def fav_key(params):
    return hashlib.sha1(json.dumps(params, sort_keys=True).encode('utf-8')).hexdigest()[:16]


def fav_list():
    return store_load('favorites.json', []) or []


def fav_add(entry):
    favs = fav_list()
    key = fav_key(entry['p'])
    if any(f.get('key') == key for f in favs):
        return False
    entry['key'] = key
    favs.append(entry)
    store_save('favorites.json', favs)
    return True


def fav_remove(key):
    favs = fav_list()
    kept = [f for f in favs if f.get('key') != key]
    store_save('favorites.json', kept)
    return len(kept) != len(favs)


# --------------------------------------------------------------------------
# Zeit (Berlin ohne zoneinfo, damit es auch unter Kodi 19 / Python 3.8 läuft)
# --------------------------------------------------------------------------
def _last_sunday(year, month):
    day = datetime(year, month, 31)
    while day.weekday() != 6:
        day -= timedelta(days=1)
    return day


def berlin_now():
    utc = datetime.utcnow()
    start = _last_sunday(utc.year, 3).replace(hour=1)
    end = _last_sunday(utc.year, 10).replace(hour=1)
    return utc + timedelta(hours=2 if start <= utc < end else 1)


def parse_iso(text):
    """'2026-10-05T13:00:00' -> datetime (ohne strptime, wegen bekannter Kodi-Thread-Probleme)."""
    try:
        return datetime(int(text[0:4]), int(text[5:7]), int(text[8:10]),
                        int(text[11:13]), int(text[14:16]), int(text[17:19] or 0))
    except Exception:
        return None
