# -*- coding: utf-8 -*-
"""Menüführung: Home / Live-TV / VOD / Cache."""
import base64
import json
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from . import util
from .providers import fls, haystack, wedotv, wocoo

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if sys.argv else ''
PROVIDERS = [fls.Provider(), haystack.Provider(), wedotv.Provider(), wocoo.Provider()]
PROVIDER_MAP = dict((p.id, p) for p in PROVIDERS)


def icon(name=None):
    path = util.media(name) if name else util.ADDON_ICON
    return {'thumb': path, 'icon': path}


def kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0].split(' ')[0])
    except Exception:
        return 21


def build_url(params):
    return '%s?%s' % (BASE_URL, urlencode(dict((k, v) for k, v in params.items() if v is not None)))


def make_item(item):
    li = xbmcgui.ListItem(label=item['label'])
    art = dict((k, v) for k, v in (item.get('art') or {}).items() if v)
    if art:
        li.setArt(art)
    info = dict((k, v) for k, v in (item.get('info') or {}).items() if v)
    if info:
        li.setInfo('video', info)
    if item.get('playable'):
        li.setProperty('IsPlayable', 'true')
    menu = fav_menu(item)
    if menu:
        li.addContextMenuItems(menu)
    return li


def _eligible(item):
    params = item['params']
    if item.get('playable') and params.get('action') == 'play':
        return True
    return bool(item.get('folder') and params.get('action') == 'list'
                and str(params.get('path', '')).startswith(('ser:', 'ch:')))


def fav_menu(item):
    if item.get('fav_key'):
        return [(util.S(30047), 'RunPlugin(%s)' % build_url({'action': 'fav_remove', 'key': item['fav_key']}))]
    if not _eligible(item):
        return None
    art = dict((k, v) for k, v in (item.get('art') or {}).items() if v)
    entry = {'l': item['label'], 'p': item['params'], 'a': art, 'f': bool(item.get('folder'))}
    payload = base64.urlsafe_b64encode(json.dumps(entry, separators=(',', ':')).encode('utf-8')).decode('ascii')
    return [(util.S(30046), 'RunPlugin(%s)' % build_url({'action': 'fav_add', 'data': payload}))]


def show(items, content='videos'):
    xbmcplugin.setContent(HANDLE, content)
    for item in items:
        url = build_url(item['params'])
        xbmcplugin.addDirectoryItem(HANDLE, url, make_item(item), bool(item.get('folder')))
    xbmcplugin.endOfDirectory(HANDLE)


# -------------------------------------------------------------------------- Menüs
def root():
    show([
        {'label': util.S(30001), 'folder': True, 'params': {'action': 'home'}, 'art': icon()},
        {'label': util.S(30002), 'folder': True, 'params': {'action': 'providers', 'area': 'live'}, 'art': icon('livetv.png')},
        {'label': util.S(30003), 'folder': True, 'params': {'action': 'providers', 'area': 'vod'}, 'art': icon('vod.png')},
        {'label': util.S(30004), 'folder': True, 'params': {'action': 'cache'}, 'art': icon()},
    ])


def home():
    show([
        {'label': util.S(30045), 'folder': True, 'params': {'action': 'favs'}, 'art': icon('favorites.png')},
        {'label': util.S(30005), 'folder': True, 'params': {'action': 'recent'}, 'art': icon()},
        {'label': util.S(30006), 'folder': False, 'params': {'action': 'about'}, 'art': icon()},
    ])


def recent():
    items = []
    for entry in util.recent_list():
        items.append({'label': entry.get('label') or '?', 'folder': False, 'playable': True,
                      'params': entry.get('params') or {}, 'art': entry.get('art') or {}})
    if not items:
        util.notify(util.S(30020))
    show(items)


def _fav_items(favs):
    items = []
    for fav in favs:
        items.append({'label': fav.get('l') or '?', 'folder': bool(fav.get('f')), 'playable': not fav.get('f'),
                      'params': fav.get('p') or {}, 'art': fav.get('a') or {}, 'fav_key': fav.get('key')})
    return items


def favs(params):
    pid, area = params.get('provider'), params.get('area')
    all_favs = util.fav_list()
    if not pid:
        items = []
        for prov in PROVIDERS:
            count = sum(1 for f in all_favs if (f.get('p') or {}).get('provider') == prov.id)
            if count:
                art = {'thumb': util.media(prov.icon), 'icon': util.media(prov.icon)}
                items.append({'label': '%s (%d)' % (util.S(prov.label), count), 'folder': True, 'art': art,
                              'params': {'action': 'favs', 'provider': prov.id}})
        if not items:
            util.notify(util.S(30020))
        show(items)
        return
    mine = [f for f in all_favs if (f.get('p') or {}).get('provider') == pid]
    areas = sorted(set((f.get('p') or {}).get('area') for f in mine))
    if not area and len(areas) > 1:
        labels = {'live': 30002, 'vod': 30003}
        show([{'label': '%s (%d)' % (util.S(labels.get(a, 30003)), sum(1 for f in mine if (f.get('p') or {}).get('area') == a)),
               'folder': True, 'params': {'action': 'favs', 'provider': pid, 'area': a}} for a in areas])
        return
    if area:
        mine = [f for f in mine if (f.get('p') or {}).get('area') == area]
    show(_fav_items(mine))


def fav_add_action(params):
    try:
        entry = json.loads(base64.urlsafe_b64decode(params.get('data', '').encode('ascii')).decode('utf-8'))
    except Exception as exc:
        util.log('Favorit konnte nicht gelesen werden: %s' % exc, 'ERROR')
        return
    if util.fav_add(entry):
        util.notify(util.S(30048))
    else:
        util.notify(util.S(30050))


def fav_remove_action(params):
    if util.fav_remove(params.get('key', '')):
        util.notify(util.S(30049))
    xbmc.executebuiltin('Container.Refresh')


def about():
    xbmcgui.Dialog().textviewer(util.S(30006), util.S(30030))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def providers(area):
    items = []
    for prov in PROVIDERS:
        if area not in getattr(prov, 'areas', ('live', 'vod')):
            continue
        art = {'thumb': util.media(prov.icon), 'icon': util.media(prov.icon)}
        if prov.available:
            items.append({'label': util.S(prov.label), 'folder': True, 'art': art,
                          'params': {'action': 'list', 'provider': prov.id, 'area': area, 'path': ''}})
        else:
            items.append({'label': util.S(prov.label), 'folder': False, 'art': art,
                          'params': {'action': 'unavailable', 'provider': prov.id}})
    show(items)


def list_provider(params):
    prov = PROVIDER_MAP.get(params.get('provider'))
    area = params.get('area')
    if not prov:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    try:
        items = prov.list(area, params.get('path', ''), params)
    except Exception as exc:
        util.log('Liste %s/%s/%s fehlgeschlagen: %s' % (prov.id, area, params.get('path'), exc), 'ERROR')
        util.notify(util.S(30018), error=True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for item in items:
        item['params'] = dict(item['params'])
        if item['params'].get('action') is None:
            item['params'].update({'action': 'list', 'provider': prov.id, 'area': area})
        elif item['params'].get('action') == 'play':
            item['params'].update({'provider': prov.id, 'area': area})
    if not items:
        util.notify(util.S(30020))
    show(items)


def cache_menu():
    show([
        {'label': util.S(30012) % util.human_size(util.cache_size()), 'folder': False, 'params': {'action': 'noop'}},
        {'label': util.S(30013), 'folder': False, 'params': {'action': 'cache_clear'}},
        {'label': util.S(30015), 'folder': False, 'params': {'action': 'log_show'}},
        {'label': util.S(30016), 'folder': False, 'params': {'action': 'log_clear'}},
    ])


# -------------------------------------------------------------------------- Wiedergabe
def play(params):
    prov = PROVIDER_MAP.get(params.get('provider'))
    result = None
    if prov:
        try:
            result = prov.resolve(params)
        except Exception as exc:
            util.log('Auflösen fehlgeschlagen (%s/%s): %s' % (params.get('provider'), params.get('kind'), exc), 'ERROR')
    if not result or not result.get('url'):
        util.notify(util.S(30019), error=True)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    host = result['url'].split('://', 1)[-1].split('/', 1)[0].split('|', 1)[0]
    util.log('Wiedergabe: %s/%s -> %s (%s)' % (
        params.get('provider'), params.get('kind'), host,
        'DASH+Widevine' if result.get('dash') else ('HLS' if result.get('hls') else 'direkt')))
    li = xbmcgui.ListItem(label=result.get('label') or params.get('title') or '', path=result['url'])
    art = dict((k, v) for k, v in (result.get('art') or {}).items() if v)
    if art:
        li.setArt(art)
    if result.get('dash'):
        if not xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'):
            util.notify(util.S(30028), error=True)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        # Widevine-Modul prüfen / bei Bedarf über InputStream Helper installieren lassen
        try:
            import inputstreamhelper
            if not inputstreamhelper.Helper('mpd', drm='com.widevine.alpha').check_inputstream():
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
        except ImportError:
            util.log('InputStream Helper nicht installiert – Widevine wird nicht automatisch geprüft')
        li.setMimeType('application/dash+xml')
        li.setContentLookup(False)
        li.setProperty('inputstream', 'inputstream.adaptive')
        if kodi_major() < 21:  # ab Kodi 21 erkennt InputStream Adaptive den Typ selbst
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        li.setProperty('inputstream.adaptive.license_key', '%s|%s|R{SSM}|' % (
            result['license_url'], urlencode(result.get('license_headers') or {})))
        if result.get('stream_headers'):
            li.setProperty('inputstream.adaptive.stream_headers', urlencode(result['stream_headers']))
        if result.get('subtitles'):
            li.setSubtitles(result['subtitles'])
    if result.get('hls') and result.get('subtitles'):
        li.setSubtitles(result['subtitles'])
    if result.get('hls'):
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        if util.setting_bool('use_ia'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    for entry in result.get('queue') or []:
        qli = xbmcgui.ListItem(label=entry.get('label') or '', path=entry['url'])
        qart = dict((k, v) for k, v in (entry.get('art') or {}).items() if v)
        if qart:
            qli.setArt(qart)
        qli.setMimeType('application/vnd.apple.mpegurl')
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).add(entry['url'], qli)
    util.recent_add({'label': result.get('label') or params.get('title') or '',
                     'params': dict((k, v) for k, v in params.items() if k != 'queue'),
                     'art': art})


# -------------------------------------------------------------------------- Einstieg
def run():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action', 'root')
    util.log('Aufruf: %s' % params, 'DEBUG')
    if action == 'root':
        root()
    elif action == 'home':
        home()
    elif action == 'recent':
        recent()
    elif action == 'favs':
        favs(params)
    elif action == 'fav_add':
        fav_add_action(params)
    elif action == 'fav_remove':
        fav_remove_action(params)
    elif action == 'about':
        about()
    elif action == 'providers':
        providers(params.get('area'))
    elif action == 'list':
        list_provider(params)
    elif action == 'play':
        play(params)
    elif action == 'cache':
        cache_menu()
    elif action == 'cache_clear':
        util.cache_clear()
        util.notify(util.S(30014))
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'log_show':
        text = util.log_read()
        xbmcgui.Dialog().textviewer(util.S(30015), text or util.S(30025))
    elif action == 'log_clear':
        util.log_clear()
        util.notify(util.S(30017))
    elif action == 'unavailable':
        util.notify(util.S(30021))
    elif action == 'noop':
        pass
