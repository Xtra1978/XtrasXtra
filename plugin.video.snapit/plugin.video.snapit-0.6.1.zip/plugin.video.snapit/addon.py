# -*- coding: utf-8 -*-
"""SnapIT – Einstiegspunkt. Die eigentliche Logik liegt in resources/lib/router.py."""
from resources.lib import router

if __name__ == '__main__':
    router.run()
