# -*- coding: utf-8 -*-
import os
import shutil

import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'storage'
TITLE = S.M_STORAGE
TOP = 8


def _size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


def _children(path):
    sizes = []
    if os.path.isdir(path):
        for name in os.listdir(path):
            full = os.path.join(path, name)
            if os.path.isdir(full):
                sizes.append((name, _size(full)))
    return sorted(sizes, key=lambda item: -item[1])[:TOP]


def run():
    dialog = utils.progress(L(S.STO_SCANNING))
    try:
        addons_dir = utils.real('special://home/addons/')
        data_dir = utils.real('special://profile/addon_data/')
        steps = [(S.STO_THUMBS, utils.real('special://thumbnails/')), (S.STO_TEMP, utils.real('special://temp/')),
                 (S.STO_PACKAGES, os.path.join(addons_dir, 'packages')), (S.STO_DATABASES, utils.real('special://database/')),
                 (S.STO_ADDONDATA, data_dir), (S.STO_ADDONS, addons_dir)]
        sizes = []
        for index, (sid, path) in enumerate(steps):
            dialog.update(int(index * 100 / (len(steps) + 2)), L(S.STO_SCANNING))
            if dialog.iscanceled():
                return
            sizes.append((sid, _size(path) if os.path.isdir(path) else 0))
        packages = dict(sizes)[S.STO_PACKAGES]
        sizes = [(sid, size - packages if sid == S.STO_ADDONS else size) for sid, size in sizes]
        top_data = _children(data_dir)
        top_addons = [(n, s) for n, s in _children(addons_dir) if n not in ('packages', 'temp')]
    finally:
        dialog.close()
    items = []
    try:
        usage = shutil.disk_usage(utils.real('special://home/'))
        items.append(xbmcgui.ListItem(L(S.STO_FREE, utils.fmt_size(usage.free), utils.fmt_size(usage.total))))
    except OSError:
        pass
    for sid, size in sorted(sizes, key=lambda i: -i[1]):
        items.append(xbmcgui.ListItem(L(sid), utils.fmt_size(size)))
    for heading, rows in ((S.STO_TOP_DATA, top_data), (S.STO_TOP_ADDONS, top_addons)):
        if rows:
            items.append(xbmcgui.ListItem('[B]%s[/B]' % L(heading)))
            items += [xbmcgui.ListItem(name, utils.fmt_size(size)) for name, size in rows]
    position = -1
    while True:  # read-only list: scrolls natively on every platform
        index = xbmcgui.Dialog().select(L(S.M_STORAGE), items, 0, position, True)
        if index < 0:
            return
        position = index
