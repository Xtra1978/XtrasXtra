# -*- coding: utf-8 -*-
import glob
import os
import shutil
import sqlite3

import xbmc
import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'orphans'
TITLE = S.M_ORPHANS
HEX = '0123456789abcdef'


def _on_disk(addon_id):
    """True when an addon folder exists, even if Kodi does not list the addon (e.g. incompatible or broken)."""
    for base in (addonops.home(), os.path.normpath(utils.real('special://xbmc/addons'))):
        if os.path.isdir(os.path.join(base, addon_id)):
            return True
    return False


def _dbs(special_dir, pattern):
    return glob.glob(os.path.join(utils.real(special_dir), pattern))


def _addon_data(installed):
    base = utils.real('special://profile/addon_data/')
    if not os.path.isdir(base):
        return []
    found = []
    for name in sorted(os.listdir(base)):
        full = os.path.join(base, name)
        if os.path.isdir(full) and name not in installed and name != utils.ADDON_ID and not _on_disk(name):
            found.append({'kind': 'dir', 'path': full, 'label': L(S.ORPH_DATA, name, utils.fmt_size(utils.scan(full)[1]))})
    return found


def _broken_folders():
    base = addonops.home()
    found = []
    if os.path.isdir(base):
        for name in sorted(os.listdir(base)):
            full = os.path.join(base, name)
            if name in ('packages', 'temp') or not os.path.isdir(full):
                continue
            if not os.path.exists(os.path.join(full, 'addon.xml')):
                found.append({'kind': 'dir', 'path': full, 'label': L(S.ORPH_FOLDER, name)})
    return found


def _stale_db_rows(installed):
    found = []
    for db in _dbs('special://database/', 'Addons*.db'):
        try:
            con = sqlite3.connect(db, timeout=5)
            try:
                rows = [r[0] for r in con.execute('SELECT addonID FROM installed')]
            finally:
                con.close()
        except sqlite3.Error as exc:
            utils.log('Addons DB read failed: %s' % exc, xbmc.LOGWARNING)
            continue
        stale = [r for r in rows if r not in installed and not _on_disk(r)]
        if stale:
            shown = ', '.join(stale[:4]) + (', ...' if len(stale) > 4 else '')
            found.append({'kind': 'addondb', 'db': db, 'ids': stale, 'label': '%s [%s]' % (L(S.ORPH_DB, len(stale)), shown)})
    return found


def _thumbnails():
    thumbs = utils.real('special://thumbnails/')
    found = []
    if not os.path.isdir(thumbs):
        return found
    for db in _dbs('special://database/', 'Textures*.db'):
        try:
            con = sqlite3.connect(db, timeout=5)
            try:
                rows = list(con.execute('SELECT id, cachedurl FROM texture'))
            finally:
                con.close()
        except sqlite3.Error as exc:
            utils.log('Textures DB read failed: %s' % exc, xbmc.LOGWARNING)
            continue
        known = {url for _id, url in rows if url}
        # Only the hashed top-level folders; Kodi manages Video/ and friends itself.
        files, size = [], 0
        for folder in HEX:
            top = os.path.join(thumbs, folder)
            if not os.path.isdir(top):
                continue
            for name in os.listdir(top):
                if '%s/%s' % (folder, name) not in known:
                    full = os.path.join(top, name)
                    try:
                        size += os.path.getsize(full)
                        files.append(full)
                    except OSError:
                        pass
        if files:
            found.append({'kind': 'files', 'files': files, 'label': L(S.ORPH_THUMB_FILES, len(files), utils.fmt_size(size))})
        dead = [rid for rid, url in rows if url and not os.path.exists(os.path.join(thumbs, url))]
        if dead:
            found.append({'kind': 'texturedb', 'db': db, 'ids': dead, 'label': L(S.ORPH_THUMB_ROWS, len(dead))})
    return found


def _apply(item):
    kind = item['kind']
    if kind == 'dir':
        shutil.rmtree(item['path'])
    elif kind == 'files':
        for path in item['files']:
            try:
                os.remove(path)
            except OSError:
                pass
    elif kind in ('addondb', 'texturedb'):
        con = sqlite3.connect(item['db'], timeout=5)
        try:
            if kind == 'addondb':
                con.executemany('DELETE FROM installed WHERE addonID=?', [(i,) for i in item['ids']])
            else:
                con.executemany('DELETE FROM sizes WHERE idtexture=?', [(i,) for i in item['ids']])
                con.executemany('DELETE FROM texture WHERE id=?', [(i,) for i in item['ids']])
            con.commit()
        finally:
            con.close()


def run():
    dialog = utils.progress(L(S.ORPH_SCANNING))
    try:
        installed = {a['addonid'] for a in utils.all_addons(('name',))}
        findings = []
        for step, scan in enumerate((lambda: _addon_data(installed), _broken_folders,
                                     lambda: _stale_db_rows(installed), _thumbnails)):
            dialog.update(step * 25, L(S.ORPH_SCANNING))
            findings += scan()
    finally:
        dialog.close()
    if not findings:
        utils.info(L(S.NOTHING))
        return
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_REMOVE), [f['label'] for f in findings])
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_ITEMS, len(chosen))):
        return
    count = 0
    for index in chosen:
        try:
            _apply(findings[index])
            count += 1
            utils.log('Orphan cleaned: %s' % findings[index]['label'])
        except (OSError, sqlite3.Error) as exc:
            utils.log('Orphan cleanup failed (%s): %s' % (findings[index]['label'], exc), xbmc.LOGWARNING)
    utils.info(L(S.REMOVED, count))
    utils.restart_prompt()
