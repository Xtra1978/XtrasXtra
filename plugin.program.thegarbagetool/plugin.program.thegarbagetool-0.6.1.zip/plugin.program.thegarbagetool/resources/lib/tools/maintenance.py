# -*- coding: utf-8 -*-
import glob
import os
import sqlite3

import xbmc
import xbmcgui

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'maintenance'
TITLE = S.M_MAINT


def _check_one(db):
    """Returns (status string id, size after)."""
    con = None
    try:
        con = sqlite3.connect(db, timeout=5)
        con.isolation_level = None
        row = con.execute('PRAGMA quick_check').fetchone()
        if not row or row[0] != 'ok':
            return S.DB_CORRUPT
        try:
            con.execute('VACUUM')
        except sqlite3.OperationalError:
            return S.DB_BUSY
        return S.DB_OK
    except sqlite3.DatabaseError:
        return S.DB_CORRUPT
    finally:
        if con:
            con.close()


def _databases():
    dbs = sorted(glob.glob(os.path.join(utils.real('special://database/'), '*.db')))
    if not dbs:
        utils.info(L(S.NOTHING))
        return
    if not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_DB, len(dbs))):
        return
    lines = []
    dialog = utils.progress(L(S.WORKING))
    try:
        for index, db in enumerate(dbs):
            dialog.update(int(index * 100 / len(dbs)), os.path.basename(db))
            if dialog.iscanceled():
                break
            before = os.path.getsize(db)
            status = _check_one(db)
            after = os.path.getsize(db) if os.path.exists(db) else 0
            utils.log('DB %s: %s (%d -> %d bytes)' % (os.path.basename(db), status, before, after))
            lines.append(L(S.DB_LINE, os.path.basename(db), utils.fmt_size(before), utils.fmt_size(after), L(status)))
    finally:
        dialog.close()
    utils.show_text(L(S.MAINT_DB), '\n'.join(lines))


def _clean_library(method, name_id):
    if xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_LIB, L(name_id))):
        utils.rpc(method, {'showdialogs': True})
        utils.log('Library clean requested: %s' % method)
        utils.info(L(S.STARTED))


def _refresh_repos():
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.executebuiltin('UpdateLocalAddons')
    utils.info(L(S.REPOS_REFRESHED))


def run():
    actions = [(S.MAINT_DB, _databases),
               (S.MAINT_VIDEO, lambda: _clean_library('VideoLibrary.Clean', S.LIB_VIDEO)),
               (S.MAINT_MUSIC, lambda: _clean_library('AudioLibrary.Clean', S.LIB_MUSIC)),
               (S.MAINT_REPOS, _refresh_repos)]
    while True:
        index = xbmcgui.Dialog().select(L(S.M_MAINT), [L(sid) for sid, _fn in actions])
        if index < 0:
            return
        actions[index][1]()
