# -*- coding: utf-8 -*-
import glob
import os
import sqlite3

import xbmc

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'thumbnails'
TITLE = S.M_THUMBS


def _clear_db():
    for db in glob.glob(os.path.join(utils.real('special://database/'), 'Textures*.db')):
        con = None
        try:
            con = sqlite3.connect(db, timeout=5)
            con.execute('DELETE FROM sizes')
            con.execute('DELETE FROM texture')
            con.commit()
            try:
                con.execute('VACUUM')
            except sqlite3.Error:
                pass
        except sqlite3.Error as exc:
            utils.log('Texture DB error (%s): %s' % (db, exc), xbmc.LOGWARNING)
            return False
        finally:
            if con:
                con.close()
    return True


def run():
    path = utils.real('special://thumbnails/')
    count, size = utils.scan(path) if os.path.isdir(path) else (0, 0)
    if count == 0:
        utils.info(L(S.NOTHING))
        return
    if not utils.confirm_clean(L(S.CONFIRM_THUMBS, count, utils.fmt_size(size))):
        return
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        # Database first: if it cannot be cleared, keep the files so no thumbnail breaks.
        if not _clear_db():
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            utils.info(L(S.DB_LOCKED))
            return
        removed, freed, failed = utils.purge(path)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    utils.log('Thumbnails cleaned: %d files, %s, %d failed' % (removed, utils.fmt_size(freed), failed))
    text = L(S.FREED, utils.fmt_size(freed), removed)
    if failed:
        text += '\n' + L(S.PARTIAL, failed)
    utils.info(text)
    utils.restart_prompt()
