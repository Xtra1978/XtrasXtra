# -*- coding: utf-8 -*-
from resources.lib.tools import (addons, backup, cache, debuglog, dependencies, devkit, favourites,
                                 loganalysis, logview, maintenance, nfocheck, orphans, packages, playlists,
                                 pvr, repositories, sources, storage, thumbnails)

# Each tool is duck-typed: ID (str), TITLE (string id), run().
TOOLS = [thumbnails, cache, packages, playlists, favourites, sources, pvr, repositories, addons,
         dependencies, orphans, nfocheck, storage, maintenance, backup, loganalysis, debuglog, devkit, logview]
BY_ID = {tool.ID: tool for tool in TOOLS}
