# -*- coding: utf-8 -*-
import re
import xml.etree.ElementTree as ET

import xbmcgui
import xbmcvfs

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'favourites'
TITLE = S.M_FAVS
PATH_SCHEMES = ('smb', 'nfs', 'sftp', 'ftp', 'special', 'file')


def _target(command):
    for candidate in re.findall(r'"([^"]+)"', command):
        if '://' in candidate or candidate.startswith('/') or re.match(r'^[A-Za-z]:[\\/]', candidate):
            return candidate
    match = re.search(r'\(([A-Za-z][A-Za-z0-9+.-]*://[^,)]*)', command)
    return match.group(1) if match else None


def _exists(path):
    return xbmcvfs.exists(path) or xbmcvfs.exists(path.rstrip('/\\') + '/')


def status_of(command, installed):
    target = _target(command)
    if target and target.startswith('plugin://'):
        addon_id = target[len('plugin://'):].split('/')[0].split('?')[0]
        return S.ST_VALID if addon_id in installed else S.ST_ADDON_MISSING
    match = re.search(r'Run(?:Script|Addon)\(\s*"?([^",)]+)', command)
    if match:
        script = match.group(1).strip()
        if '/' not in script and '\\' not in script:
            return S.ST_VALID if script in installed else S.ST_ADDON_MISSING
        return S.ST_VALID if _exists(script) else S.ST_PATH_MISSING
    if target:
        scheme = target.split('://')[0].lower() if '://' in target else 'file'
        if scheme in PATH_SCHEMES:
            return S.ST_VALID if _exists(target) else S.ST_PATH_MISSING
    return S.ST_UNKNOWN


def _save(tree):
    path = utils.real('special://profile/favourites.xml')
    saved = utils.backup(path)
    if hasattr(ET, 'indent'):
        ET.indent(tree, space='    ')
    tree.write(path, encoding='utf-8', xml_declaration=True)
    return saved


def run():
    path = utils.real('special://profile/favourites.xml')
    try:
        tree = ET.parse(path)
    except Exception:
        utils.info(L(S.NO_FAVS))
        return
    root = tree.getroot()
    nodes = root.findall('favourite')
    if not nodes:
        utils.info(L(S.NO_FAVS))
        return

    installed = {a['addonid'] for a in utils.all_addons(('name',))}
    dialog = utils.progress(L(S.CHECKING_FAVS))
    entries = []
    try:
        for i, node in enumerate(nodes):
            dialog.update(int(i * 100 / len(nodes)), L(S.CHECKING_FAVS))
            if dialog.iscanceled():
                return
            entries.append({'node': node, 'name': node.get('name', ''),
                            'status': status_of((node.text or '').strip(), installed)})
    finally:
        dialog.close()

    bad = (S.ST_ADDON_MISSING, S.ST_PATH_MISSING)
    changed = deleted = 0

    def delete(items):
        nonlocal changed, deleted
        for item in items:
            root.remove(item['node'])
            entries.remove(item)
        saved = _save(tree)
        if not changed:
            utils.info(L(S.BACKUP_SAVED, saved))
        changed = 1
        deleted += len(items)
        utils.log('Favourites deleted: %s' % ', '.join(i['name'] for i in items))

    while entries:
        broken = [e for e in entries if e['status'] in bad]
        labels, actions = [], []
        if broken:
            labels.append(L(S.FAV_DEL_BROKEN, len(broken)))
            actions.append(broken)
        labels.append(L(S.FAV_DEL_ALL, len(entries)))
        actions.append(list(entries))
        for entry in entries:
            labels.append('%s  [%s]' % (entry['name'], L(entry['status'])))
            actions.append([entry])
        index = xbmcgui.Dialog().select(L(S.FAVS_TITLE), labels)
        if index < 0:
            break
        items = actions[index]
        question = L(S.CONFIRM_FAV, items[0]['name']) if len(items) == 1 else L(S.CONFIRM_FAV_MANY, len(items))
        if xbmcgui.Dialog().yesno(utils.title(), question):
            delete(items)
    if changed:
        utils.info(L(S.DELETED_COUNT, deleted))
        utils.restart_prompt()
