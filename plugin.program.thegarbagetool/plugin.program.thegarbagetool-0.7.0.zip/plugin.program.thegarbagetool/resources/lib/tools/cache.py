# -*- coding: utf-8 -*-
from resources.lib import ids as S
from resources.lib import utils

ID = 'cache'
TITLE = S.M_CACHE
KEEP = ('kodi.log', 'kodi.old.log', 'kodi.crash.log')


def run():
    utils.clean_folder('special://temp/', S.CONFIRM_CACHE, KEEP)
