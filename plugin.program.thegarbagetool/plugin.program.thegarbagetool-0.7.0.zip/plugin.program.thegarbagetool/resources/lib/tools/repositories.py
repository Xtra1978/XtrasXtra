# -*- coding: utf-8 -*-
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'repositories'
TITLE = S.M_REPOS


def run():
    repos = [a for a in utils.all_addons() if a.get('type') == addonops.REPO_TYPE and addonops.is_user(a)]
    if not repos:
        utils.info(L(S.NO_REPOS))
        return
    status = {}
    timeout = utils.get_int('net_timeout', 8)
    dialog = utils.progress(L(S.CHECKING_REPOS))
    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(addonops.check_repo, repo, timeout) for repo in repos]
            for done, future in enumerate(as_completed(futures), 1):
                dialog.update(int(done * 100 / len(futures)), L(S.CHECKING_REPOS))
                if dialog.iscanceled():
                    for f in futures:
                        f.cancel()
                    return
                addon, ok = future.result()
                status[addon['addonid']] = S.ST_UNKNOWN if ok is None else (S.ST_REACHABLE if ok else S.ST_REPO_DEAD)
    finally:
        dialog.close()
    repos.sort(key=lambda a: (status.get(a['addonid']) != S.ST_REPO_DEAD, addonops.label(a).lower()))
    labels = ['%s (%s)  [%s]' % (addonops.label(a), a['addonid'], L(status.get(a['addonid'], S.ST_UNKNOWN))) for a in repos]
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_REMOVE), labels)
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_ITEMS, len(chosen))):
        return
    count = sum(1 for i in chosen if addonops.uninstall(repos[i]))
    addonops.finish()
    utils.info(L(S.REMOVED, count))
    utils.restart_prompt()
