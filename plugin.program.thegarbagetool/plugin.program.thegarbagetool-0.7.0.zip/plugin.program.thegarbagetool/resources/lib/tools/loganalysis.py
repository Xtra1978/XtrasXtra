# -*- coding: utf-8 -*-
import glob
import json
import os
import time
import urllib.request

import xbmc
import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import logparse
from resources.lib import utils
from resources.lib.utils import L

ID = 'loganalysis'
TITLE = S.M_LOGANALYSIS
REPORT_DIR = os.path.join(utils.PROFILE, 'reports')
KEEP_REPORTS = 10
PASTE_URL = 'https://paste.kodi.tv/'


def _read(path, dialog):
    """Parse the log in a streaming way; returns (analysis, line_count) or None when cancelled."""
    total = max(os.path.getsize(path), 1)
    state = {'lines': 0}

    def lines():
        pos = 0
        with open(path, 'rb') as handle:
            for raw in handle:
                pos += len(raw)
                state['lines'] += 1
                if state['lines'] % 5000 == 0:
                    dialog.update(min(int(pos * 100 / total), 99), L(S.LOG_ANALYSING))
                    if dialog.iscanceled():
                        raise KeyboardInterrupt
                yield raw.decode('utf-8', 'replace')

    try:
        analysis = logparse.analyse(logparse.iter_entries(lines()))
    except KeyboardInterrupt:
        return None
    return analysis, state['lines']


def _installed():
    versions, lines = {}, []
    for addon in sorted(utils.all_addons(), key=lambda a: a['addonid']):
        versions[addon['addonid']] = addon.get('version', '')
        if addonops.is_user(addon):
            flag = '  (%s)' % L(S.ST_DISABLED) if not addon.get('enabled') else ''
            lines.append('%s %s%s' % (addon['addonid'], addon.get('version', ''), flag))
    return versions, lines[:120]


def _save(report):
    os.makedirs(REPORT_DIR, exist_ok=True)
    path = os.path.join(REPORT_DIR, 'log-analysis-%s.txt' % time.strftime('%Y%m%d-%H%M%S'))
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write(report)
    for old in sorted(glob.glob(os.path.join(REPORT_DIR, 'log-analysis-*.txt')))[:-KEEP_REPORTS]:
        try:
            os.remove(old)
        except OSError:
            pass
    return path


def _upload(report):
    request = urllib.request.Request(PASTE_URL + 'documents', data=report.encode('utf-8'), method='POST',
                                     headers={'User-Agent': 'Kodi-TheGarbageTool', 'Content-Type': 'text/plain; charset=utf-8'})
    with urllib.request.urlopen(request, timeout=max(utils.get_int('net_timeout', 8), 15)) as response:
        return PASTE_URL + json.loads(response.read().decode('utf-8'))['key']


def run():
    index = xbmcgui.Dialog().select(L(S.LOG_WHICH), [L(S.LOG_CURRENT), L(S.LOG_PREVIOUS)])
    if index < 0:
        return
    name = ('kodi.log', 'kodi.old.log')[index]
    path = os.path.join(utils.real('special://logpath/'), name)
    if not os.path.isfile(path):
        utils.info(L(S.LOG_MISSING))
        return
    dialog = utils.progress(L(S.LOG_ANALYSING))
    try:
        result = _read(path, dialog)
    finally:
        dialog.close()
    if result is None:
        return
    analysis, line_count = result
    if not analysis['groups']:
        utils.info(L(S.LOG_NO_ERRORS))
        return

    groups = analysis['groups']
    found = logparse.addons_in(groups)
    if found:
        choice = xbmcgui.Dialog().select(L(S.LOG_FILTER_TITLE),
                                         [L(S.LOG_ALL_ADDONS)] + ['%s (%d)' % item for item in found])
        if choice < 0:
            return
        if choice > 0:
            groups = [g for g in groups if g['addon'] == found[choice - 1][0]]

    versions, installed_lines = _installed()
    header = {'created': time.strftime('%Y-%m-%d %H:%M'), 'logname': name, 'lines': line_count,
              'system': (xbmc.getInfoLabel('System.BuildVersion') or '?', xbmc.getInfoLabel('System.OSVersionInfo') or '?')}
    report = logparse.render(analysis, groups, L, header, versions, installed_lines)
    saved = _save(report)
    utils.log('Log analysis saved: %s (%d groups)' % (saved, len(groups)))
    utils.show_text(L(S.M_LOGANALYSIS), report)
    utils.info(L(S.REPORT_SAVED, saved))
    if xbmcgui.Dialog().yesno(utils.title(), L(S.ASK_UPLOAD)):
        try:
            utils.info(L(S.UPLOAD_OK, _upload(report)))
        except Exception as exc:
            utils.log('Upload failed: %s' % exc, xbmc.LOGWARNING)
            utils.info(L(S.UPLOAD_FAILED))
