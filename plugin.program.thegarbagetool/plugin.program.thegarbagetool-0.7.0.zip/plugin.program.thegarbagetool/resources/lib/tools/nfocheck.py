# -*- coding: utf-8 -*-
import os
import time
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import ids as S
from resources.lib import nfolib, utils
from resources.lib.tools import favourites
from resources.lib.utils import L

ID = 'nfocheck'
TITLE = S.M_NFO
ARCHIVES = os.path.join(utils.PROFILE, 'archives')


class VfsFs(object):
    """Filesystem access through xbmcvfs, so local paths and network shares both work."""

    def listdir(self, path):
        dirs, files = xbmcvfs.listdir(path)
        return list(dirs), list(files)

    def read(self, path, limit):
        handle = None
        try:
            handle = xbmcvfs.File(path)
            return bytes(handle.readBytes(limit + 1))
        except Exception as exc:
            utils.log('NFO read failed: %s (%s)' % (path, exc), xbmc.LOGDEBUG)
            return None
        finally:
            if handle:
                handle.close()

    def join(self, base, name):
        if '://' in base or base.startswith('/'):
            return base.rstrip('/') + '/' + name
        return os.path.join(base, name)


def _sources():
    found = []
    for media in ('video', 'music'):
        result = utils.rpc('Files.GetSources', {'media': media}).get('result', {})
        for source in result.get('sources', []):
            paths = [source.get('file', '')]
            if paths[0].startswith('multipath://'):
                paths = [unquote(p) for p in paths[0][len('multipath://'):].split('/') if p]
            for path in paths:
                scheme = path.split('://')[0].lower() if '://' in path else 'file'
                if path and scheme in favourites.PATH_SCHEMES and (source.get('label'), path) not in found:
                    found.append((source.get('label') or path, path))
    return found


def _pick_roots():
    sources = _sources()
    labels = ['%s  (%s)' % item for item in sources] + [L(S.DEV_BROWSE)]
    chosen = xbmcgui.Dialog().multiselect(L(S.NFO_PICK), labels)
    if not chosen:
        return []
    roots = [sources[i][1] for i in chosen if i < len(sources)]
    if len(sources) in chosen:
        folder = xbmcgui.Dialog().browse(0, L(S.DEV_BROWSE), 'files') or ''
        if folder:
            roots.append(folder)
    return roots


def _remove(fs, result):
    items = nfolib.deletable(result)
    if not items:
        return
    sev_labels = {kind: L(nfolib.KINDS[kind][1]) for kind, _path in items}
    chosen = xbmcgui.Dialog().multiselect(L(S.NFO_DELETE_SELECT), ['[%s] %s' % (sev_labels[k], p) for k, p in items])
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_ITEMS, len(chosen))):
        return
    paths = [items[i][1] for i in chosen]
    backup = os.path.join(ARCHIVES, 'nfo-removed-%s.zip' % time.strftime('%Y%m%d-%H%M%S'))
    nfolib.backup_zip(fs, paths, backup)
    removed = 0
    for path in paths:
        if xbmcvfs.delete(path):
            removed += 1
            utils.log('NFO removed: %s' % path)
    utils.info(L(S.NFO_REMOVED, removed, backup))


def run():
    roots = _pick_roots()
    if not roots:
        if not _sources():
            utils.info(L(S.NFO_NO_SOURCES))
        return
    fs = VfsFs()
    dialog = utils.progress(L(S.NFO_PROGRESS, 0))
    try:
        result = nfolib.scan(fs, roots,
                             progress=lambda n: dialog.update(n % 100, L(S.NFO_PROGRESS, n)),
                             cancelled=dialog.iscanceled)
    finally:
        dialog.close()
    utils.log('NFO check: %d folders, %d NFOs' % (result['folders'], result['nfos']))
    utils.show_text(L(S.M_NFO), nfolib.render(result, L))
    _remove(fs, result)
