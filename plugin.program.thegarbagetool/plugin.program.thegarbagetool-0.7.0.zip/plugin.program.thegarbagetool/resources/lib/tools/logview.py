# -*- coding: utf-8 -*-
import os

import xbmcgui

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'log'
TITLE = S.M_LOG
TAIL_BYTES = 24 * 1024


def run():
    text = ''
    try:
        with open(utils.LOG_FILE, 'rb') as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - TAIL_BYTES))
            text = f.read().decode('utf-8', 'replace')
    except OSError:
        pass
    if not text.strip():
        utils.info(L(S.LOG_EMPTY))
        return
    xbmcgui.Dialog().textviewer(L(S.M_LOG), text)
    if xbmcgui.Dialog().yesno(utils.title(), L(S.LOG_CLEAR)):
        open(utils.LOG_FILE, 'w').close()
