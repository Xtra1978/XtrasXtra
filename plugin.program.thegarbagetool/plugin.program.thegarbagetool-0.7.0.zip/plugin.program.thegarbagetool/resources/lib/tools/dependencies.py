# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'dependencies'
TITLE = S.M_DEPS
BUILTIN_PREFIXES = ('xbmc.', 'kodi.')


def _scan(addons):
    by_id = {a['addonid']: a for a in addons}
    missing, disabled = {}, {}
    for addon in addons:
        if not addon.get('enabled'):
            continue
        for dep in addon.get('dependencies') or []:
            dep_id = dep.get('addonid')
            if not dep_id or dep.get('optional') or dep_id.startswith(BUILTIN_PREFIXES):
                continue
            if dep_id not in by_id:
                missing.setdefault(dep_id, []).append(addonops.label(addon))
            elif not by_id[dep_id].get('enabled'):
                disabled.setdefault(dep_id, []).append(addonops.label(addon))
    findings = []
    for dep_id, users in sorted(missing.items()):
        findings.append(('missing', dep_id, L(S.DEP_MISSING, dep_id, ', '.join(users[:2])), None))
    for dep_id, users in sorted(disabled.items()):
        findings.append(('disabled', dep_id, L(S.DEP_DISABLED, dep_id, ', '.join(users[:2])), None))
    for addon in addonops.orphan_modules(addons):
        findings.append(('orphan', addon['addonid'], L(S.DEP_ORPHAN, addon['addonid']), addon))
    return findings


def run():
    addons = utils.all_addons()
    findings = _scan(addons)
    if not findings:
        utils.info(L(S.NO_FINDINGS))
        return
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_FIX), [f[2] for f in findings])
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_FIX, len(chosen))):
        return
    fixed = 0
    for index in chosen:
        kind, addon_id, _label, addon = findings[index]
        if kind == 'missing':
            xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
            xbmc.sleep(2500)
            fixed += 1
        elif kind == 'disabled':
            addonops.set_enabled(addon_id, True)
            fixed += 1
        elif kind == 'orphan' and addonops.uninstall(addon):
            fixed += 1
        utils.log('Dependency fix (%s): %s' % (kind, addon_id))
    addonops.finish()
    utils.info(L(S.FIXED, fixed))
