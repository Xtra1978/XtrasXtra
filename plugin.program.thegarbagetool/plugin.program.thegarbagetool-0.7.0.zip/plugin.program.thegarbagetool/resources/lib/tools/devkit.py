# -*- coding: utf-8 -*-
import os

import xbmc
import xbmcgui

from resources.lib import addonops, devcheck, repobuild
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'devkit'
TITLE = S.M_DEVKIT


def _user_addons():
    return sorted((a for a in utils.all_addons() if addonops.is_user(a)), key=lambda a: addonops.label(a).lower())


def _labels(addons):
    return ['%s (%s)' % (addonops.label(a), a['addonid']) for a in addons]


def _browse(heading, kind=0, default=''):
    return xbmcgui.Dialog().browse(kind, heading, 'files', '', False, False, default) or ''


def _pick_one():
    addons = _user_addons()
    index = xbmcgui.Dialog().select(L(S.DEV_PICK), _labels(addons) + [L(S.DEV_BROWSE)])
    if index < 0:
        return None
    if index == len(addons):
        return _browse(L(S.DEV_BROWSE)).rstrip('/\\') or None
    return addonops.addon_path(addons[index])


def _show(title, results):
    utils.show_text(title, devcheck.render(title, results, L))


def _check_addon():
    path = _pick_one()
    if not path:
        return
    installed = {a['addonid'] for a in utils.all_addons(('name',))}
    _show(L(S.DEV_REPORT_TITLE, os.path.basename(path)), devcheck.check_addon(path, installed, L))


def _check_po():
    path = _pick_one()
    if path:
        _show(L(S.DEV_PO_TITLE, os.path.basename(path)), devcheck.check_po(path, L))


def _build_repo():
    addons = _user_addons()
    chosen = xbmcgui.Dialog().multiselect(L(S.REPO_PICK), _labels(addons) + [L(S.DEV_BROWSE)])
    if not chosen:
        return
    sources = [addonops.addon_path(addons[i]) for i in chosen if i < len(addons)]
    if len(addons) in chosen:
        extra = _browse(L(S.DEV_BROWSE)).rstrip('/\\')
        if extra:
            sources.append(extra)
    if not sources:
        return
    default = os.path.join(utils.PROFILE, 'repo')
    os.makedirs(default, exist_ok=True)
    out_dir = _browse(L(S.REPO_OUT), 3, default + os.sep).rstrip('/\\')
    if not out_dir:
        return
    packed = 0
    for source in sources:
        try:
            repobuild.build_zip(source, out_dir)
            packed += 1
        except Exception as exc:
            utils.log('Pack failed (%s): %s' % (source, exc), xbmc.LOGWARNING)
            utils.info(L(S.REPO_FAIL, os.path.basename(source), exc))
    if packed:
        repobuild.update_index(out_dir)
        utils.log('Repository files built in %s (%d addons)' % (out_dir, packed))
        utils.info(L(S.REPO_DONE, packed, out_dir))


def run():
    actions = [(S.DEV_CHECK, _check_addon), (S.DEV_PO, _check_po), (S.DEV_REPO, _build_repo)]
    while True:
        index = xbmcgui.Dialog().select(L(S.M_DEVKIT), [L(sid) for sid, _fn in actions])
        if index < 0:
            return
        actions[index][1]()
