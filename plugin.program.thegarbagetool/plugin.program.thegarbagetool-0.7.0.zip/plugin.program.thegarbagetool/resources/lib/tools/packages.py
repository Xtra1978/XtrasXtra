# -*- coding: utf-8 -*-
from resources.lib import ids as S
from resources.lib import utils

ID = 'packages'
TITLE = S.M_PACKAGES


def run():
    utils.clean_folder('special://home/addons/packages/', S.CONFIRM_PACKAGES)
