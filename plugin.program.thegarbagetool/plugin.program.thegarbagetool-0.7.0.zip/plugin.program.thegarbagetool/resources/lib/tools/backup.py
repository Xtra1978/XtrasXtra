# -*- coding: utf-8 -*-
import os
import time
import zipfile

import xbmc
import xbmcgui

from resources.lib import addonops, backuplib
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'backup'
TITLE = S.M_BACKUP
LABELS = [('favourites', S.FAVS_TITLE), ('sources', S.SOURCES_TITLE), ('playlists', S.BK_PLAYLISTS),
          ('advanced', S.BK_ADVANCED), ('addon_data', S.BK_ADDONDATA)]
ARCHIVES = os.path.join(utils.PROFILE, 'archives')
OWN_EXCLUDE = ['addon_data/%s/%s' % (utils.ADDON_ID, d) for d in ('archives', 'backups', 'reports', 'repo')]


def _profile():
    return os.path.normpath(utils.real('special://profile/'))


def _browse(kind, heading, mask=''):
    os.makedirs(ARCHIVES, exist_ok=True)
    return xbmcgui.Dialog().browse(kind, heading, 'files', mask, False, False, ARCHIVES + os.sep) or ''


def _addons_text():
    lines = []
    for addon in sorted(utils.all_addons(), key=lambda a: a['addonid']):
        if addonops.is_user(addon):
            lines.append('%s %s%s' % (addon['addonid'], addon.get('version', ''), '' if addon.get('enabled') else ' (disabled)'))
    return '\n'.join(lines)


def _progress_callback(dialog):
    def update(done, total):
        dialog.update(int(done * 100 / max(total, 1)), L(S.WORKING))
    return update


def _write(out_zip, components, files, with_addons=True):
    dialog = utils.progress(L(S.WORKING))
    try:
        return backuplib.create(out_zip, components, files,
                                meta={'kodi': xbmc.getInfoLabel('System.BuildVersion'), 'addon_version': utils.ADDON.getAddonInfo('version')},
                                addons_text=_addons_text() if with_addons else '', progress=_progress_callback(dialog))
    finally:
        dialog.close()


def _create():
    chosen = xbmcgui.Dialog().multiselect(L(S.BK_SELECT), [L(sid) for _key, sid in LABELS])
    if not chosen:
        return
    components = [LABELS[i][0] for i in chosen]
    if 'addon_data' in components and not xbmcgui.Dialog().yesno(utils.title(), L(S.BK_WARN_SECRETS)):
        return
    files = backuplib.collect(_profile(), components, OWN_EXCLUDE)
    if not files:
        utils.info(L(S.BK_EMPTY))
        return
    out_dir = _browse(3, L(S.BK_OUT)).rstrip('/\\')
    if not out_dir:
        return
    out_zip = os.path.join(out_dir, 'garbagetool-backup-%s.zip' % time.strftime('%Y%m%d-%H%M%S'))
    _write(out_zip, components, files)
    utils.log('Backup created: %s (%s)' % (out_zip, ', '.join(components)))
    utils.info(L(S.BK_DONE, out_zip, utils.fmt_size(os.path.getsize(out_zip))))


def _restore():
    path = _browse(1, L(S.BK_FILE), '.zip')
    if not path:
        return
    counts = backuplib.read_components(path) if zipfile.is_zipfile(path) else None
    if not counts:
        utils.info(L(S.BK_INVALID))
        return
    available = [(key, sid) for key, sid in LABELS if key in counts]
    chosen = xbmcgui.Dialog().multiselect(L(S.BK_SELECT_RESTORE),
                                          [L(S.BK_ITEM, L(sid), counts[key]) for key, sid in available])
    if not chosen:
        return
    components = [available[i][0] for i in chosen]
    total = sum(counts[c] for c in components)
    if not xbmcgui.Dialog().yesno(utils.title(), L(S.BK_CONFIRM_RESTORE, total)):
        return
    # Safety copy of what is about to be overwritten.
    safety = os.path.join(ARCHIVES, 'before-restore-%s.zip' % time.strftime('%Y%m%d-%H%M%S'))
    existing = backuplib.collect(_profile(), components, OWN_EXCLUDE)
    if existing:
        _write(safety, components, existing, with_addons=False)
    dialog = utils.progress(L(S.WORKING))
    try:
        restored = backuplib.restore(path, _profile(), components, _progress_callback(dialog))
    finally:
        dialog.close()
    utils.log('Backup restored from %s: %d files (%s)' % (path, restored, ', '.join(components)))
    utils.info(L(S.BK_RESTORED, restored, safety if existing else '-'))
    utils.restart_prompt()


def run():
    actions = [(S.BK_CREATE, _create), (S.BK_RESTORE, _restore)]
    index = xbmcgui.Dialog().select(L(S.M_BACKUP), [L(sid) for sid, _fn in actions])
    if index >= 0:
        actions[index][1]()
