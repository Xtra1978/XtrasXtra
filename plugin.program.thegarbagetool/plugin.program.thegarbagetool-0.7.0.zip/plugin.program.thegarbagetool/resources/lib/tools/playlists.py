# -*- coding: utf-8 -*-
import os
import xml.etree.ElementTree as ET

import xbmcgui

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'playlists'
TITLE = S.M_PLAYLISTS
EXTENSIONS = ('.xsp', '.m3u', '.m3u8', '.pls')


def _name(path):
    if path.lower().endswith('.xsp'):
        try:
            name = ET.parse(path).getroot().findtext('name')
            if name:
                return name.strip()
        except Exception:
            pass
    return os.path.splitext(os.path.basename(path))[0]


def run():
    base = utils.real('special://profile/playlists/')
    found = []
    for root, _dirs, files in os.walk(base):
        for name in sorted(files):
            if name.lower().endswith(EXTENSIONS):
                found.append(os.path.join(root, name))
    if not found:
        utils.info(L(S.NO_PLAYLISTS))
        return
    labels = ['%s  (%s)' % (_name(p), os.path.relpath(p, base)) for p in found]
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_REMOVE), labels)
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_ITEMS, len(chosen))):
        return
    count = 0
    for index in chosen:
        try:
            os.remove(found[index])
            count += 1
            utils.log('Playlist removed: %s' % found[index])
        except OSError as exc:
            utils.log('Playlist delete failed: %s (%s)' % (found[index], exc), 2)
    utils.info(L(S.REMOVED, count))
