# -*- coding: utf-8 -*-
import xbmcgui

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'debuglog'
TITLE = S.M_DEBUG
SETTING = 'debug.showloginfo'


def run():
    value = utils.rpc('Settings.GetSettingValue', {'setting': SETTING}).get('result', {}).get('value')
    enabled = bool(value)
    if not xbmcgui.Dialog().yesno(utils.title(), L(S.DEBUG_IS_ON if enabled else S.DEBUG_IS_OFF)):
        return
    utils.rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': not enabled})
    utils.log('Debug logging %s' % ('off' if enabled else 'on'))
    utils.info(L(S.DEBUG_SET_OFF if enabled else S.DEBUG_SET_ON))
