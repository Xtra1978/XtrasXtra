# -*- coding: utf-8 -*-
import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'addons'
TITLE = S.M_ADDONS


def run():
    addons = utils.all_addons()
    required = addonops.required_by(addons)
    rows = []
    for addon in addons:
        if not addonops.is_user(addon) or addon.get('type') == addonops.REPO_TYPE:
            continue
        flags = []
        if addonops.is_broken(addon):
            flags.append(L(S.ST_BROKEN))
        if addon.get('type') == addonops.MODULE_TYPE and addon['addonid'] not in required:
            flags.append(L(S.ST_ORPHAN))
        if not addon.get('enabled') and addon['addonid'] not in required:
            flags.append(L(S.ST_DISABLED))
        rows.append((not flags, addonops.label(addon).lower(), addon, flags))
    if not rows:
        utils.info(L(S.NO_ADDONS))
        return
    rows.sort(key=lambda r: (r[0], r[1]))
    labels = ['%s (%s)%s' % (addonops.label(r[2]), r[2]['addonid'], '  [%s]' % ', '.join(r[3]) if r[3] else '')
              for r in rows]
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_REMOVE), labels)
    if not chosen:
        return
    picked = [rows[i][2] for i in chosen]
    picked_ids = {a['addonid'] for a in picked}

    # Warn when other (not selected) addons still depend on a selected one.
    still_needed = []
    for addon in picked:
        users = required.get(addon['addonid'], set()) - picked_ids
        if users:
            still_needed.append('%s (%s)' % (addonops.label(addon), ', '.join(sorted(users)[:2])))
    if still_needed and not xbmcgui.Dialog().yesno(utils.title(), L(S.WARN_REQUIRED, '; '.join(still_needed))):
        return
    if not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_ITEMS, len(picked))):
        return

    count = sum(1 for addon in picked if addonops.uninstall(addon))
    extra = addonops.cascade_orphans(addons, picked_ids)
    if extra and xbmcgui.Dialog().yesno(utils.title(), L(S.ASK_ORPHAN_DEPS, len(extra))):
        count += sum(1 for addon in extra if addonops.uninstall(addon))
    addonops.finish()
    utils.info(L(S.REMOVED, count))
    utils.restart_prompt()
