# -*- coding: utf-8 -*-
import glob
import os
import shutil

import xbmcgui

from resources.lib import addonops
from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'pvr'
TITLE = S.M_PVR


def _is_pvr(addon):
    return addon.get('type') == 'kodi.pvrclient' or addon['addonid'].startswith('pvr.')


def _delete_pvr_databases():
    count = 0
    base = utils.folder('special://database/')
    for pattern in ('TV*.db', 'Epg*.db'):
        for db in glob.glob(os.path.join(base, pattern)):
            try:
                os.remove(db)
                count += 1
                utils.log('PVR database removed: %s' % db)
            except OSError as exc:
                utils.log('PVR database delete failed: %s (%s)' % (db, exc), 2)
    return count


def run():
    clients = [a for a in utils.all_addons() if _is_pvr(a)]
    if not clients:
        utils.info(L(S.NO_PVR))
        return
    labels = []
    for addon in clients:
        flags = []
        if not addonops.is_user(addon):
            flags.append(L(S.ST_SYSTEM))
        if not addon.get('enabled'):
            flags.append(L(S.ST_DISABLED))
        labels.append('%s (%s)%s' % (addonops.label(addon), addon['addonid'],
                                     '  [%s]' % ', '.join(flags) if flags else ''))
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_REMOVE), labels)
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_PVR, len(chosen))):
        return
    remove_data = xbmcgui.Dialog().yesno(utils.title(), L(S.ASK_DATA))
    count = 0
    for index in chosen:
        addon = clients[index]
        if addonops.is_user(addon):
            ok = addonops.uninstall(addon, remove_data)
        else:
            addonops.set_enabled(addon['addonid'], False)
            if remove_data:
                shutil.rmtree(addonops.data_dir(addon['addonid']), ignore_errors=True)
            utils.log('PVR client disabled: %s' % addon['addonid'])
            ok = True
        count += 1 if ok else 0
    if xbmcgui.Dialog().yesno(utils.title(), L(S.ASK_PVR_DB)):
        _delete_pvr_databases()
    addonops.finish()
    utils.info(L(S.REMOVED, count))
    utils.restart_prompt()
