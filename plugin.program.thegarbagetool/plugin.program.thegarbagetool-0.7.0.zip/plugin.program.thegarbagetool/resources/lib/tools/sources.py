# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
from urllib.parse import unquote

import xbmcgui

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.tools import favourites
from resources.lib.utils import L

ID = 'sources'
TITLE = S.M_SOURCES


def _expand(path):
    if path.startswith('multipath://'):
        return [unquote(p) for p in path[len('multipath://'):].split('/') if p]
    return [path]


def _check(path, installed, timeout):
    """True = reachable, False = not reachable, None = not verifiable."""
    scheme = path.split('://')[0].lower() if '://' in path else 'file'
    if scheme in ('http', 'https'):
        return utils.http_ok(path, timeout)
    if scheme == 'plugin':
        return path[len('plugin://'):].split('/')[0] in installed
    if scheme in favourites.PATH_SCHEMES:
        return favourites._exists(path)
    return None


def _status(paths, installed, timeout):
    results = [_check(p, installed, timeout) for raw in paths for p in _expand(raw)]
    if any(r is True for r in results):
        return S.ST_REACHABLE
    if any(r is False for r in results):
        return S.ST_UNREACHABLE
    return S.ST_UNKNOWN


def _save(tree):
    path = utils.real('special://profile/sources.xml')
    saved = utils.backup(path)
    if hasattr(ET, 'indent'):
        ET.indent(tree, space='    ')
    tree.write(path, encoding='utf-8', xml_declaration=True)
    return saved


def run():
    path = utils.real('special://profile/sources.xml')
    try:
        tree = ET.parse(path)
    except Exception:
        utils.info(L(S.NO_SOURCES))
        return
    root = tree.getroot()
    found = [(section, src) for section in root for src in section.findall('source')]
    if not found:
        utils.info(L(S.NO_SOURCES))
        return

    installed = {a['addonid'] for a in utils.all_addons(('name',))}
    timeout = utils.get_int('net_timeout', 8)
    dialog = utils.progress(L(S.CHECKING_SOURCES))
    entries = []
    try:
        for i, (section, src) in enumerate(found):
            dialog.update(int(i * 100 / len(found)), L(S.CHECKING_SOURCES))
            if dialog.iscanceled():
                return
            paths = [(p.text or '').strip() for p in src.findall('path') if (p.text or '').strip()]
            entries.append({'section': section, 'node': src, 'name': src.findtext('name', ''),
                            'path': paths[0] if paths else '',
                            'status': _status(paths, installed, timeout)})
    finally:
        dialog.close()

    removed = 0
    while entries:
        dead = [e for e in entries if e['status'] == S.ST_UNREACHABLE]
        labels, actions = [], []
        if dead:
            labels.append(L(S.SRC_REMOVE_BROKEN, len(dead)))
            actions.append(dead)
        for entry in entries:
            labels.append('%s - %s  [%s]' % (entry['name'], entry['path'], L(entry['status'])))
            actions.append([entry])
        index = xbmcgui.Dialog().select(L(S.SOURCES_TITLE), labels)
        if index < 0:
            break
        items = actions[index]
        question = L(S.CONFIRM_SRC, items[0]['name']) if len(items) == 1 else L(S.CONFIRM_SRC_MANY, len(items))
        if not xbmcgui.Dialog().yesno(utils.title(), question):
            continue
        for item in items:
            item['section'].remove(item['node'])
            entries.remove(item)
        saved = _save(tree)
        if not removed:
            utils.info(L(S.BACKUP_SAVED, saved))
        removed += len(items)
        utils.log('Sources removed: %s' % ', '.join(i['name'] for i in items))
    if removed:
        utils.info(L(S.DELETED_COUNT, removed))
        utils.restart_prompt()
