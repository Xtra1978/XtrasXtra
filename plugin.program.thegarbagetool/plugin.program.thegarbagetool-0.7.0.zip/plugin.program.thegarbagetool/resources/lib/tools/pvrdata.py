# -*- coding: utf-8 -*-
import glob
import os
import sqlite3

import xbmc
import xbmcgui

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.utils import L

ID = 'pvrdata'
TITLE = S.M_PVRDATA


def _groups():
    """[(label id, [files])] - databases with their journal/wal sidecars, plus IPTV Simple caches."""
    base = utils.folder('special://database/')
    cache = os.path.join(utils.real('special://profile/addon_data/pvr.iptvsimple/'), '*.cache')
    return [(S.PVR_EPG, sorted(glob.glob(os.path.join(base, 'Epg*.db*')))),
            (S.PVR_CHANNELS, sorted(glob.glob(os.path.join(base, 'TV*.db*')))),
            (S.PVR_CACHE, sorted(glob.glob(cache)))]


def _size(files):
    total = 0
    for path in files:
        try:
            total += os.path.getsize(path)
        except OSError:
            pass
    return total


def _empty_database(path):
    """Fallback when the file cannot be deleted (e.g. Windows keeps it locked while Kodi runs)."""
    con = None
    try:
        con = sqlite3.connect(path, timeout=5)
        con.isolation_level = None
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' "
                                            "AND name NOT LIKE 'sqlite_%' AND name != 'version'")]
        for table in tables:
            con.execute('DELETE FROM "%s"' % table.replace('"', '""'))
        try:
            con.execute('VACUUM')
        except sqlite3.OperationalError:
            pass
        return True
    except sqlite3.Error as exc:
        utils.log('PVR database could not be emptied: %s (%s)' % (path, exc), xbmc.LOGWARNING)
        return False
    finally:
        if con:
            con.close()


def run():
    groups = [(sid, files) for sid, files in _groups() if files]
    if not groups:
        utils.info(L(S.PVR_NO_DATA))
        return
    labels = [L(S.PVR_ITEM, L(sid), utils.fmt_size(_size(files))) for sid, files in groups]
    chosen = xbmcgui.Dialog().multiselect(L(S.SELECT_REMOVE), labels)
    if not chosen or not xbmcgui.Dialog().yesno(utils.title(), L(S.CONFIRM_PVR_RESET)):
        return
    deleted = emptied = 0
    for index in chosen:
        for path in groups[index][1]:
            try:
                os.remove(path)
                deleted += 1
                utils.log('PVR data deleted: %s' % path)
            except OSError:
                if path.endswith('.db') and _empty_database(path):
                    emptied += 1
                    utils.log('PVR database emptied: %s' % path)
    utils.info(L(S.PVR_RESET_DONE, deleted, emptied))
    utils.restart_prompt()
