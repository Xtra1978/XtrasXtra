# -*- coding: utf-8 -*-
import json
import os
import shutil
import textwrap
import time
import xml.etree.ElementTree as ET
import urllib.error
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import ids as S

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
MAX_LOG_BYTES = 200 * 1024


def L(string_id, *args):
    text = ADDON.getLocalizedString(string_id)
    return text.format(*args) if args else text


def real(path):
    return xbmcvfs.translatePath(path)


PROFILE = real(ADDON.getAddonInfo('profile'))
LOG_FILE = os.path.join(PROFILE, 'garbagetool.log')
BACKUP_DIR = os.path.join(PROFILE, 'backups')


ALIASES = {
    'special://thumbnails/': ('special://masterprofile/Thumbnails/', 'special://profile/Thumbnails/'),
    'special://database/': ('special://masterprofile/Database/', 'special://profile/Database/'),
}


def substitutions():
    """(from, to) pairs of <pathsubstitution> in advancedsettings.xml."""
    pairs = []
    try:
        root = ET.parse(real('special://masterprofile/advancedsettings.xml')).getroot()
    except Exception:
        return pairs
    for node in root.iter('substitute'):
        src = (node.findtext('from') or '').strip()
        dst = (node.findtext('to') or '').strip()
        if src and dst:
            pairs.append((src, dst))
    return pairs


def resolve(special_path):
    """(folder, unsupported_target). Follows pathsubstitution for local targets, like Kodi does for its own access."""
    forms = (special_path,) + ALIASES.get(special_path, ())
    for src, dst in substitutions():
        for form in forms:
            if form.lower().startswith(src.lower()):
                target = dst + form[len(src):]
                if target.startswith('special://'):
                    return real(target), None
                if target.startswith('file://'):
                    return os.path.normpath(target[len('file://'):]), None
                if '://' in target:
                    return real(special_path), target
                return os.path.normpath(target), None
    return real(special_path), None


def folder(special_path):
    return resolve(special_path)[0]


def get_bool(key, default=True):
    value = ADDON.getSetting(key)
    return default if value == '' else value == 'true'


def get_int(key, default):
    try:
        return int(ADDON.getSetting(key))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------- log
def _rotate():
    try:
        if os.path.getsize(LOG_FILE) > MAX_LOG_BYTES:
            with open(LOG_FILE, 'rb') as f:
                f.seek(-MAX_LOG_BYTES // 2, os.SEEK_END)
                tail = f.read()
            with open(LOG_FILE, 'wb') as f:
                f.write(tail.split(b'\n', 1)[-1])
    except OSError:
        pass


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, message), level)
    if not get_bool('write_log', True):
        return
    try:
        os.makedirs(PROFILE, exist_ok=True)
        _rotate()
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), message))
    except OSError:
        pass


# ---------------------------------------------------------------- files
def fmt_size(num):
    num = float(num)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if num < 1024 or unit == 'GB':
            return ('%d %s' % (num, unit)) if unit == 'B' else ('%.1f %s' % (num, unit))
        num /= 1024


def scan(path, keep=()):
    count = size = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            if name.lower() in keep:
                continue
            try:
                size += os.path.getsize(os.path.join(root, name))
                count += 1
            except OSError:
                pass
    return count, size


def purge(path, keep=()):
    removed = freed = failed = 0
    for root, dirs, files in os.walk(path, topdown=False):
        for name in files:
            if name.lower() in keep:
                continue
            full = os.path.join(root, name)
            try:
                size = os.path.getsize(full)
                os.remove(full)
                removed += 1
                freed += size
            except OSError as exc:
                failed += 1
                log('Delete failed: %s (%s)' % (full, exc), xbmc.LOGWARNING)
        for name in dirs:
            try:
                os.rmdir(os.path.join(root, name))
            except OSError:
                pass
    return removed, freed, failed


def backup(path):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    target = os.path.join(BACKUP_DIR, '%s.%s.bak' % (os.path.basename(path), time.strftime('%Y%m%d-%H%M%S')))
    shutil.copy2(path, target)
    log('Backup: %s' % target)
    return target


# ---------------------------------------------------------------- dialogs
def title():
    return ADDON.getAddonInfo('name')


def info(text):
    xbmcgui.Dialog().ok(title(), text)


def confirm_clean(text):
    if not get_bool('confirm_delete', True):
        return True
    return xbmcgui.Dialog().yesno(title(), text)


def restart_prompt():
    """Offer restart (where Kodi can do it itself), quit, or later. Android cannot self-restart."""
    options = []
    if not xbmc.getCondVisibility('System.Platform.Android'):
        options.append((S.RESTART_NOW, 'RestartApp'))
    options.append((S.QUIT_ONLY, 'Quit'))
    options.append((S.LATER, None))
    index = xbmcgui.Dialog().select(L(S.RESTART_NOTE), [L(sid) for sid, _builtin in options])
    if index >= 0 and options[index][1]:
        log('Kodi %s requested' % options[index][1])
        xbmc.executebuiltin(options[index][1])


def clean_folder(special_path, confirm_text_id, keep=()):
    """Shared flow for the plain folder cleaners (cache, packages)."""
    path, remote = resolve(special_path)
    if remote:
        info(L(S.PATHSUB_NETWORK, remote))
        return
    count, size = scan(path, keep) if os.path.isdir(path) else (0, 0)
    if count == 0:
        info(L(S.NOTHING))
        return
    if not confirm_clean(L(confirm_text_id, count, fmt_size(size))):
        return
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        removed, freed, failed = purge(path, keep)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    log('Cleaned %s: %d files, %s, %d failed' % (path, removed, fmt_size(freed), failed))
    text = L(S.FREED, fmt_size(freed), removed)
    if failed:
        text += '\n' + L(S.PARTIAL, failed)
    info(text)


# ---------------------------------------------------------------- json-rpc / network
def rpc(method, params=None):
    query = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        query['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(query)))
    except ValueError:
        return {}


def all_addons(properties=('name', 'version', 'enabled', 'broken', 'path', 'dependencies', 'type')):
    result = rpc('Addons.GetAddons', {'enabled': 'all', 'properties': list(properties)})
    return result.get('result', {}).get('addons', [])


def http_ok(url, timeout):
    headers = {'User-Agent': 'Kodi-TheGarbageTool'}
    for method in ('HEAD', 'GET'):
        try:
            request = urllib.request.Request(url, headers=headers, method=method)
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return response.status < 400
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                return True
            if method == 'GET':
                return False
        except Exception as exc:  # timeout, DNS, TLS ...
            log('HTTP check failed: %s (%s)' % (url, exc), xbmc.LOGDEBUG)
            return False
    return False


def show_text(heading, text, width=72):
    """Read-only, scrollable view. Avoids Dialog.textviewer, whose page change closes the window on Android."""
    items = []
    for line in text.split('\n'):
        if not line.strip():
            items.append(' ')
            continue
        items.extend(textwrap.wrap(line, width=width, subsequent_indent='    ') or [line])
    position = -1
    while True:
        index = xbmcgui.Dialog().select(heading, items, 0, position)
        if index < 0:
            return
        position = index


def progress(text):
    dialog = xbmcgui.DialogProgress()
    dialog.create(title(), text)
    return dialog
