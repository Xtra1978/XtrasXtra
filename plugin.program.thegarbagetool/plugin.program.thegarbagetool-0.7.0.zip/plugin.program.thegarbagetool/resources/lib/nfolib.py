# -*- coding: utf-8 -*-
"""NFO checker (pure python, filesystem injected so it is unit-testable).

fs must offer: listdir(path) -> (dirs, files), read(path, limit) -> bytes|None, join(base, name).
"""
import os
import re
import xml.etree.ElementTree as ET
import zipfile
from collections import OrderedDict

from resources.lib import ids as S

ERR, WARN, NOTE = 'error', 'warn', 'note'
VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.wmv', '.mpg', '.mpeg', '.ts', '.m2ts', '.iso', '.img',
             '.flv', '.webm', '.divx', '.vob', '.ogm', '.ogv', '.3gp', '.strm')
AUDIO_EXT = ('.mp3', '.flac', '.m4a', '.ogg', '.opus', '.wav', '.wma', '.aac', '.ape', '.wv', '.mka', '.dsf', '.alac')
MAX_NFO = 2 * 1024 * 1024
SPECIAL = ('tvshow.nfo', 'movie.nfo', 'album.nfo', 'artist.nfo')
SKIP_DIRS = ('video_ts', 'bdmv', 'extrafanart', 'extrathumbs', '@eadir', '#recycle', 'metadata')
SKIP_PREFIX = ('.', '@')
EPISODE_RE = re.compile(r'[sS]\d{1,3}[eE]\d{1,3}|(?<!\d)\d{1,2}x\d{1,3}(?!\d)')
SEASON_RE = re.compile(r'^(season|staffel|saison|temporada|s)[ ._-]*\d+$|^specials?$', re.I)
DISC_RE = re.compile(r'^(cd|disc|disk|dvd)[ ._-]*\d+$', re.I)
STACK_RE = re.compile(r'[ _.-]*(cd|dvd|part|pt|disc|disk)[ _.-]*\d+$')
MAX_PER_GROUP = 15

KINDS = OrderedDict([
    ('broken', (ERR, S.NFO_BROKEN)), ('encoding', (WARN, S.NFO_ENCODING)), ('empty', (WARN, S.NFO_EMPTY)),
    ('too_big', (WARN, S.NFO_TOO_BIG)), ('root', (WARN, S.NFO_ROOT)), ('no_title', (WARN, S.NFO_NO_TITLE)),
    ('multi_ep_num', (WARN, S.NFO_MULTI_EP_NUM)), ('dup', (WARN, S.NFO_DUP)), ('orphan', (WARN, S.NFO_ORPHAN)),
    ('ep_name', (WARN, S.NFO_EP_NAME)), ('multi_ep', (NOTE, S.NFO_MULTI_EP)), ('text', (NOTE, S.NFO_TEXT)),
    ('missing_show', (NOTE, S.NFO_MISSING_SHOW)), ('missing_album', (NOTE, S.NFO_MISSING_ALBUM)),
    ('missing_movie', (NOTE, S.NFO_MISSING_MOVIE)), ('missing_ep', (NOTE, S.NFO_MISSING_EP)),
])
DELETABLE = ('broken', 'empty', 'text', 'orphan')


def parse_nfo(data):
    """('ok', [elements]) | ('url', None) | ('empty', None) | ('encoding', None) | ('text', None) | ('broken', msg)"""
    if not data.strip():
        return 'empty', None
    try:
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError:
        return 'encoding', None
    if '<' not in text:
        return ('url', None) if re.search(r'https?://\S+', text) else ('text', None)
    body = re.sub(r'^\s*<\?xml[^>]*\?>', '', text.lstrip())
    try:
        wrapper = ET.fromstring('<nfo-root>%s</nfo-root>' % body)
    except ET.ParseError as exc:
        return 'broken', str(exc)
    return 'ok', list(wrapper)


class _Ctx(object):
    def __init__(self, fs, progress, cancelled):
        self.fs, self.progress, self.cancelled = fs, progress, cancelled
        self.groups = OrderedDict((kind, []) for kind in KINDS)
        self.folders = self.nfos = 0
        self.stopped = False

    def add(self, kind, path, detail=''):
        self.groups[kind].append((path, detail))


def _expected_roots(low):
    if low == 'tvshow.nfo':
        return ('tvshow',)
    if low == 'album.nfo':
        return ('album',)
    if low == 'artist.nfo':
        return ('artist',)
    if low == 'movie.nfo':
        return ('movie',)
    return ('movie', 'episodedetails', 'musicvideo')


def _check_nfo(ctx, path, nfo, names, videos, media_keys, flags):
    low = nfo.lower()
    full = ctx.fs.join(path, nfo)
    ctx.nfos += 1
    data = ctx.fs.read(full, MAX_NFO)
    if data is None:
        return
    if len(data) > MAX_NFO:
        ctx.add('too_big', full)
        return
    status, payload = parse_nfo(bytes(data))
    if status in ('empty', 'encoding', 'text'):
        ctx.add(status, full)
        return
    if status == 'broken':
        ctx.add('broken', full, payload)
        return
    has_video, has_audio, disc_layout, audios, sub_audio, videos_here = flags
    if low in ('movie.nfo', 'tvshow.nfo'):
        orphan = not (videos_here or disc_layout) if low == 'movie.nfo' else not has_video
    elif low == 'album.nfo':
        orphan = not (audios or sub_audio)
    elif low == 'artist.nfo':
        orphan = not has_audio
    else:
        base = low[:-4]
        orphan = not (base in media_keys or any(base.startswith(key + '-') for key in media_keys))
    if orphan:
        ctx.add('orphan', full)
    if status != 'ok':
        return
    roots = payload
    expected = _expected_roots(low)
    wrong = [e.tag for e in roots if e.tag not in expected]
    if wrong:
        ctx.add('root', full, '<%s> in %s' % (wrong[0], nfo))
    if any(e.tag in ('movie', 'tvshow', 'episodedetails', 'musicvideo', 'album')
           and not (e.findtext('title') or '').strip() for e in roots):
        ctx.add('no_title', full)
    episodes = [e for e in roots if e.tag == 'episodedetails']
    if len(episodes) > 1:
        ctx.add('multi_ep', full)
        if any(not (e.findtext('season') or '').strip() or not (e.findtext('episode') or '').strip() for e in episodes):
            ctx.add('multi_ep_num', full)
    if episodes and low not in SPECIAL:
        base = low[:-4]
        for video in videos:
            vbase = os.path.splitext(video)[0].lower()
            if base in (vbase, STACK_RE.sub('', vbase)) or base.startswith(vbase + '-'):
                if not EPISODE_RE.search(vbase):
                    ctx.add('ep_name', full, video)
                break


def _scan_dir(ctx, path, name, is_season):
    if ctx.cancelled and ctx.cancelled():
        ctx.stopped = True
        return False, False
    try:
        dirs, files = ctx.fs.listdir(path)
    except Exception:
        return False, False
    ctx.folders += 1
    if ctx.progress:
        ctx.progress(ctx.folders)
    names = {f.lower() for f in files}
    nfos = [f for f in files if f.lower().endswith('.nfo')]
    videos = [f for f in files if f.lower().endswith(VIDEO_EXT)]
    audios = [f for f in files if f.lower().endswith(AUDIO_EXT)]
    dir_lower = {d.lower() for d in dirs}
    disc_layout = 'video_ts' in dir_lower or 'bdmv' in dir_lower
    season_dirs = [d for d in dirs if SEASON_RE.match(d.strip())]
    is_disc_folder = bool(DISC_RE.match(name.strip()))

    sub_video = sub_audio = False
    disc_dirs = []
    for d in dirs:
        if d.lower() in SKIP_DIRS or d.startswith(SKIP_PREFIX):
            continue
        v, a = _scan_dir(ctx, ctx.fs.join(path, d), d, bool(SEASON_RE.match(d.strip())))
        sub_video |= v
        sub_audio |= a
        if a and DISC_RE.match(d.strip()):
            disc_dirs.append(d)
        if ctx.stopped:
            break
    has_video = bool(videos) or disc_layout or sub_video
    has_audio = bool(audios) or sub_audio

    video_bases = [os.path.splitext(v)[0] for v in videos]
    media_keys = set()
    for base in video_bases:
        media_keys.add(base.lower())
        media_keys.add(STACK_RE.sub('', base.lower()))
    flags = (has_video, has_audio, disc_layout, audios, sub_audio, bool(videos))
    for nfo in nfos:
        _check_nfo(ctx, path, nfo, names, videos, media_keys, flags)
    if 'movie.nfo' in names and any(n.endswith('.nfo') and n not in SPECIAL and n[:-4] in media_keys for n in names):
        ctx.add('dup', ctx.fs.join(path, 'movie.nfo'))

    # missing NFOs (informational)
    nfo_bases = {n[:-4] for n in names if n.endswith('.nfo')}
    is_show_folder = 'tvshow.nfo' in names
    for video, base in zip(videos, video_bases):
        low = base.lower()
        if 'sample' in low or 'trailer' in low:
            continue
        if low in nfo_bases or STACK_RE.sub('', low) in nfo_bases or any(b.startswith(low + '-') for b in nfo_bases):
            continue
        episode = bool(EPISODE_RE.search(low)) or is_show_folder or is_season
        if not episode and 'movie.nfo' in names and len(videos) == 1:
            continue
        ctx.add('missing_ep' if episode else 'missing_movie', ctx.fs.join(path, video))
    if not is_season and not is_show_folder and ((season_dirs and sub_video) or any(EPISODE_RE.search(v) for v in videos)):
        ctx.add('missing_show', path)
    if (audios or disc_dirs) and not is_disc_folder and 'album.nfo' not in names:
        ctx.add('missing_album', path)
    return has_video, has_audio


def scan(fs, roots, progress=None, cancelled=None):
    ctx = _Ctx(fs, progress, cancelled)
    for root in roots:
        if ctx.stopped:
            break
        _scan_dir(ctx, root, os.path.basename(root.rstrip('/\\')) or root, False)
    return {'groups': ctx.groups, 'folders': ctx.folders, 'nfos': ctx.nfos, 'stopped': ctx.stopped}


def render(result, tr):
    labels = {ERR: tr(S.ERROR), WARN: tr(S.SEV_WARN), NOTE: tr(S.SEV_NOTE)}
    counts = {ERR: 0, WARN: 0, NOTE: 0}
    for kind, items in result['groups'].items():
        counts[KINDS[kind][0]] += len(items)
    lines = [tr(S.M_NFO), '=' * 40, tr(S.NFO_SUMMARY, result['folders'], result['nfos']),
             tr(S.DEV_SUMMARY, counts[ERR], counts[WARN], counts[NOTE]), '']
    if not any(result['groups'].values()):
        lines.append(tr(S.NO_FINDINGS))
    for kind, items in result['groups'].items():
        if not items:
            continue
        sev, sid = KINDS[kind]
        lines.append('[%s] %s' % (labels[sev], tr(S.NFO_GROUP, tr(sid), len(items))))
        for path, detail in items[:MAX_PER_GROUP]:
            lines.append('    ' + path + (' - ' + detail if detail else ''))
        if len(items) > MAX_PER_GROUP:
            lines.append('    ' + tr(S.NFO_MORE, len(items) - MAX_PER_GROUP))
        lines.append('')
    return '\n'.join(lines)


def deletable(result):
    seen, items = set(), []
    for kind in DELETABLE:
        for path, _detail in result['groups'][kind]:
            if path not in seen:
                seen.add(path)
                items.append((kind, path))
    return items


def backup_zip(fs, paths, zip_path):
    os.makedirs(os.path.dirname(zip_path), exist_ok=True)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as archive:
        index = []
        for number, path in enumerate(paths, 1):
            data = fs.read(path, MAX_NFO)
            if data is None:
                continue
            safe = re.sub(r'[^A-Za-z0-9._-]+', '_', path)[-120:]
            archive.writestr('%04d_%s' % (number, safe), bytes(data))
            index.append('%04d_%s\t%s' % (number, safe, path))
        archive.writestr('paths.txt', '\n'.join(index))
    return len(index)
