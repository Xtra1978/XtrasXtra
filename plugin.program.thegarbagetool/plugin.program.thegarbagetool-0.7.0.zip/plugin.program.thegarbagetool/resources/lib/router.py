# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import ids as S
from resources.lib import utils
from resources.lib.tools import BY_ID, TOOLS
from resources.lib.utils import L, log

BASE = 'plugin://%s/' % utils.ADDON_ID


def _menu(handle):
    icon = utils.ADDON.getAddonInfo('icon')
    entries = [(tool.ID, tool.TITLE) for tool in TOOLS] + [('settings', S.M_SETTINGS)]
    for tool_id, title_id in entries:
        item = xbmcgui.ListItem(label=L(title_id))
        item.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle, BASE + '?' + urlencode({'tool': tool_id}), item, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def run():
    handle = int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    tool_id = params.get('tool')
    if not tool_id:
        _menu(handle)
        return
    try:
        if tool_id == 'settings':
            utils.ADDON.openSettings()
        elif tool_id in BY_ID:
            log('Start: %s' % tool_id)
            BY_ID[tool_id].run()
    except Exception as exc:  # keep the UI alive, details go to the log
        import traceback
        log('%s failed: %s\n%s' % (tool_id, exc, traceback.format_exc()), xbmc.LOGERROR)
        utils.info('%s: %s' % (L(S.ERROR), exc))
    finally:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
