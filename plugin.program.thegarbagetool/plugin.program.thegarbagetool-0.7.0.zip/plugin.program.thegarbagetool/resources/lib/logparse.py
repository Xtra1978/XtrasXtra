# -*- coding: utf-8 -*-
"""Pure log parsing / analysis / redaction (no Kodi imports, unit-testable)."""
import re

from resources.lib import ids as S

LINE = re.compile(r'^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})(?:\.\d+)?\s+(?:T:\d+\s+)?(\w+)\s+(.*)$')
ERROR_LEVELS = ('error', 'fatal', 'severe')
MAX_CONTINUATION = 200
MAX_GROUPS = 40

CATEGORIES = [('python', S.CAT_PYTHON), ('addon', S.CAT_ADDON), ('pvr', S.CAT_PVR),
              ('playback', S.CAT_PLAYBACK), ('database', S.CAT_DATABASE),
              ('network', S.CAT_NETWORK), ('other', S.CAT_OTHER)]

RULES = [
    ('pvr', re.compile(r'\bpvr\b|tvheadend|\bhts\b|\bepg\b|CPVR', re.I)),
    ('database', re.compile(r'sqlite|database is locked|CDatabase|CVideoDatabase|CMusicDatabase|CTextureDatabase|database.*(corrupt|locked|failed)', re.I)),
    ('addon', re.compile(r'unmet dependenc|missing dependenc|dependency.*(not found|failed|missing)|CAddonMgr|CAddonInstall|CRepository|addon\.xml|failed to (install|parse|load|start).*(addon|script|plugin)|unknown addon|CAddon|Failed to start (Python|script)', re.I)),
    ('playback', re.compile(r'CVideoPlayer|PAPlayer|OpenInputStream|DVDPlayer|CApplication::PlayStack|inputstream|cannot play|can not play', re.I)),
    ('network', re.compile(r'CCurl|curl|http error|ssl|certificate|timed out|timeout|could not resolve|connection (refused|reset|timed)|unable to connect|no route|\bdns\b', re.I)),
]
ADDON_PREFIX = r'(?:plugin|script|service|resource|repository|pvr|skin|metadata|weather|screensaver|context|game|inputstream|audioencoder|audiodecoder|vfs|visualization|webinterface|xbmc)'
RE_BRACKET_ID = re.compile(r'\[(%s\.[A-Za-z0-9_.-]+)\]' % ADDON_PREFIX)
RE_PLUGIN_URL = re.compile(r'plugin://([A-Za-z0-9_.-]+)')
RE_PATH_ID = re.compile(r'addons[/\\]([A-Za-z0-9_.-]+)[/\\]')
RE_FRAME = re.compile(r'File "([^"]+)", line (\d+), in (\S+)')
RE_MODULE = re.compile(r"No module named '?([\w.]+)'?")


# ---------------------------------------------------------------- parsing
def iter_entries(lines):
    """Group raw lines into entries; lines without a timestamp continue the previous entry."""
    cur = None
    extra = 0
    for line in lines:
        match = LINE.match(line)
        if match:
            if cur:
                yield cur
            cur = {'time': match.group(2), 'level': match.group(3).lower(), 'text': match.group(4).rstrip()}
            extra = 0
        elif cur is not None and line.strip() and extra < MAX_CONTINUATION:
            cur['text'] += '\n' + line.rstrip()
            extra += 1
    if cur:
        yield cur


def _first_line(text):
    first = text.split('\n', 1)[0]
    first = re.sub(r'^<[^>]+>:\s*', '', first)
    return first.strip()


def _python_info(text):
    etype = re.search(r"Error Type: <(?:class|type) '([^']+)'>", text)
    contents = re.search(r'Error Contents: (.*)', text)
    lines = [l.strip() for l in text.split('\n') if l.strip() and not l.strip().startswith('-->')]
    if etype:
        message = '%s: %s' % (etype.group(1), contents.group(1).strip() if contents else '')
    else:
        message = lines[-1] if lines else _first_line(text)
    frames = RE_FRAME.findall(text)
    return message.strip(), frames


def _path_short(path):
    match = re.search(r'addons[/\\](.*)', path)
    return match.group(1).replace('\\', '/') if match else path.replace('\\', '/').rsplit('/', 1)[-1]


def _addon_from_frames(frames):
    ids = []
    for path, _line, _func in frames:
        match = RE_PATH_ID.search(path)
        if match:
            ids.append(match.group(1))
    for addon_id in reversed(ids):
        if not addon_id.startswith('script.module.'):
            return addon_id
    return ids[-1] if ids else None


def _addon_from_text(text):
    for regex in (RE_BRACKET_ID, RE_PLUGIN_URL):
        match = regex.search(text)
        if match:
            return match.group(1)
    found = RE_PATH_ID.findall(text)
    return found[-1] if found else None


def _normalize(message):
    message = re.sub(r'0x[0-9a-fA-F]+', '0x#', message)
    message = re.sub(r'\d+', '#', message)
    return re.sub(r'\s+', ' ', message).strip()[:200]


def classify(text):
    if 'PythonToCppException' in text or 'Traceback (most recent call last)' in text:
        return 'python'
    for name, regex in RULES:
        if regex.search(text):
            return name
    return 'other'


# ---------------------------------------------------------------- analysis
def analyse(entries):
    errors = warnings = 0
    groups = {}
    first = last = ''
    for entry in entries:
        level = entry['level']
        first = first or entry['time']
        last = entry['time']
        if level == 'warning':
            warnings += 1
            continue
        if level not in ERROR_LEVELS:
            continue
        errors += 1
        text = entry['text']
        cat = classify(text)
        frames = []
        if cat == 'python':
            message, frames = _python_info(text)
            addon = _addon_from_frames(frames) or _addon_from_text(text)
        else:
            message = _first_line(text)
            addon = _addon_from_text(text)
        key = (cat, addon, _normalize(message))
        group = groups.get(key)
        if group is None:
            group = groups[key] = {'cat': cat, 'addon': addon, 'message': message[:240], 'count': 0,
                                   'last': entry['time'], 'frames': frames, 'text': text}
        group['count'] += 1
        group['last'] = entry['time']
    order = {name: i for i, (name, _sid) in enumerate(CATEGORIES)}
    ranked = sorted(groups.values(), key=lambda g: (order[g['cat']], -g['count']))
    return {'errors': errors, 'warnings': warnings, 'groups': ranked, 'first': first, 'last': last}


def addons_in(groups):
    counts = {}
    for group in groups:
        if group['addon']:
            counts[group['addon']] = counts.get(group['addon'], 0) + group['count']
    return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))


# ---------------------------------------------------------------- redaction
_REDACTIONS = [
    (re.compile(r'(://)[^/\s:@]+:[^@\s/]+@'), r'\1***:***@'),
    (re.compile(r'(?i)([?&;\s](?:token|access_token|api[_-]?key|apikey|key|password|passwd|pwd|secret|auth|authorization|sid|session|sessionid|signature|sig|user|username|login|email)=)[^&\s"\'<>]+'), r'\1***'),
    (re.compile(r'(?i)bearer\s+[A-Za-z0-9._~+/=-]+'), 'Bearer ***'),
    (re.compile(r'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]*'), '***'),
    (re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+'), '***@***'),
    (re.compile(r'\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b'), '**:**:**:**:**:**'),
    (re.compile(r'\b(?!127\.)(?!0\.0\.0\.0\b)(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b'), 'x.x.x.x'),
    (re.compile(r'(?i)([/\\](?:Users|home)[/\\])[^/\\\s]+'), r'\1***'),
    (re.compile(r'(?<=/)[A-Za-z0-9_-]{32,}(?=[/?\s"\']|$)'), '***'),
]


def redact(text):
    for regex, replacement in _REDACTIONS:
        text = regex.sub(replacement, text)
    return text


# ---------------------------------------------------------------- report
def _tail(group):
    lines = [l.strip() for l in group['text'].split('\n') if l.strip() and not l.strip().startswith('-->')]
    lines = [l for l in lines if not l.startswith('- NOTE') and 'PythonToCppException' not in l]
    return lines[-7:]


def render(analysis, groups, tr, header, versions, installed_lines):
    """tr(string_id, *args) -> text. header: dict(created, system, logname, lines)."""
    out = [tr(S.R_TITLE), '=' * 40, tr(S.R_CREATED, header['created']), tr(S.R_SYSTEM, *header['system']),
           tr(S.R_LOGFILE, header['logname'], header['lines']),
           tr(S.R_COUNTS, analysis['errors'], analysis['warnings'])]
    current = None
    for group in groups[:MAX_GROUPS]:
        if group['cat'] != current:
            current = group['cat']
            title = dict(CATEGORIES)[current]
            out += ['', '== %s ==' % tr(title)]
        out.append('')
        out.append('* %s  [%s]' % (group['message'], tr(S.R_TIMES, group['count'], group['last'])))
        if group['addon']:
            out.append('    ' + tr(S.R_ADDON, ('%s %s' % (group['addon'], versions.get(group['addon'], ''))).strip()))
        if group['cat'] == 'python':
            if group['frames']:
                path, line, func = group['frames'][-1]
                out.append('    ' + tr(S.R_FILE, '%s:%s (%s)' % (_path_short(path), line, func)))
            module = RE_MODULE.search(group['message'])
            if module:
                out.append('    ' + tr(S.R_HINT, tr(S.HINT_MODULE, module.group(1))))
            for line in _tail(group):
                out.append(('    ' if line.startswith('File ') else '      ') + line)
        else:
            extra = [l.strip() for l in group['text'].split('\n')[1:3] if l.strip()]
            out += ['    ' + l for l in extra]
    if installed_lines:
        out += ['', '== %s ==' % tr(S.R_INSTALLED)] + installed_lines
    return redact('\n'.join(out))
