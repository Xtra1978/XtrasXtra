# -*- coding: utf-8 -*-
"""Addon linter and strings.po checker (pure python, no Kodi imports)."""
import os
import re
import struct
import xml.etree.ElementTree as ET

from resources.lib import ids as S

ERR, WARN, NOTE = 'error', 'warn', 'note'
PY_POINTS = ('xbmc.python.pluginsource', 'xbmc.service', 'xbmc.python.script', 'xbmc.python.module',
             'xbmc.python.lyrics', 'xbmc.python.library', 'xbmc.python.weather', 'xbmc.ui.screensaver')
SKIP_DIRS = {'__pycache__', '.git', '.github', '.idea', '.vscode'}
VERSION_RE = re.compile(r'^\d+(\.\d+){0,3}([~+-][\w.+~-]+)?$')
ID_USE_RE = re.compile(r'(?<![<>]=\s)(?<![<>]\s)(?<![<>]=)(?<![<>])(?<![\d.])(30\d{3})(?![\d.])(?!\s*(?:[<>]|-\s*\d))')
PLACEHOLDER_RE = re.compile(r'%\(\w+\)[sdif]|%[sdif]|\{\w*\}')
MAX_LINES = 50


def _walk(path):
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in files:
            yield os.path.join(root, name)


def _png_size(path):
    try:
        with open(path, 'rb') as handle:
            head = handle.read(24)
    except OSError:
        return None
    if head[:8] == b'\x89PNG\r\n\x1a\n':
        return struct.unpack('>II', head[16:24])
    return None


# ---------------------------------------------------------------- addon.xml
def check_addon(path, installed, tr):
    results = []

    def add(sev, sid, *args):
        results.append((sev, tr(sid, *args)))

    xml_path = os.path.join(path, 'addon.xml')
    if not os.path.isfile(xml_path):
        add(ERR, S.XML_MISSING)
        return results
    try:
        root = ET.parse(xml_path).getroot()
    except ET.ParseError as exc:
        add(ERR, S.XML_PARSE, exc)
        return results
    if root.tag != 'addon':
        add(ERR, S.XML_PARSE, '<%s>' % root.tag)
        return results

    for attr in ('id', 'name', 'version', 'provider-name'):
        if not root.get(attr):
            add(ERR, S.XML_ATTR, attr)
    addon_id = root.get('id', '')
    folder = os.path.basename(path.rstrip('/\\'))
    if addon_id and addon_id != folder:
        add(ERR, S.XML_ID_FOLDER, addon_id, folder)
    if addon_id and not re.match(r'^[a-z0-9._-]+$', addon_id):
        add(WARN, S.XML_ID_FORMAT, addon_id)
    version = root.get('version', '')
    if version and not VERSION_RE.match(version):
        add(WARN, S.XML_VERSION, version)

    extensions = root.findall('extension')
    imports = root.findall('./requires/import')
    has_python = any(e.get('point', '').startswith('xbmc.python') or e.get('point') == 'xbmc.service'
                     for e in extensions)
    python_import = [i for i in imports if i.get('addon') == 'xbmc.python']
    if has_python and not python_import:
        add(WARN, S.XML_NO_PYTHON)
    for imp in python_import:
        major = re.findall(r'\d+', imp.get('version', '') or '0')
        if major and int(major[0]) < 3:
            add(WARN, S.XML_OLD_PYTHON, imp.get('version'))
    for imp in imports:
        dep = imp.get('addon', '')
        if dep and not dep.startswith(('xbmc.', 'kodi.')) and dep != addon_id \
                and imp.get('optional') != 'true' and dep not in installed:
            add(WARN, S.XML_DEP_MISSING, dep)

    for ext in extensions:
        point = ext.get('point', '')
        library = ext.get('library')
        if library and point in PY_POINTS and not os.path.exists(os.path.join(path, library)):
            add(ERR, S.XML_LIB_MISSING, library)
        if point == 'xbmc.python.pluginsource' and ext.find('provides') is None:
            add(WARN, S.XML_NO_PROVIDES)

    meta = next((e for e in extensions if e.get('point') in ('xbmc.addon.metadata', 'kodi.addon.metadata')), None)
    icon_rel = 'icon.png'
    if meta is None:
        add(ERR, S.XML_NO_META, 'xbmc.addon.metadata')
    else:
        for tag in ('summary', 'description', 'license'):
            if meta.find(tag) is None:
                add(WARN, S.XML_NO_META, tag)
        assets = meta.find('assets')
        if assets is not None:
            for node in assets:
                rel = (node.text or '').strip()
                if rel and not os.path.isfile(os.path.join(path, rel)):
                    add(WARN, S.XML_ASSET_MISSING, rel)
            icon = assets.find('icon')
            if icon is not None and (icon.text or '').strip():
                icon_rel = icon.text.strip()
    icon_path = os.path.join(path, icon_rel)
    if not os.path.isfile(icon_path):
        add(WARN, S.XML_NO_ICON)
    else:
        size = _png_size(icon_path)
        if size and size != (256, 256):
            add(WARN if size[0] != size[1] else NOTE, S.XML_ICON_SIZE, size[0], size[1])

    settings = os.path.join(path, 'resources', 'settings.xml')
    if os.path.isfile(settings):
        try:
            ET.parse(settings)
        except ET.ParseError as exc:
            add(ERR, S.SETTINGS_PARSE, exc)

    junk = 0
    for root_dir, dirs, files in os.walk(path):
        junk += sum(1 for d in dirs if d in ('__pycache__', '.git'))
        junk += sum(1 for f in files if f.endswith(('.pyc', '.pyo')) or f in ('.DS_Store', 'Thumbs.db'))
        dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git')]
    for full in _walk(path):
        if full.endswith('.py'):
            try:
                with open(full, 'rb') as handle:
                    compile(handle.read(), full, 'exec')
            except SyntaxError as exc:
                add(ERR, S.PY_SYNTAX, os.path.relpath(full, path).replace('\\', '/'), exc.lineno, exc.msg)
            except (OSError, ValueError):
                pass
    if junk:
        add(NOTE, S.DEV_JUNK, junk)
    return results


# ---------------------------------------------------------------- strings.po
def _unquote(text):
    text = text.strip()
    if text.startswith('"') and text.endswith('"') and len(text) >= 2:
        text = text[1:-1]
    return text.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')


def parse_po(file_path):
    """Returns [(id, msgid, msgstr)] for entries with a '#<id>' msgctxt."""
    entries, cur, field = [], {}, None

    def flush():
        match = re.match(r'#(\d+)$', cur.get('ctx', ''))
        if match:
            entries.append((int(match.group(1)), cur.get('id', ''), cur.get('str', '')))

    with open(file_path, 'r', encoding='utf-8', errors='replace') as handle:
        for line in handle:
            line = line.strip()
            if line.startswith('msgctxt'):
                flush()
                cur, field = {'ctx': _unquote(line[7:])}, 'ctx'
            elif line.startswith('msgid_plural'):
                field = None
            elif line.startswith('msgid'):
                cur['id'], field = _unquote(line[5:]), 'id'
            elif line.startswith('msgstr'):
                cur['str'], field = _unquote(line[6:]), 'str'
            elif line.startswith('"') and field:
                cur[field] = cur.get(field, '') + _unquote(line)
    flush()
    return entries


def _code_ids(path):
    used = set()
    for full in _walk(path):
        if full.endswith(('.py', '.xml')):
            try:
                with open(full, 'r', encoding='utf-8', errors='replace') as handle:
                    text = handle.read()
                if full.endswith('.py'):
                    text = re.sub(r'(?m)#.*$', '', text)
                used.update(int(m) for m in ID_USE_RE.findall(text))
            except OSError:
                pass
    return used


def check_po(path, tr):
    results = []

    def add(sev, sid, *args):
        results.append((sev, tr(sid, *args)))

    base = os.path.join(path, 'resources', 'language')
    languages = {}
    if os.path.isdir(base):
        for name in sorted(os.listdir(base)):
            po = os.path.join(base, name, 'strings.po')
            if os.path.isfile(po):
                languages[name.replace('resource.language.', '')] = parse_po(po)
    if not languages:
        add(WARN, S.PO_MISSING)
        return results

    reference = next((l for l in languages if l.startswith('en')), next(iter(languages)))
    ref_entries = {i: (mid, mstr) for i, mid, mstr in languages[reference]}
    for lang, entries in languages.items():
        seen = set()
        for sid, msgid, msgstr in entries:
            if sid in seen:
                add(ERR, S.PO_DUP, lang, sid)
            seen.add(sid)
            if not 30000 <= sid <= 30999:
                add(WARN, S.PO_RANGE, lang, sid)
            if lang.startswith('en'):
                continue
            if not msgstr.strip():
                add(WARN, S.PO_EMPTY, lang, sid)
            elif msgstr == msgid:
                add(WARN, S.PO_SAME, lang, sid)
            if msgstr.strip() and sorted(PLACEHOLDER_RE.findall(msgid)) != sorted(PLACEHOLDER_RE.findall(msgstr)):
                add(WARN, S.PO_PLACEHOLDER, lang, sid)
        if lang != reference:
            for sid in sorted(set(ref_entries) - seen):
                add(WARN, S.PO_MISSING_IN, lang, sid, reference)
            for sid in sorted(seen - set(ref_entries)):
                add(WARN, S.PO_MISSING_IN, reference, sid, lang)

    used = _code_ids(path)
    defined = set(ref_entries)
    for sid in sorted(used - defined):
        add(ERR, S.PO_UNDEFINED, sid, reference)
    unused = sorted(defined - used)
    if unused:
        add(NOTE, S.PO_UNUSED, len(unused), ', '.join(str(i) for i in unused[:8]))
    return results


# ---------------------------------------------------------------- report
def render(title, results, tr):
    labels = {ERR: tr(S.ERROR), WARN: tr(S.SEV_WARN), NOTE: tr(S.SEV_NOTE)}
    counts = {sev: sum(1 for r in results if r[0] == sev) for sev in (ERR, WARN, NOTE)}
    out = [title, '=' * 40, tr(S.DEV_SUMMARY, counts[ERR], counts[WARN], counts[NOTE]), '']
    if not results:
        out.append(tr(S.NO_FINDINGS))
    order = {ERR: 0, WARN: 1, NOTE: 2}
    for sev, text in sorted(results, key=lambda r: order[r[0]])[:MAX_LINES]:
        out.append('[%s] %s' % (labels[sev], text))
    return '\n'.join(out)
