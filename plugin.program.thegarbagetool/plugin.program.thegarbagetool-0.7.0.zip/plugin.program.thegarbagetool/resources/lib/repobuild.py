# -*- coding: utf-8 -*-
"""Builds repository files: addon ZIPs, addons.xml and addons.xml.md5 (pure python)."""
import hashlib
import os
import re
import shutil
import xml.etree.ElementTree as ET
import zipfile

EXCLUDE_DIRS = {'__pycache__', '.git', '.github', '.idea', '.vscode'}
EXCLUDE_FILES = {'.DS_Store', 'Thumbs.db', '.gitignore'}
EXCLUDE_EXT = ('.pyc', '.pyo')
STANDARD_FILES = ('addon.xml', 'icon.png', 'fanart.jpg', 'changelog.txt')


def read_addon(addon_dir):
    root = ET.parse(os.path.join(addon_dir, 'addon.xml')).getroot()
    return root.get('id'), root.get('version'), root


def _asset_paths(root):
    paths = []
    for node in root.iter('assets'):
        paths += [(c.text or '').strip() for c in node if (c.text or '').strip()]
    return paths


def build_zip(addon_dir, out_dir):
    addon_id, version, root = read_addon(addon_dir)
    if not addon_id or not version:
        raise ValueError('addon.xml: id/version missing')
    target = os.path.join(out_dir, addon_id)
    os.makedirs(target, exist_ok=True)
    zip_path = os.path.join(target, '%s-%s.zip' % (addon_id, version))
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for current, dirs, files in os.walk(addon_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for name in sorted(files):
                if name in EXCLUDE_FILES or name.endswith(EXCLUDE_EXT):
                    continue
                full = os.path.join(current, name)
                rel = os.path.relpath(full, addon_dir).replace(os.sep, '/')
                archive.write(full, '%s/%s' % (addon_id, rel))
    for rel in set(STANDARD_FILES) | set(_asset_paths(root)):
        source = os.path.join(addon_dir, rel)
        if os.path.isfile(source):
            destination = os.path.join(target, rel)
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            shutil.copy2(source, destination)
    return zip_path


def update_index(out_dir):
    parts = []
    for name in sorted(os.listdir(out_dir)):
        xml_path = os.path.join(out_dir, name, 'addon.xml')
        if os.path.isfile(xml_path):
            with open(xml_path, 'r', encoding='utf-8') as handle:
                text = re.sub(r'^\s*<\?xml[^>]*\?>\s*', '', handle.read())
            parts.append(text.strip())
    data = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<addons>\n%s\n</addons>\n' % '\n'.join(parts)
    with open(os.path.join(out_dir, 'addons.xml'), 'w', encoding='utf-8', newline='\n') as handle:
        handle.write(data)
    digest = hashlib.md5(data.encode('utf-8')).hexdigest()
    with open(os.path.join(out_dir, 'addons.xml.md5'), 'w', encoding='utf-8', newline='') as handle:
        handle.write(digest)
    return digest
