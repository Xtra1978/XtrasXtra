# -*- coding: utf-8 -*-
"""Shared addon helpers: path checks, dependency maps, disable/uninstall, repo checks."""
import glob
import os
import shutil
import sqlite3
import xml.etree.ElementTree as ET

import xbmc

from resources.lib import utils

PROTECTED = {utils.ADDON_ID, 'repository.xbmc.org'}
MODULE_TYPE = 'xbmc.python.module'
REPO_TYPE = 'xbmc.addon.repository'


def home():
    return os.path.normpath(utils.real('special://home/addons'))


def addon_path(addon):
    return os.path.normpath(utils.real(addon.get('path') or ''))


def is_user(addon):
    return addon_path(addon).startswith(home() + os.sep) and addon.get('addonid') not in PROTECTED


def is_broken(addon):
    value = addon.get('broken')
    return value is True or (isinstance(value, str) and value.lower() not in ('', 'false'))


def label(addon):
    return addon.get('name') or addon.get('addonid', '')


def required_by(addons, exclude=()):
    """dependency id -> set of addon ids that list it (optional ones included)."""
    result = {}
    for addon in addons:
        if addon['addonid'] in exclude:
            continue
        for dep in addon.get('dependencies') or []:
            result.setdefault(dep.get('addonid'), set()).add(addon['addonid'])
    return result


def orphan_modules(addons, exclude=()):
    required = required_by(addons, exclude)
    return [a for a in addons if a['addonid'] not in exclude and a.get('type') == MODULE_TYPE
            and is_user(a) and a['addonid'] not in required]


def cascade_orphans(addons, removed_ids):
    """Libraries that become unneeded once removed_ids are gone (repeated until stable)."""
    removed = set(removed_ids)
    extra = []
    while True:
        new = orphan_modules(addons, exclude=removed)
        if not new:
            return extra
        for addon in new:
            removed.add(addon['addonid'])
            extra.append(addon)


def set_enabled(addon_id, enabled):
    utils.rpc('Addons.SetAddonEnabled', {'addonid': addon_id, 'enabled': enabled})


def data_dir(addon_id):
    return os.path.join(utils.real('special://profile/addon_data/'), addon_id)


def drop_db_entries(addon_ids):
    for db in glob.glob(os.path.join(utils.folder('special://database/'), 'Addons*.db')):
        con = None
        try:
            con = sqlite3.connect(db, timeout=5)
            con.executemany('DELETE FROM installed WHERE addonID=?', [(i,) for i in addon_ids])
            con.commit()
        except sqlite3.Error as exc:
            utils.log('Addons DB error: %s' % exc, xbmc.LOGWARNING)
        finally:
            if con:
                con.close()


def uninstall(addon, remove_data=False):
    if not is_user(addon):
        return False
    addon_id = addon['addonid']
    set_enabled(addon_id, False)
    try:
        shutil.rmtree(addon_path(addon))
    except OSError as exc:
        utils.log('Uninstall failed: %s (%s)' % (addon_id, exc), xbmc.LOGWARNING)
        return False
    drop_db_entries([addon_id])
    if remove_data:
        shutil.rmtree(data_dir(addon_id), ignore_errors=True)
    utils.log('Uninstalled: %s%s' % (addon_id, ' (+data)' if remove_data else ''))
    return True


def finish():
    xbmc.executebuiltin('UpdateLocalAddons')


def repo_urls(addon):
    try:
        root = ET.parse(os.path.join(addon_path(addon), 'addon.xml')).getroot()
    except Exception:
        return []
    urls = []
    for node in root.iter('dir'):
        info = node.find('info')
        if info is not None and info.text and info.text.strip().startswith('http'):
            urls.append(info.text.strip())
    return urls


def check_repo(addon, timeout):
    """(addon, True/False/None) - None when the repository lists no URL."""
    urls = repo_urls(addon)
    if not urls:
        return addon, None
    return addon, any(utils.http_ok(url, timeout) for url in urls)
