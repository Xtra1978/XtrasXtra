# -*- coding: utf-8 -*-
"""Backup / restore of userdata files (pure python, no Kodi imports).

Databases and guisettings.xml are deliberately not part of it: Kodi keeps them open or
rewrites them on exit, so replacing them while Kodi runs is unsafe or has no effect.
"""
import json
import os
import shutil
import time
import zipfile

COMPONENTS = {
    'favourites': ('favourites.xml',),
    'sources': ('sources.xml',),
    'playlists': ('playlists',),
    'advanced': ('advancedsettings.xml', 'RssFeeds.xml', 'keymaps'),
    'addon_data': ('addon_data',),
}
MANIFEST = 'manifest.json'
PREFIX = 'userdata/'
TOOL = 'thegarbagetool'


def _excluded(rel, exclude):
    return any(rel == e or rel.startswith(e + '/') for e in exclude)


def component_of(rel):
    for name, prefixes in COMPONENTS.items():
        for prefix in prefixes:
            if rel == prefix or rel.startswith(prefix + '/'):
                return name
    return None


def collect(profile, components, exclude=()):
    """[(absolute path, relative path)] of everything that belongs to the components."""
    files = []
    for component in components:
        for rel in COMPONENTS[component]:
            full = os.path.join(profile, rel)
            if os.path.isfile(full):
                files.append((full, rel))
            elif os.path.isdir(full):
                for root, dirs, names in os.walk(full):
                    rel_root = os.path.relpath(root, profile).replace(os.sep, '/')
                    dirs[:] = [d for d in dirs if not _excluded('%s/%s' % (rel_root, d), exclude)]
                    for name in names:
                        files.append((os.path.join(root, name), '%s/%s' % (rel_root, name)))
    return files


def create(out_zip, components, files, meta=None, addons_text='', progress=None):
    os.makedirs(os.path.dirname(out_zip), exist_ok=True)
    stored = 0
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as archive:
        info = dict(meta or {}, tool=TOOL, components=list(components), created=time.strftime('%Y-%m-%d %H:%M:%S'))
        archive.writestr(MANIFEST, json.dumps(info, indent=1))
        if addons_text:
            archive.writestr('addons.txt', addons_text)
        for index, (full, rel) in enumerate(files, 1):
            try:
                archive.write(full, PREFIX + rel)
                stored += 1
            except OSError:
                pass
            if progress:
                progress(index, len(files))
    return stored


def read_components(zip_path):
    """{component: file count} or None when this is not one of our backups."""
    try:
        with zipfile.ZipFile(zip_path) as archive:
            manifest = json.loads(archive.read(MANIFEST).decode('utf-8'))
            if manifest.get('tool') != TOOL:
                return None
            counts = {}
            for name in archive.namelist():
                if name.startswith(PREFIX) and not name.endswith('/'):
                    component = component_of(name[len(PREFIX):])
                    if component:
                        counts[component] = counts.get(component, 0) + 1
            return counts
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return None


def restore(zip_path, profile, components, progress=None):
    base = os.path.realpath(profile)
    count = 0
    with zipfile.ZipFile(zip_path) as archive:
        members = [i for i in archive.infolist()
                   if i.filename.startswith(PREFIX) and not i.filename.endswith('/')
                   and component_of(i.filename[len(PREFIX):]) in components]
        for index, member in enumerate(members, 1):
            rel = member.filename[len(PREFIX):]
            dest = os.path.realpath(os.path.join(profile, *rel.split('/')))
            if not dest.startswith(base + os.sep):  # zip-slip protection
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            tmp = dest + '.restore-tmp'
            with archive.open(member) as src, open(tmp, 'wb') as dst:
                shutil.copyfileobj(src, dst)
            os.replace(tmp, dest)
            count += 1
            if progress:
                progress(index, len(members))
    return count
