# -*- coding: utf-8 -*-
from resources.lib import router

if __name__ == '__main__':
    router.run()
