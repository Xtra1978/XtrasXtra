#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WikiFlix Kodi Addon
===================
Öffentliche Domain Filme von wikiflix.toolforge.org direkt in Kodi.
"""

import sys
import xbmcaddon
from resources.lib import router

ADDON   = xbmcaddon.Addon()
HANDLE  = int(sys.argv[1])
BASE_URL = sys.argv[0]
ARGS    = sys.argv[2]

if __name__ == '__main__':
    router.dispatch(BASE_URL, HANDLE, ARGS, ADDON)
