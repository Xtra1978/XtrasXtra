# 🎬 WikiFlix – Kodi Addon

**plugin.video.wikiflix** · Version 1.0.0

Über 4800 gemeinfreie Filme direkt in Kodi – kostenlos, werbefrei, keine Anmeldung.

## Installation
1. ZIP herunterladen
2. Kodi → Addons → Aus ZIP-Datei installieren
3. Unter **Video-Addons** aktivieren

## Funktionen
- 📅 Filme nach Jahr / Jahrzehnt (1910er–1970er)
- 🎬 Filme nach Genre (Drama, Komödie, Horror, Western, Sci-Fi …)
- 🌍 Filme nach Land (USA, Deutschland, Frankreich, Japan …)
- 👤 Regisseure & Schauspieler (Chaplin, Keaton, Lang, Murnau …)
- 🏛️ US National Film Registry
- 👩‍🎬 Regisseurinnen
- ⭐ Hoch bewertete Filme
- 🔍 Volltextsuche
- ▶️ Quellen: Wikimedia Commons, Internet Archive, YouTube

## Quellen
- https://wikiflix.toolforge.org
- https://wikimedia.org
- https://archive.org

## Lizenz: MIT
