#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API-Modul: WikiFlix Kodi Addon – Internet Archive als primäre Quelle.

Strategie (Reihenfolge nach Zuverlässigkeit):
  1. Internet Archive Advanced Search API  → schnell, kein Rate-Limit
  2. Wikimedia Commons API                 → Filme auf Commons
  3. Wikidata SPARQL                       → nur als letzter Fallback,
                                             mit Retry-Logik bei HTTP 429

Das Internet Archive hostet Tausende gemeinfreier Filme mit direkten
MP4-Streams und hat eine sehr robuste, öffentliche Such-API.
"""

import json
import time
import xbmc
from urllib.request import urlopen, Request
from urllib.parse   import urlencode, quote
from urllib.error   import HTTPError, URLError

UA      = 'KodiWikiFlixAddon/1.1 (kodi.tv; public domain films)'
TIMEOUT = 20

# Internet Archive Advanced Search
IA_SEARCH = 'https://archive.org/advancedsearch.php'
# Internet Archive Metadata
IA_META   = 'https://archive.org/metadata/{id}'
# Wikimedia Commons API
COMMONS   = 'https://commons.wikimedia.org/w/api.php'
# Wikidata SPARQL (Fallback)
SPARQL    = 'https://query.wikidata.org/sparql'


def _get_json(url, retries=2):
    """HTTP-GET, gibt geparste JSON-Daten zurück oder None."""
    for attempt in range(retries):
        try:
            xbmc.log(f'[WikiFlix] GET {url[:120]}', xbmc.LOGDEBUG)
            req  = Request(url, headers={
                'User-Agent': UA,
                'Accept': 'application/json',
            })
            resp = urlopen(req, timeout=TIMEOUT)
            return json.loads(resp.read().decode('utf-8'))
        except HTTPError as e:
            if e.code == 429 and attempt < retries - 1:
                xbmc.log(f'[WikiFlix] 429 – warte 3s...', xbmc.LOGWARNING)
                time.sleep(3)
            else:
                xbmc.log(f'[WikiFlix] HTTP {e.code}: {e.reason}', xbmc.LOGWARNING)
                return None
        except Exception as e:
            xbmc.log(f'[WikiFlix] Fehler: {e}', xbmc.LOGWARNING)
            return None
    return None


# -----------------------------------------------------------------------
#  INTERNET ARCHIVE – Primärquelle
# -----------------------------------------------------------------------

def _ia_search(extra_query='', rows=40, page=1, sort='downloads desc'):
    """
    Sucht im Internet Archive nach gemeinfreien Stummfilmen und Spielfilmen.
    Gibt eine Liste von Film-Dicts zurück.
    """
    base_q = ('mediatype:movies AND licenseurl:*creativecommons* '
              'OR (mediatype:movies AND subject:"public domain")'
              'OR (mediatype:movies AND subject:"feature film" AND date:[1880 TO 1970])')

    if extra_query:
        q = f'({extra_query}) AND mediatype:movies'
    else:
        q = ('mediatype:movies AND (subject:"public domain" '
             'OR subject:"silent film" OR subject:"feature film") '
             'AND date:[1880 TO 1970]')

    params = {
        'q':      q,
        'fl[]':   ['identifier','title','creator','date','description',
                   'subject','downloads','avg_rating','num_reviews',
                   'thumbnail'],
        'rows':   rows,
        'page':   page,
        'output': 'json',
        'sort[]': sort,
    }

    url  = f'{IA_SEARCH}?{urlencode(params, doseq=True)}'
    data = _get_json(url)
    if not data:
        return []

    docs = data.get('response', {}).get('docs', [])
    return [_ia_doc_to_movie(d) for d in docs if d.get('identifier')]


def _ia_doc_to_movie(doc):
    """Wandelt ein Internet Archive Suchergebnis in ein Film-Dict um."""
    ia_id   = doc.get('identifier', '')
    title   = doc.get('title', ia_id)
    creator = doc.get('creator', '')
    date    = doc.get('date', '')
    desc    = doc.get('description', '')
    year    = date[:4] if date and len(date) >= 4 else ''

    # Thumbnail
    thumb = f'https://archive.org/services/img/{ia_id}'

    # Beschreibung bereinigen
    if isinstance(desc, list):
        desc = ' '.join(desc)
    desc = str(desc)[:300]

    return {
        'q':           ia_id,
        'label':       title if isinstance(title, str) else str(title),
        'year':        year,
        'thumb':       thumb,
        'description': desc,
        'source':      'ia',
        'ia_id':       ia_id,
        'creator':     creator if isinstance(creator, str) else
                       (creator[0] if isinstance(creator, list) and creator else ''),
    }


def get_recent_movies(limit=30):
    """Zuletzt hinzugefügte gemeinfreie Filme vom Internet Archive."""
    return _ia_search(
        extra_query='mediatype:movies AND subject:"public domain" AND date:[1880 TO 1970]',
        rows=limit,
        sort='publicdate desc'
    )


def get_highly_rated_movies(limit=30):
    """Meistgeladene / bestbewertete gemeinfreie Filme."""
    return _ia_search(
        extra_query='mediatype:movies AND subject:"public domain" AND date:[1880 TO 1970]',
        rows=limit,
        sort='downloads desc'
    )


def get_movies_by_decade(decade, limit=40):
    """Filme eines Jahrzehnts."""
    year_from = decade
    year_to   = decade + 9
    return _ia_search(
        extra_query=(f'mediatype:movies AND date:[{year_from} TO {year_to}] '
                     f'AND (subject:"public domain" OR subject:"silent film" '
                     f'OR subject:"feature film")'),
        rows=limit,
        sort='date asc'
    )


def get_movies_by_genre(genre_label, limit=40):
    """Filme nach Genre (Freitext-Suche im IA-Subjektfeld)."""
    return _ia_search(
        extra_query=(f'mediatype:movies AND subject:"{genre_label}" '
                     f'AND date:[1880 TO 1970]'),
        rows=limit,
        sort='downloads desc'
    )


def get_movies_by_country(country_label, limit=40):
    """Filme nach Land (Freitext-Suche)."""
    return _ia_search(
        extra_query=(f'mediatype:movies AND subject:"{country_label}" '
                     f'AND date:[1880 TO 1970]'),
        rows=limit,
        sort='downloads desc'
    )


def get_movies_by_person(person_name, limit=30):
    """Filme mit einer bestimmten Person als Regisseur/Schauspieler."""
    return _ia_search(
        extra_query=(f'mediatype:movies AND (creator:"{person_name}" '
                     f'OR subject:"{person_name}")'),
        rows=limit,
        sort='date asc'
    )


def get_nfr_movies(limit=40):
    """US National Film Registry Filme."""
    return _ia_search(
        extra_query='mediatype:movies AND subject:"National Film Registry"',
        rows=limit,
        sort='downloads desc'
    )


def get_silent_films(limit=40):
    """Stummfilme."""
    return _ia_search(
        extra_query='mediatype:movies AND subject:"silent film"',
        rows=limit,
        sort='date asc'
    )


def get_chaplin_films(limit=20):
    """Charlie Chaplin Filme."""
    return _ia_search(
        extra_query='mediatype:movies AND creator:"Chaplin"',
        rows=limit,
        sort='date asc'
    )


def search_movies(query_text, limit=30):
    """Volltextsuche im Internet Archive."""
    safe = query_text.replace('"', '').strip()
    return _ia_search(
        extra_query=f'mediatype:movies AND (title:"{safe}" OR subject:"{safe}")',
        rows=limit,
        sort='downloads desc'
    )


def get_movie_details(ia_id):
    """
    Lädt Details eines Films vom Internet Archive.
    Gibt Stream-URLs, Beschreibung, Besetzung etc. zurück.
    """
    data = _get_json(IA_META.format(id=ia_id))
    if not data:
        return {}

    meta   = data.get('metadata', {})
    files  = data.get('files', [])

    title  = _first(meta.get('title', ia_id))
    date   = _first(meta.get('date', ''))
    year   = date[:4] if date and len(date) >= 4 else ''
    desc   = _first(meta.get('description', ''))
    creator= _first(meta.get('creator', ''))
    thumb  = f'https://archive.org/services/img/{ia_id}'

    # Video-Dateien filtern
    videos = []
    for fmt in ['mp4', 'ogv', 'webm', 'mpeg4', 'h.264']:
        for f in files:
            fname = f.get('name', '')
            fmtl  = f.get('format', '').lower()
            if (fname.lower().endswith('.' + fmt.split('.')[0]) or fmt in fmtl) \
               and 'thumb' not in fname.lower() \
               and 'sample' not in fname.lower():
                stream_url = f'https://archive.org/download/{ia_id}/{quote(fname)}'
                try:
                    size_mb = int(f.get('size', 0)) // 1024 // 1024
                    size_str = f'{size_mb} MB' if size_mb else ''
                except (ValueError, TypeError):
                    size_str = ''
                videos.append({
                    'src':   'ia',
                    'id':    stream_url,
                    'label': f'{fname}{" – " + size_str if size_str else ""}',
                })
                break  # nur erste Datei pro Format
        if videos:
            break  # erste gefundene Formatgruppe reicht

    return {
        'q':           ia_id,
        'label':       str(title),
        'year':        year,
        'thumb':       thumb,
        'description': str(desc)[:500],
        'creator':     str(creator),
        'videos':      videos,
        'directors':   [{'label': creator, 'q': ''}] if creator else [],
        'cast':        [],
    }


def resolve_ia_video_url(url):
    """Gibt die URL direkt zurück (bereits vollständige URL vom IA)."""
    return url


def resolve_commons_video_url(filename):
    """Löst Commons-Dateinamen in Stream-URL auf."""
    if not filename:
        return None
    fn = filename.replace(' ', '_')
    if not fn.startswith('File:'):
        fn = 'File:' + fn
    url = (f'{COMMONS}?action=query&titles={quote(fn)}'
           f'&prop=videoinfo&viprop=url&format=json')
    data = _get_json(url)
    try:
        pages = data['query']['pages']
        for _, page in pages.items():
            u = page.get('videoinfo', [{}])[0].get('url', '')
            if u:
                return u
    except Exception:
        pass
    return f'https://commons.wikimedia.org/wiki/Special:FilePath/{quote(fn.replace("File:",""))}'


def get_commons_thumbnail(filename, width=300):
    if not filename:
        return ''
    fn = filename.replace(' ', '_').replace('File:', '')
    return f'https://commons.wikimedia.org/wiki/Special:FilePath/{quote(fn)}?width={width}'


def _first(val):
    """Gibt erstes Element einer Liste oder den Wert selbst zurück."""
    if isinstance(val, list):
        return val[0] if val else ''
    return val or ''
