#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI-Modul: Kodi-Menüs für WikiFlix (Internet Archive basiert)."""

from urllib.parse import urlencode
import xbmcgui
import xbmcplugin
from resources.lib import api

ADDON_ICON   = 'special://home/addons/plugin.video.wikiflix/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.video.wikiflix/resources/media/fanart.jpg'

# Genres als Internet Archive subject-Begriffe
GENRES = [
    ('😂 Komödie',         'comedy'),
    ('🎭 Drama',           'drama'),
    ('👻 Horror',          'horror'),
    ('🚀 Science Fiction', 'science fiction'),
    ('🤠 Western',         'western'),
    ('🔍 Krimi',           'crime'),
    ('🌹 Romantik',        'romance'),
    ('🎨 Animation',       'animation'),
    ('📚 Dokumentarfilm',  'documentary'),
    ('🎬 Stummfilm',       'silent film'),
    ('🥊 Abenteuer',       'adventure'),
    ('🎵 Musical',         'musical'),
]

# Länder als IA-Suchbegriffe
COUNTRIES = [
    ('🇺🇸 USA',            'United States'),
    ('🇩🇪 Deutschland',    'Germany'),
    ('🇫🇷 Frankreich',     'France'),
    ('🇬🇧 Großbritannien', 'Great Britain'),
    ('🇮🇹 Italien',        'Italy'),
    ('🇷🇺 Sowjetunion',    'Soviet Union'),
    ('🇯🇵 Japan',          'Japan'),
    ('🇮🇳 Indien',         'India'),
    ('🇸🇪 Schweden',       'Sweden'),
    ('🇦🇹 Österreich',     'Austria'),
    ('🇲🇽 Mexiko',         'Mexico'),
    ('🇦🇺 Australien',     'Australia'),
]

# Jahrzehnte
DECADES = [1900,1910,1920,1930,1940,1950,1960,1970]

# Bekannte Regisseure/Schauspieler: Name → IA-Suchbegriff
PEOPLE = [
    ('Charlie Chaplin',    'Charlie Chaplin'),
    ('Buster Keaton',      'Buster Keaton'),
    ('Harold Lloyd',       'Harold Lloyd'),
    ('Georges Méliès',     'Melies'),
    ('Fritz Lang',         'Fritz Lang'),
    ('F.W. Murnau',        'Murnau'),
    ('D.W. Griffith',      'Griffith'),
    ('Laurel & Hardy',     'Laurel Hardy'),
    ('Greta Garbo',        'Greta Garbo'),
    ('John Ford',          'John Ford'),
    ('Cecil B. DeMille',   'DeMille'),
    ('Lillian Gish',       'Lillian Gish'),
    ('Mary Pickford',      'Mary Pickford'),
    ('Douglas Fairbanks',  'Douglas Fairbanks'),
]


def build_url(base_url, params):
    return '{0}?{1}'.format(base_url, urlencode(params))


def _li(label, thumb='', info=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        'icon':   thumb or ADDON_ICON,
        'thumb':  thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
    })
    if info:
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _end(handle, content='movies'):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def _notify(msg):
    xbmcgui.Dialog().notification('WikiFlix', msg,
                                  xbmcgui.NOTIFICATION_INFO, 4000)


# -----------------------------------------------------------------------
# Hauptmenü
# -----------------------------------------------------------------------

def show_main_menu(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, 'WikiFlix – Public Domain Filme')
    entries = [
        ('⭐  Meistgeladene Filme',          {'mode': 'section', 'section_id': 'highly_ranked'}),
        ('🕐  Zuletzt hinzugefügt',          {'mode': 'section', 'section_id': 'recent'}),
        ('🎬  Stummfilme',                   {'mode': 'section', 'section_id': 'silent'}),
        ('📅  Nach Jahrzehnt',               {'mode': 'section', 'section_id': 'browse_decades'}),
        ('🎭  Nach Genre',                   {'mode': 'section', 'section_id': 'browse_genres'}),
        ('🌍  Nach Land',                    {'mode': 'section', 'section_id': 'browse_countries'}),
        ('👤  Regisseure & Schauspieler',    {'mode': 'section', 'section_id': 'browse_people'}),
        ('🏛️  US National Film Registry',   {'mode': 'section', 'section_id': 'nfr'}),
        ('🔍  Suchen',                       {'mode': 'search'}),
    ]
    for label, params in entries:
        url = build_url(base_url, params)
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
                                    listitem=_li(label), isFolder=True)
    _end(handle, 'files')


# -----------------------------------------------------------------------
# Sektionen
# -----------------------------------------------------------------------

def show_section(base_url, handle, addon, section_id):
    # Unter-Kategorien
    if section_id == 'browse_decades':
        _show_list(base_url, handle, 'WikiFlix – Jahrzehnte',
                   [(f'📅  {d}er Jahre', {'mode': 'section', 'section_id': f'decade_{d}'})
                    for d in DECADES])
        return
    if section_id == 'browse_genres':
        _show_list(base_url, handle, 'WikiFlix – Genres',
                   [(label, {'mode': 'section', 'section_id': f'genre_{term}'})
                    for label, term in GENRES])
        return
    if section_id == 'browse_countries':
        _show_list(base_url, handle, 'WikiFlix – Länder',
                   [(label, {'mode': 'section', 'section_id': f'country_{term}'})
                    for label, term in COUNTRIES])
        return
    if section_id == 'browse_people':
        _show_list(base_url, handle, 'WikiFlix – Personen',
                   [(f'🎬 {name}', {'mode': 'person', 'person_id': term, 'person_name': name})
                    for name, term in PEOPLE])
        return

    # Filme laden
    xbmcplugin.setPluginCategory(handle, f'WikiFlix')
    movies = []

    if section_id == 'recent':
        movies = api.get_recent_movies(30)
    elif section_id == 'highly_ranked':
        movies = api.get_highly_rated_movies(30)
    elif section_id == 'nfr':
        movies = api.get_nfr_movies(40)
    elif section_id == 'silent':
        movies = api.get_silent_films(40)
    elif section_id.startswith('decade_'):
        decade = int(section_id.split('_')[1])
        movies = api.get_movies_by_decade(decade, 40)
    elif section_id.startswith('genre_'):
        term   = section_id.split('_', 1)[1]
        movies = api.get_movies_by_genre(term, 40)
    elif section_id.startswith('country_'):
        term   = section_id.split('_', 1)[1]
        movies = api.get_movies_by_country(term, 40)

    if not movies:
        _notify('Keine Filme gefunden. Internetverbindung prüfen.')
        _end(handle)
        return

    for movie in movies:
        _add_movie_item(base_url, handle, movie)
    _end(handle)


def _show_list(base_url, handle, title, entries):
    xbmcplugin.setPluginCategory(handle, title)
    for label, params in entries:
        url = build_url(base_url, params)
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
                                    listitem=_li(label), isFolder=True)
    _end(handle, 'files')


# -----------------------------------------------------------------------
# Film-Item
# -----------------------------------------------------------------------

def _add_movie_item(base_url, handle, movie):
    ia_id = movie.get('q', '') or movie.get('ia_id', '')
    label = movie.get('label', 'Unbekannt')
    year  = movie.get('year', '')
    thumb = movie.get('thumb', '')
    desc  = movie.get('description', '')
    creator = movie.get('creator', '')

    display = f'{label}  [{year}]' if year else label
    info = {
        'title':     label,
        'year':      int(year) if str(year).isdigit() else 0,
        'plot':      desc,
        'director':  creator,
        'mediatype': 'movie',
    }
    url = build_url(base_url, {'mode': 'movie_detail', 'qid': ia_id})
    li  = _li(display, thumb=thumb, info=info)
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)


# -----------------------------------------------------------------------
# Film-Detail & Abspielen
# -----------------------------------------------------------------------

def show_movie_detail(base_url, handle, addon, ia_id):
    movie  = api.get_movie_details(ia_id)
    label  = movie.get('label', ia_id)
    year   = movie.get('year', '')
    thumb  = movie.get('thumb', '')
    desc   = movie.get('description', '')
    videos = movie.get('videos', [])

    xbmcplugin.setPluginCategory(handle, f'{label} [{year}]')

    if not videos:
        # Direktlink als Fallback
        videos = [{'src': 'ia', 'id': f'https://archive.org/download/{ia_id}/{ia_id}.mp4',
                   'label': 'Standard MP4 Stream'}]

    for v in videos:
        src   = v.get('src', 'ia')
        url_v = v.get('id', '')
        vlabel = f'▶  {v.get("label", "Stream")}'
        info  = {'title': label, 'year': int(year) if str(year).isdigit() else 0,
                 'plot': desc, 'mediatype': 'movie'}
        params = {'mode': 'play', 'qid': ia_id, 'src': src,
                  'url': url_v, 'title': label, 'thumb': thumb}
        url = build_url(base_url, params)
        li  = _li(vlabel, thumb=thumb, info=info, playable=True)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    # IA-Seite öffnen
    ia_url = f'https://archive.org/details/{ia_id}'
    li_web = _li(f'🌐  Auf archive.org ansehen')
    web_url = build_url(base_url, {'mode': 'open_web', 'url': ia_url})
    xbmcplugin.addDirectoryItem(handle=handle, url=web_url, listitem=li_web, isFolder=True)

    _end(handle)


# -----------------------------------------------------------------------
# Personen & Suche
# -----------------------------------------------------------------------

def show_person_movies(base_url, handle, addon, person_id, person_name):
    xbmcplugin.setPluginCategory(handle, f'WikiFlix – {person_name}')
    movies = api.get_movies_by_person(person_id, 30)
    if not movies:
        _notify(f'Keine Filme für {person_name} gefunden.')
    else:
        for movie in movies:
            _add_movie_item(base_url, handle, movie)
    _end(handle)


def ask_search_query(addon):
    return xbmcgui.Dialog().input('WikiFlix – Film suchen',
                                  type=xbmcgui.INPUT_ALPHANUM)


def show_search_results(base_url, handle, addon, query):
    xbmcplugin.setPluginCategory(handle, f'WikiFlix – Suche: {query}')
    movies = api.search_movies(query)
    if not movies:
        _notify(f'Keine Ergebnisse für "{query}".')
    else:
        for movie in movies:
            _add_movie_item(base_url, handle, movie)
    _end(handle)
