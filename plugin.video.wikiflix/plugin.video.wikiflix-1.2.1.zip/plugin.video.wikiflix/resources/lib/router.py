#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""URL-Router für WikiFlix."""

from urllib.parse import parse_qsl
from resources.lib import ui, player
import xbmc
import xbmcplugin


def dispatch(base_url, handle, args, addon):
    params = dict(parse_qsl(args.lstrip('?')))
    mode   = params.get('mode', 'main')

    if mode == 'main':
        ui.show_main_menu(base_url, handle, addon)
    elif mode == 'section':
        ui.show_section(base_url, handle, addon, params.get('section_id', ''))
    elif mode == 'movie_detail':
        ui.show_movie_detail(base_url, handle, addon, params.get('qid', ''))
    elif mode == 'play':
        player.play(handle,
                    qid   = params.get('qid', ''),
                    src   = params.get('src', 'ia'),
                    url   = params.get('url', ''),
                    title = params.get('title', ''),
                    thumb = params.get('thumb', ''),
                    addon = addon)
    elif mode == 'search':
        query = params.get('query', '') or ui.ask_search_query(addon)
        if query:
            ui.show_search_results(base_url, handle, addon, query)
    elif mode == 'person':
        ui.show_person_movies(base_url, handle, addon,
                              params.get('person_id', ''),
                              params.get('person_name', ''))
    elif mode == 'open_web':
        _open_web(params.get('url', ''))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    else:
        ui.show_main_menu(base_url, handle, addon)


def _open_web(url):
    if url:
        xbmc.executebuiltin(f'StartAndroidActivity(,,,{url})')
