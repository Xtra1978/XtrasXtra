#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Player: Gibt IA-Streams direkt an Kodi weiter."""

import xbmc
import xbmcgui
import xbmcplugin

ADDON_ICON   = 'special://home/addons/plugin.video.wikiflix/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.video.wikiflix/resources/media/fanart.jpg'


def play(handle, qid, src, url, title, thumb, addon):
    if not url:
        xbmcgui.Dialog().notification('WikiFlix', 'Keine Stream-URL.',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    xbmc.log(f'[WikiFlix] Play: {title} → {url[:80]}', xbmc.LOGINFO)

    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setArt({'thumb': thumb or ADDON_ICON, 'icon': thumb or ADDON_ICON,
               'fanart': ADDON_FANART})
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})

    if url.endswith('.mp4') or 'mp4' in url:
        li.setMimeType('video/mp4')
    elif url.endswith('.ogv') or url.endswith('.ogg'):
        li.setMimeType('video/ogg')
    elif url.endswith('.webm'):
        li.setMimeType('video/webm')
    li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(handle, True, li)
