import hashlib
import html as htmlmod
import http.cookiejar
import json
import os
import re
import time
import uuid
import urllib.parse
import urllib.request

import xbmcaddon
import xbmcvfs

from .log import log

BASE = 'https://rappers.in'
ENDPOINTS = BASE + '/endpoints'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0')
FREE_GENRES = ['aggro', 'deep', 'experimental', 'fun', 'oldschool', 'smooth', 'trap']
# Kategorien (explore-genres/<id>) und Top-50-Listen (top-genres/<id>): 1 Beats, 2 HipHop en, 3 HipHop de, 4 andere Sprachen, 7 Other
RELOGIN_AFTER = 6 * 3600

# kind -> (Seite, load-more-Typ)
KINDS = {
    'home': ('/', None),
    'new': ('/new_music', 'latest_music'),
    'free': ('/free-beats/{g}', 'songs_search'),
    'cat': ('/explore-genres/{g}', 'categories'),
    'albums': ('/albums', 'store_albums'),
    'album': ('/album/{g}', None),
    'top50': ('top-genres/{g}', None),   # über ajax-load.php, feste 50er-Liste
}

_ADDON = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
_JAR_PATH = os.path.join(_PROFILE, 'cookies.lwp')
_TS_PATH = os.path.join(_PROFILE, 'login_ts')
_HASH_PATH = os.path.join(_PROFILE, 'session_hash')
_JAR = http.cookiejar.LWPCookieJar(_JAR_PATH)
try:
    _JAR.load(ignore_discard=True)
except Exception:
    pass
_OPENER = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_JAR))
_MARK = re.compile(r'<(?:li|div)\b[^>]*\bclass="[^"]*\b(?:song_search_list|track_list|list-recommended|'
                   r'playlist-list-song)\b[^"]*"[^>]*>', re.S)


class ApiError(Exception):
    pass


def _session_hash():
    try:
        with open(_HASH_PATH) as f:
            return f.read().strip()
    except Exception:
        return ''


def _hash_id():
    """Server-ausgestellter Session-Hash (aus der Startseite); sonst lokaler Fallback."""
    h = _session_hash()
    if h:
        return h
    h = _ADDON.getSetting('hash_id')
    if not h:
        h = hashlib.sha1(uuid.uuid4().bytes).hexdigest()
        _ADDON.setSetting('hash_id', h)
    return h


def _fetch_session():
    """Startseite laden: liefert Session-Cookies, den Session-Hash (input.main_session) und die Seite."""
    page = _open(BASE + '/')
    m = re.search(r'class="main_session"\s+value="([A-Za-z0-9]+)"', page)
    if m:
        try:
            os.makedirs(_PROFILE, exist_ok=True)
            with open(_HASH_PATH, 'w') as f:
                f.write(m.group(1))
        except Exception as e:
            log('Session-Hash speichern fehlgeschlagen: %s' % e)
    log('Session-Hash %s, Cookies: %s' % ('gefunden (%s…)' % m.group(1)[:6] if m else 'NICHT gefunden',
                                          ', '.join(sorted(c.name for c in _JAR)) or '-'))
    return page


def _is_logged_in(page):
    return 'logout' in page.lower()


def _mark_logged_in():
    _save_jar()
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with open(_TS_PATH, 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _login_ts():
    try:
        with open(_TS_PATH) as f:
            return float(f.read().strip() or 0)
    except Exception:
        return 0.0


def has_credentials():
    return bool(_ADDON.getSetting('username') and _ADDON.getSetting('password'))


def _save_jar():
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        _JAR.save(ignore_discard=True)
    except Exception as e:
        log('Cookie-Speichern fehlgeschlagen: %s' % e)


def _open(url, data=None, ajax=False, referer=None):
    headers = {'User-Agent': UA, 'Accept': '*/*', 'Accept-Language': 'de,en;q=0.8',
               'Referer': referer or BASE + '/'}
    if ajax:
        headers['X-Requested-With'] = 'XMLHttpRequest'
    if data is not None:
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        data = urllib.parse.urlencode(data).encode()
    try:
        with _OPENER.open(urllib.request.Request(url, data=data, headers=headers), timeout=20) as r:
            return r.read().decode('utf-8', 'replace')
    except Exception as e:
        log('ERR %s -> %s' % (url, e), error=True)
        raise ApiError(str(e))


_FIRST_PATH = os.path.join(_PROFILE, 'first_run')
LAST_ERROR = ''


def first_run_done():
    return os.path.exists(_FIRST_PATH)


def mark_first_run():
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with open(_FIRST_PATH, 'w') as f:
            f.write('1')
    except Exception as e:
        log('first_run speichern fehlgeschlagen: %s' % e)


def set_credentials(user, password):
    _ADDON.setSetting('username', user)
    _ADDON.setSetting('password', password)


def clear_session():
    """Löscht Session-Daten (Cookies, Session-Hash, Login-Zeitstempel) und das Addon-Log."""
    _JAR.clear()
    for p in (_JAR_PATH, _HASH_PATH, _TS_PATH, os.path.join(_PROFILE, 'rappersin.log')):
        try:
            os.remove(p)
        except OSError:
            pass


def login(force=False):
    """Meldet mit den Settings-Daten an (Passwort wird nie geloggt)."""
    global LAST_ERROR
    LAST_ERROR = ''
    if not has_credentials():
        return False
    last = _login_ts()
    if not force and time.time() - last < RELOGIN_AFTER and len(_JAR):
        return True
    log('Login als "%s"' % _ADDON.getSetting('username'))
    page = ''
    try:
        page = _fetch_session()
    except ApiError:
        pass
    if page and _is_logged_in(page):
        log('Bereits angemeldet – kein neuer Login nötig')
        _mark_logged_in()
        return True
    txt = _open('%s/auth/login?hash_id=%s' % (ENDPOINTS, _hash_id()),
                data={'username': _ADDON.getSetting('username').strip(),
                      'password': _ADDON.getSetting('password')},
                ajax=True)
    try:
        d = json.loads(txt)
        ok = isinstance(d, dict) and d.get('status') == 200
        info = {k: str(v)[:120] for k, v in d.items() if k != 'header'} if isinstance(d, dict) else {'raw': txt[:150]}
    except ValueError:
        ok, info = False, {'raw': txt[:150]}
    log('Login-Antwort: %s' % info)
    log('Login %s' % ('OK' if ok else 'FEHLGESCHLAGEN'))
    if ok:
        _mark_logged_in()
    else:
        LAST_ERROR = str(info)
    return ok


def _clean(s):
    return re.sub(r'\s+', ' ', htmlmod.unescape(re.sub(r'<[^>]+>', '', s or ''))).strip()


def parse_cards(page, default_artist='', default_cover=''):
    """Tracks aus allen Kartentypen (Genre-Liste, Startseite, Kategorien, Neu, Album)."""
    marks = list(_MARK.finditer(page))
    items, seen = [], set()
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(page)
        chunk = page[m.start():end]
        pid = re.search(r"playSong\('([A-Za-z0-9]+)'\)", chunk)
        if not pid or pid.group(1) in seen:
            continue
        seen.add(pid.group(1))
        did = re.search(r'data-id="(\d+)"', m.group(0))
        title = (re.search(r'<span class="title">(.*?)</span>', chunk, re.S)
                 or re.search(r'<h4>\s*<a[^>]*>(.*?)</a\s*>', chunk, re.S)
                 or re.search(r'<h4>(.*?)</h4>', chunk, re.S))
        artists = [_clean(a) for a in re.findall(r'<span class="artist"[^>]*>(.*?)</span\s*>', chunk, re.S)]
        artists = [a for a in artists if a and '{{' not in a]
        if not artists:
            a = (re.search(r'<p>\s*<a[^>]*>(.*?)</a\s*>', chunk, re.S)
                 or re.search(r'class="a_name">\s*<a[^>]*>(.*?)</a\s*>', chunk, re.S))
            artists = [_clean(a.group(1))] if a else []
        cover = re.search(r'<img[^>]+src="(https://[^"]+?)(?:\?[^"]*)?"', chunk)
        rank = re.search(r'<span class="numbers">\s*(\d+)\s*</span>', chunk)
        items.append({
            'rank': rank.group(1) if rank else '',
            'audio_id': pid.group(1),
            'data_id': did.group(1) if did else '',
            'title': _clean(title.group(1)) if title else pid.group(1),
            'artist': artists[-1] if artists else default_artist,
            'cover': htmlmod.unescape(cover.group(1)) if cover else default_cover,
        })
    return items


def parse_albums(page):
    items, seen = [], set()
    marks = list(re.finditer(r'<div class="track_list" data-id="(\d+)"', page))
    for i, m in enumerate(marks):
        chunk = page[m.start():marks[i + 1].start() if i + 1 < len(marks) else len(page)]
        aid = re.search(r'/album/([A-Za-z0-9]+)"', chunk)
        if not aid or aid.group(1) in seen:
            continue
        seen.add(aid.group(1))
        title = re.search(r'<span class="title">(.*?)</span>', chunk, re.S)
        artist = re.search(r'<span class="artist">(.*?)</span>', chunk, re.S)
        cover = re.search(r'<img[^>]+src="(https://[^"]+?)(?:\?[^"]*)?"', chunk)
        items.append({'album_id': aid.group(1), 'data_id': m.group(1),
                      'title': _clean(title.group(1)) if title else aid.group(1),
                      'artist': _clean(artist.group(1)) if artist else '',
                      'cover': htmlmod.unescape(cover.group(1)) if cover else ''})
    return items


def _parse(kind, page):
    if kind == 'albums':
        return parse_albums(page)
    if kind == 'album':
        cover = re.search(r'class="al_art_img"[^>]*url\(([^)]+)\)', page)
        artist = re.search(r'class="al_artist">\s*<a[^>]*>(.*?)</a\s*>', page, re.S)
        return parse_cards(page, default_artist=_clean(artist.group(1)) if artist else '',
                           default_cover=htmlmod.unescape(cover.group(1)) if cover else '')
    return parse_cards(page)


def listing(kind, arg=''):
    if has_credentials():
        login()
    if kind == 'top50':
        q = {'path': KINDS[kind][0].format(g=arg), 'hash_id': _hash_id(), '_': int(time.time() * 1000)}
        page = _open('%s/ajax-load.php?%s' % (BASE, urllib.parse.urlencode(q)), ajax=True)
    else:
        page = _open(BASE + KINDS[kind][0].format(g=arg))
    items = _parse(kind, page)
    log('%s %s -> %d Einträge' % (kind, arg, len(items)))
    return items


def _load_more_once(kind, arg, last_id):
    lm = KINDS[kind][1]
    ref = BASE + KINDS[kind][0].format(g=arg)
    for attempt in (1, 2):
        q = [('hash_id', _hash_id()), ('id', last_id), ('track_id', 0)]
        if kind in ('cat', 'free', 'albums'):
            q.append(('get_data', arg if kind in ('cat', 'free') else ''))
        # Free Beats = Suche: die Seite sendet filter_type=songs (hidden input #filter_type)
        q += [('params[filter_type]', 'songs' if kind == 'free' else ''), ('params[current_tag]', ''),
              ('views', 0), ('product_id', 0), ('_', int(time.time() * 1000))]
        txt = _open('%s/load-more/%s?%s' % (ENDPOINTS, lm, urllib.parse.urlencode(q)), ajax=True, referer=ref)
        try:
            data = json.loads(txt)
        except ValueError:
            data = None
        if not isinstance(data, dict):
            log('load-more %s: unerwartete Antwort: %s' % (kind, txt[:150].replace('\n', ' ')))
            data = {}
        html = data.get('html') or ''
        log('load-more Antwort: status=%s, html=%d Zeichen' % (data.get('status'), len(html)))
        if data.get('status') == 200:
            items = _parse(kind, html)
            log('load-more %s %s id=%s -> %d Einträge' % (kind, arg, last_id, len(items)))
            return items
        if attempt == 1:
            log('load-more Status %s – neu anmelden' % data.get('status'))
            login(force=True)
    return []


def load_more(kind, arg, last_id):
    """Weitere Ergebnisse – nur mit Login."""
    if not KINDS[kind][1]:
        return []
    if not login():
        raise ApiError('Login erforderlich')
    items = _load_more_once(kind, arg, last_id)
    if kind == 'free':
        # Die Such-Schnittstelle liefert bei Free Beats nur ~1 Treffer je Abruf -> bis zu 10 sammeln
        calls = 1
        while items and len(items) < 10 and calls < 14:
            nxt = next((i['data_id'] for i in reversed(items) if i.get('data_id')), '')
            more = _load_more_once(kind, arg, nxt) if nxt else []
            calls += 1
            if not more:
                break
            known = {i['audio_id'] for i in items}
            items += [m for m in more if m['audio_id'] not in known]
    return items


def resolve(audio_id):
    login()
    q = {'hash_id': _hash_id(), 'id': audio_id, 'audio_ad_id': 0, '_': int(time.time() * 1000)}
    data = json.loads(_open('%s/get-song-info?%s' % (ENDPOINTS, urllib.parse.urlencode(q)), ajax=True))
    url = data.get('songURL')
    if data.get('status') != 200 or not url:
        raise ApiError('kein songURL: %s' % str(data)[:200])
    log('resolve %s -> %s' % (audio_id, url))
    return {'url': url, 'title': data.get('songTitle', ''), 'artist': data.get('artistName', ''),
            'cover': data.get('coverURL', '')}


def play_headers():
    return urllib.parse.urlencode({'Referer': BASE + '/', 'User-Agent': UA}, quote_via=urllib.parse.quote)
