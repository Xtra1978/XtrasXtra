import traceback
import urllib.parse

import xbmcgui
import xbmcplugin

from . import api, features, ui
from .log import log
from .ui import ADDON, HANDLE, S, action_item, folder

# Beats-Genres (free-beats/<slug>) und Kategorien (explore-genres/<id> bzw. top-genres/<id>)
BEAT_GENRES = [('aggro', 30020), ('deep', 30021), ('experimental', 30022), ('fun', 30023),
               ('oldschool', 30024), ('smooth', 30025), ('trap', 30026)]
SONG_CATS = [('2', 30031), ('3', 30032), ('4', 30034), ('7', 30035)]
TOP_CATS = [('1', 30039), ('2', 30031), ('3', 30032), ('4', 30034), ('7', 30035)]


# ---------------------------------------------------------------- Menüs

def root():
    if not api.first_run_done():
        start_dialog()
    folder(S(30001), action='list', kind='home')
    folder(S(30000), action='beats_menu')
    folder(S(30036), action='songs_menu')
    folder(S(30002), action='list', kind='new')
    folder(S(30003), action='top_menu')
    folder(S(30011), action='list', kind='albums')
    folder(S(30060), action='playlists')
    action_item(S(30061), action='lets_play')
    action_item(S(30062), action='generator')
    action_item(S(30040), action='settings')
    action_item(S(30041), action='clear_cache')
    xbmcplugin.endOfDirectory(HANDLE)


def beats_menu():
    folder(S(30030), action='list', kind='cat', arg='1')
    for slug, label in BEAT_GENRES:
        folder(S(label), action='list', kind='free', arg=slug)
    xbmcplugin.endOfDirectory(HANDLE)


def songs_menu():
    for cid, label in SONG_CATS:
        folder(S(label), action='list', kind='cat', arg=cid)
    xbmcplugin.endOfDirectory(HANDLE)


def top_menu():
    for cid, label in TOP_CATS:
        folder(S(30038) % S(label), action='list', kind='top50', arg=cid)
    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- Start-Dialog

def start_dialog():
    """Erster Start: Free-Modus oder Login mit Zugangsdaten (echter Login-Test, kein Dummy)."""
    dlg = xbmcgui.Dialog()
    if api.has_credentials():
        api.mark_first_run()
        return
    login_mode = dlg.yesno(S(30050), S(30051), nolabel=S(30052), yeslabel=S(30053))
    api.mark_first_run()
    if not login_mode:
        return
    while True:
        user = dlg.input(S(30054), type=xbmcgui.INPUT_ALPHANUM)
        if not user:
            return
        pw = dlg.input(S(30014), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not pw:
            return
        api.set_credentials(user.strip(), pw)
        try:
            ok = api.login(force=True)
        except Exception as e:
            log('Start-Login: %s' % e, error=True)
            ok = False
        if ok:
            dlg.notification('Rappers.in', S(30019))
            return
        api.set_credentials('', '')
        if 'Too many' in api.LAST_ERROR:
            dlg.notification('Rappers.in', S(30033), xbmcgui.NOTIFICATION_ERROR)
            return
        if not dlg.yesno(S(30050), S(30056)):
            return


# ---------------------------------------------------------------- Listen

def _add_albums(items):
    for a in items:
        li = xbmcgui.ListItem(label='%s – %s' % (a['artist'], a['title']) if a['artist'] else a['title'])
        tag = li.getMusicInfoTag()
        tag.setAlbum(a['title'])
        tag.setArtist(a['artist'])
        tag.setMediaType('album')
        ui.art(li, a['cover'])
        li.addContextMenuItems(ui.shuffle_context('album', a['album_id']))
        xbmcplugin.addDirectoryItem(HANDLE, ui.url(action='list', kind='album', arg=a['album_id']), li, True)


def list_items(params):
    kind, arg, last_id = params['kind'], params.get('arg', ''), params.get('last')
    if last_id:
        if not api.has_credentials():
            xbmcgui.Dialog().ok('Rappers.in', S(30016))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            ADDON.openSettings()
            return
        if not api.login():
            xbmcgui.Dialog().notification('Rappers.in', S(30018), xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
    try:
        items = api.load_more(kind, arg, last_id) if last_id else api.listing(kind, arg)
    except api.ApiError as e:
        log('Liste %s fehlgeschlagen: %s' % (kind, e), error=True)
        xbmcgui.Dialog().notification('Rappers.in', S(30007), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if not items:
        xbmcgui.Dialog().notification('Rappers.in', S(30005))
    if kind == 'albums':
        xbmcplugin.setContent(HANDLE, 'albums')
        _add_albums(items)
    else:
        xbmcplugin.setContent(HANDLE, 'songs')
        for t in items:
            features.track_item(t)
    last = next((i['data_id'] for i in reversed(items) if i.get('data_id')), '')
    if items and last and api.KINDS[kind][1]:
        args = dict(action='list', kind=kind, last=last)
        if arg:
            args['arg'] = arg
        folder(S(30004), **args)
    xbmcplugin.endOfDirectory(HANDLE, updateListing=bool(last_id))


# ---------------------------------------------------------------- Wiedergabe

def play(params):
    try:
        info = api.resolve(params['id'])
    except Exception as e:
        log('play %s fehlgeschlagen: %s' % (params.get('id'), e), error=True)
        xbmcgui.Dialog().notification('Rappers.in', S(30006), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path='%s|%s' % (info['url'], api.play_headers()))
    tag = li.getMusicInfoTag()
    tag.setTitle(info['title'])
    tag.setArtist(info['artist'])
    # Vollbild-Wiedergabe: eigener Background statt Listen-Fanart
    art = {'fanart': ui.BACKGROUND}
    if info['cover']:
        art['thumb'] = art['poster'] = art['icon'] = info['cover']
    li.setArt(art)
    li.setProperty('fanart_image', ui.BACKGROUND)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ---------------------------------------------------------------- Aktionen

def settings():
    ui.finish_action()
    ADDON.openSettings()


def clear_cache():
    ui.finish_action()
    if xbmcgui.Dialog().yesno('Rappers.in', S(30043)):
        api.clear_session()
        xbmcgui.Dialog().notification('Rappers.in', S(30042))


def login_test():
    try:
        ok = api.has_credentials() and api.login(force=True)
    except Exception as e:
        log('login_test: %s' % e, error=True)
        ok = False
    msg = 30019 if ok else (30033 if 'Too many' in api.LAST_ERROR else 30018)
    xbmcgui.Dialog().notification('Rappers.in', S(msg),
                                  xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR)


def run(argv):
    try:
        _dispatch(argv)
    except Exception:
        log('EXCEPTION: %s' % traceback.format_exc().replace('\n', ' | '), error=True)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception:
            pass


def _dispatch(argv):
    p = dict(urllib.parse.parse_qsl(argv[2][1:])) if len(argv) > 2 else {}
    action = p.get('action')
    log('route %s' % {k: v for k, v in p.items() if k != 'track'})
    try:
        xbmcplugin.setPluginFanart(HANDLE, ui.FANART)
    except Exception:
        pass
    simple = {
        'beats_menu': beats_menu, 'songs_menu': songs_menu, 'top_menu': top_menu,
        'settings': settings, 'clear_cache': clear_cache, 'login_test': login_test,
        'playlists': features.playlists, 'lets_play': features.lets_play, 'generator': features.generator,
    }
    if action == 'list':
        list_items(p)
    elif action == 'play':
        play(p)
    elif action in simple:
        simple[action]()
    elif action == 'playlist_tracks':
        features.playlist_tracks(p['name'])
    elif action == 'add_to_playlist_prompt':
        features.add_to_playlist_prompt(p['track'])
    elif action == 'remove_from_playlist':
        features.remove_from_playlist(p['name'], p['audio_id'])
    elif action == 'play_playlist':
        features.play_playlist(p['name'], shuffle=bool(p.get('shuffle')))
    elif action == 'delete_playlist':
        features.delete_playlist(p['name'])
    elif action == 'shuffle_source':
        features.shuffle_source(p['kind'], p.get('arg', ''))
    else:
        root()
