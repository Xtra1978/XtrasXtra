"""Playlisten, Let's Play it (Shuffle) und Give me Beats (Generator) – nach dem Muster von SoundWave 1."""
import base64
import json
import random
import time

import xbmc
import xbmcgui
import xbmcplugin

from . import api, storage, ui
from .log import log
from .ui import S

# Quellen für Shuffle/Generator: (kind, arg) – explore-genres/<id> bzw. top-genres/<id>
SOURCES = {
    'beats': [('cat', '1'), ('top50', '1')],
    'de': [('cat', '3'), ('top50', '3')],
    'en': [('cat', '2'), ('top50', '2')],
    'other': [('cat', '4'), ('top50', '4')],
    'other_genres': [('cat', '7'), ('top50', '7')],
}
BEAT_GENRES = [('aggro', 30020), ('deep', 30021), ('experimental', 30022), ('fun', 30023),
               ('oldschool', 30024), ('smooth', 30025), ('trap', 30026)]
GEN_OPTIONS = [('beats', 30000), ('beatgenres', 30083), ('album', 30078),
               ('de', 30084), ('en', 30085), ('other', 30086)]
GEN_COUNTS = ['15', '25', '50']


# ---------------------------------------------------------------- Track-Helfer

def compact(t):
    return {'audio_id': t.get('audio_id'), 'title': t.get('title'),
            'artist': t.get('artist'), 'cover': t.get('cover')}


def encode_track(t):
    return base64.urlsafe_b64encode(json.dumps(compact(t), ensure_ascii=False).encode('utf-8')).decode('ascii')


def decode_track(s):
    return json.loads(base64.urlsafe_b64decode(s.encode('ascii')).decode('utf-8'))


def label_of(t):
    name = '%s – %s' % (t['artist'], t['title']) if t.get('artist') else (t.get('title') or '?')
    return '%s. %s' % (t['rank'], name) if t.get('rank') else name


def track_item(t, playlist=None):
    """Titel-Eintrag mit Kontextmenü (Zur Playlist hinzufügen bzw. aus Playlist entfernen)."""
    li = xbmcgui.ListItem(label=label_of(t))
    li.setProperty('IsPlayable', 'true')
    tag = li.getMusicInfoTag()
    tag.setTitle(t.get('title') or '')
    tag.setArtist(t.get('artist') or '')
    tag.setMediaType('song')
    ui.art(li, t.get('cover') or '')
    if playlist is None:
        ctx = [(S(30063), 'RunPlugin(%s)' % ui.url(action='add_to_playlist_prompt', track=encode_track(t)))]
    else:
        ctx = [(S(30064), 'RunPlugin(%s)' % ui.url(action='remove_from_playlist', name=playlist,
                                                   audio_id=t.get('audio_id')))]
    li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(ui.HANDLE, ui.url(action='play', id=t['audio_id']), li, False)


def play_queue(tracks):
    """Startet die Titel als Kodi-Musikwarteschlange; die Streams werden erst beim Abspielen aufgelöst."""
    pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    pl.clear()
    n = 0
    for t in tracks:
        if not t.get('audio_id'):
            continue
        li = xbmcgui.ListItem(label=label_of(t))
        li.setProperty('IsPlayable', 'true')
        tag = li.getMusicInfoTag()
        tag.setTitle(t.get('title') or '')
        tag.setArtist(t.get('artist') or '')
        art = {'fanart': ui.BACKGROUND}
        if t.get('cover'):
            art['thumb'] = art['icon'] = t['cover']
        li.setArt(art)
        pl.add(ui.url(action='play', id=t['audio_id']), li)
        n += 1
    if not n:
        xbmcgui.Dialog().notification('Rappers.in', S(30005))
        return False
    log('Warteschlange: %d Titel' % n)
    xbmc.Player().play(pl)
    return True


# ---------------------------------------------------------------- Sammeln

def _gather(kind, arg, need):
    """Titel einer Liste; mit Login werden bei Bedarf weitere Seiten nachgeladen."""
    try:
        items = api.listing(kind, arg)
    except api.ApiError as e:
        log('gather %s %s: %s' % (kind, arg, e))
        return []
    loops = 0
    while len(items) < need and api.has_credentials() and api.KINDS[kind][1] and loops < 4:
        last = next((i['data_id'] for i in reversed(items) if i.get('data_id')), '')
        if not last:
            break
        try:
            more = api.load_more(kind, arg, last)
        except api.ApiError:
            break
        if not more:
            break
        items += more
        loops += 1
    return items


def _album_pool(need, max_albums=8):
    try:
        albums = api.listing('albums')
    except api.ApiError:
        return []
    random.shuffle(albums)
    pool = []
    for a in albums[:max_albums]:
        try:
            pool += api.listing('album', a['album_id'])
        except api.ApiError:
            continue
        if len(pool) >= need:
            break
    return pool


def _source_pool(key, need, beat_genres=None):
    if key == 'album':
        return _album_pool(need)
    if key == 'beatgenres':
        pool = []
        for slug in (beat_genres or []):
            pool += _gather('free', slug, need)
        return pool
    pool = []
    for kind, arg in SOURCES[key]:
        pool += _gather(kind, arg, need)
    return pool


def _unique(tracks):
    seen, out = set(), []
    for t in tracks:
        if t.get('audio_id') and t['audio_id'] not in seen:
            seen.add(t['audio_id'])
            out.append(t)
    return out


def _mix(pools, count):
    """Reihum aus allen Pools ziehen, damit jede gewählte Auswahl vorkommt."""
    for p in pools:
        random.shuffle(p)
    out, seen = [], set()
    while len(out) < count and any(pools):
        for p in pools:
            while p and p[-1]['audio_id'] in seen:
                p.pop()
            if p and len(out) < count:
                t = p.pop()
                seen.add(t['audio_id'])
                out.append(t)
    return out


# ---------------------------------------------------------------- Playlisten

def playlists():
    data = storage.get_playlists()
    if not data:
        xbmcgui.Dialog().notification('Rappers.in', S(30070))
        xbmcplugin.endOfDirectory(ui.HANDLE)
        return
    for name, tracks in data.items():
        li = xbmcgui.ListItem(label='%s (%d)' % (name, len(tracks)))
        ui.art(li, tracks[0].get('cover') if tracks else '')
        li.addContextMenuItems([
            (S(30072), 'RunPlugin(%s)' % ui.url(action='play_playlist', name=name)),
            (S(30073), 'RunPlugin(%s)' % ui.url(action='play_playlist', name=name, shuffle='1')),
            (S(30074), 'RunPlugin(%s)' % ui.url(action='delete_playlist', name=name)),
        ])
        xbmcplugin.addDirectoryItem(ui.HANDLE, ui.url(action='playlist_tracks', name=name), li, True)
    xbmcplugin.setContent(ui.HANDLE, 'files')
    xbmcplugin.endOfDirectory(ui.HANDLE)


def playlist_tracks(name):
    tracks = storage.get_playlist(name)
    if not tracks:
        xbmcgui.Dialog().notification('Rappers.in', S(30071))
    for t in tracks:
        track_item(t, playlist=name)
    xbmcplugin.setContent(ui.HANDLE, 'songs')
    xbmcplugin.endOfDirectory(ui.HANDLE)


def add_to_playlist_prompt(encoded):
    track = decode_track(encoded)
    dlg = xbmcgui.Dialog()
    existing = list(storage.get_playlists().keys())
    options = existing + [S(30065)]
    idx = dlg.select(S(30063), options)
    if idx < 0:
        return
    if idx == len(options) - 1:
        name = dlg.input(S(30066))
        if not name:
            return
    else:
        name = existing[idx]
    added = storage.add_to_playlist(name, track)
    dlg.notification('Rappers.in', S(30067 if added else 30068))


def remove_from_playlist(name, audio_id):
    storage.remove_from_playlist(name, audio_id)
    xbmcgui.Dialog().notification('Rappers.in', S(30069))
    xbmc.executebuiltin('Container.Refresh')


def play_playlist(name, shuffle=False):
    tracks = list(storage.get_playlist(name))
    if shuffle:
        random.shuffle(tracks)
    play_queue(tracks)


def delete_playlist(name):
    if xbmcgui.Dialog().yesno('Rappers.in', S(30075) % name):
        storage.delete_playlist(name)
        xbmcgui.Dialog().notification('Rappers.in', S(30069))
        xbmc.executebuiltin('Container.Refresh')


# ---------------------------------------------------------------- Let's Play it

def lets_play():
    """Menüpunkt: Vorauswahl Beats / Album / Genres, dann zufällig abspielen."""
    dlg = xbmcgui.Dialog()
    idx = dlg.select(S(30077), [S(30000), S(30078), S(30079)])
    if idx < 0:
        xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
        return
    bg = xbmcgui.DialogProgressBG()
    bg.create('Rappers.in', S(30094))
    try:
        if idx == 0:
            tracks = _source_pool('beats', 50)
        elif idx == 1:
            tracks = _album_pool(1, max_albums=1)
        else:
            tracks = []
    finally:
        bg.close()
    if idx == 2:
        keys = [('de', S(30084)), ('en', S(30085)), ('other', S(30086)), ('other_genres', S(30035))]
        g = dlg.select(S(30079), [S(30080)] + [k[1] for k in keys])
        if g < 0:
            xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
            return
        key = random.choice(keys)[0] if g == 0 else keys[g - 1][0]
        bg = xbmcgui.DialogProgressBG()
        bg.create('Rappers.in', S(30094))
        try:
            tracks = _source_pool(key, 50)
        finally:
            bg.close()
    tracks = _unique(tracks)
    random.shuffle(tracks)
    log("Let's Play it: Auswahl %d -> %d Titel" % (idx, len(tracks)))
    play_queue(tracks[:50])
    xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)


def shuffle_source(kind, arg):
    """Kontextmenü an Listen: diese Liste zufällig abspielen."""
    tracks = api.listing('album', arg) if kind == 'album' else _gather(kind, arg, 50)
    tracks = _unique(tracks)
    random.shuffle(tracks)
    log("Let's Play it (Kontext): %s %s -> %d Titel" % (kind, arg, len(tracks)))
    play_queue(tracks[:50])


# ---------------------------------------------------------------- Give me Beats

def generator():
    dlg = xbmcgui.Dialog()
    cidx = dlg.select(S(30081), GEN_COUNTS)
    if cidx < 0:
        xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
        return
    count = int(GEN_COUNTS[cidx])
    sel = dlg.multiselect(S(30082), [S(l) for _, l in GEN_OPTIONS])
    if not sel:
        xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
        return
    keys = [GEN_OPTIONS[i][0] for i in sel]
    genres = []
    if 'beatgenres' in keys:
        gsel = dlg.multiselect(S(30093), [S(l) for _, l in BEAT_GENRES])
        genres = [BEAT_GENRES[i][0] for i in (gsel or [])]
        if not genres:
            keys.remove('beatgenres')
    if not keys:
        xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
        return

    bg = xbmcgui.DialogProgressBG()
    bg.create('Rappers.in', S(30094))
    pools = []
    try:
        for n, key in enumerate(keys):
            bg.update(int(100 * n / len(keys)), 'Rappers.in', S(30094))
            pools.append(_unique(_source_pool(key, count, genres)))
    finally:
        bg.close()
    tracks = _mix([p for p in pools if p], count)
    log('Generator: %s, %d gewünscht -> %d Titel' % (keys, count, len(tracks)))
    if not tracks:
        dlg.notification('Rappers.in', S(30005))
        xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
        return
    if len(tracks) < count:
        dlg.notification('Rappers.in', S(30088) % len(tracks))
    if play_queue(tracks) and dlg.yesno('Rappers.in', S(30089)):
        name = dlg.input(S(30066), defaultt='Give me Beats – %s' % time.strftime('%Y-%m-%d %H:%M'))
        if name:
            storage.save_playlist(name, [compact(t) for t in tracks])
            dlg.notification('Rappers.in', S(30092))
    xbmcplugin.endOfDirectory(ui.HANDLE, succeeded=True)
