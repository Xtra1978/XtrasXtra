import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_PATH = os.path.join(xbmcvfs.translatePath(_ADDON.getAddonInfo('profile')), 'rappersin.log')
_MAX = 150 * 1024


def log(msg, error=False):
    if error:
        xbmc.log('[rappersin] %s' % msg, xbmc.LOGERROR)
    if _ADDON.getSetting('debug_log') != 'true':
        return
    try:
        os.makedirs(os.path.dirname(_PATH), exist_ok=True)
        if os.path.exists(_PATH) and os.path.getsize(_PATH) > _MAX:
            with open(_PATH, 'rb') as f:
                f.seek(-_MAX // 2, os.SEEK_END)
                tail = f.read()
            with open(_PATH, 'wb') as f:
                f.write(tail)
        with open(_PATH, 'a', encoding='utf-8') as f:
            f.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except Exception:
        pass
