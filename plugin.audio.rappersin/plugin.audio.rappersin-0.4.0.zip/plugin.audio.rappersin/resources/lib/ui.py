"""Gemeinsame UI-Helfer: Pfade, Strings, Neon-Labels, Menü-Einträge, Kontextmenü."""
import os
import sys
import urllib.parse

import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = 'plugin://plugin.audio.rappersin/'
_PATH = ADDON.getAddonInfo('path')
FANART = os.path.join(_PATH, 'resources', 'media', 'fanart.jpg')
BACKGROUND = os.path.join(_PATH, 'resources', 'media', 'background.jpg')
BLANK = os.path.join(_PATH, 'resources', 'media', 'blank.png')  # transparent: unterdrückt Ordner-/Standard-Icons

# Kontextmenü "Let's Play it" an Listen, die sich mischen lassen
SHUFFLE_KINDS = ('free', 'cat', 'top50', 'new', 'album')


def S(i):
    return ADDON.getLocalizedString(i)


def neon(text):
    """Menü-Label im Neon-Stil: == Text == in Cyan, fett und kursiv (keine Menü-Icons)."""
    return '[B][I][COLOR FF00FFFF]== %s ==[/COLOR][/I][/B]' % text


def url(**kw):
    return BASE_URL + '?' + urllib.parse.urlencode(kw)


def art(li, cover=''):
    """Fanart dauerhaft; Titel/Alben mit Cover, sonst transparentes Bild (keine Ordner-Icons im Menü)."""
    img = cover or BLANK
    li.setArt({'fanart': FANART, 'thumb': img, 'poster': img, 'icon': img})
    li.setProperty('fanart_image', FANART)


def shuffle_context(kind, arg=''):
    return [(S(30061), 'RunPlugin(%s)' % url(action='shuffle_source', kind=kind, arg=arg))]


def folder(label, context=None, **kw):
    li = xbmcgui.ListItem(label=neon(label))
    art(li)
    ctx = list(context or [])
    if kw.get('action') == 'list' and kw.get('kind') in SHUFFLE_KINDS and not kw.get('last'):
        ctx += shuffle_context(kw['kind'], kw.get('arg', ''))
    if ctx:
        li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(HANDLE, url(**kw), li, True)


def action_item(label, **kw):
    li = xbmcgui.ListItem(label=neon(label))
    art(li)
    xbmcplugin.addDirectoryItem(HANDLE, url(**kw), li, False)


def finish_action():
    """Aktions-Einträge (Einstellungen, Cache) lösen nichts auf."""
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
