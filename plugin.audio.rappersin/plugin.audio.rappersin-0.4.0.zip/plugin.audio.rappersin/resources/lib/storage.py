"""Eigene Playlisten – JSON im Addon-Profil, unabhängig von Kodis eigenen Playlisten/Favoriten.

playlists.json: {"Playlistname": [Track-Dicts], ...}
Ein Track ist {audio_id, title, artist, cover}; Duplikate werden über audio_id vermieden.
"""
import json
import os

import xbmcaddon
import xbmcvfs

from .log import log

_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
PATH = os.path.join(_PROFILE, 'playlists.json')


def _read():
    try:
        with open(PATH, encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(data):
    os.makedirs(_PROFILE, exist_ok=True)
    tmp = PATH + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, PATH)


def get_playlists():
    return _read()


def get_playlist(name):
    return _read().get(name, [])


def save_playlist(name, tracks):
    data = _read()
    data[name] = tracks
    _write(data)
    log('Playlist gespeichert: "%s" (%d Titel)' % (name, len(tracks)))


def delete_playlist(name):
    data = _read()
    if name in data:
        del data[name]
        _write(data)
        log('Playlist gelöscht: "%s"' % name)


def add_to_playlist(name, track):
    tracks = get_playlist(name)
    if any(t.get('audio_id') == track.get('audio_id') for t in tracks):
        return False
    tracks.append(track)
    save_playlist(name, tracks)
    return True


def remove_from_playlist(name, audio_id):
    save_playlist(name, [t for t in get_playlist(name) if t.get('audio_id') != audio_id])
