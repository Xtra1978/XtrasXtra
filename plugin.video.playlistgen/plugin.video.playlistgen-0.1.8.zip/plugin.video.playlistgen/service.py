import xbmc
import xbmcgui

from resources.lib import cleanup
from resources.lib.common import ACTIVE_PROP, log


class PlayerLog(xbmc.Player):
    """Logs playback events of lists started by this add-on (helps with 'list plays nothing')."""

    @staticmethod
    def _active():
        return xbmcgui.Window(10000).getProperty(ACTIVE_PROP) == '1'

    def onAVStarted(self):
        if self._active():
            try:
                log('playback started: %s' % self.getPlayingFile())
            except RuntimeError:
                pass

    def onPlayBackError(self):
        if self._active():
            log('playback ERROR: item could not be played', xbmc.LOGWARNING)

    def onPlayBackStopped(self):
        if self._active():
            log('playback stopped')
            xbmcgui.Window(10000).clearProperty(ACTIVE_PROP)


def main():
    monitor = xbmc.Monitor()
    player = PlayerLog()  # noqa: F841 - must stay alive to receive callbacks
    while not monitor.abortRequested():
        cleanup.run()
        if monitor.waitForAbort(3600):
            break


main()
