import math
import sys
import time
from urllib.parse import parse_qsl, urlencode

import xbmcgui
import xbmcplugin

from . import cleanup, diag, generator, sources, store
from .common import ART, notify, tr


def _url(base, **params):
    return base + '?' + urlencode(params)


def _root(base, handle):
    entries = ((30043, 'quick', False), (30001, 'generate', False), (30002, 'lists', True), (30003, 'sources', False),
               (30046, 'diag', False))
    for sid, action, folder in entries:
        li = xbmcgui.ListItem(tr(sid))
        li.setArt(ART)
        xbmcplugin.addDirectoryItem(handle, _url(base, action=action), li, folder)
    xbmcplugin.endOfDirectory(handle)


def _lists(base, handle):
    now = time.time()
    ttl = cleanup.ttl_seconds()
    shown = 0
    for path, data in store.iter_lists():
        if not data or not data.get('items'):
            continue
        created = data.get('created', 0)
        hours_left = max(0, math.ceil((created + ttl - now) / 3600))
        label = tr(30034) % (time.strftime('%d.%m. %H:%M', time.localtime(created)),
                             len(data['items']), hours_left)
        name = path.replace('\\', '/').rsplit('/', 1)[-1]
        li = xbmcgui.ListItem(label)
        li.setArt(ART)
        xbmcplugin.addDirectoryItem(handle, _url(base, action='play_list', name=name), li, False)
        shown += 1
    if not shown:
        notify(tr(30033))
    xbmcplugin.endOfDirectory(handle, succeeded=bool(shown))


def run():
    base, handle = sys.argv[0], int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2].lstrip('?')))
    action = params.get('action', 'root')
    cleanup.run()
    if action == 'root':
        _root(base, handle)
    elif action == 'lists':
        _lists(base, handle)
    else:
        # dialog-driven actions: nothing to resolve for Kodi
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        if action == 'quick':
            generator.quick()
        elif action == 'generate':
            generator.run()
        elif action == 'sources':
            sources.manage()
        elif action == 'diag':
            diag.menu()
        elif action == 'play_list':
            generator.play(store.read_list(params.get('name', '')).get('items', []))
