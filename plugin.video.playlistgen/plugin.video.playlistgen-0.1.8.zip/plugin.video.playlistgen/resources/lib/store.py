import json
import os
import time
import uuid

from .common import PROFILE, log

LISTS_DIR = os.path.join(PROFILE, 'lists')
SOURCES_FILE = os.path.join(PROFILE, 'sources.json')


def _read(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# --- sources -------------------------------------------------------------
def load_sources():
    data = _read(SOURCES_FILE)
    return data if isinstance(data, list) else []


def save_sources(sources):
    _write(SOURCES_FILE, sources)


def add_source(name, path, media, depth):
    sources = load_sources()
    sources.append({'id': uuid.uuid4().hex[:8], 'name': name, 'path': path,
                    'media': media, 'depth': depth})
    save_sources(sources)


def remove_source(source_id):
    save_sources([s for s in load_sources() if s.get('id') != source_id])


# --- generated lists -----------------------------------------------------
def save_list(items):
    now = time.time()
    created = int(now)
    name = 'list_%d.json' % int(now * 1000)     # ms: two lists in one second must not collide
    _write(os.path.join(LISTS_DIR, name), {'created': created, 'items': items})
    log('saved %s (%d items)' % (name, len(items)))
    return name


def iter_lists():
    """[(path, data|None)] newest first; data is None for unreadable files."""
    if not os.path.isdir(LISTS_DIR):
        return []
    names = sorted((n for n in os.listdir(LISTS_DIR)
                    if n.startswith('list_') and n.endswith('.json')), reverse=True)
    result = []
    for name in names:
        path = os.path.join(LISTS_DIR, name)
        data = _read(path)
        result.append((path, data if isinstance(data, dict) else None))
    return result


def read_list(name):
    data = _read(os.path.join(LISTS_DIR, os.path.basename(name)))
    return data if isinstance(data, dict) else {'items': []}
