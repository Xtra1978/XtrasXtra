import random
import time
from collections import Counter

import xbmc
import xbmcgui

from . import diag, store
from .common import ACTIVE_PROP, log, notify, rpc, setting_bool, setting_int, tr

COUNTS = (3, 5, 10)               # video / mixed sources: max. 10 titles
COUNTS_AUDIO = (10, 25, 50)       # music-only sources: up to 50 titles
AUDIO_MIN_POOL = 150              # enough music to draw 50 varied titles from
MAX_GENRES = 3
MAX_CALLS = 40        # directory reads per source
SCAN_SECONDS = 25     # time budget per source
SHOW_LINES = 12       # titles listed in the result dialog
MAX_GROUPS = 15       # enough different series/folders, then stop reading
PROPS = ['title', 'genre', 'playcount', 'file', 'showtitle', 'season', 'episode', 'artist']


# --- reading sources -----------------------------------------------------
def _list_dir(path, media, depth):
    started = time.time()
    result = rpc('Files.GetDirectory', {'directory': path, 'media': media, 'properties': PROPS})
    files, dirs = [], []
    for entry in (result or {}).get('files', []):
        if not entry.get('file'):
            continue
        (dirs if entry.get('filetype') == 'directory' else files).append(entry)
    log('read d%d %s -> %d files, %d dirs, %d ms%s' % (
        depth, path, len(files), len(dirs), int((time.time() - started) * 1000),
        '' if result is not None else ' [FAILED]'))
    return files, dirs


def _genres(entry):
    genre = entry.get('genre') or []
    if isinstance(genre, str):
        genre = [genre]
    return [g.strip() for g in genre if g and g.strip()]


def _title(entry, group):
    title = entry.get('title') or entry.get('label') or entry['file']
    artist = entry.get('artist') or ''
    if isinstance(artist, list):
        artist = ', '.join(a for a in artist if a)
    show = entry.get('showtitle') or artist or group
    season, episode = entry.get('season'), entry.get('episode')
    tag = ''
    if isinstance(season, int) and isinstance(episode, int) and season >= 0 and episode > 0:
        tag = 'S%02dE%02d' % (season, episode)
    parts = []
    if show and show.lower() not in title.lower():
        parts.append(show)
    if tag:
        parts.append(tag)
    parts.append(title)
    return ' - '.join(parts)


def _collect(files, src, seen, found, group, inherited):
    for entry in files:
        path = entry['file']
        if path in seen:
            continue
        seen.add(path)
        found.append({
            'title': _title(entry, group),
            'file': path,
            # episodes often carry no genre themselves: inherit it from the series folder
            'genre': _genres(entry) or list(inherited),
            'playcount': int(entry.get('playcount') or 0),
            'media': src['media'],
            'source': src['name'],
            'group': group,
        })


def scan_source(src, limit, deadline, prog, seen):
    """Random dives: from the source folder into many different series/folders,
    each dive goes down until it reaches playable items (up to max depth)."""
    started = time.time()
    media = 'music' if src['media'] == 'audio' else 'video'
    max_depth = setting_int('max_depth', 4, 1, 6)
    found, groups = [], set()
    files, dirs = _list_dir(src['path'], media, 1)
    calls = 1
    root_files, root_dirs = len(files), len(dirs)
    _collect(files, src, seen, found, '', [])
    random.shuffle(dirs)

    def reason():
        if len(found) >= limit:
            return 'item limit'
        if len(groups) >= MAX_GROUPS:
            return 'enough series/folders'
        if calls >= MAX_CALLS:
            return 'read limit'
        if time.time() > deadline:
            return 'time budget'
        if prog.iscanceled():
            return 'cancelled'
        return ''

    exhausted = set()                 # folders without sub-folders are read only once
    while dirs and max_depth > 1 and not reason():
        before = len(found)
        for top in dirs:
            if reason():
                break
            if top['file'] in exhausted:
                continue
            group = top.get('label') or top['file']
            current, depth, genre = top['file'], 2, _genres(top)
            while calls < MAX_CALLS and time.time() < deadline:
                calls += 1
                files, subdirs = _list_dir(current, media, depth)
                _collect(files, src, seen, found, group, genre)
                if depth == 2 and not subdirs:
                    exhausted.add(top['file'])
                if files or depth >= max_depth or not subdirs:
                    if files:
                        groups.add(group)
                    break
                nxt = random.choice(subdirs)
                current, depth = nxt['file'], depth + 1
                genre = _genres(nxt) or genre
        if len(found) == before:      # a full round brought nothing new
            break
    stopped = reason() or 'nothing more to read'
    if len(found) > limit:
        found = random.sample(found, limit)
    log('source "%s" done: %d items (%d with genre, %d watched), %d series/folders, %d reads, '
        '%.1fs, root had %d files/%d dirs, stopped: %s, max depth %d, sample: %s' % (
            src['name'], len(found), sum(1 for i in found if i['genre']),
            sum(1 for i in found if i['playcount']), len(groups), calls, time.time() - started,
            root_files, root_dirs, stopped, max_depth, [i['title'] for i in found[:3]]))
    if not found:
        log('source "%s": NOTHING playable found - check path, depth setting and that the '
            'add-on lists files below this folder' % src['name'])
    return found


def scan(sources, per_limit):
    diag.log_environment()
    for src in sources:
        log('source: ' + diag.describe_source(src))
    prog = xbmcgui.DialogProgress()
    prog.create(tr(30000), tr(30023))
    pools, seen = [], set()
    try:
        for n, src in enumerate(sources):
            prog.update(int(100 * n / len(sources)), '%s\n%s' % (tr(30023), src['name']))
            limit = per_limit if src['media'] == 'video' else max(per_limit, AUDIO_MIN_POOL)
            pools.append(scan_source(src, limit, time.time() + SCAN_SECONDS, prog, seen))
            if prog.iscanceled():
                log('scan cancelled by user')
                return None
    finally:
        prog.close()
    return pools


# --- choosing ------------------------------------------------------------
def _genre_choice(pools):
    """None = cancelled, [] = no filter, else list of genres (max 3)."""
    counts = Counter(g for pool in pools for item in pool for g in item['genre'])
    log('genres in pool: %s' % dict(counts.most_common(10)))
    if not counts:
        return []
    names = [g for g, _ in counts.most_common()]
    labels = ['%s (%d)' % (g, counts[g]) for g in names]
    dlg = xbmcgui.Dialog()
    while True:
        idx = dlg.multiselect(tr(30024), labels)
        if idx is None:
            return None
        if len(idx) <= MAX_GENRES:
            return [names[i] for i in idx]
        notify(tr(30025))


def _filter(pools, genres, unseen):
    wanted = {g.lower() for g in genres}
    result = []
    for pool in pools:
        items = pool
        if wanted:
            items = [i for i in items if wanted & {g.lower() for g in i['genre']}]
        if unseen:
            items = [i for i in items if i['playcount'] == 0]
        result.append(items)
    return result


def _interleave(items):
    """Order items so different series/folders alternate."""
    by_group = {}
    for item in items:
        by_group.setdefault(item.get('group', ''), []).append(item)
    lists = list(by_group.values())
    for lst in lists:
        random.shuffle(lst)
    random.shuffle(lists)
    out = []
    while any(lists):
        for lst in lists:
            if lst:
                out.append(lst.pop())
    return out


def pick(pools, count):
    """Fair mix: sources take turns, inside a source series/folders take turns."""
    lists = [_interleave(p) for p in pools if p]
    out = []
    while len(out) < count and any(lists):
        for lst in lists:
            if lst and len(out) < count:
                out.append(lst.pop(0))
    random.shuffle(out)
    return out


def count_options(chosen_sources):
    """Music-only selection allows up to 50 titles, anything with video max. 10."""
    return COUNTS_AUDIO if all(s['media'] == 'audio' for s in chosen_sources) else COUNTS


def _log_pick(items):
    per_source = Counter(i['source'] for i in items)
    folders = len({(i['source'], i.get('group', '')) for i in items})
    log('pick: %d items from %d series/folders, per source: %s' % (len(items), folders, dict(per_source)))


# --- playing -------------------------------------------------------------
def play(items):
    if not items:
        return
    audio_only = all(i['media'] == 'audio' for i in items)
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC if audio_only else xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for item in items:
        li = xbmcgui.ListItem(item['title'], path=item['file'])
        kind = 'music' if item['media'] == 'audio' else 'video'
        tag = li.getMusicInfoTag() if kind == 'music' else li.getVideoInfoTag()
        if hasattr(tag, 'setTitle'):          # Kodi 20+
            tag.setTitle(item['title'])
        else:                                 # Kodi 19
            li.setInfo(kind, {'title': item['title']})
        playlist.add(item['file'], li)
    log('play: %d items, %s playlist, first: %s' % (
        len(items), 'music' if audio_only else 'video', items[0]['file']))
    xbmcgui.Window(10000).setProperty(ACTIVE_PROP, '1')   # service logs playback events
    xbmc.Player().play(playlist)


# --- main flow -----------------------------------------------------------
def run():
    dlg = xbmcgui.Dialog()
    sources = store.load_sources()
    if not sources:
        dlg.ok(tr(30000), tr(30006))
        return
    selected = dlg.multiselect(tr(30005), [s['name'] for s in sources])
    if not selected:
        return
    chosen = [sources[i] for i in selected]
    log('mode: generator, %d sources selected' % len(chosen))
    pools = scan(chosen, setting_int('per_source', 50, 10, 200))
    if pools is None:
        return
    if not any(pools):
        dlg.ok(tr(30000), tr(30028))
        return
    genres = _genre_choice(pools)
    if genres is None:
        return
    if genres and any(not i['genre'] for p in pools for i in p):
        notify(tr(30037))
    unseen = dlg.yesno(tr(30000), tr(30026))
    options = count_options(chosen)
    idx = dlg.select(tr(30027), [str(c) for c in options])
    if idx < 0:
        return
    count = options[idx]
    filtered = _filter(pools, genres, unseen)
    log('choice: genres=%s unseen=%s count=%d, pool per source before/after filter: %s' % (
        genres, unseen, count, [(len(a), len(b)) for a, b in zip(pools, filtered)]))

    while True:
        items = pick(filtered, count)
        if not items:
            log('pick: nothing left after filtering')
            dlg.ok(tr(30000), tr(30028))
            return
        _log_pick(items)
        lines = ['- ' + i['title'] for i in items[:SHOW_LINES]]
        if len(items) > SHOW_LINES:
            lines.append(tr(30042) % (len(items) - SHOW_LINES))
        text = (tr(30029) % len(items)) + '\n\n' + '\n'.join(lines)
        answer = dlg.yesnocustom(tr(30000), text, tr(30031), tr(30032), tr(30030))
        if answer == 2:      # roll again
            continue
        if answer == 1:      # start
            store.save_list(items)
            play(items)
        elif answer == 0:    # save only
            store.save_list(items)
        return


def quick():
    """One-tap mode: category (video/music) -> amount -> list is built and started."""
    dlg = xbmcgui.Dialog()
    sources = store.load_sources()
    if not sources:
        dlg.ok(tr(30000), tr(30006))
        return
    idx = dlg.select(tr(30043), [tr(30012), tr(30013)])
    if idx < 0:
        return
    media = ('video', 'audio')[idx]
    chosen = [s for s in sources if s['media'] == media]
    if not chosen:
        notify(tr(30045))
        return
    options = count_options(chosen)
    pos = dlg.select(tr(30027), [str(c) for c in options])
    if pos < 0:
        return
    count = options[pos]
    log('mode: quick, %s, %d sources, count %d' % (media, len(chosen), count))
    pools = scan(chosen, setting_int('per_source', 50, 10, 200))
    if pools is None:
        return
    items = []
    if setting_bool('quick_unseen', True):          # unwatched first, rest fills up
        items = pick(_filter(pools, [], True), count)
        log('quick: %d unwatched titles found' % len(items))
    if len(items) < count:
        have = {i['file'] for i in items}
        extra = [i for i in pick(pools, count) if i['file'] not in have]
        items += extra[:count - len(items)]
    if not items:
        log('quick: nothing found')
        dlg.ok(tr(30000), tr(30028))
        return
    random.shuffle(items)
    _log_pick(items)
    store.save_list(items)
    play(items)
