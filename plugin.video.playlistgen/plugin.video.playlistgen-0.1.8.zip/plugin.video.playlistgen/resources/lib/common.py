import json
import os
import re
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
ICON = os.path.join(_PATH, 'icon.png')
FANART = os.path.join(_PATH, 'fanart.jpg')
ART = {'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': FANART}
# own file name per add-on ID, so both versions can share one log folder without mixing
LOG_NAME = ADDON_ID.replace('plugin.video.', '') + '.log'
ACTIVE_PROP = ADDON_ID + '.active'     # window property: "this add-on started the playing list"
LOG_MAX = 500 * 1024

# --- masking of credentials -------------------------------------------------
_TOKEN_KEYS = (r'x-plex-token|plex[_-]?token|access[_-]?token|refresh[_-]?token|api[_-]?key|apikey|'
               r'token|password|passwd|pwd|secret|auth|sid|session')
_MASKS = (
    # scheme://user:pass@host  ->  scheme://***@host   (smb, ftp, http, nfs, webdav ...)
    (re.compile(r'(://)[^/@\s"\']+@'), r'\1***@'),
    # same, but URL-encoded inside plugin:// parameters
    (re.compile(r'(?i)(%3A//)[^/&\s"\']*?%40'), r'\1***%40'),
    # ?token=..., &password=..., "token": "...", also URL-encoded (%3D)
    (re.compile(r'(?i)((?:%s)(?:=|%%3D|":\s*"))[^&\s"\'%%]+' % _TOKEN_KEYS), r'\1***'),
)


def sanitize(text):
    text = str(text)
    for pattern, repl in _MASKS:
        text = pattern.sub(repl, text)
    return text


# --- helpers ------------------------------------------------------------
def tr(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def notify(message):
    xbmcgui.Dialog().notification(tr(30000), message, ICON, 4000)


def setting_int(key, default, lo, hi):
    # fresh Addon object so changed settings are picked up in the long-running service too
    try:
        value = int(xbmcaddon.Addon().getSetting(key))
    except (TypeError, ValueError):
        value = default
    return max(lo, min(hi, value))


def setting_bool(key, default):
    value = xbmcaddon.Addon().getSetting(key)
    return default if value == '' else value == 'true'


# --- log file (location chosen by the user, everything masked) -------------
_dir_cache = {}


def log_dir():
    raw = (xbmcaddon.Addon().getSetting('log_dir') or '').strip()
    if raw in _dir_cache:
        return _dir_cache[raw]
    path = PROFILE
    if raw:
        candidate = xbmcvfs.translatePath(raw)
        if '://' not in candidate:          # only local folders can be written with os
            try:
                os.makedirs(candidate, exist_ok=True)
                if os.access(candidate, os.W_OK):
                    path = candidate
            except OSError:
                pass
    _dir_cache[raw] = path
    return path


def log_file():
    return os.path.join(log_dir(), LOG_NAME)


def log(msg, level=xbmc.LOGDEBUG):
    """Own log file; kodi.log only gets errors. Credentials are always masked."""
    msg = sanitize(msg)
    if level >= xbmc.LOGERROR:
        xbmc.log('[%s] %s' % (ADDON_ID, msg), level)
    if not setting_bool('log_enabled', False):
        return
    try:
        path = log_file()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > LOG_MAX:
            os.replace(path, path + '.old')
        with open(path, 'a', encoding='utf-8') as fh:
            fh.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except OSError:
        pass


def rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except ValueError:
        log('RPC %s: invalid response' % method, xbmc.LOGERROR)
        return None
    if 'error' in response:
        log('RPC %s failed: %s' % (method, response['error']), xbmc.LOGERROR)
        return None
    return response.get('result')
