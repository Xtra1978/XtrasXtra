import xbmcgui

from . import store
from .common import notify, rpc, setting_int, tr

# (string id, path, media, depth)
PRESETS = [
    (30016, 'videodb://movies/titles/', 'video', 1),
    (30017, 'videodb://tvshows/titles/', 'video', 3),
    (30018, 'videodb://musicvideos/titles/', 'video', 1),
    (30019, 'musicdb://songs/', 'audio', 1),
]


def manage():
    idx = xbmcgui.Dialog().select(tr(30003), [tr(30004), tr(30014)])
    if idx == 0:
        add()
    elif idx == 1:
        remove()


def _ask_media():
    idx = xbmcgui.Dialog().select(tr(30011), [tr(30012), tr(30013)])
    return None if idx < 0 else ('video', 'audio')[idx]


def _list_dirs(path, media):
    result = rpc('Files.GetDirectory', {'directory': path,
                                        'media': 'music' if media == 'audio' else 'video'})
    return [(f.get('label') or f['file'], f['file'])
            for f in (result or {}).get('files', [])
            if f.get('filetype') == 'directory' and f.get('file')]


def _list_roots(kind, media):
    """Top level: installed add-ons (Composite, ARD, ...) or file sources."""
    dlg = xbmcgui.Dialog()
    idx = dlg.select(tr(30007), [tr(30040), tr(30041)])
    if idx < 0:
        return None
    if idx == 0:
        return _list_dirs('addons://sources/%s/' % kind, media)
    result = rpc('Files.GetSources', {'media': 'music' if media == 'audio' else 'video'})
    return [(s.get('label') or s['file'], s['file'])
            for s in (result or {}).get('sources', []) if s.get('file')]


def _browse():
    """Own folder browser: Dialog.browse() does not list video add-ons such as Composite."""
    media = _ask_media()
    if not media:
        return None
    dlg = xbmcgui.Dialog()
    entries = _list_roots('audio' if media == 'audio' else 'video', media)
    if entries is None:
        return None
    stack = []                       # (path, label, entries) to go back to
    path, label = None, ''
    while True:
        head = [tr(30038)] if path else []
        offset = len(head) + 1       # + the "back" row
        idx = dlg.select(label or tr(30007), head + [tr(30039)] + [e[0] for e in entries])
        if idx < 0:
            return None
        if path and idx == 0:
            return path, media, setting_int('max_depth', 4, 1, 6), label
        if idx == offset - 1:        # back
            if not stack:
                return None
            path, label, entries = stack.pop()
            continue
        stack.append((path, label, entries))
        label, path = entries[idx - offset]
        entries = _list_dirs(path, media)


def _favourite():
    result = rpc('Favourites.GetFavourites', {'properties': ['windowparameter', 'path']})
    favs = []
    for fav in (result or {}).get('favourites') or []:
        target = fav.get('windowparameter') or fav.get('path')
        if target and '://' in target and fav.get('type') != 'media':
            favs.append((fav.get('title') or target, target))
    if not favs:
        notify(tr(30020))
        return None
    idx = xbmcgui.Dialog().select(tr(30021), [f[0] for f in favs])
    if idx < 0:
        return None
    media = _ask_media()
    if not media:
        return None
    return favs[idx][1], media, setting_int('max_depth', 4, 1, 6), favs[idx][0]


def _preset():
    idx = xbmcgui.Dialog().select(tr(30009), [tr(p[0]) for p in PRESETS])
    if idx < 0:
        return None
    sid, path, media, depth = PRESETS[idx]
    return path, media, depth, tr(sid)


def add():
    dlg = xbmcgui.Dialog()
    idx = dlg.select(tr(30004), [tr(30007), tr(30008), tr(30009)])
    if idx < 0:
        return
    picked = (_browse, _favourite, _preset)[idx]()
    if not picked:
        return
    path, media, depth, suggestion = picked
    name = dlg.input(tr(30010), defaultt=suggestion)
    if not name:
        return
    store.add_source(name, path, media, depth)
    notify(tr(30022))


def remove():
    sources = store.load_sources()
    if not sources:
        notify(tr(30006))
        return
    idx = xbmcgui.Dialog().select(tr(30014), [s['name'] for s in sources])
    if idx >= 0 and xbmcgui.Dialog().yesno(tr(30000), tr(30015)):
        store.remove_source(sources[idx]['id'])
