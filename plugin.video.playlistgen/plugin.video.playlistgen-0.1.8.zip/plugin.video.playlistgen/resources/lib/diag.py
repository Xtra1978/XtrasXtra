import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import store
from .common import ADDON_ID, LOG_NAME, log, log_dir, log_file, notify, sanitize, tr

_SETTING_KEYS = ('ttl_hours', 'per_source', 'max_depth', 'quick_unseen', 'log_enabled', 'log_dir')


def environment():
    addon = xbmcaddon.Addon()
    return [
        'addon: %s %s' % (ADDON_ID, addon.getAddonInfo('version')),
        'kodi: %s' % xbmc.getInfoLabel('System.BuildVersion'),
        'os: %s' % xbmc.getInfoLabel('System.OSVersionInfo'),
        'python: %s' % sys.version.split()[0],
        'settings: ' + ', '.join('%s=%s' % (k, addon.getSetting(k) or '-') for k in _SETTING_KEYS),
    ]


def log_environment():
    for line in environment():
        log('env ' + line)


def describe_source(src):
    return '"%s" media=%s path=%s' % (src['name'], src['media'], src['path'])


def _read_lines(path):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as fh:
            return fh.read().splitlines()
    except OSError:
        return []


def _kodi_log_excerpt():
    lines = _read_lines(xbmcvfs.translatePath('special://logpath/kodi.log'))
    head = [l for l in lines[:60] if 'Starting Kodi' in l or 'Running on' in l]
    key = [l for l in lines if ADDON_ID in l or 'playlistgen' in l or ' ERROR ' in l
           or 'Traceback' in l or 'Error Type' in l]
    return head + ['[...]'] + key[-150:]


def export():
    """Write one masked diagnosis file into the user's log folder."""
    parts = ['== environment =='] + environment()
    parts += ['', '== sources =='] + [describe_source(s) for s in store.load_sources()]
    parts += ['', '== add-on log (last 400 lines) =='] + _read_lines(log_file())[-400:]
    parts += ['', '== kodi.log (header + add-on/error lines) =='] + _kodi_log_excerpt()
    path = os.path.join(log_dir(), '%s_diagnose_%s.txt' % (LOG_NAME[:-4], time.strftime('%Y%m%d_%H%M%S')))
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(sanitize('\n'.join(parts)) + '\n')
    except OSError:
        return None
    return path


def menu():
    dlg = xbmcgui.Dialog()
    idx = dlg.select(tr(30046), [tr(30047), tr(30048), tr(30049), tr(30050)])
    if idx == 0:
        lines = _read_lines(log_file())[-300:]
        if lines:
            dlg.textviewer(tr(30047), '\n'.join(lines))
        else:
            notify(tr(30051))
    elif idx == 1:
        path = export()
        dlg.ok(tr(30000), (tr(30052) % path) if path else tr(30055))
    elif idx == 2:
        try:
            os.remove(log_file())
        except OSError:
            pass
        notify(tr(30054))
    elif idx == 3:
        dlg.ok(tr(30000), tr(30053) % log_file())
