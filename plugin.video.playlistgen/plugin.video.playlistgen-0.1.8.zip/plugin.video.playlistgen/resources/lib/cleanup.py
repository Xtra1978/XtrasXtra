import os
import time

from . import store
from .common import log, setting_int


def ttl_seconds():
    return setting_int('ttl_hours', 24, 1, 72) * 3600


def run():
    """Delete expired (or broken) saved lists. Safe to call at any time."""
    now = time.time()
    ttl = ttl_seconds()
    for path, data in store.iter_lists():
        expired = data is None or now - data.get('created', 0) > ttl
        if expired:
            try:
                os.remove(path)
                log('removed expired list %s' % os.path.basename(path))
            except OSError:
                pass
