# -*- coding: utf-8 -*-
"""
RSN.Radio – Kodi-Musik-Addon

Spielt alle Sender des RSN-Netzwerks (Radio Summernight, Aarau/Rüti CH) ab.
Die Senderliste kommt vollstaendig aus resources/lib/channels.py, die
Stream-URL-Logik aus resources/lib/stream.py - es gibt keine hartcodierten
Sender- oder Stream-Angaben in dieser Datei.
"""

import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import api, stream
from resources.lib.channels import CHANNELS, get_channel

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

STATION_PAGE_BASE = "https://rsn.radio/"


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    """Schreibt ins Kodi-Log. DEBUG-Meldungen nur bei aktivierter
    erweiterter Protokollierung in den Addon-Einstellungen."""
    if level == xbmc.LOGDEBUG and not ADDON.getSettingBool("debug_logging"):
        return
    xbmc.log("[%s] %s" % (ADDON_ID, message), level=level)


def logo_path(filename):
    return "%sresources/media/%s" % (ADDON_PATH.rstrip("/") + "/", filename)


def get_nowplaying_text(slug):
    if not ADDON.getSettingBool("show_nowplaying"):
        return None
    song = api.get_current_song(slug, log)
    if not song:
        return None
    title = song.get("title") or _(30030)
    artist = song.get("artist") or _(30031)
    return _(30003) % (artist, title)


def list_root():
    xbmcplugin.setPluginCategory(HANDLE, "RSN.Radio")
    xbmcplugin.setContent(HANDLE, "songs")

    fanart = ADDON.getAddonInfo("fanart")

    for channel in CHANNELS:
        icon = logo_path(channel["logo"])
        label = channel["name"]

        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({"icon": icon, "thumb": icon, "fanart": fanart})
        list_item.setProperty("IsPlayable", "true")
        list_item.setInfo("music", {
            "title": channel["name"],
            "comment": _(channel["subtitle_id"]),
        })

        context_menu = [(
            _(30002),
            "RunPlugin(%s?action=info&slug=%s)" % (BASE_URL, channel["slug"]),
        )]
        list_item.addContextMenuItems(context_menu)

        play_url = "%s?action=play&slug=%s" % (BASE_URL, channel["slug"])
        xbmcplugin.addDirectoryItem(HANDLE, play_url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play(slug):
    channel = get_channel(slug)
    if not channel:
        xbmcgui.Dialog().notification("RSN.Radio", _(30040), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    url = stream.get_stream_url(slug)
    log("Starte Wiedergabe von '%s': %s" % (channel["name"], url))

    list_item = xbmcgui.ListItem(path=url)
    list_item.setMimeType("audio/mpeg")
    list_item.setContentLookup(False)
    list_item.setArt({"icon": logo_path(channel["logo"]), "thumb": logo_path(channel["logo"])})
    list_item.setInfo("music", {"title": "%s – Live" % channel["name"]})
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)


def show_info(slug):
    channel = get_channel(slug)
    if not channel:
        return

    url = stream.get_stream_url(slug)
    page = STATION_PAGE_BASE + channel["slug"]

    lines = [
        _(channel["subtitle_id"]),
        "",
        "%s: %s" % (_(30007), url),
        "%s: %s" % (_(30008), page),
    ]
    nowplaying = get_nowplaying_text(slug)
    if nowplaying:
        lines.insert(1, nowplaying)
        lines.insert(2, "")

    xbmcgui.Dialog().textviewer(channel["name"], "\n".join(lines))


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get("action")
    slug = params.get("slug")

    if action == "play" and slug:
        play(slug)
    elif action == "info" and slug:
        show_info(slug)
    else:
        list_root()


if __name__ == "__main__":
    router(sys.argv[2][1:])
