# -*- coding: utf-8 -*-
"""
"Jetzt läuft"-Abfrage über die öffentliche laut.fm-API.

Da RSN.Radio technisch über laut.fm gehostet wird (siehe stream.py), lässt
sich der aktuell gespielte Titel über die öffentliche, unauthentifizierte
laut.fm-API abfragen:

    https://api.laut.fm/station/<slug>/current_song

Diese Funktion ist bewusst defensiv: Jeder Fehler (Netzwerk, Format,
fehlendes Feld) fuehrt lediglich dazu, dass kein "Jetzt läuft"-Text
angezeigt wird - die Wiedergabe ist davon nie betroffen.
"""

import json
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
TIMEOUT_SECONDS = 4

DEFAULT_API_TEMPLATE = "https://api.laut.fm/station/{slug}/current_song"


def get_current_song(slug, log=None):
    """
    Liest den aktuellen Titel fuer den Sender <slug> ueber die laut.fm-API.

    :return: dict {'title': str|None, 'artist': str|None} oder None
    """
    template = ADDON.getSetting("nowplaying_api_template") or DEFAULT_API_TEMPLATE
    url = template.replace("{slug}", slug)

    try:
        with urlopen(url, timeout=TIMEOUT_SECONDS) as response:
            raw = response.read().decode("utf-8", errors="replace")

        data = json.loads(raw)

        title = data.get("title")
        artist = data.get("artist")
        # Die laut.fm-API liefert den Interpreten meist als verschachteltes
        # Objekt {"name": "..."} - hier defensiv beide Formen abfangen.
        if isinstance(artist, dict):
            artist = artist.get("name")

        if not title and not artist:
            return None
        return {"title": title or None, "artist": artist or None}

    except (URLError, HTTPError, ValueError, AttributeError, TypeError) as exc:
        if log:
            log("Jetzt-laeuft-Abfrage nicht verwertbar: %s" % exc, xbmc.LOGDEBUG)
        return None
    except Exception as exc:  # Sicherheitsnetz - darf Kodi nie zum Absturz bringen
        if log:
            log("Unerwarteter Fehler bei Jetzt-laeuft-Abfrage: %s" % exc, xbmc.LOGDEBUG)
        return None

