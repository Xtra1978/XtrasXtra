# -*- coding: utf-8 -*-
"""
Zentrale Senderliste des RSN-Netzwerks (Radio Summernight, Aarau/Rüti CH).

Dies ist die EINZIGE Stelle im Addon, an der die 12 Sender mit ihren
Eigenschaften (Slug, Name, Logo-Datei) hinterlegt sind. main.py baut daraus
dynamisch das Menü auf - es gibt keine hartcodierten Sender-Einträge im
Code selbst.

Wichtig zum Feld "slug":
Der Slug entspricht dem Pfad-Bestandteil auf https://rsn.radio/<slug> und
wird zugleich als Mountpoint-Bestandteil für die Stream-URL verwendet
(siehe stream.py). Sollte sich am Streaming-Server ein abweichendes
Mountpoint-Schema herausstellen, kann das zentral in stream.py angepasst
werden, ohne diese Liste zu verändern.
"""

# Hinweis zu "lebkuchen-radio", "rock-music" und "country": Fuer diese drei
# Sender wurde der laut.fm-Slug nicht einzeln per Browser-Konsole bestaetigt
# (lief ohne Musik). Sie folgen dem gleichen, fuer 13 andere Sender bereits
# bestaetigten Muster (rsn.radio-Pfad == laut.fm-Slug). Sollte einer davon
# nicht abspielen, bitte kurz Bescheid geben.

CHANNELS = [
    {
        "slug": "radiosummernight",
        "name": "Radio Summernight",
        "subtitle_id": 30101,
        "logo": "radiosummernight.png",
    },
    {
        "slug": "80er-90er",
        "name": "80er/90er",
        "subtitle_id": 30102,
        "logo": "80er-90er.png",
    },
    {
        "slug": "1000weihnachten",
        "name": "1000 Weihnachten",
        "subtitle_id": 30103,
        "logo": "1000weihnachten.png",
    },
    {
        "slug": "kuschelrock",
        "name": "Kuschelrock",
        "subtitle_id": 30104,
        "logo": "kuschelrock.png",
    },
    {
        "slug": "deutschrock",
        "name": "Deutschrock",
        "subtitle_id": 30105,
        "logo": "deutschrock.png",
    },
    {
        "slug": "1000hiphop",
        "name": "1000 Hiphop",
        "subtitle_id": 30106,
        "logo": "1000hiphop.png",
    },
    {
        "slug": "rap",
        "name": "Rap",
        "subtitle_id": 30107,
        "logo": "rap.png",
    },
    {
        "slug": "trap",
        "name": "Trap",
        "subtitle_id": 30108,
        "logo": "trap.png",
    },
    {
        "slug": "1000techno",
        "name": "1000 Techno",
        "subtitle_id": 30109,
        "logo": "1000techno.png",
    },
    {
        "slug": "1000discofox",
        "name": "1000 Discofox",
        "subtitle_id": 30110,
        "logo": "1000discofox.png",
    },
    {
        "slug": "1000dance",
        "name": "1000 Dance",
        "subtitle_id": 30111,
        "logo": "1000dance.png",
    },
    {
        "slug": "1000indie",
        "name": "1000 Indie",
        "subtitle_id": 30112,
        "logo": "1000indie.png",
    },
    {
        "slug": "lebkuchen-radio",
        "name": "Lebkuchen Radio",
        "subtitle_id": 30113,
        "logo": "lebkuchen-radio.png",
    },
    {
        "slug": "rock-music",
        "name": "Rock Music",
        "subtitle_id": 30114,
        "logo": "rock-music.png",
    },
    {
        "slug": "country",
        "name": "Country Music",
        "subtitle_id": 30115,
        "logo": "country.png",
    },
]


def get_channel(slug):
    """Liefert den Kanal-Eintrag zu einem Slug oder None."""
    for channel in CHANNELS:
        if channel["slug"] == slug:
            return channel
    return None
