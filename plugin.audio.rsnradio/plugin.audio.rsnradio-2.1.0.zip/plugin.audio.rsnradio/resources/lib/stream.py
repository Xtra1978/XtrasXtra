# -*- coding: utf-8 -*-
"""
Zentrale Stream-URL-Auflösung für RSN-Sender.

RSN.Radio hostet seine Streams technisch ueber laut.fm. Verifiziert per
Browser-Konsole (document.querySelector('audio').currentSrc) am Beispiel
"Radio Summernight":

    https://radiosummernight.stream.laut.fm/radiosummernight?ref=vtuner

Das Muster lautet demnach:

    https://<slug>.stream.laut.fm/<slug>

wobei <slug> exakt dem Pfad auf rsn.radio (siehe channels.py) entspricht.
Fuer "Deutschrock" wurde das zusaetzlich inhaltlich bestaetigt (Songtitel
"Rauhbein" passte zu laut.fm/deutschrock). Die uebrigen 10 Sender folgen
dem gleichen, einheitlichen Muster.

Die Vorlage ist trotzdem ueber die Addon-Einstellungen
("Stream-URL-Vorlage", Platzhalter {slug}) ueberschreibbar, falls sich bei
einzelnen Sendern doch eine Abweichung zeigen sollte - der Code muss dafuer
nicht angefasst werden.
"""

import xbmcaddon

ADDON = xbmcaddon.Addon()

# Verifiziertes Muster (siehe Hinweis oben). {slug} wird durch den
# jeweiligen Sender-Slug aus channels.py ersetzt. Ueberschreibbar in den
# Addon-Einstellungen (Einstellung "stream_url_template").
DEFAULT_STREAM_TEMPLATE = "https://{slug}.stream.laut.fm/{slug}?ref=vtuner"


def get_stream_url(slug):
    """
    Baut die Stream-URL fuer einen Sender-Slug aus der konfigurierbaren
    URL-Vorlage zusammen. Es gibt keine hartcodierten Stream-Pfade pro
    Sender - die Vorlage kommt vollstaendig aus den Addon-Einstellungen.
    """
    template = ADDON.getSetting("stream_url_template") or DEFAULT_STREAM_TEMPLATE
    return template.replace("{slug}", slug)

