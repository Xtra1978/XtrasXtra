#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI-Modul: Menues und Listen fuer das EFG Kodi Addon."""

from urllib.parse import urlencode, quote
import xbmcgui
import xbmcplugin
from resources.lib import api
from resources.lib.api import EFG_CATEGORIES

ADDON_ICON   = 'special://home/addons/plugin.video.efg/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.video.efg/resources/media/fanart.jpg'
ICON_DIR     = 'special://home/addons/plugin.video.efg/resources/media/icons/'
PER_PAGE     = 24


def build_url(base_url, params):
    return '{0}?{1}'.format(base_url, urlencode(params))


def _li(label, thumb='', info=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        'icon':   thumb or ADDON_ICON,
        'thumb':  thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
        'poster': thumb or ADDON_ICON,
    })
    if info:
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _end(handle, content='movies'):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def _notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification('European Film Gateway', msg, icon, 4000)


# -----------------------------------------------------------------------
# Hauptmenue
# -----------------------------------------------------------------------

def show_main_menu(base_url, handle, addon):
    xbmcplugin.setPluginCategory(handle, 'European Film Gateway')

    # Suche ganz oben
    url = build_url(base_url, {'mode': 'search'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url,
        listitem=_li('Suchen', thumb=ICON_DIR+'search.png'), isFolder=True)

    # Kategorien
    for cat in EFG_CATEGORIES:
        url   = build_url(base_url, {'mode': 'category', 'cat_id': cat['id']})
        icon  = ICON_DIR + cat.get('icon', 'all.png')
        label = cat['label']
        xbmcplugin.addDirectoryItem(handle=handle, url=url,
            listitem=_li(label, thumb=icon), isFolder=True)

    _end(handle, 'files')


# -----------------------------------------------------------------------
# Kategorie-Ansicht
# -----------------------------------------------------------------------

def show_category(base_url, handle, addon, cat_id, page=1):
    cat = api.get_category_by_id(cat_id)
    if not cat:
        _notify('Kategorie nicht gefunden.', error=True)
        _end(handle)
        return

    xbmcplugin.setPluginCategory(handle, f'EFG – {cat["label"]}')

    films, total = api.search_films(
        query=cat['query'],
        page=page,
        per_page=PER_PAGE,
    )

    if not films:
        _notify('Keine Filme gefunden. Bitte spaeter erneut versuchen.')
        _end(handle)
        return

    for film in films:
        _add_film_item(base_url, handle, film)

    # Naechste Seite
    if page * PER_PAGE < total:
        next_url = build_url(base_url, {
            'mode':   'category',
            'cat_id': cat_id,
            'page':   page + 1,
        })
        li_next = _li(f'Weiter  (Seite {page + 1} / {total // PER_PAGE + 1})',
                      thumb=ADDON_ICON)
        xbmcplugin.addDirectoryItem(handle=handle, url=next_url,
                                    listitem=li_next, isFolder=True)

    _end(handle)


# -----------------------------------------------------------------------
# Film-Item
# -----------------------------------------------------------------------

def _add_film_item(base_url, handle, film):
    """Fuegt ein Film-Item zur Liste hinzu."""
    record_id = film.get('id', '')
    title     = film.get('title', 'Unbekannt')
    year      = film.get('year', '')
    thumb     = film.get('thumb', '')
    desc      = film.get('desc', '')
    creator   = film.get('creator', '')
    provider  = film.get('provider', '')
    has_stream= film.get('has_stream', False)

    display = title
    if year:
        display += f'  [{year}]'

    # Kein Stream: markieren aber trotzdem anzeigen
    if not has_stream:
        display = f'[NO STREAM]  {display}'

    info = {
        'title':     title,
        'year':      int(year[:4]) if year and year[:4].isdigit() else 0,
        'plot':      f'{desc}\n\nArchiv: {provider}' if provider else desc,
        'director':  creator,
        'mediatype': 'movie',
        'studio':    provider,
    }

    # Direkt abspielen wenn Stream-URL vorhanden, sonst Detail-Seite
    if has_stream:
        stream_url = film.get('stream_url', '')
        mime       = api._guess_mime(stream_url)
        params = {
            'mode':  'play',
            'url':   stream_url,
            'title': title,
            'thumb': thumb,
            'mime':  mime,
        }
        url = build_url(base_url, params)
        li  = _li(display, thumb=thumb, info=info, playable=True)
        # Kontextmenue: Detail-Seite fuer weitere Quellen
        ctx = [(
            'Weitere Quellen / Details',
            f'RunPlugin({build_url(base_url, {"mode": "film_detail", "record_id": record_id})})'
        )]
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    else:
        # Kein direkter Stream: Detail-Seite oeffnen
        url = build_url(base_url, {'mode': 'film_detail', 'record_id': record_id})
        li  = _li(display, thumb=thumb, info=info)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)


# -----------------------------------------------------------------------
# Film-Detail
# -----------------------------------------------------------------------

def show_film_detail(base_url, handle, addon, record_id):
    """
    Laedt alle Details eines Films und zeigt alle verfuegbaren Stream-Optionen.
    """
    film = api.get_record(record_id)

    title  = film.get('title', 'Unbekannt')
    year   = film.get('year', '')
    thumb  = film.get('thumb', '')
    desc   = film.get('desc', '')
    videos = film.get('videos', [])

    xbmcplugin.setPluginCategory(handle, f'{title} [{year}]')

    if not videos:
        _notify('Kein abspielbarer Stream gefunden.')
        # Fallback: Archiv-Seite anzeigen
        shown_at = film.get('shown_at', '')
        if shown_at:
            url = build_url(base_url, {'mode': 'open_web', 'url': shown_at})
            li  = _li('Im Archiv ansehen (Browser)', thumb=ADDON_ICON)
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        _end(handle)
        return

    # Alle verfuegbaren Streams anzeigen
    for i, v in enumerate(videos):
        v_url   = v.get('url', '')
        mime    = v.get('mime', '')
        width   = v.get('width', 0)
        height  = v.get('height', 0)
        dur     = v.get('dur', 0)

        # Qualitaets-Label
        if width and height:
            qual = f'{width}x{height}'
            if height >= 1080:  qual += ' (Full HD)'
            elif height >= 720: qual += ' (HD)'
        else:
            qual = mime.split('/')[-1].upper() if mime else 'Stream'

        if dur:
            mins = dur // 60; secs = dur % 60
            qual += f'  {mins}:{secs:02d}'

        label = f'Abspielen  –  {qual}'
        if i == 0:
            label = f'Beste Qualitaet  –  {qual}'

        info = {
            'title':     title,
            'year':      int(year) if year.isdigit() else 0,
            'plot':      desc,
            'duration':  dur,
            'mediatype': 'movie',
        }
        params = {
            'mode':  'play',
            'url':   v_url,
            'title': title,
            'thumb': thumb,
            'mime':  mime,
        }
        url = build_url(base_url, params)
        li  = _li(label, thumb=thumb, info=info, playable=True)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    # Archiv-Link
    shown_at = film.get('shown_at', '')
    if shown_at:
        url = build_url(base_url, {'mode': 'open_web', 'url': shown_at})
        li  = _li('Im Originalarchiv ansehen', thumb=ADDON_ICON)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    _end(handle)


# -----------------------------------------------------------------------
# Suche
# -----------------------------------------------------------------------

def ask_search(addon):
    return xbmcgui.Dialog().input(
        'European Film Gateway – Film suchen',
        type=xbmcgui.INPUT_ALPHANUM)


def show_search_results(base_url, handle, addon, query):
    xbmcplugin.setPluginCategory(handle, f'EFG – Suche: {query}')

    films, total = api.search_films(query=query, page=1, per_page=30)

    if not films:
        _notify(f'Keine Ergebnisse fuer "{query}".')
        _end(handle)
        return

    for film in films:
        _add_film_item(base_url, handle, film)

    _end(handle)
