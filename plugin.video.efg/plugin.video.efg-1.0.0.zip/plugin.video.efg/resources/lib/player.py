#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Player-Modul: Wiedergabe von EFG-Streams.

Besonderheiten gegenueber normalem Streaming:
- EFG-Streams kommen aus historischen Archiven: MP4, WebM, OGV, AVI, MPEG
- Manche URLs sind Resolver/Proxy-URLs die auf echte Streams zeigen
- HLS-Streams (m3u8) werden via inputstream.adaptive abgespielt
- Fallback: direkte Wiedergabe ohne MIME-Angabe
"""

import xbmc
import xbmcgui
import xbmcplugin
from urllib.request import urlopen, Request
from urllib.error   import URLError

ADDON_ICON   = 'special://home/addons/plugin.video.efg/resources/media/icon.png'
ADDON_FANART = 'special://home/addons/plugin.video.efg/resources/media/fanart.jpg'
UA           = 'KodiEFGAddon/1.0 (kodi.tv)'


def play(handle, url, title, thumb, mime=''):
    """Startet die Wiedergabe eines EFG-Streams."""
    if not url:
        xbmcgui.Dialog().notification(
            'European Film Gateway', 'Keine Stream-URL verfuegbar.',
            xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    xbmc.log(f'[EFG] Play: {title} | {url[:80]} | mime={mime}', xbmc.LOGINFO)

    # URL vorher aufwaermen (verhindert sofortigen Abbruch)
    _warmup(url)

    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setArt({
        'thumb':  thumb or ADDON_ICON,
        'icon':   thumb or ADDON_ICON,
        'fanart': ADDON_FANART,
        'poster': thumb or ADDON_ICON,
    })
    li.setInfo('video', {
        'title':     title,
        'mediatype': 'movie',
    })

    # MIME-Typ und Inputstream setzen
    mime_lower = mime.lower()

    if 'mpegurl' in mime_lower or url.lower().endswith('.m3u8'):
        # HLS-Stream via inputstream.adaptive
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)

    elif 'mp4' in mime_lower or url.lower().split('?')[0].endswith('.mp4'):
        li.setMimeType('video/mp4')
        li.setContentLookup(False)

    elif 'webm' in mime_lower or url.lower().split('?')[0].endswith('.webm'):
        li.setMimeType('video/webm')
        li.setContentLookup(False)

    elif 'ogg' in mime_lower or url.lower().split('?')[0].endswith(('.ogv', '.ogg')):
        li.setMimeType('video/ogg')
        li.setContentLookup(False)

    elif 'mpeg' in mime_lower or url.lower().split('?')[0].endswith(('.mpg', '.mpeg')):
        li.setMimeType('video/mpeg')
        li.setContentLookup(False)

    elif 'x-msvideo' in mime_lower or url.lower().split('?')[0].endswith('.avi'):
        li.setMimeType('video/x-msvideo')
        li.setContentLookup(False)

    elif 'quicktime' in mime_lower or url.lower().split('?')[0].endswith('.mov'):
        li.setMimeType('video/quicktime')
        li.setContentLookup(False)

    else:
        # Unbekannter Typ: kein MIME setzen, Kodi erkennt selbst
        li.setContentLookup(True)

    xbmcplugin.setResolvedUrl(handle, True, li)


def _warmup(url, timeout=5):
    """HEAD-Request um den Stream-Link zu aktivieren."""
    try:
        req = Request(url, method='HEAD', headers={
            'User-Agent': UA,
            'Range':      'bytes=0-1023',
        })
        urlopen(req, timeout=timeout)
        xbmc.log(f'[EFG] Warmup OK', xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f'[EFG] Warmup ignoriert: {e}', xbmc.LOGDEBUG)
