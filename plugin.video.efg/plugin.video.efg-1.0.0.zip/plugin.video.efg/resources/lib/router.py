#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""URL-Router fuer das EFG Kodi Addon."""

from urllib.parse import parse_qsl
from resources.lib import ui, player
import xbmc
import xbmcplugin


def dispatch(base_url, handle, args, addon):
    params = dict(parse_qsl(args.lstrip('?')))
    mode   = params.get('mode', 'main')

    if mode == 'main':
        ui.show_main_menu(base_url, handle, addon)
    elif mode == 'category':
        cat_id = params.get('cat_id', 'all')
        page   = int(params.get('page', 1))
        ui.show_category(base_url, handle, addon, cat_id, page)
    elif mode == 'search':
        query = params.get('query', '') or ui.ask_search(addon)
        if query:
            ui.show_search_results(base_url, handle, addon, query)
    elif mode == 'film_detail':
        record_id = params.get('record_id', '')
        ui.show_film_detail(base_url, handle, addon, record_id)
    elif mode == 'play':
        player.play(
            handle=handle,
            url=params.get('url', ''),
            title=params.get('title', ''),
            thumb=params.get('thumb', ''),
            mime=params.get('mime', ''),
        )
    elif mode == 'open_web':
        url = params.get('url', '')
        if url:
            xbmc.executebuiltin(f'StartAndroidActivity(,,,{url})')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    else:
        ui.show_main_menu(base_url, handle, addon)
