#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API-Modul: European Film Gateway – drei Quellen ohne API-Key.

Reihenfolge:
  1. EUscreen Portal API  (groesster EFG-Videopartner)
  2. Europeana Search API (ohne wskey, TYPE:VIDEO)
  3. Internet Archive     (direkter Fallback mit MP4-URLs)
"""

import json
import time
import xbmc
from urllib.request import urlopen, Request
from urllib.parse   import urlencode, quote
from urllib.error   import HTTPError, URLError

EUROPEANA  = 'https://api.europeana.eu/record/v2/search.json'
UA         = 'Mozilla/5.0 (compatible; KodiEFGAddon/1.0; kodi.tv)'
TIMEOUT    = 20

EFG_CATEGORIES = [
    {'id': 'all',         'label': 'Alle Filme',            'query': '',                      'icon': 'all.png'},
    {'id': 'silent',      'label': 'Stummfilme',            'query': 'silent film',           'icon': 'silent.png'},
    {'id': 'newsreel',    'label': 'Wochenschauen',         'query': 'newsreel',              'icon': 'newsreel.png'},
    {'id': 'documentary', 'label': 'Dokumentarfilme',       'query': 'documentary',           'icon': 'documentary.png'},
    {'id': 'wwi',         'label': 'Erster Weltkrieg',      'query': 'world war 1914',        'icon': 'wwi.png'},
    {'id': 'wwii',        'label': 'Zweiter Weltkrieg',     'query': 'world war 1939',        'icon': 'wwii.png'},
    {'id': 'avantgarde',  'label': 'Avantgarde',            'query': 'avantgarde',            'icon': 'avantgarde.png'},
    {'id': 'germany',     'label': 'Deutsche Filme',        'query': 'Germany film',          'icon': 'germany.png'},
    {'id': 'france',      'label': 'Franzoesische Filme',   'query': 'France cinema',         'icon': 'france.png'},
    {'id': 'italy',       'label': 'Italienische Filme',    'query': 'Italy cinema',          'icon': 'italy.png'},
    {'id': 'animation',   'label': 'Animationsfilme',       'query': 'animation cartoon',     'icon': 'animation.png'},
    {'id': 'science',     'label': 'Wissenschaft',          'query': 'science technology',    'icon': 'science.png'},
    {'id': 'propaganda',  'label': 'Propagandafilme',       'query': 'propaganda',            'icon': 'propaganda.png'},
    {'id': 'sport',       'label': 'Sport',                 'query': 'sport olympic',         'icon': 'sport.png'},
]


def _get(url, retries=2):
    for attempt in range(retries):
        try:
            xbmc.log(f'[EFG] GET {url[:120]}', xbmc.LOGDEBUG)
            req  = Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'})
            resp = urlopen(req, timeout=TIMEOUT)
            return json.loads(resp.read().decode('utf-8', errors='replace'))
        except HTTPError as e:
            if e.code == 429 and attempt < retries - 1:
                time.sleep(3)
            else:
                xbmc.log(f'[EFG] HTTP {e.code}: {url[:80]}', xbmc.LOGWARNING)
                return None
        except Exception as e:
            xbmc.log(f'[EFG] Fehler: {e}', xbmc.LOGWARNING)
            return None
    return None


# -----------------------------------------------------------------------
# Haupt-Suchfunktion – versucht drei Quellen
# -----------------------------------------------------------------------

def search_films(query='', page=1, per_page=24, extra_filters=None):
    films, total = _search_euscreen(query, page, per_page)
    if films:
        xbmc.log(f'[EFG] Quelle: EUscreen ({len(films)} Filme)', xbmc.LOGINFO)
        return films, total

    films, total = _search_europeana(query, page, per_page)
    if films:
        xbmc.log(f'[EFG] Quelle: Europeana ({len(films)} Filme)', xbmc.LOGINFO)
        return films, total

    films, total = _search_ia(query, page, per_page)
    xbmc.log(f'[EFG] Quelle: Internet Archive ({len(films)} Filme)', xbmc.LOGINFO)
    return films, total


# -----------------------------------------------------------------------
# 1. EUscreen
# -----------------------------------------------------------------------

def _search_euscreen(query, page=1, per_page=24):
    q = query if query else 'film history'
    params = {
        'q':      q,
        'rows':   per_page,
        'start':  (page - 1) * per_page,
        'wt':     'json',
        'fl':     'id,title,description,year,thumbnail,videoUrl,provider',
    }
    url  = 'https://portal.euscreen.eu/api/search?' + urlencode(params)
    data = _get(url)
    if not data:
        return [], 0
    docs  = data.get('response', {}).get('docs', [])
    total = data.get('response', {}).get('numFound', 0)
    films = [_parse_euscreen(d) for d in docs]
    films = [f for f in films if f]
    return films, total


def _parse_euscreen(doc):
    vid_id    = doc.get('id', '')
    title     = _first(doc.get('title', vid_id))
    desc      = _first(doc.get('description', ''))
    year      = str(doc.get('year', ''))[:4]
    thumb     = _first(doc.get('thumbnail', ''))
    video_url = _first(doc.get('videoUrl', ''))
    provider  = _first(doc.get('provider', 'EUscreen'))
    if not video_url:
        video_url = f'https://portal.euscreen.eu/item/{vid_id}'
    is_stream = (video_url.endswith(('.mp4', '.webm', '.ogv'))
                 or 'stream' in video_url.lower())
    return {
        'id':         vid_id,
        'title':      str(title),
        'year':       year,
        'desc':       _clean(str(desc)),
        'creator':    '',
        'provider':   str(provider),
        'thumb':      str(thumb),
        'stream_url': str(video_url),
        'shown_at':   f'https://portal.euscreen.eu/item/{vid_id}',
        'has_stream': is_stream,
    }


# -----------------------------------------------------------------------
# 2. Europeana (ohne wskey)
# -----------------------------------------------------------------------

def _search_europeana(query, page=1, per_page=24):
    q = query if query else 'film'

    # Versuch 1: nur TYPE:VIDEO + media:true (kein Provider-Filter)
    params = [
        ('query',       q),
        ('qf',          'TYPE:VIDEO'),
        ('rows',        str(per_page)),
        ('start',       str((page - 1) * per_page + 1)),
        ('profile',     'minimal'),
        ('media',       'true'),
        ('reusability', 'open'),
    ]
    url  = EUROPEANA + '?' + '&'.join(f'{k}={quote(str(v))}' for k, v in params)
    data = _get(url)

    if data and data.get('success') and data.get('items'):
        items  = data['items']
        total  = data.get('totalResults', len(items))
        films  = [_parse_europeana(i) for i in items]
        films  = [f for f in films if f]
        if films:
            return films, total

    return [], 0


def _parse_europeana(item):
    record_id = item.get('id', '')
    title     = _first(item.get('title', ['Unbekannt']))
    year      = _first(item.get('year', []))
    desc      = _first(item.get('dcDescription', []))
    creator   = _first(item.get('dcCreator', []))
    provider  = _first(item.get('dataProvider', []))
    thumb     = item.get('edmPreview', '')
    shown_by  = item.get('edmIsShownBy', '')
    shown_at  = item.get('edmIsShownAt', '')

    for field in [thumb, shown_by, shown_at]:
        if isinstance(field, list):
            field = field[0] if field else ''

    if isinstance(thumb,    list): thumb    = thumb[0]    if thumb    else ''
    if isinstance(shown_by, list): shown_by = shown_by[0] if shown_by else ''
    if isinstance(shown_at, list): shown_at = shown_at[0] if shown_at else ''

    return {
        'id':         record_id,
        'title':      str(title) if title else 'Unbekannt',
        'year':       str(year)[:4] if year else '',
        'desc':       _clean(str(desc) if desc else ''),
        'creator':    str(creator) if creator else '',
        'provider':   str(provider) if provider else 'Europeana',
        'thumb':      str(thumb) if thumb else '',
        'stream_url': str(shown_by) if shown_by else '',
        'shown_at':   str(shown_at) if shown_at else '',
        'has_stream': bool(shown_by),
    }


# -----------------------------------------------------------------------
# 3. Internet Archive (zuverlaessiger Fallback)
# -----------------------------------------------------------------------

def _search_ia(query, page=1, per_page=24):
    q = query if query else 'european film history'
    params = {
        'q':      (f'({q}) AND mediatype:movies AND date:[1895 TO 1975]'),
        'fl[]':   ['identifier', 'title', 'creator', 'date', 'description'],
        'rows':   per_page,
        'page':   page,
        'output': 'json',
        'sort[]': 'downloads desc',
    }
    url  = 'https://archive.org/advancedsearch.php?' + urlencode(params, doseq=True)
    data = _get(url)
    if not data:
        return [], 0
    docs  = data.get('response', {}).get('docs', [])
    total = data.get('response', {}).get('numFound', 0)
    films = [_parse_ia(d) for d in docs if d.get('identifier')]
    return films, total


def _parse_ia(doc):
    ia_id   = doc.get('identifier', '')
    title   = _first(doc.get('title', ia_id))
    creator = _first(doc.get('creator', ''))
    date    = _first(doc.get('date', ''))
    desc    = _first(doc.get('description', ''))
    year    = str(date)[:4] if date else ''
    return {
        'id':         ia_id,
        'title':      str(title),
        'year':       year,
        'desc':       _clean(str(desc)),
        'creator':    str(creator),
        'provider':   'Internet Archive',
        'thumb':      f'https://archive.org/services/img/{ia_id}',
        'stream_url': f'https://archive.org/download/{ia_id}/{ia_id}.mp4',
        'shown_at':   f'https://archive.org/details/{ia_id}',
        'has_stream': True,
    }


# -----------------------------------------------------------------------
# Record-Details
# -----------------------------------------------------------------------

def get_record(record_id):
    if not record_id.startswith('/'):
        return _get_ia_record(record_id)
    return _get_europeana_record(record_id)


def _get_ia_record(ia_id):
    data = _get(f'https://archive.org/metadata/{ia_id}')
    if not data:
        return {}
    meta  = data.get('metadata', {})
    files = data.get('files', [])
    title   = _first(meta.get('title', ia_id))
    date    = _first(meta.get('date', ''))
    desc    = _first(meta.get('description', ''))
    creator = _first(meta.get('creator', ''))
    year    = str(date)[:4] if date else ''
    videos  = []
    for fmt in ['mp4', 'ogv', 'webm']:
        for f in files:
            fname = f.get('name', '')
            if fname.lower().endswith('.' + fmt) \
               and 'thumb' not in fname.lower() \
               and 'sample' not in fname.lower():
                try:
                    size_mb  = int(f.get('size', 0)) // 1024 // 1024
                    size_str = f'{size_mb} MB' if size_mb else ''
                except (ValueError, TypeError):
                    size_str = ''
                videos.append({
                    'url':   f'https://archive.org/download/{ia_id}/{quote(fname)}',
                    'mime':  f'video/{fmt}',
                    'label': f'{fname}{" – " + size_str if size_str else ""}',
                    'score': 10,
                })
                break
        if videos:
            break
    if not videos:
        videos = [{'url': f'https://archive.org/download/{ia_id}/{ia_id}.mp4',
                   'mime': 'video/mp4', 'label': 'MP4 Stream', 'score': 5}]
    return {
        'title':    str(title),
        'year':     year,
        'desc':     _clean(str(desc)),
        'creator':  str(creator),
        'thumb':    f'https://archive.org/services/img/{ia_id}',
        'shown_at': f'https://archive.org/details/{ia_id}',
        'videos':   videos,
    }


def _get_europeana_record(record_id):
    data = _get(f'https://api.europeana.eu/record/v2{record_id}.json?profile=full')
    if not data or not data.get('success'):
        return {}
    obj  = data.get('object', {})
    aggs = obj.get('aggregations', [{}])
    agg  = aggs[0] if aggs else {}
    title    = _first(obj.get('title', []))
    shown_by = agg.get('edmIsShownBy', '')
    shown_at = agg.get('edmIsShownAt', '')
    thumb    = agg.get('edmPreview', '')
    if isinstance(shown_by, list): shown_by = shown_by[0] if shown_by else ''
    if isinstance(shown_at, list): shown_at = shown_at[0] if shown_at else ''
    if isinstance(thumb,    list): thumb    = thumb[0]    if thumb    else ''
    videos = []
    if shown_by:
        videos.append({'url': shown_by, 'mime': _guess_mime(shown_by),
                       'label': 'Stream', 'score': 5})
    return {
        'title':    str(title) if title else 'Unbekannt',
        'year':     '',
        'desc':     '',
        'creator':  '',
        'thumb':    str(thumb),
        'shown_at': str(shown_at),
        'videos':   videos,
    }


def get_category_by_id(cat_id):
    for cat in EFG_CATEGORIES:
        if cat['id'] == cat_id:
            return cat
    return None


def _guess_mime(url):
    u = url.lower().split('?')[0]
    if u.endswith('.mp4'):   return 'video/mp4'
    if u.endswith('.webm'):  return 'video/webm'
    if u.endswith('.ogv'):   return 'video/ogg'
    if u.endswith('.ogg'):   return 'video/ogg'
    if u.endswith('.avi'):   return 'video/x-msvideo'
    if u.endswith('.mov'):   return 'video/quicktime'
    if u.endswith('.mpg'):   return 'video/mpeg'
    if u.endswith('.m3u8'):  return 'application/x-mpegURL'
    return 'video/mp4'


def _first(val, default=''):
    if isinstance(val, list):
        return val[0] if val else default
    return val or default


def _clean(text):
    import re
    if not text:
        return ''
    return re.sub(r'<[^>]+>', '', str(text)).strip()[:400]
