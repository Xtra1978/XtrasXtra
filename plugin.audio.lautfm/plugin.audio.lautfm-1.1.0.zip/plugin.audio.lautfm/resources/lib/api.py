# -*- coding: utf-8 -*-
"""
api.py - Wrapper fuer die oeffentliche laut.fm API (https://api.laut.fm)

Endpunkte bestaetigt am 02.07.2026 gegen die offizielle Laut AG
Referenz-Bibliothek (github.com/laut-ag/api-browser) und live getestet.
WICHTIG: Keine ".json"-Endung an den Pfaden!

Basis-URL: https://api.laut.fm/
"""

import json
import urllib.request
import urllib.parse
import urllib.error

BASE_URL = "https://api.laut.fm"
USER_AGENT = "Kodi-Addon-plugin.audio.lautfm/1.0 (+https://kodinerds.net)"
TIMEOUT = 10


class LautFMError(Exception):
    """Wird ausgeloest, wenn die laut.fm API nicht erreichbar ist oder einen Fehler liefert."""
    pass


def _request(path, params=None):
    """Fuehrt einen GET-Request gegen die laut.fm API aus und liefert das geparste JSON zurueck."""
    url = BASE_URL + path
    if params:
        url += "?" + urllib.parse.urlencode(params)

    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = resp.read()
            return json.loads(data.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise LautFMError("HTTP %s bei %s" % (e.code, url))
    except urllib.error.URLError as e:
        raise LautFMError("Verbindung fehlgeschlagen: %s" % e.reason)
    except (ValueError, json.JSONDecodeError):
        raise LautFMError("Ungueltige Antwort von laut.fm (kein JSON)")


def _quote(value):
    """URL-encoded einen Pfad-Bestandteil (z.B. Genre-Namen mit Leerzeichen/Sonderzeichen wie 'R&B')."""
    return urllib.parse.quote(value, safe="")


# ---------------------------------------------------------------------------
# Allgemeine Endpunkte
# ---------------------------------------------------------------------------

def get_server_status():
    """GET /server_status -> {running, message}"""
    return _request("/server_status")


def get_genres():
    """
    GET /genres -> Liste von {name, score, related[]}, sortiert nach score (Popularitaet).
    Insgesamt ca. 580+ Genres.
    """
    return _request("/genres")


def get_letters():
    """GET /letters -> Liste der Anfangsbuchstaben aller Sendernamen, z.B. ['a','b','c',...]"""
    return _request("/letters")


def get_station_names():
    """GET /station_names -> Liste aller Sendernamen (Slugs) als Strings."""
    return _request("/station_names")


# ---------------------------------------------------------------------------
# Sender-Listen
# ---------------------------------------------------------------------------

def get_stations(limit=50, offset=0):
    """
    GET /stations -> paginierte Liste aller Sender.
    Antwortformat je nach API-Version ggf. {total, offset, limit, items:[...]}
    oder direkt eine Liste - wird in default.py defensiv behandelt.
    """
    return _request("/stations", {"limit": limit, "offset": offset})


def get_live_stations():
    """GET /stations/live -> Liste der Sender, die aktuell live senden."""
    return _request("/stations/live")


def get_stations_by_genre(genre, limit=50, offset=0):
    """GET /stations/genre/{genre} -> Sender eines bestimmten Genres."""
    return _request("/stations/genre/%s" % _quote(genre), {"limit": limit, "offset": offset})


def get_stations_by_letter(letter, limit=50, offset=0):
    """GET /stations/letter/{buchstabe} -> Sender, deren Name mit diesem Buchstaben beginnt."""
    return _request("/stations/letter/%s" % _quote(letter), {"limit": limit, "offset": offset})


def get_stations_by_number():
    """GET /stations/numbers -> Sender, deren Name mit einer Ziffer beginnt."""
    return _request("/stations/numbers")


# ---------------------------------------------------------------------------
# Einzelner Sender
# ---------------------------------------------------------------------------

def get_station(name):
    """
    GET /station/{name} -> Senderdetails.
    Bekannte Felder: name, display_name, page_url, stream_url, format,
    description, genres[], images{}, active, djs
    """
    return _request("/station/%s" % _quote(name))


def get_current_song(name):
    """GET /station/{name}/current_song -> aktuell laufender Titel."""
    return _request("/station/%s/current_song" % _quote(name))


def get_last_songs(name):
    """GET /station/{name}/last_songs -> zuletzt gespielte Titel."""
    return _request("/station/%s/last_songs" % _quote(name))


def get_listeners(name):
    """GET /station/{name}/listeners -> aktuelle Hoererzahl."""
    return _request("/station/%s/listeners" % _quote(name))


# ---------------------------------------------------------------------------
# Suche
# ---------------------------------------------------------------------------

def search_stations(query, limit=20, offset=0):
    """
    GET /search/stations?query=... -> Suchergebnisse, gruppiert nach Kategorien
    (z.B. current_artist, name, format). Struktur:
    {total, offset, next_offset, limit, results: [{categories, total, items: [{station, current_song}]}]}
    """
    return _request("/search/stations", {"query": query, "limit": limit, "offset": offset})
