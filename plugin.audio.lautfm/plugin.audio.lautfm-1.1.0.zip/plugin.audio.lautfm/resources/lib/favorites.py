# -*- coding: utf-8 -*-
"""
favorites.py - Lokale Favoritenverwaltung fuer plugin.audio.lautfm
Speichert eine einfache JSON-Liste in special://profile/addon_data/plugin.audio.lautfm/favorites.json
"""

import json
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()
PROFILE_DIR = ADDON.getAddonInfo("profile")
FAVORITES_FILE = PROFILE_DIR + "favorites.json"


def _ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)


def load_favorites():
    """Liefert die Liste der Favoriten als Liste von Dicts {name, display_name}."""
    _ensure_profile_dir()
    if not xbmcvfs.exists(FAVORITES_FILE):
        return []
    f = xbmcvfs.File(FAVORITES_FILE)
    try:
        content = f.read()
        if not content:
            return []
        return json.loads(content)
    except (ValueError, TypeError):
        return []
    finally:
        f.close()


def save_favorites(favorites):
    _ensure_profile_dir()
    f = xbmcvfs.File(FAVORITES_FILE, "w")
    try:
        f.write(json.dumps(favorites, ensure_ascii=False))
    finally:
        f.close()


def is_favorite(name):
    favorites = load_favorites()
    return any(fav["name"] == name for fav in favorites)


def add_favorite(name, display_name):
    favorites = load_favorites()
    if not any(fav["name"] == name for fav in favorites):
        favorites.append({"name": name, "display_name": display_name})
        save_favorites(favorites)


def remove_favorite(name):
    favorites = load_favorites()
    favorites = [fav for fav in favorites if fav["name"] != name]
    save_favorites(favorites)
