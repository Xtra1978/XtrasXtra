# -*- coding: utf-8 -*-
"""
utils.py - Hilfsfunktionen fuer plugin.audio.lautfm
"""

import re

_TAG_RE = re.compile(r"<[^>]+>")


def _clean(text, max_length=400):
    """
    Entfernt HTML-Tags und kuerzt Text auf eine Wortgrenze um max_length Zeichen.
    Nach Addon-Standard: Bricht an Wortgrenzen, kein hartes Abschneiden mitten im Wort.
    """
    if not text:
        return ""

    stripped = _TAG_RE.sub("", text).strip()
    stripped = re.sub(r"\s+", " ", stripped)

    if len(stripped) <= max_length:
        return stripped

    truncated = stripped[:max_length]
    last_space = truncated.rfind(" ")
    if last_space > 0:
        truncated = truncated[:last_space]
    return truncated + " ..."


def format_listener_count(count):
    """Formatiert Hoererzahlen mit Tausender-Trennzeichen, z.B. 1234 -> '1.234'."""
    try:
        return "{:,}".format(int(count)).replace(",", ".")
    except (ValueError, TypeError):
        return str(count)
