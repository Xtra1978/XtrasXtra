# -*- coding: utf-8 -*-
"""
default.py - plugin.audio.lautfm
Haupteinstiegspunkt des Kodi-Addons.

Navigationsstruktur:
  Genres (Top nach score / A-Z) -> Sender im Genre -> Wiedergabe
  Suche -> Sucheingabe -> Ergebnisse -> Wiedergabe
  Live jetzt -> aktuell live sendende Sender -> Wiedergabe
  Favoriten -> gespeicherte Sender -> Wiedergabe
  A-Z -> Buchstaben-Menue -> Sender -> Wiedergabe
"""

import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from resources.lib import api
from resources.lib import favorites
from resources.lib.utils import _clean, format_listener_count
from resources.lib.api import LautFMError

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo("path")
# Absoluter Pfad noetig, damit das Fanart in jeder Skin-Ansicht zuverlaessig
# als Hintergrund greift (relative Pfade wurden von manchen Skins nicht
# konsistent aufgeloest -> war Ursache des "kein Hintergrund"-Problems).
FANART_PATH = ADDON_PATH + "/fanart.jpg" if not ADDON_PATH.endswith("/") else ADDON_PATH + "fanart.jpg"


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def log(msg):
    if ADDON.getSettingBool("debug_logging"):
        xbmc.log("[plugin.audio.lautfm] %s" % msg, xbmc.LOGINFO)


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def get_params():
    return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))


def items_per_page():
    return ADDON.getSettingInt("items_per_page") or 50


def show_error(string_id):
    xbmcgui.Dialog().notification(_(30000), _(string_id), xbmcgui.NOTIFICATION_ERROR, 4000)


# ---------------------------------------------------------------------------
# Menu-Aufbau: Hauptmenue
# ---------------------------------------------------------------------------

def media_path(filename):
    # Absoluter Pfad noetig (siehe FANART_PATH weiter oben) - relative Pfade
    # wie "resources/media/..." wurden von der Skin nicht zuverlaessig
    # aufgeloest und blieben als leeres Icon stehen.
    base = ADDON_PATH if ADDON_PATH.endswith("/") else ADDON_PATH + "/"
    return base + "resources/media/" + filename


def _media_file_exists(filename):
    base = ADDON_PATH if ADDON_PATH.endswith("/") else ADDON_PATH + "/"
    return xbmcvfs.exists(base + "resources/media/" + filename)


def letter_icon(letter):
    """Einheitliches Icon fuer alle A-Z-Eintraege, gleiches Icon wie bei den
    Genres - fuer optische Konsistenz statt 26 Einzel-Icons."""
    return media_path("icon_genre_item.png")


def number_icon():
    return media_path("icon_genre_item.png")


def main_menu():
    items = [
        (_(30001), build_url(mode="genres"), media_path("icon_genres.png")),
        (_(30002), build_url(mode="search"), media_path("icon_search.png")),
        (_(30003), build_url(mode="live"), media_path("icon_live.png")),
        (_(30004), build_url(mode="favorites"), media_path("icon_favorites.png")),
        (_(30005), build_url(mode="az"), media_path("icon_az.png")),
    ]
    for label, url, icon in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART_PATH})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------------------
# Genres
# ---------------------------------------------------------------------------

def genres_menu():
    li_top = xbmcgui.ListItem(label=_(30020))
    li_top.setArt({"icon": media_path("icon_top_genres.png"), "fanart": FANART_PATH})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="genres_top"), li_top, isFolder=True)

    li_az = xbmcgui.ListItem(label=_(30022))
    li_az.setArt({"icon": media_path("icon_all_genres.png"), "fanart": FANART_PATH})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="genres_az"), li_az, isFolder=True)

    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


def _list_genres(genres):
    for genre in genres:
        name = genre.get("name", "")
        li = xbmcgui.ListItem(label=name)
        li.setArt({"icon": media_path("icon_genre_item.png"), "fanart": FANART_PATH})
        url = build_url(mode="genre_stations", genre=name)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


def genres_top():
    try:
        genres = api.get_genres()
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    count = ADDON.getSettingInt("top_genres_count") or 25
    genres_sorted = sorted(genres, key=lambda g: g.get("score", 0), reverse=True)
    _list_genres(genres_sorted[:count])


def genres_az():
    try:
        genres = api.get_genres()
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    genres_sorted = sorted(genres, key=lambda g: g.get("name", "").lower())
    _list_genres(genres_sorted)


def genre_stations(genre, offset=0):
    try:
        result = api.get_stations_by_genre(genre, limit=items_per_page(), offset=offset)
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    stations = _extract_station_list(result)
    _list_stations(stations)
    _maybe_add_next_page(result, mode="genre_stations", offset=offset, genre=genre)


# ---------------------------------------------------------------------------
# A-Z
# ---------------------------------------------------------------------------

def az_menu():
    try:
        letters = api.get_letters()
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # Nur echte Buchstaben (a-z) aus der API-Antwort uebernehmen. laut.fm fuehrt
    # auf der Webseite keine Sender mit echten Sonderzeichen am Anfang - falls
    # /letters trotzdem mal ein Nicht-Buchstaben-Element liefert (z.B. Artefakt),
    # wird es hier rausgefiltert statt einen kaputten Menuepunkt zu erzeugen.
    letters = [l for l in letters if isinstance(l, str) and len(l) == 1 and l.isalpha()]

    for letter in letters:
        li = xbmcgui.ListItem(label=letter.upper())
        li.setArt({"icon": letter_icon(letter), "fanart": FANART_PATH})
        url = build_url(mode="letter_stations", letter=letter)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    # 0-9: auf laut.fm selbst unter "#" gefuehrt, eigener Endpunkt /stations/numbers
    li_numbers = xbmcgui.ListItem(label="#")
    li_numbers.setArt({"icon": number_icon(), "fanart": FANART_PATH})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="number_stations"), li_numbers, isFolder=True)

    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


def letter_stations(letter, offset=0):
    try:
        result = api.get_stations_by_letter(letter, limit=items_per_page(), offset=offset)
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    stations = _extract_station_list(result)
    _list_stations(stations)
    _maybe_add_next_page(result, mode="letter_stations", offset=offset, letter=letter)


def number_stations():
    try:
        result = api.get_stations_by_number()
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    stations = _extract_station_list(result)
    _list_stations(stations)


# ---------------------------------------------------------------------------
# Live jetzt
# ---------------------------------------------------------------------------

def live_menu():
    try:
        result = api.get_live_stations()
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    stations = _extract_station_list(result)
    if not stations:
        li = xbmcgui.ListItem(label=_(30019))
        xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="noop"), li, isFolder=False)
        xbmcplugin.setContent(HANDLE, "files")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    _list_stations(stations)


# ---------------------------------------------------------------------------
# Favoriten
# ---------------------------------------------------------------------------

def favorites_menu():
    favs = favorites.load_favorites()
    if not favs:
        li = xbmcgui.ListItem(label=_(30023))
        xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="noop"), li, isFolder=False)
        xbmcplugin.setContent(HANDLE, "files")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for fav in favs:
        _add_station_item(fav["name"], fav.get("display_name", fav["name"]), is_favorite=True)

    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE)


def toggle_favorite(name, display_name):
    if favorites.is_favorite(name):
        favorites.remove_favorite(name)
        xbmcgui.Dialog().notification(_(30000), _(30013), xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        favorites.add_favorite(name, display_name)
        xbmcgui.Dialog().notification(_(30000), _(30012), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------------------------
# Suche
# ---------------------------------------------------------------------------

def search_menu():
    keyboard = xbmcgui.Dialog().input(_(30008))
    if not keyboard:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    try:
        result = api.search_stations(keyboard, limit=items_per_page())
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    stations = []
    for group in result.get("results", []):
        for item in group.get("items", []):
            station = item.get("station")
            if station:
                stations.append(station)

    if not stations:
        li = xbmcgui.ListItem(label=_(30009))
        xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="noop"), li, isFolder=False)
        xbmcplugin.setContent(HANDLE, "files")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    _list_stations(stations)


# ---------------------------------------------------------------------------
# Gemeinsame Sender-Listen-Logik
# ---------------------------------------------------------------------------

def _extract_station_list(result):
    """Die /stations-Endpunkte liefern je nach Fall entweder direkt eine Liste
    oder ein Objekt mit 'items'/'stations'. Defensiv behandeln, bis die exakte
    Struktur an allen Endpunkten final verifiziert ist."""
    if isinstance(result, list):
        return result
    if isinstance(result, dict):
        return result.get("items") or result.get("stations") or []
    return []


def _maybe_add_next_page(result, mode, offset, **extra):
    if not isinstance(result, dict):
        return
    next_offset = result.get("next_offset")
    if next_offset is None:
        return
    li = xbmcgui.ListItem(label=_(30006))
    params = dict(extra)
    params["mode"] = mode
    params["offset"] = next_offset
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**params), li, isFolder=True)


def _list_stations(stations):
    for station in stations:
        name = station.get("name") or station.get("slug") or ""
        display_name = station.get("display_name") or name
        _add_station_item(name, display_name, description=station.get("description"),
                           thumb=_extract_thumb(station))
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE)


def _extract_thumb(station):
    """
    Bestaetigtes Feldformat (02.07.2026, live gegen /station/{name} getestet):
    images: {station, station_80x80, station_120x120, station_640x640}
    Fuer Listenansichten reicht die 640er Aufloesung, station_120x120 waere
    die kleinere Alternative falls Performance/Bandbreite mal ein Thema wird.
    """
    images = station.get("images") or {}
    return (
        images.get("station_640x640")
        or images.get("station_120x120")
        or images.get("station_80x80")
        or images.get("station")
        or ""
    )


def _add_station_item(name, display_name, description=None, thumb=None, is_favorite=False):
    li = xbmcgui.ListItem(label=display_name)
    art = {"icon": "DefaultAudio.png", "fanart": FANART_PATH}
    if thumb:
        art["thumb"] = thumb
        art["poster"] = thumb
    else:
        art["thumb"] = "DefaultAudio.png"
    li.setArt(art)
    li.setProperty("IsPlayable", "true")

    info_tag = li.getMusicInfoTag()
    info_tag.setTitle(display_name)
    if description:
        info_tag.setComment(_clean(description))

    context_menu = []
    if is_favorite or favorites.is_favorite(name):
        context_menu.append((_(30011), "RunPlugin(%s)" % build_url(mode="toggle_favorite", name=name, display_name=display_name)))
    else:
        context_menu.append((_(30010), "RunPlugin(%s)" % build_url(mode="toggle_favorite", name=name, display_name=display_name)))
    li.addContextMenuItems(context_menu)

    url = build_url(mode="play", name=name, display_name=display_name)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


# ---------------------------------------------------------------------------
# Wiedergabe
# ---------------------------------------------------------------------------

def play_station(name, display_name):
    try:
        info = api.get_station(name)
        stream_url = info.get("stream_url")
    except LautFMError as e:
        log(str(e))
        show_error(30015)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if not stream_url:
        # Fallback nach bekanntem laut.fm Stream-Pattern (siehe plugin.audio.rsnradio)
        stream_url = "https://%s.stream.laut.fm/%s" % (name, name)

    li = xbmcgui.ListItem(label=display_name, path=stream_url)
    li.setProperty("IsPlayable", "true")
    li.getMusicInfoTag().setTitle(display_name)

    thumb = _extract_thumb(info)
    if thumb:
        li.setArt({"thumb": thumb, "poster": thumb, "fanart": FANART_PATH})
    else:
        li.setArt({"fanart": FANART_PATH})

    try:
        song = api.get_current_song(name)
        artist = song.get("artist", {}).get("name") if isinstance(song.get("artist"), dict) else song.get("artist")
        title = song.get("title")
        if artist and title:
            li.getMusicInfoTag().setArtist(artist)
            li.getMusicInfoTag().setTitle(title)
    except LautFMError:
        pass

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def router():
    params = get_params()
    mode = params.get("mode")

    if mode is None:
        main_menu()
    elif mode == "genres":
        genres_menu()
    elif mode == "genres_top":
        genres_top()
    elif mode == "genres_az":
        genres_az()
    elif mode == "genre_stations":
        genre_stations(params["genre"], int(params.get("offset", 0)))
    elif mode == "az":
        az_menu()
    elif mode == "letter_stations":
        letter_stations(params["letter"], int(params.get("offset", 0)))
    elif mode == "number_stations":
        number_stations()
    elif mode == "live":
        live_menu()
    elif mode == "favorites":
        favorites_menu()
    elif mode == "toggle_favorite":
        toggle_favorite(params["name"], params.get("display_name", params["name"]))
    elif mode == "search":
        search_menu()
    elif mode == "play":
        play_station(params["name"], params.get("display_name", params["name"]))
    elif mode == "noop":
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == "__main__":
    router()
