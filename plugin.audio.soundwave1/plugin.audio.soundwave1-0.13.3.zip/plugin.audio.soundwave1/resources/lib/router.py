# -*- coding: utf-8 -*-
"""
SoundWave 1 - Router

Verbindet alle Provider-Module unter einer einheitlichen Aufruf-Schnitt-
stelle, analog zum Router-Muster in Saschas anderen Addons (Slim-Router,
delegiert an Source-Module).

Stand dieser Runde: 13 Quellen sind als Provider angebunden.

PD/FM-Quellen (8): Musopen, ccMixter, Jamendo, Audius, Netlabelarchive,
Blocsonic, Internet Archive (Musik-Collections) - allesamt unkompliziert;
plus Ektoplazm und Open Music Archive mit kleineren Einschraenkungen:
  - Ektoplazm: Stream-URL zeitlich signiert, wird ueber resolve_stream()
    live aufgeloest; Track-URL-Muster ist eine Heuristik (im Testlauf an
    zwei Beispielen bestaetigt, nicht breit verifiziert)
  - Open Music Archive: braucht immer einen Tag-Parameter (browse.php
    allein ist nur eine leere Landing-Page), Default-Tag "Free-to-air"
    (im Testlauf bestaetigt); keine Datumsangaben -> new_releases() leer

Ein-Kuenstler-Quelle (1): Phish.in (Live-Mitschnitte, rechtlich ueber
die "Taping Policy" der Band abgesichert) - Account/API-Key per E-Mail-
Anfrage bei den Maintainern noetig, noch nicht produktiv getestet.

Mainstream-Quelle (1, bewusst mit kommerziellen Acts): Bandcamp.
Rechtlich sauber, da SoundWave 1 nur streamt statt herunterlaedt und
damit exakt die Funktion nutzt, die Bandcamp ohnehin jedem anonymen
Besucher kostenlos bietet - kein Paywall-Bypass. Auf UI-Ebene ist dafuer
ein eigener Hauptmenue-Punkt vorgesehen, damit der Nutzer zwischen PD/FM
und Mainstream waehlen kann - betrifft die noch zu bauende UI-Schicht,
nicht dieses Router-Modul.
  - Bandcamp: im Testlauf bestaetigt (korrektes Feld ist "item_url");
    Volltextsuche ueber die Discover-API nicht moeglich (nur Tag-Browsing)

Wackelkandidat (1): ReverbNation. Kein offizielles API, nur HTML-Scraping
der instabilen "legacy"-Domain. Grundmechanik (Charts -> Artist-Seite ->
eingebettetes FEATURED_SONGS-JSON) funktioniert nachweislich, aber die
Stream-Aufloesung (html_player_stream-Endpunkt) hat einen "client"-
Parameter, dessen Anforderungen NICHT verifiziert sind - siehe Modul-
Docstring. Bewusst als separate Kategorie/optional zu aktivieren gedacht,
nicht als Kern-Quelle.

Bewusst NICHT eingebunden:
  - FreeMusicArchive: Hotlink-Policy wird gerade mit den Kodinerds/FMA
    geklaert - kann spaeter einfach ergaenzt werden.
  - Dogmazic/Ampache: RAUSGENOMMEN - Ampache verlangt pro Nutzer einen
    eigenen Account/API-Key, das waere eine Huerde fuer jeden Addon-
    Nutzer. Internet Archive kam als Ersatz dazu.
  - SoundCloud: RAUSGENOMMEN - erfordert seit einer Aenderung ihrerseits
    zwingend ein kostenpflichtiges "Artist Pro"-Abo, nur um ueberhaupt
    eine App/Client-ID zu registrieren.
  - Audiomack: RAUSGENOMMEN - Creator-Registrierung fuer API-Zugangsdaten
    verlangt mind. 25 Follower UND mind. 2 selbst hochgeladene Tracks -
    fuer Sascha (macht keine eigene Musik) nicht erfuellbar.
  - TelevisionTunes.com: abgelehnt, ungeklärte Urheberrechte laut eigener
    Copyright-Seite des Betreibers.

client_id/Zugangsdaten kommen aus addon.getSetting() - hier nur als
Parameter durchgereicht, damit dieses Modul unabhaengig von xbmcaddon
testbar bleibt.
"""

from .providers.musopen import MusopenProvider
from .providers.ccmixter import CCMixterProvider
from .providers.jamendo import JamendoProvider
from .providers.audius import AudiusProvider
from .providers.netlabelarchive import NetlabelarchiveProvider
from .providers.blocsonic import BlocsonicProvider
from .providers.ektoplazm import EktoplazmProvider
from .providers.openmusicarchive import OpenMusicArchiveProvider
from .providers.bandcamp import BandcampProvider
from .providers.internetarchive import InternetArchiveProvider
from .providers.phishin import PhishinProvider
from .providers.reverbnation import ReverbNationProvider
from .providers.hearthis import HearthisProvider
from .providers.incompetech import IncompetechProvider
from .providers.worldhiphopbeats import WorldHipHopBeatsProvider
from .providers.nativeamericanmusic import NativeAmericanMusicAwardsProvider
from .providers.ncs import NCSProvider
from .providers.mixkit import MixkitProvider
from .providers.mixotic import MixoticProvider
from .providers.rappersin import RappersInProvider


def build_providers(settings):
    """settings: dict mit Zugangsdaten aus addon.getSetting(), z.B.
    {"jamendo_client_id": "...", "phishin_api_key": "..."}
    Nur Provider aufnehmen, die der Nutzer in den Settings aktiviert hat
    (Anbieter-Auswahl) - Aktivierungs-Check erfolgt hier bewusst nicht,
    das uebernimmt die aufrufende UI-Schicht anhand der Settings-Bools.
    """
    return {
        "musopen": MusopenProvider(),
        "ccmixter": CCMixterProvider(),
        "jamendo": JamendoProvider(settings.get("jamendo_client_id", "")),
        "audius": AudiusProvider(),
        "netlabels": NetlabelarchiveProvider(),
        "blocsonic": BlocsonicProvider(),
        "ektoplazm": EktoplazmProvider(),
        "openmusicarchive": OpenMusicArchiveProvider(),
        "bandcamp": BandcampProvider(),
        "internetarchive": InternetArchiveProvider(),
        "phishin": PhishinProvider(settings.get("phishin_api_key")),
        "reverbnation": ReverbNationProvider(),
        "hearthis": HearthisProvider(),
        "incompetech": IncompetechProvider(),
        "worldhiphopbeats": WorldHipHopBeatsProvider(),
        "nativeamericanmusic": NativeAmericanMusicAwardsProvider(),
        "ncs": NCSProvider(),
        "mixkit": MixkitProvider(),
        "mixotic": MixoticProvider(),
        "rappersin": RappersInProvider(),  # Free-Modus, kein Login
    }


def route(providers, provider_id, action, raise_errors=False, **kwargs):
    """Zentraler Einstiegspunkt. providers = Ergebnis von build_providers().
    action in {"browse", "search", "random", "new_releases", "genres", "artists"}.
    Liefert bei unbekanntem Provider/Action immer eine leere Liste statt
    eines Fehlers, damit z.B. der SW1-Generator ueber mehrere Provider
    hinweg robust weiterlaufen kann, auch wenn einer davon (noch) nicht
    unterstuetzt oder kurzzeitig nicht erreichbar ist.

    raise_errors=True unterdrueckt dieses Abfangen (nur fuer Tests/Debug
    gedacht, z.B. test_providers.py) - im Addon-Betrieb bleibt es bei
    False, damit die UI robust bleibt.
    """
    api = providers.get(provider_id)
    if not api:
        return []

    def _dispatch():
        if action == "browse":
            return api.browse_tracks(**kwargs)
        if action == "search":
            return api.search(kwargs.get("query", ""), limit=kwargs.get("limit", 50))
        if action == "random":
            return api.random_tracks(count=kwargs.get("count", 1), filters=kwargs.get("filters"))
        if action == "new_releases":
            return api.new_releases(limit=kwargs.get("limit", 30))
        if action == "genres":
            return api.get_genres()
        if action == "artists":
            return api.get_artists(genre=kwargs.get("genre"))
        if action == "resolve_stream":
            return api.resolve_stream(kwargs.get("track_id"))
        return []

    if raise_errors:
        return _dispatch()

    try:
        return _dispatch()
    except Exception as exc:
        # Ein einzelner ausfallender Provider darf nie den ganzen
        # Generator/New-on-SW1-Aufruf ueber alle Quellen hinweg reissen -
        # aber damit sich sowas wie das ccMixter-Problem (still leere
        # Ergebnisse statt Fehleranzeige) ueberhaupt aufspueren laesst,
        # jetzt ins Debug-Log geschrieben (nur sichtbar, wenn der Nutzer
        # das Debug-Log in den Settings aktiviert hat).
        try:
            from . import logger
            logger.error("route(%s, %s) fehlgeschlagen: %s: %s" % (provider_id, action, type(exc).__name__, exc))
        except Exception:
            pass  # Logging darf selbst nie einen Absturz verursachen
        return []


def route_many(providers, provider_ids, action, **kwargs):
    """Fuer 'New on SoundWave 1' und den SW1 Generator: gleiche Aktion
    ueber mehrere/alle aktivierten Provider hinweg, Ergebnisse ungesortiert
    zusammengefuehrt (z.B. fuer 'New on SoundWave 1' explizit gewuenscht)."""
    results = []
    for pid in provider_ids:
        results.extend(route(providers, pid, action, **kwargs))
    return results
