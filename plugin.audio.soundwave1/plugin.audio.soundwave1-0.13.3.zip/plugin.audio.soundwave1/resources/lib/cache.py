# -*- coding: utf-8 -*-
"""
SoundWave 1 - Cache-Verwaltung

Eigenes Cache-Verzeichnis (getrennt von mysounds.json/mylists.json/dem
Debug-Log, damit "Cache leeren" niemals versehentlich Favoriten oder
Playlisten mitreisst). In dieser Ausbaustufe noch ohne den groesseren
Metadaten-Index fuer den SW1 Generator (kommt in einer spaeteren Runde) -
hier schon die Grundmechanik (Cache-Verzeichnis, manuelles Leeren, Auto
Cache Cleaner nach Alter), damit Settings und "Cache leeren"-Menuepunkt
von Anfang an echt funktionieren statt nur Platzhalter zu sein.
"""
import time

import xbmcaddon
import xbmcvfs

from . import logger

ADDON = xbmcaddon.Addon()
CACHE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile")) + "cache/"


def _ensure_dir():
    if not xbmcvfs.exists(CACHE_DIR):
        xbmcvfs.mkdirs(CACHE_DIR)


def clear_cache():
    """Leert das komplette Cache-Verzeichnis. Rueckgabe: Anzahl geloeschter Dateien."""
    if not xbmcvfs.exists(CACHE_DIR):
        return 0
    dirs, files = xbmcvfs.listdir(CACHE_DIR)
    count = 0
    for fname in files:
        if xbmcvfs.delete(CACHE_DIR + fname):
            count += 1
    logger.log("Cache: %d Datei(en) geleert" % count)
    return count


def auto_clean_if_needed():
    """Vom Setting 'auto_cache_cleaner' gesteuert - loescht Cache-Dateien,
    die aelter als 'cache_max_age_days' sind. Gedacht fuer einen Aufruf
    beim Addon-Start (main_menu())."""
    if not ADDON.getSettingBool("auto_cache_cleaner"):
        return
    if not xbmcvfs.exists(CACHE_DIR):
        return
    max_age_days = ADDON.getSettingInt("cache_max_age_days") or 7
    max_age_seconds = max_age_days * 86400
    now = time.time()

    dirs, files = xbmcvfs.listdir(CACHE_DIR)
    removed = 0
    for fname in files:
        path = CACHE_DIR + fname
        stat = xbmcvfs.Stat(path)
        try:
            mtime = stat.st_mtime()
        except AttributeError:
            continue
        if (now - mtime) > max_age_seconds:
            if xbmcvfs.delete(path):
                removed += 1
    if removed:
        logger.log("Auto Cache Cleaner: %d veraltete Datei(en) entfernt" % removed)


def cache_path(filename):
    """Hilfsfunktion fuer spaetere Module (Metadaten-Index etc.), um
    konsistent im Cache-Verzeichnis abzulegen."""
    _ensure_dir()
    return CACHE_DIR + filename
