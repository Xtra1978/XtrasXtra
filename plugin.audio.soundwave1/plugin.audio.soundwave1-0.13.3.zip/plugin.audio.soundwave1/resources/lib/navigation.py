# -*- coding: utf-8 -*-
"""
SoundWave 1 - Navigation / Hauptmenue

Farb-Hervorhebung fuer Spezial-Features ueber Kodis eingebaute
[COLOR]-Tags (siehe COLOR_FEATURE / COLOR_UTILITY) - kein Skin-Aufwand
noetig. Bindet den Provider-Router (resources/lib/router.py) an die
eigentliche Kodi-Oberflaeche an.

Diese Ausbaustufe deckt ab: Anbieter-Menue, Titel/Genres (aggregiert
ueber alle aktiven Quellen), Kuenstler/Alben (Album-Gruppierung: Einzel-
tracks bleiben flach, Tracks mit gemeinsamem Album-Feld werden zum
Ordner), New on SoundWave 1, MySounds/MyLists (lokale Favoriten inkl.
Kontextmenues), Play for me (Shuffle-Modi), Abspielen (inkl. Live-
Aufloesung fuer Ektoplazm/ReverbNation), Cache leeren, Debug-Log.

Kuenstler-Browse ist ehrlich eingeschraenkt: nur Musopen (Komponisten)
und Phish.in (sich selbst) liefern aktuell eine echte Kuenstlerliste -
die anderen Provider haben (noch) kein get_artists() implementiert.
Erweiterbar pro Provider, ohne dass sich an dieser Stelle etwas aendern
muss.

Bewusst NOCH Platzhalter (naechste, letzte grosse Ausbaustufe): SW1
Generator (Dialogfenster mit mehreren Filtern).
"""
import base64
import json
import time
from urllib.parse import urlencode, quote, unquote

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from . import router as provider_router
from . import storage
from . import cache
from . import logger

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = None
BASE_URL = None

COLOR_FEATURE = "FFFFD700"   # Gold - MySounds, Anbieter, Generator, Play for me, MyLists, New on SW1
COLOR_UTILITY = "FF8FA8C4"  # ruhiges Grau-Blau - Cache leeren, Einstellungen

# Provider-IDs (Router-Schluessel) <-> Settings-Toggle-IDs. Bewusst 1:1
# benannt (provider_<id>), siehe settings.xml.
PROVIDER_IDS = [
    "musopen", "ccmixter", "jamendo", "audius", "netlabels", "blocsonic",
    "ektoplazm", "openmusicarchive", "internetarchive", "phishin",
    "bandcamp", "reverbnation", "hearthis", "incompetech", "worldhiphopbeats",
    "nativeamericanmusic", "ncs", "mixkit", "mixotic", "rappersin",
]

# Anzeigenamen fuer das Anbieter-Menue (aus den jeweiligen Providern
# uebernommen - hier zentral gepflegt, da wir sie auch OHNE Instanz
# brauchen, bevor Zugangsdaten/Settings geladen sind)
PROVIDER_DISPLAY_NAMES = {
    "musopen": "Musopen",
    "ccmixter": "ccMixter",
    "jamendo": "Jamendo",
    "audius": "Audius",
    "netlabels": "Netlabelarchive",
    "blocsonic": "Blocsonic",
    "ektoplazm": "Ektoplazm",
    "openmusicarchive": "Open Music Archive",
    "internetarchive": "Internet Archive",
    "phishin": "Phish.in",
    "bandcamp": "Bandcamp",
    "reverbnation": "ReverbNation",
    "hearthis": "hearthis.at (CC)",
    "incompetech": "Incompetech",
    "worldhiphopbeats": "World Hip Hop Beats",
    "nativeamericanmusic": "Native American Music Awards",
    "ncs": "NCS (NoCopyrightSounds)",
    "mixkit": "Mixkit",
    "mixotic": "Mixotic",
    "rappersin": "Rappers.in",
}

# Fest hinterlegte Jamendo-App-Client-ID (Saschas eigene, registrierte
# App "SoundWave 1's App"). Jamendo-Client-IDs sind App-Kennungen, keine
# Nutzer-Geheimnisse (aehnlich einem oeffentlichen API-Key) - alle
# Addon-Nutzer teilen sich diese eine App-Registrierung, niemand muss
# selbst etwas anlegen. Das Settings-Feld bleibt als optionaler Override
# bestehen, falls doch mal ein eigener Client-ID gewuenscht ist.
DEFAULT_JAMENDO_CLIENT_ID = "c8b2033d"


# ------------------------------------------------------------- Provider-Setup

def _addon_settings():
    return {
        "jamendo_client_id": ADDON.getSetting("jamendo_client_id") or DEFAULT_JAMENDO_CLIENT_ID,
        "phishin_api_key": ADDON.getSetting("phishin_api_key") or None,
    }


def _enabled_provider_ids():
    return [pid for pid in PROVIDER_IDS if ADDON.getSettingBool("provider_%s" % pid)]


def _enabled_providers():
    all_providers = provider_router.build_providers(_addon_settings())
    enabled_ids = _enabled_provider_ids()
    return {pid: p for pid, p in all_providers.items() if pid in enabled_ids}


# ------------------------------------------------------------------ Hilfsfns

def _colorize(label, color):
    return "[COLOR %s]%s[/COLOR]" % (color, label)


def _url(**kwargs):
    return "{0}?{1}".format(BASE_URL, urlencode(kwargs))


def _add_dir_item(label, action, color=None, is_folder=True, icon=None, extra=None):
    display_label = _colorize(label, color) if color else label
    li = xbmcgui.ListItem(label=display_label)
    # Ohne explizit uebergebenes Icon (z.B. Anbieter-eigenes Logo) faellt
    # jeder Menuepunkt auf das SoundWave-1-Icon zurueck, damit die Grafik
    # durchgaengig im ganzen Hauptmenue sichtbar ist.
    art_icon = icon or ADDON.getAddonInfo("icon")
    li.setArt({"icon": art_icon, "thumb": art_icon})
    params = {"action": action}
    if extra:
        params.update(extra)
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url="{0}?{1}".format(BASE_URL, urlencode(params)),
        listitem=li,
        isFolder=is_folder,
    )


def _encode_track(track):
    # Kompakte Teilmenge - alles was zum Abspielen/Speichern noetig ist.
    compact = {
        "provider": track.get("provider"),
        "track_id": track.get("track_id"),
        "title": track.get("title"),
        "artist": track.get("artist"),
        "album": track.get("album"),
        "stream_url": track.get("stream_url"),
        "thumb": track.get("thumb"),
    }
    raw = json.dumps(compact, ensure_ascii=False)
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii")


def _decode_track(encoded):
    raw = base64.urlsafe_b64decode(encoded.encode("ascii")).decode("utf-8")
    return json.loads(raw)


def _track_listitem(track, with_context_menu=True):
    li = xbmcgui.ListItem(label="%s - %s" % (track.get("artist") or "?", track.get("title") or "?"))
    li.setInfo("music", {
        "title": track.get("title"),
        "artist": track.get("artist"),
        "album": track.get("album"),
    })
    if track.get("thumb"):
        li.setArt({"thumb": track["thumb"], "icon": track["thumb"]})
    li.setProperty("IsPlayable", "true")

    if with_context_menu:
        encoded = _encode_track(track)
        context_items = [(
            ADDON.getLocalizedString(30052),  # "Add to MySounds"
            "RunPlugin(%s)" % _url(action="add_to_mysounds", track=encoded),
        ), (
            ADDON.getLocalizedString(30053),  # "Add to MyList..."
            "RunPlugin(%s)" % _url(action="add_to_mylist_prompt", track=encoded),
        )]
        li.addContextMenuItems(context_items)
    return li


def _add_track_item(track):
    li = _track_listitem(track)
    url = _url(action="play", track=_encode_track(track))
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)


# --------------------------------------------------------------- Hauptmenue

def main_menu():
    cache.auto_clean_if_needed()

    _add_dir_item(ADDON.getLocalizedString(30000), "list_artists")   # Kuenstler
    _add_dir_item(ADDON.getLocalizedString(30001), "list_tracks")    # Titel
    _add_dir_item(ADDON.getLocalizedString(30002), "list_albums")    # Alben
    _add_dir_item(ADDON.getLocalizedString(30003), "list_genres")    # Genres

    _add_dir_item(ADDON.getLocalizedString(30004), "mysounds", COLOR_FEATURE)
    _add_dir_item(ADDON.getLocalizedString(30005), "providers", COLOR_FEATURE)
    _add_dir_item(ADDON.getLocalizedString(30006), "sw1_generator", COLOR_FEATURE, is_folder=False)
    _add_dir_item(ADDON.getLocalizedString(30007), "play_for_me", COLOR_FEATURE, is_folder=False)
    _add_dir_item(ADDON.getLocalizedString(30008), "mylists", COLOR_FEATURE)
    _add_dir_item(ADDON.getLocalizedString(30009), "new_on_sw1", COLOR_FEATURE)

    _add_dir_item(ADDON.getLocalizedString(30010), "clear_cache", COLOR_UTILITY, is_folder=False)
    _add_dir_item(ADDON.getLocalizedString(30011), "open_settings", COLOR_UTILITY, is_folder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


# ------------------------------------------------------------- Anbieter-Menue

def providers_menu():
    enabled = _enabled_provider_ids()
    if not enabled:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30080), xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for pid in enabled:
        _add_dir_item(PROVIDER_DISPLAY_NAMES.get(pid, pid), "provider_browse", extra={"provider": pid})
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


PAGE_SIZE = 100

# Provider mit abweichendem Referer fuer die Wiedergabe
REFERER_OVERRIDE = {"rappersin": "https://rappers.in/"}


def provider_browse(provider_id, offset=0, section=None, genre=None):
    providers = _enabled_providers()
    api = providers.get(provider_id)
    if not api:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    # Anbieter mit eigenem Menue (z.B. Rappers.in: Home, Beats, Songs, New Music, Top 50)
    if genre:
        tracks = provider_router.route(providers, provider_id, "browse", genre=genre, limit=PAGE_SIZE)
        _list_tracks(tracks, sort=False)  # Reihenfolge der Quelle beibehalten (z.B. Top-50-Platzierung)
        return
    if not offset and hasattr(api, "get_menu"):
        entries = api.get_menu(section) or []
        if entries:
            for entry in entries:
                extra = {"provider": provider_id}
                if entry.get("section"):
                    extra["section"] = entry["section"]
                else:
                    extra["genre"] = entry.get("genre")
                _add_dir_item(entry["label"], "provider_browse", extra=extra)
            xbmcplugin.setContent(ADDON_HANDLE, "files")
            xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return
    if offset == 0:
        tracks = provider_router.route(providers, provider_id, "new_releases", limit=PAGE_SIZE)
        if not tracks:
            tracks = provider_router.route(providers, provider_id, "browse", limit=PAGE_SIZE)
    else:
        # Ab der zweiten Seite konsequent ueber browse_tracks() mit
        # offset weiterblaettern (new_releases kennt kein offset-Konzept).
        tracks = provider_router.route(providers, provider_id, "browse", limit=PAGE_SIZE, offset=offset)

    more_params = None
    if len(tracks) >= PAGE_SIZE:
        # Heuristik: kam die Seite komplett voll zurueck, gibt's
        # vermutlich noch mehr - "Weitere laden" anbieten.
        more_params = {"action": "provider_browse", "provider": provider_id, "offset": offset + PAGE_SIZE}
    _list_tracks(tracks, more_params=more_params)


# ------------------------------------------------------ Titel / Genres (aggregiert)

def list_tracks():
    providers = _enabled_providers()
    # Aggregation ueber alle aktiven Anbieter gleichzeitig - bewusst kein
    # unbegrenztes Limit (Freeze-Risiko bei vielen Anbietern parallel,
    # siehe fruehere Testlauf-Probleme), aber deutlich grosszuegiger als
    # zuvor.
    tracks = provider_router.route_many(providers, list(providers.keys()), "browse", limit=30)
    _list_tracks(tracks)


def list_genres():
    providers = _enabled_providers()
    genres = set()
    for pid, api in providers.items():
        try:
            genres.update(provider_router.route(providers, pid, "genres") or [])
        except Exception as exc:
            logger.error("list_genres: %s: %s" % (pid, exc))
    if not genres:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30081), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for genre in sorted(genres):
        _add_dir_item(genre, "genre_tracks", extra={"genre": genre})
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def genre_tracks(genre):
    providers = _enabled_providers()
    tracks = provider_router.route_many(
        providers, list(providers.keys()), "browse", genre=genre, limit=30
    )
    _list_tracks(tracks)


def _split_tracks_by_album(tracks):
    """Trennt eine Trackliste in Einzeltracks (kein Album-Feld gesetzt)
    und nach (Anbieter, Album) gruppierte Alben. Ein Track MIT Album-Feld
    wird immer als Teil eines Album-Ordners behandelt, auch wenn in der
    aktuellen Stichprobe nur ein einzelner Track davon vorliegt (siehe
    Absprache: 'ganzes Album wird als Ordner dargestellt')."""
    singles = []
    albums = {}
    for t in tracks:
        if t.get("album"):
            key = (t.get("provider"), t.get("album"))
            albums.setdefault(key, []).append(t)
        else:
            singles.append(t)
    return singles, albums


def list_albums():
    providers = _enabled_providers()
    tracks = provider_router.route_many(providers, list(providers.keys()), "browse", limit=20)
    _, albums = _split_tracks_by_album(tracks)
    if not albums:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30092), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for (pid, album), sample_tracks in sorted(albums.items(), key=lambda kv: kv[0][1] or ""):
        artist = sample_tracks[0].get("artist") or "?"
        label = "%s - %s" % (artist, album)
        _add_dir_item(label, "album_tracks", extra={"provider": pid, "album": quote(album)})
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def album_tracks(provider_id, album):
    providers = _enabled_providers()
    if provider_id not in providers:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    pool = provider_router.route(providers, provider_id, "browse", limit=PAGE_SIZE)
    if not pool:
        pool = provider_router.route(providers, provider_id, "new_releases", limit=PAGE_SIZE)
    matching = [t for t in pool if t.get("album") == album]
    _list_tracks(matching)


def list_artists():
    providers = _enabled_providers()
    artists = []  # Liste von (provider_id, artist_id, artist_name)
    for pid in providers:
        try:
            for a in provider_router.route(providers, pid, "artists") or []:
                artists.append((pid, a.get("id"), a.get("name") or a.get("id")))
        except Exception as exc:
            logger.error("list_artists: %s: %s" % (pid, exc))
    if not artists:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30093), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for pid, artist_id, name in sorted(artists, key=lambda a: a[2] or ""):
        label = "%s (%s)" % (name, PROVIDER_DISPLAY_NAMES.get(pid, pid))
        _add_dir_item(label, "artist_tracks", extra={"provider": pid, "artist_id": quote(str(artist_id))})
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def artist_tracks(provider_id, artist_id):
    providers = _enabled_providers()
    if provider_id not in providers:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    tracks = provider_router.route(providers, provider_id, "browse", artist=artist_id, limit=PAGE_SIZE)
    singles, albums = _split_tracks_by_album(tracks)

    for (pid, album), sample_tracks in sorted(albums.items(), key=lambda kv: kv[0][1] or ""):
        _add_dir_item(album, "album_tracks", extra={"provider": pid, "album": quote(album)})
    for track in singles:
        _add_track_item(track)

    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


# ------------------------------------------------------------- New on SW1

def new_on_sw1():
    providers = _enabled_providers()
    tracks = provider_router.route_many(providers, list(providers.keys()), "new_releases", limit=20)
    if not tracks:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30082), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    _list_tracks(tracks, sort=False)


def _list_tracks(tracks, sort=True, more_params=None):
    for track in tracks:
        _add_track_item(track)
    if more_params:
        li = xbmcgui.ListItem(label=_colorize(ADDON.getLocalizedString(30094), COLOR_UTILITY))
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url="{0}?{1}".format(BASE_URL, urlencode(more_params)),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


# --------------------------------------------------------- MySounds / MyLists

def mysounds():
    tracks = storage.get_mysounds()
    if not tracks:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30083), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for track in tracks:
        li = _track_listitem(track, with_context_menu=False)
        encoded = _encode_track(track)
        li.addContextMenuItems([(
            ADDON.getLocalizedString(30054),  # "Remove from MySounds"
            "RunPlugin(%s)" % _url(action="remove_from_mysounds", provider=track.get("provider"), track_id=track.get("track_id")),
        )])
        url = _url(action="play", track=encoded)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def add_to_mysounds(encoded_track):
    track = _decode_track(encoded_track)
    added = storage.add_to_mysounds(track)
    msg = ADDON.getLocalizedString(30084) if added else ADDON.getLocalizedString(30085)
    xbmcgui.Dialog().notification("SoundWave 1", msg, xbmcgui.NOTIFICATION_INFO)


def remove_from_mysounds(provider_id, track_id):
    storage.remove_from_mysounds(provider_id, track_id)
    xbmcgui.Dialog().notification(
        "SoundWave 1", ADDON.getLocalizedString(30086), xbmcgui.NOTIFICATION_INFO
    )


def mylists():
    lists = storage.get_mylists()
    if not lists:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30087), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for name, tracks in lists.items():
        label = "%s (%d)" % (name, len(tracks))
        _add_dir_item(label, "mylist_tracks", extra={"name": quote(name)})
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def mylist_tracks(name):
    tracks = storage.get_mylist(name)
    for track in tracks:
        li = _track_listitem(track, with_context_menu=False)
        li.addContextMenuItems([(
            ADDON.getLocalizedString(30051),  # "Discard" / aus dieser Liste entfernen
            "RunPlugin(%s)" % _url(action="remove_from_mylist", name=quote(name), provider=track.get("provider"), track_id=track.get("track_id")),
        )])
        url = _url(action="play", track=_encode_track(track))
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def remove_from_mylist(name, provider_id, track_id):
    tracks = storage.get_mylist(name)
    new_tracks = [t for t in tracks if not (t.get("provider") == provider_id and t.get("track_id") == track_id)]
    storage.save_mylist(name, new_tracks)
    xbmcgui.Dialog().notification(
        "SoundWave 1", ADDON.getLocalizedString(30086), xbmcgui.NOTIFICATION_INFO
    )


def add_to_mylist_prompt(encoded_track):
    track = _decode_track(encoded_track)
    existing = list(storage.get_mylists().keys())
    options = existing + [ADDON.getLocalizedString(30055)]  # "+ New list..."
    idx = xbmcgui.Dialog().select(ADDON.getLocalizedString(30053), options)
    if idx < 0:
        return
    if idx == len(options) - 1:
        name = xbmcgui.Dialog().input(ADDON.getLocalizedString(30056))  # "List name"
        if not name:
            return
    else:
        name = existing[idx]
    added = storage.add_to_mylist(name, track)
    msg = ADDON.getLocalizedString(30084) if added else ADDON.getLocalizedString(30085)
    xbmcgui.Dialog().notification("SoundWave 1", msg, xbmcgui.NOTIFICATION_INFO)


# ------------------------------------------------------------------- Play

def _resolve_playable_url(track, providers=None):
    """Liefert die abspielbare URL (inkl. User-Agent/Referer-Anhang) fuer
    einen Track - loest bei Bedarf live auf (Ektoplazm, ReverbNation).
    Gibt None zurueck, wenn nichts aufgeloest werden konnte."""
    stream_url = track.get("stream_url")
    if not stream_url:
        providers = providers if providers is not None else _enabled_providers()
        provider_id = track.get("provider")
        try:
            stream_url = provider_router.route(
                providers, provider_id, "resolve_stream", track_id=track.get("track_id")
            )
        except Exception as exc:
            logger.error("resolve_stream fehlgeschlagen fuer %s/%s: %s"
                         % (provider_id, track.get("track_id"), exc))
    if not stream_url:
        return None

    from urllib.parse import urlparse, quote
    parsed = urlparse(stream_url)
    # Standard: Referer = Stream-Host. Ausnahme: Anbieter, deren Streams nur mit dem
    # Referer der eigenen Webseite bestaetigt sind (Rappers.in: Dateien liegen bei Wasabi).
    referer = quote(REFERER_OVERRIDE.get(track.get("provider")) or "%s://%s/" % (parsed.scheme, parsed.netloc),
                    safe="")
    return ("%s|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36&Referer=%s" % (stream_url, referer))


def _build_playlist_item(track, url):
    li = xbmcgui.ListItem(label="%s - %s" % (track.get("artist") or "?", track.get("title") or "?"))
    li.setInfo("music", {"title": track.get("title"), "artist": track.get("artist"), "album": track.get("album")})
    if track.get("thumb"):
        li.setArt({"thumb": track["thumb"]})
    li.setPath(url)
    return li


# ------------------------------------------------------------------- Play

def play(encoded_track):
    track = _decode_track(encoded_track)
    playable_url = _resolve_playable_url(track)

    if not playable_url:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30090), xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return

    logger.log("play: %s - %s" % (track.get("artist"), track.get("title")))
    li = _build_playlist_item(track, playable_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)


# --------------------------------------------------------------- Play for me

def play_for_me():
    options = [
        ADDON.getLocalizedString(30030),  # Shuffle Play Full Album
        ADDON.getLocalizedString(30031),  # Shuffle Play One Track
        ADDON.getLocalizedString(30032),  # Shuffle Play Mix
    ]
    idx = xbmcgui.Dialog().select(ADDON.getLocalizedString(30007), options)
    if idx < 0:
        # "Cancel" - Nutzer hat den Dialog verlassen, ohne etwas zu waehlen
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return

    providers = _enabled_providers()
    if not providers:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30080), xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return

    if idx == 1:  # Shuffle Play One Track
        _play_one_random_track(providers)
    elif idx == 2:  # Shuffle Play Mix
        _play_mix(providers)
    else:  # Shuffle Play Full Album
        _play_full_album(providers)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)


def _play_one_random_track(providers):
    import random
    pid = random.choice(list(providers.keys()))
    tracks = provider_router.route(providers, pid, "random", count=1)
    if not tracks:
        xbmcgui.Dialog().notification("SoundWave 1", ADDON.getLocalizedString(30082), xbmcgui.NOTIFICATION_INFO)
        return
    track = tracks[0]
    url = _resolve_playable_url(track, providers)
    if not url:
        xbmcgui.Dialog().notification("SoundWave 1", ADDON.getLocalizedString(30090), xbmcgui.NOTIFICATION_ERROR)
        return
    logger.log("play_for_me/one_track: %s - %s" % (track.get("artist"), track.get("title")))
    xbmc.Player().play(url, _build_playlist_item(track, url))


def _play_mix(providers, count=20):
    import random
    pool = provider_router.route_many(providers, list(providers.keys()), "random", count=2)
    random.shuffle(pool)
    pool = pool[:count]
    _play_track_list(providers, pool, "play_for_me/mix")


def _play_full_album(providers):
    import random
    # Zufaellig Tracks ziehen, bis einer mit gesetztem "album"-Feld dabei
    # ist (nicht alle Anbieter haben ein Album-Konzept - siehe
    # Feature-Analyse), dann alle Tracks desselben Anbieters+Albums
    # zusammensuchen.
    candidates = provider_router.route_many(providers, list(providers.keys()), "random", count=5)
    with_album = [t for t in candidates if t.get("album")]
    if not with_album:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30091), xbmcgui.NOTIFICATION_INFO
        )
        return
    seed = random.choice(with_album)
    pid = seed.get("provider")
    album = seed.get("album")

    pool = provider_router.route(providers, pid, "browse", limit=50)
    album_tracks = [t for t in pool if t.get("album") == album]
    if not album_tracks:
        album_tracks = [seed]
    random.shuffle(album_tracks)
    _play_track_list({pid: providers[pid]}, album_tracks, "play_for_me/full_album")


def _play_track_list(providers, tracks, log_label):
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    added = 0
    for track in tracks:
        url = _resolve_playable_url(track, providers)
        if not url:
            continue
        playlist.add(url, _build_playlist_item(track, url))
        added += 1
    if added == 0:
        xbmcgui.Dialog().notification("SoundWave 1", ADDON.getLocalizedString(30090), xbmcgui.NOTIFICATION_ERROR)
        return
    logger.log("%s: %d Tracks in Playlist" % (log_label, added))
    xbmc.Player().play(playlist)


# --------------------------------------------------------- Cache / Settings

def clear_cache():
    count = cache.clear_cache()
    xbmcgui.Dialog().notification(
        "SoundWave 1",
        "%s (%d)" % (ADDON.getLocalizedString(30021), count),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def open_settings():
    ADDON.openSettings()
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def sw1_generator():
    providers_all = _enabled_providers()
    if not providers_all:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30080), xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return

    dialog = xbmcgui.Dialog()

    # Schritt 1: Anzahl Tracks
    count_options = ["10", "25", "50"]
    idx = dialog.select(ADDON.getLocalizedString(30040), count_options)
    if idx < 0:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return
    count = int(count_options[idx])

    # Schritt 2: Genre (aggregiert ueber alle aktiven Anbieter, + "Alle")
    genres = set()
    for pid in providers_all:
        try:
            genres.update(provider_router.route(providers_all, pid, "genres") or [])
        except Exception as exc:
            logger.error("sw1_generator/genres: %s: %s" % (pid, exc))
    genre_options = [ADDON.getLocalizedString(30057)] + sorted(genres)
    gidx = dialog.select(ADDON.getLocalizedString(30041), genre_options)
    if gidx < 0:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return
    selected_genre = None if gidx == 0 else genre_options[gidx]

    # Schritt 3: Kuenstler (nur Anbieter mit echter Kuenstlerliste, + "Alle")
    artist_entries = []  # (provider_id, artist_id, name)
    for pid in providers_all:
        try:
            for a in provider_router.route(providers_all, pid, "artists") or []:
                artist_entries.append((pid, a.get("id"), a.get("name") or a.get("id")))
        except Exception as exc:
            logger.error("sw1_generator/artists: %s: %s" % (pid, exc))
    artist_options = [ADDON.getLocalizedString(30058)] + [a[2] for a in artist_entries]
    aidx = dialog.select(ADDON.getLocalizedString(30042), artist_options)
    if aidx < 0:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return
    selected_artist = None if aidx == 0 else artist_entries[aidx - 1]

    # Schritt 4: Anbieter (Mehrfachauswahl, alle aktiven vorausgewaehlt)
    provider_ids = list(providers_all.keys())
    provider_labels = [PROVIDER_DISPLAY_NAMES.get(p, p) for p in provider_ids]
    chosen = dialog.multiselect(
        ADDON.getLocalizedString(30044), provider_labels, preselect=list(range(len(provider_ids)))
    )
    if not chosen:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return
    selected_providers = {provider_ids[i]: providers_all[provider_ids[i]] for i in chosen}

    # Playlist zusammenstellen
    import random
    if selected_artist:
        artist_pid, artist_id, _ = selected_artist
        if artist_pid not in selected_providers:
            # Kuenstler gehoert zu einem Anbieter, der in Schritt 4
            # abgewaehlt wurde - dann ergibt die Kombination keinen Sinn.
            xbmcgui.Dialog().notification(
                "SoundWave 1", ADDON.getLocalizedString(30082), xbmcgui.NOTIFICATION_INFO
            )
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
            return
        tracks = provider_router.route(
            selected_providers, artist_pid, "browse", artist=artist_id, genre=selected_genre, limit=100
        )
    else:
        per_provider_limit = max((count * 2) // max(len(selected_providers), 1), 5)
        tracks = provider_router.route_many(
            selected_providers, list(selected_providers.keys()), "browse",
            genre=selected_genre, limit=per_provider_limit,
        )

    if not tracks:
        xbmcgui.Dialog().notification(
            "SoundWave 1", ADDON.getLocalizedString(30082), xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        return

    random.shuffle(tracks)
    playlist_tracks = tracks[:count]
    logger.log("sw1_generator: %d Tracks generiert (Genre=%r, Artist=%r, Anbieter=%s)"
               % (len(playlist_tracks), selected_genre, selected_artist, list(selected_providers.keys())))

    _play_track_list(selected_providers, playlist_tracks, "sw1_generator")

    # Nach dem Start: gleich fragen, ob die generierte Playlist dauerhaft
    # in MyLists gespeichert werden soll (statt auf Wiedergabe-Ende zu
    # warten - das liesse sich in einem Kodi-Addon nur mit deutlich mehr
    # Aufwand ueber einen Player-Monitor zuverlaessig abfangen).
    if dialog.yesno("SoundWave 1", ADDON.getLocalizedString(30059)):
        default_name = "SW1 Generator - %s" % time.strftime("%Y-%m-%d %H:%M")
        name = dialog.input(ADDON.getLocalizedString(30056), defaultt=default_name)
        if name:
            storage.save_mylist(name, playlist_tracks)
            xbmcgui.Dialog().notification("SoundWave 1", ADDON.getLocalizedString(30084), xbmcgui.NOTIFICATION_INFO)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)


# ----------------------------------------------------------------- Placeholder

def _placeholder(title_string_id):
    """Fuer die noch nicht umgesetzten Bereiche (SW1 Generator, Play for
    me, Kuenstler/Alben - siehe Modul-Docstring)."""
    xbmcgui.Dialog().notification(
        "SoundWave 1",
        ADDON.getLocalizedString(title_string_id) + " - " + ADDON.getLocalizedString(30020),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


# ------------------------------------------------------------------- Router

def router(base_url, addon_handle, params):
    global BASE_URL, ADDON_HANDLE
    BASE_URL = base_url
    ADDON_HANDLE = addon_handle

    action = params.get("action")

    if action is None:
        main_menu()
    elif action == "list_artists":
        list_artists()
    elif action == "artist_tracks":
        artist_tracks(params["provider"], unquote(params["artist_id"]))
    elif action == "list_tracks":
        list_tracks()
    elif action == "list_albums":
        list_albums()
    elif action == "album_tracks":
        album_tracks(params["provider"], unquote(params["album"]))
    elif action == "list_genres":
        list_genres()
    elif action == "genre_tracks":
        genre_tracks(unquote(params.get("genre", "")))
    elif action == "mysounds":
        mysounds()
    elif action == "add_to_mysounds":
        add_to_mysounds(params["track"])
    elif action == "remove_from_mysounds":
        remove_from_mysounds(params["provider"], params["track_id"])
    elif action == "providers":
        providers_menu()
    elif action == "provider_browse":
        provider_browse(params["provider"], offset=int(params.get("offset", 0)),
                        section=params.get("section"), genre=params.get("genre"))
    elif action == "sw1_generator":
        sw1_generator()
    elif action == "play_for_me":
        play_for_me()
    elif action == "mylists":
        mylists()
    elif action == "mylist_tracks":
        mylist_tracks(unquote(params["name"]))
    elif action == "remove_from_mylist":
        remove_from_mylist(unquote(params["name"]), params["provider"], params["track_id"])
    elif action == "add_to_mylist_prompt":
        add_to_mylist_prompt(params["track"])
    elif action == "new_on_sw1":
        new_on_sw1()
    elif action == "clear_cache":
        clear_cache()
    elif action == "open_settings":
        open_settings()
    elif action == "play":
        play(params["track"])
    else:
        main_menu()
