# -*- coding: utf-8 -*-
"""
SoundWave 1 - lokale Favoriten & Playlisten (MySounds / MyLists)

JSON-basiert und unabhaengig von Kodis eingebauten Favoriten, wie in
Saschas Standardmuster ("JSON-based local favorites systems independent
of Kodi's built-in favorites"). Zwei Dateien im Addon-Datenverzeichnis:

  mysounds.json  - flache Liste von Track-Dicts (die "Herz"-Favoriten)
  mylists.json   - {"Listenname": [Track-Dicts], ...} (benannte Playlisten,
                   z.B. vom SW1 Generator nach dem Anhoeren gespeichert)

Ein Track wird ueber (provider, track_id) eindeutig identifiziert -
Duplikate beim Hinzufuegen werden automatisch vermieden.
"""
import json

import xbmcaddon
import xbmcvfs

from . import logger

ADDON = xbmcaddon.Addon()
DATA_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
MYSOUNDS_PATH = DATA_DIR + "mysounds.json"
MYLISTS_PATH = DATA_DIR + "mylists.json"


def _ensure_dir():
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)


def _read_json(path, default):
    if not xbmcvfs.exists(path):
        return default
    try:
        f = xbmcvfs.File(path)
        content = f.read()
        f.close()
        return json.loads(content) if content else default
    except (ValueError, OSError) as exc:
        logger.error("storage: konnte %s nicht lesen: %s" % (path, exc))
        return default


def _write_json(path, data):
    _ensure_dir()
    f = xbmcvfs.File(path, "w")
    f.write(json.dumps(data, ensure_ascii=False, indent=2))
    f.close()


def _track_key(track):
    return "%s:%s" % (track.get("provider"), track.get("track_id"))


# ---------------------------------------------------------------- MySounds

def get_mysounds():
    return _read_json(MYSOUNDS_PATH, [])


def add_to_mysounds(track):
    tracks = get_mysounds()
    key = _track_key(track)
    if any(_track_key(t) == key for t in tracks):
        return False  # bereits drin
    tracks.append(track)
    _write_json(MYSOUNDS_PATH, tracks)
    logger.log("MySounds: hinzugefuegt %s" % key)
    return True


def remove_from_mysounds(provider, track_id):
    tracks = get_mysounds()
    key = "%s:%s" % (provider, track_id)
    new_tracks = [t for t in tracks if _track_key(t) != key]
    _write_json(MYSOUNDS_PATH, new_tracks)
    logger.log("MySounds: entfernt %s" % key)


def is_in_mysounds(provider, track_id):
    key = "%s:%s" % (provider, track_id)
    return any(_track_key(t) == key for t in get_mysounds())


# ----------------------------------------------------------------- MyLists

def get_mylists():
    return _read_json(MYLISTS_PATH, {})


def get_mylist(name):
    return get_mylists().get(name, [])


def save_mylist(name, tracks):
    lists = get_mylists()
    lists[name] = tracks
    _write_json(MYLISTS_PATH, lists)
    logger.log("MyLists: gespeichert '%s' (%d Tracks)" % (name, len(tracks)))


def delete_mylist(name):
    lists = get_mylists()
    if name in lists:
        del lists[name]
        _write_json(MYLISTS_PATH, lists)
        logger.log("MyLists: geloescht '%s'" % name)


def add_to_mylist(name, track):
    tracks = get_mylist(name)
    key = _track_key(track)
    if any(_track_key(t) == key for t in tracks):
        return False
    tracks.append(track)
    save_mylist(name, tracks)
    return True
