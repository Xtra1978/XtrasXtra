# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Netlabelarchive (netlabelarchive.org)

KORREKTUR nach echtem Testlauf: Die Seite ist WordPress.COM-gehostet
(<meta name="generator" content="WordPress.com" />), NICHT selbst
gehostet. Der Standard-Endpunkt netlabelarchive.org/wp-json/wp/v2/posts
existiert dort nicht (404, im Testlauf bestaetigt) - stattdessen die
oeffentliche WordPress.com-REST-API verwenden:

    https://public-api.wordpress.com/rest/v1.1/sites/netlabelarchive.org/posts/

Diese liefert pro Post ein flaches "content"-Feld (HTML-String, nicht
verschachtelt wie bei der self-hosted API) und "title" als reinen String
statt {"rendered": ...}. Das Modul unterstuetzt beide Formen defensiv,
falls sich das API-Verhalten unterscheidet.

Die eigentlichen Tracks liegen weiterhin NICHT auf netlabelarchive.org
selbst, sondern werden dort nur verlinkt - gehostet auf archive.org
(archive.org/download/{item}/{file}.mp3), statisch und unsigniert. Das
ist exakt das bestehende Internet-Archive-Muster aus Saschas anderen
Addons - und dieser Teil hat sich in der urspruenglichen HTML-Analyse
bereits bestaetigt.

NOCH ZU VERIFIZIEREN (im Testlauf noch nicht geprueft, da der alte
Endpunkt fehlschlug, bevor es dazu kam): ob per_page/page-Parameter bei
der WordPress.com-API genauso heissen wie unten angenommen (number/page)
oder ob "orderby"/"order" hier verwendet werden.
"""
import re

import requests

from .base import BaseProvider

API_BASE = "https://public-api.wordpress.com/rest/v1.1/sites/netlabelarchive.org/posts"
_MP3_RE = re.compile(r'https://archive\.org/download/([^/"\']+)/([^"\']+\.mp3)', re.IGNORECASE)


class NetlabelarchiveProvider(BaseProvider):
    id = "netlabels"
    name = "Netlabelarchive"
    display_name = "Netlabelarchive"

    def _get(self, params=None):
        r = requests.get(API_BASE + "/", params=params or {}, timeout=15)
        r.raise_for_status()
        return r.json()

    def _tracks_from_post(self, post):
        content_html = post.get("content") or (post.get("content") or {}).get("rendered", "")
        if isinstance(content_html, dict):
            content_html = content_html.get("rendered", "")
        title_field = post.get("title")
        release_title = title_field if isinstance(title_field, str) else (title_field or {}).get("rendered", "Unknown Release")
        date_str = post.get("date") or post.get("date_gmt") or ""
        tracks = []
        for item_id, filename in _MP3_RE.findall(content_html):
            import urllib.parse
            fname_decoded = urllib.parse.unquote(filename)
            # Dateiname ist oft "01 - Trackname.mp3" -> Tracknamen extrahieren
            title = re.sub(r"^\d+\s*-\s*", "", fname_decoded).rsplit(".", 1)[0]
            tracks.append({
                "provider": self.id,
                "track_id": "%s/%s" % (item_id, filename),
                "title": title or fname_decoded,
                "artist": release_title,  # Netlabelarchive strukturiert nach Release, nicht Artist-Feld
                "album": release_title,
                "genre": None,  # ueber WP-Kategorien/Tags des Posts nachruestbar
                "year": date_str[:4] or None,
                "duration": None,
                "license": None,
                "thumb": None,
                "stream_url": "https://archive.org/download/%s/%s" % (item_id, filename),
                "date_added": date_str,
            })
        return tracks

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None:
            # Netlabelarchive hat kein Genre-Feld, das wir filtern
            # koennten - lieber nichts zurueckgeben, als das Genre
            # stillschweigend zu ignorieren und die normale Liste zu
            # zeigen (das fuehrte dazu, dass jede Genre-Auswahl dieselben
            # Treffer zeigte, siehe Testlauf-Fehlerbericht).
            return []
        params = {"number": min(limit, 50), "page": (offset // 50) + 1}
        data = self._get(params)
        tracks = []
        for post in data.get("posts", []):
            tracks.extend(self._tracks_from_post(post))
        return tracks

    def search(self, query, limit=50):
        data = self._get({"search": query, "number": min(limit, 50)})
        tracks = []
        for post in data.get("posts", []):
            tracks.extend(self._tracks_from_post(post))
        return tracks

    def random_tracks(self, count=1, filters=None):
        import random
        data = self._get({"number": 20, "page": random.randint(1, 20)})
        tracks = []
        for post in data.get("posts", []):
            tracks.extend(self._tracks_from_post(post))
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        data = self._get({"number": min(limit, 50), "order_by": "date", "order": "DESC"})
        tracks = []
        for post in data.get("posts", []):
            tracks.extend(self._tracks_from_post(post))
        return tracks
