# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: NCS (NoCopyrightSounds, ncs.io)

Die bekannteste "free to use"-Musikmarke fuer YouTuber/Streamer/Creator.
Kein API - alle Metadaten stecken direkt als Datenattribute im HTML.

KORREKTUR nach zwei echten Testlaeufen (zeigte erst 1, dann nur 16 statt
20+ Titel pro Seite):
  1) Die eigentliche, vollstaendige Musik-Bibliothek liegt NICHT unter
     /music oder /?page=N (beide unvollstaendig/andere Darstellung),
     sondern unter der echten Such-Route:
         /music-search?q=&genre=&mood=&version=regular&page=N
     Bestaetigt anhand einer echten Aufnahme (21 eindeutige Treffer auf
     einer Seite).
  2) Der Play-Button hat je nach Seitenbereich DREI unterschiedliche
     class-Werte ("btn white player-play" fuer Featured-Release,
     "btn black player-play" fuer normale Homepage-Eintraege, nur
     "player-play" auf der echten Suchergebnis-Tabelle) - die Regex
     deckt jetzt alle drei ab.

Volles Attribut-Muster (aus echter Aufnahme):
    <a class="player-play" data-url="https://ncsmusic.s3..../....mp3"
       data-artist="<a href='...'>Name</a>" data-artistraw="Name"
       data-track="Titel" data-cover="..." data-preview="55"
       data-tid="uuid" data-versions="Regular" data-genre="House">

"data-url" ist die STATISCHE, unsignierte volle MP3-Datei (kein
Redirect, kein Signatur-Token noetig) - direkt S3-gehostet.

LIZENZ: NCS-eigenes "free to use"-Lizenzmodell - kein CC, aber im
Kern aehnlich (kostenlose Nutzung bei Pflicht-Namensnennung, siehe
"license"-Feld im Track-Dict). MUSS in der Player-/Detailansicht
sichtbar gemacht werden.

Die Suchseite unterstuetzt zwar auch einen numerischen "genre="-Query-
Parameter serverseitig (z.B. genre=45 fuer "House", aus einer Aufnahme
abgeleitet) - die vollstaendige ID-zu-Name-Zuordnung ist aber nicht
verifiziert. Deshalb wird "genre" hier bewusst clientseitig ueber das
"data-genre"-Feld gefiltert (unverfiltert abrufen, danach in Python
filtern) statt den Server-Parameter zu nutzen.

Keine bestaetigte /artists-Seiten-Struktur vorhanden (nur Bild-Assets
im Mitschnitt, kein HTML-Text) - get_artists() leitet Kuenstlernamen
deshalb aus den bereits abgerufenen Tracks ab (stichprobenbasiert).
"""
import re

import requests

from .base import BaseProvider

BASE = "https://ncs.io"
MUSIC_SEARCH_PATH = "/music-search"

_TRACK_RE = re.compile(
    r'class="(?:btn (?:white|black) )?player-play" data-url="([^"]+)" data-artist="[^"]*" '
    r'data-artistraw="([^"]*)" data-track="([^"]*)" data-cover="([^"]*)" '
    r'data-preview="[^"]*" data-tid="([^"]*)" data-versions="[^"]*" '
    r'data-genre="([^"]*)"'
)

LICENSE_TEXT = "NCS (NoCopyrightSounds) - free to use, credit required"


class NCSProvider(BaseProvider):
    id = "ncs"
    name = "NCS"
    display_name = "NCS (NoCopyrightSounds)"

    def _get_html(self, page=1):
        params = {"q": "", "genre": "", "mood": "", "version": "regular", "page": page}
        r = requests.get(BASE + MUSIC_SEARCH_PATH, params=params, timeout=15)
        r.raise_for_status()
        return r.text

    def _parse_tracks(self, html):
        tracks = []
        seen = set()
        for url, artist, title, cover, tid, genre in _TRACK_RE.findall(html):
            if tid in seen:
                continue
            seen.add(tid)
            tracks.append({
                "provider": self.id,
                "track_id": tid,
                "title": title.strip() or "Unknown",
                "artist": artist.strip() or "Unknown",
                "album": None,
                "genre": genre or None,
                "year": None,
                "duration": None,
                "license": LICENSE_TEXT,
                "thumb": cover or None,
                "stream_url": url,
                "date_added": None,
            })
        return tracks

    def _fetch_pages(self, max_pages=3):
        tracks = []
        for page in range(1, max_pages + 1):
            html = self._get_html(page=page)
            batch = self._parse_tracks(html)
            if not batch:
                break
            tracks.extend(batch)
        return tracks

    def get_genres(self):
        tracks = self._fetch_pages(max_pages=3)
        return sorted({t["genre"] for t in tracks if t.get("genre")})

    def get_artists(self, genre=None):
        tracks = self._fetch_pages(max_pages=3)
        seen = {}
        for t in tracks:
            if t["artist"] not in seen:
                seen[t["artist"]] = t["artist"]
        return [{"id": name, "name": name} for name in sorted(seen)]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        start_page = (offset // 20) + 1
        pages_needed = max((limit // 20) + 2, 3)
        tracks = self._fetch_pages(max_pages=start_page + pages_needed)
        if genre:
            tracks = [t for t in tracks if t.get("genre") == genre]
        if artist:
            tracks = [t for t in tracks if t.get("artist") == artist]
        return tracks[offset:offset + limit]

    def search(self, query, limit=50):
        query_lower = query.lower()
        tracks = self._fetch_pages(max_pages=5)
        matches = [
            t for t in tracks
            if query_lower in (t.get("title") or "").lower()
            or query_lower in (t.get("artist") or "").lower()
        ]
        return matches[:limit]

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(genre=(filters or {}).get("genre"), limit=200)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # KORREKTUR nach echtem Testlauf: holte urspruenglich nur EINE
        # Seite (~20 Treffer) und ignorierte "limit" komplett - dadurch
        # gab es nie einen "Weitere laden"-Eintrag, obwohl die Seite 99
        # eigene Unterseiten mit je ca. 20-30 Titeln hat. Jetzt genauso
        # paginiert wie browse_tracks().
        pages_needed = max((limit // 20) + 2, 3)
        return self._fetch_pages(max_pages=pages_needed)[:limit]
