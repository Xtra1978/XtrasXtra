# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Musopen (musopen.org)

Oeffentliche REST-API unter api.musopen.org/v2/. Klassische Musik,
komponisten-zentriert (nicht kuenstler-zentriert wie bei den anderen
Quellen) - "composer" wird im Track-Dict als artist gemappt, der
tatsaechliche Interpret liegt in "performer" und wird zusaetzlich an
"album"-Stelle mitgefuehrt, damit er im Player sichtbar bleibt.

Stream-URLs (Feld "fileurl") sind statisch und unsigniert - kein
resolve_stream() noetig.

Cursor-Pagination ueber "next"-Feld in der Antwort; fuer unsere Zwecke
reicht limit/offset-artiges Blaettern ueber wiederholte Aufrufe mit
steigendem "limit", da Musopen kein offset kennt sondern nur cursor.
Fuer SW1 halten wir es simpel: wir laden jeweils eine Seite (limit)
und liefern die zurueck; echtes Cursor-Blaettern kann spaeter in der
UI-Schicht nachgezogen werden (naechste-Seite-Button haelt sich den
"next"-Cursor).
"""
import requests

from .base import BaseProvider

API_BASE = "https://api.musopen.org/v2"


class MusopenProvider(BaseProvider):
    id = "musopen"
    name = "Musopen"
    display_name = "Musopen"

    def _get(self, path, params=None):
        r = requests.get("%s/%s" % (API_BASE, path), params=params or {}, timeout=15)
        r.raise_for_status()
        return r.json()

    def _map_track(self, rec):
        piece = rec.get("piece") or {}
        composer = piece.get("composer") or {}
        performer = rec.get("performer") or {}
        composer_name = (
            ("%s %s" % (composer.get("first_name", ""), composer.get("last_name", ""))).strip()
            or None
        )
        return {
            "provider": self.id,
            "track_id": str(rec.get("id")),
            "title": rec.get("title") or piece.get("title") or "Unknown",
            "artist": composer_name or performer.get("name") or "Unknown",
            "album": performer.get("name"),
            "genre": (piece.get("form") or {}).get("name"),
            "year": None,  # Musopen liefert kein Aufnahmejahr im Recording-Objekt
            "duration": int(rec["length"]) if rec.get("length") else None,
            "license": rec.get("license"),
            "thumb": (composer.get("image") if composer else None),
            "stream_url": rec.get("fileurl"),
            "date_added": None,
        }

    def get_genres(self):
        data = self._get("forms/", {"limit": 100})
        return [f["name"] for f in data.get("results", [])]

    def get_artists(self, genre=None):
        # "Artists" = Komponisten bei Musopen
        data = self._get("composers/", {"limit": 200, "ordering": "last_name"})
        return [
            {"id": c["slug"], "name": ("%s %s" % (c.get("first_name", ""), c.get("last_name", ""))).strip()}
            for c in data.get("results", [])
        ]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        params = {"limit": limit, "ordering": "-popularity"}
        if artist:
            params["composer"] = artist  # composer-slug
        if genre:
            params["form"] = genre  # form-slug
        data = self._get("recordings/", params)
        return [self._map_track(r) for r in data.get("results", [])]

    def search(self, query, limit=50):
        data = self._get("recordings/", {"search": query, "limit": limit})
        return [self._map_track(r) for r in data.get("results", [])]

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        params = {"limit": max(count, 30), "ordering": "?"}  # Musopen unterstuetzt kein "?"-Random offiziell
        if filters.get("artist"):
            params["composer"] = filters["artist"]
        if filters.get("genre"):
            params["form"] = filters["genre"]
        try:
            data = self._get("recordings/", params)
        except requests.HTTPError:
            # Fallback ohne ordering=? falls die API das ablehnt
            params.pop("ordering", None)
            data = self._get("recordings/", params)
        results = data.get("results", [])
        import random
        random.shuffle(results)
        return [self._map_track(r) for r in results[:count]]

    def new_releases(self, limit=30):
        data = self._get("recordings/", {"limit": limit, "ordering": "-id"})
        return [self._map_track(r) for r in data.get("results", [])]
