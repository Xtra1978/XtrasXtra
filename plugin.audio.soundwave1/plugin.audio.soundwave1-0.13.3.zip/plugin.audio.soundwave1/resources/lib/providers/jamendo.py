# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Jamendo (jamendo.com)

Wichtig: NICHT die interne www.jamendo.com/api/* Web-App-API verwenden,
die im HAR sichtbar war (die ist session-/ID-basiert und nur zur
Anreicherung bereits bekannter IDs gedacht, kein echtes Such-/Filter-API).
Stattdessen die offizielle, dokumentierte oeffentliche REST-API nutzen:

    https://api.jamendo.com/v3.0/

Benoetigt einen kostenlosen client_id (Registrierung unter
https://devportal.jamendo.com/). Der client_id gehoert in die
Addon-Settings (Feld "Jamendo Client-ID"), NICHT hart codiert.

Stream-Feld "audio" in der API-Antwort ist eine direkte, unsignierte
MP3-URL (mp3l.jamendo.com o.ae.) - kein resolve_stream() noetig.
"""
import requests

from .base import BaseProvider

API_BASE = "https://api.jamendo.com/v3.0"


class JamendoProvider(BaseProvider):
    id = "jamendo"
    name = "Jamendo"
    display_name = "Jamendo"

    def __init__(self, client_id):
        # client_id kommt aus addon.getSetting("jamendo_client_id")
        self.client_id = client_id

    def _get(self, path, params=None):
        p = dict(params or {})
        p["client_id"] = self.client_id
        p["format"] = "json"
        r = requests.get("%s/%s" % (API_BASE, path), params=p, timeout=15)
        r.raise_for_status()
        return r.json()

    def _map_track(self, t):
        return {
            "provider": self.id,
            "track_id": str(t.get("id")),
            "title": t.get("name") or "Unknown",
            "artist": t.get("artist_name") or "Unknown",
            "album": t.get("album_name"),
            "genre": None,  # Genre kommt bei Jamendo ueber "tags" (separater Call)
            "year": int(t["releasedate"][:4]) if t.get("releasedate") else None,
            "duration": t.get("duration"),
            "license": t.get("license_ccurl"),
            "thumb": t.get("album_image") or t.get("image"),
            "stream_url": t.get("audio"),
            "date_added": t.get("releasedate"),
        }

    def get_genres(self):
        data = self._get("autocomplete/", {"prefix": "", "entity": "tracks", "limit": 100})
        # KORREKTUR nach echtem Testlauf-Fehler: "results" kam als Liste
        # zurueck, nicht als Dict mit "tags"-Schluessel wie urspruenglich
        # angenommen - beide Formen defensiv abfangen statt blind
        # data.get("results", {}).get("tags", []) zu erwarten.
        results = data.get("results", [])
        if isinstance(results, dict):
            tags = results.get("tags", [])
        elif isinstance(results, list):
            tags = [t for t in results if isinstance(t, str)]
        else:
            tags = []
        return sorted(set(tags))

    def get_artists(self, genre=None):
        params = {"limit": 100, "order": "popularity_total"}
        if genre:
            params["tags"] = genre
        data = self._get("artists/", params)
        return [{"id": str(a["id"]), "name": a["name"]} for a in data.get("results", [])]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        params = {"limit": limit, "offset": offset, "order": "popularity_total", "include": "musicinfo"}
        if genre:
            params["tags"] = genre
        if artist:
            params["artist_id"] = artist
        if year:
            params["datebetween"] = "%s-01-01_%s-12-31" % (year, year)
        data = self._get("tracks/", params)
        return [self._map_track(t) for t in data.get("results", [])]

    def search(self, query, limit=50):
        data = self._get("tracks/", {"search": query, "limit": limit})
        return [self._map_track(t) for t in data.get("results", [])]

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        params = {"limit": max(count, 20), "order": "random", "include": "musicinfo"}
        if filters.get("genre"):
            params["tags"] = filters["genre"]
        if filters.get("artist"):
            params["artist_id"] = filters["artist"]
        if filters.get("year"):
            y = filters["year"]
            params["datebetween"] = "%s-01-01_%s-12-31" % (y, y)
        data = self._get("tracks/", params)
        return [self._map_track(t) for t in data.get("results", [])[:count]]

    def new_releases(self, limit=30):
        data = self._get("tracks/", {"limit": limit, "order": "releasedate_desc"})
        return [self._map_track(t) for t in data.get("results", [])]
