# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: hearthis.at (nur Creative-Commons-Gruppe)

WICHTIGE KONZEPTENTSCHEIDUNG: hearthis.at ist strukturell wie SoundCloud -
offene Upload-Plattform, allgemeiner Katalog NICHT durchgaengig sauber
lizenziert (u.a. Profile mit expliziten "I don't own the copyright, fair
use only"-Angaben gefunden). Deshalb bindet dieser Provider AUSSCHLIESSLICH
die kuratierte "Creative Commons Music"-Gruppe an (hearthis.at/creative-
commons/), NICHT den allgemeinen "feed"/"popular"/"search"-Bereich der
Plattform. Genre- und Kuenstler-Filter werden deshalb bewusst NICHT
unterstuetzt (return []) - das wuerde die sichere Eingrenzung auf die
CC-Gruppe umgehen und Content ausserhalb des geprueften Bereichs
einblenden.

API-Struktur verifiziert anhand eines bestehenden, oeffentlichen
Kodi-Addons (github.com/baranator/plugin.audio.hearthis_at), nicht
geraten:
  - Basis-URL: https://api-v2.hearthis.at/
  - Ein Gruppen-/Nutzer-Permalink (hier: "creative-commons") liefert
    ueber GET {permalink}?type=tracks&page=N&count=M die Tracks.
  - Kein API-Key fuer reines Lesen/Abspielen noetig (nur fuer Login-
    Funktionen wie Likes/Follows relevant, die wir nicht nutzen).
  - Abspiel-URL wird NICHT ueber die API aufgeloest, sondern direkt als
    https://hearthis.at/{user_permalink}/{track_permalink}/listen
    konstruiert - kein resolve_stream() noetig.
"""
import requests

from .base import BaseProvider

API_BASE = "https://api-v2.hearthis.at/"
CC_GROUP_PERMALINK = "creative-commons"
PAGE_COUNT = 20


class HearthisProvider(BaseProvider):
    id = "hearthis"
    name = "hearthis.at"
    display_name = "hearthis.at (Creative Commons)"

    def _get(self, path, params=None):
        r = requests.get(API_BASE + path, params=params or {}, timeout=15)
        r.raise_for_status()
        return r.json()

    def _map_track(self, t):
        user = t.get("user") or {}
        user_permalink = user.get("permalink")
        track_permalink = t.get("permalink")
        return {
            "provider": self.id,
            "track_id": "%s:%s" % (user_permalink, track_permalink),
            "title": t.get("title") or "Unknown",
            "artist": user.get("username", "Unknown"),
            "album": None,
            "genre": t.get("genre"),
            "year": int(t["created_at"][:4]) if t.get("created_at") else None,
            "duration": t.get("duration"),
            "license": "Creative Commons (hearthis.at CC-Gruppe)",
            "thumb": t.get("artwork_url"),
            "stream_url": "https://hearthis.at/%s/%s/listen" % (user_permalink, track_permalink),
            "date_added": t.get("created_at"),
        }

    def get_genres(self):
        # Bewusst leer - Genre-Filter wuerde ausserhalb der CC-Gruppe
        # suchen muessen (siehe Modul-Docstring).
        return []

    def _cc_group_tracks(self, start_page=1, limit=PAGE_COUNT):
        # WICHTIG: hearthis.at deckelt "count" laut eigener API-Doku hart
        # bei 20 pro Aufruf. Um trotzdem groessere limit-Werte (z.B. 50)
        # zu befuellen, wird hier intern ueber mehrere 20er-Seiten
        # geblaettert, statt sich auf das generische "Weitere laden" der
        # Kodi-Oberflaeche zu verlassen (das erst ab 100 Treffern pro
        # Antwort ausloest und bei hearthis.at nie gegriffen haette).
        tracks = []
        page = start_page
        while len(tracks) < limit:
            batch = self._get(CC_GROUP_PERMALINK, {"type": "tracks", "page": page, "count": PAGE_COUNT})
            if isinstance(batch, dict) or not batch:
                break  # Fehlerantwort oder keine weiteren Seiten mehr
            tracks.extend(self._map_track(t) for t in batch)
            if len(batch) < PAGE_COUNT:
                break  # letzte Seite erreicht
            page += 1
        return tracks[:limit]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None or artist is not None:
            # Wuerde die CC-Gruppen-Eingrenzung umgehen - siehe Docstring.
            return []
        start_page = (offset // PAGE_COUNT) + 1
        return self._cc_group_tracks(start_page=start_page, limit=limit)

    def search(self, query, limit=50):
        # Client-seitig innerhalb der CC-Gruppe filtern, statt die
        # globale hearthis.at-Suche zu nutzen (die wuerde auch nicht
        # lizenzgeprueften Content liefern). Grosszuegiger abrufen, da
        # nach dem Textfilter viel wegfaellt.
        query_lower = query.lower()
        pool = self._cc_group_tracks(start_page=1, limit=max(limit * 4, 100))
        matches = [t for t in pool if query_lower in (t.get("title") or "").lower()]
        return matches[:limit]

    def random_tracks(self, count=1, filters=None):
        if filters and (filters.get("genre") or filters.get("artist")):
            return []
        import random
        tracks = self._cc_group_tracks(start_page=1, limit=max(count * 3, 60))
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        return self._cc_group_tracks(start_page=1, limit=limit)
