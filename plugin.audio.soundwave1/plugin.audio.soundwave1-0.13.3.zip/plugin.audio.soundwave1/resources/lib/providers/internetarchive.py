# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Internet Archive (archive.org)

Genau das bestehende Muster aus Saschas anderen Addons (IA als
Streaming-Quelle mit direkter Datei-URL-Aufloesung), hier als
eigenstaendige Quelle statt nur als Fallback. Zwei offizielle,
dokumentierte, unauthentifizierte Endpunkte (archive.org/services/docs/api/):

  1) Advanced Search API - Suche/Browsing nach Collection, Mediatype etc.
       https://archive.org/advancedsearch.php
  2) Metadata API - Datei-Liste eines einzelnen Items
       https://archive.org/metadata/{identifier}

Kein API-Key, kein Account, keine Rate-Limit-Anmeldung noetig. Direkte
Downloadlinks unter https://archive.org/download/{identifier}/{filename} -
statisch, unsigniert, dauerhaft.

WICHTIGE KONZEPTENTSCHEIDUNG (nach Ruecksprache): Statt sich auf eine
Handvoll manuell kuratierter Collections zu beschraenken, wird der
komplette IA-Audio-Bestand durchsucht - ABER mit einem echten
Lizenz-Filter statt einer Collection-Whitelist: nur Treffer, die selbst
eine Creative-Commons- oder Public-Domain-Lizenz-URL hinterlegt haben
(IA-Feld "licenseurl"). Das ist das eigentliche Kriterium (ist der Titel
lizenziert, ja oder nein), nicht die Frage, in welcher Collection er
zufaellig einsortiert ist - und deutlich treffsicherer als der reine
"podcasts"/"opensource_audio"-Fehlschlag aus einer frueheren Version
dieses Moduls. Ohne hinterlegte Lizenz-URL wird ein Treffer NICHT
angezeigt, selbst wenn er inhaltlich nach freier Musik aussieht - lieber
false negatives als ungeprueften Content durchlassen.

Die drei zusaetzlich weiterhin als "Genre"-Ordner nutzbaren, klar
abgegrenzten Collections (siehe CURATED_COLLECTIONS) filtern praezise
nach Collection UND greifen zusaetzlich denselben Lizenz-Filter - das
"etree"-Live-Music-Archive enthaelt Konzertmitschnitte von Bands mit
expliziter Taping-Policy, rechtlich also dasselbe Modell wie Phish.in.
"""
import requests

from .base import BaseProvider
from urllib.parse import quote

SEARCH_URL = "https://archive.org/advancedsearch.php"
METADATA_URL = "https://archive.org/metadata"

# Nur fuer die "Genre"-Ordneransicht - der eigentliche Sicherheitsfilter
# ist LICENSE_FILTER unten, nicht diese Liste. Diese hier ist nur eine
# bequeme Vorauswahl fuer thematisch enger gefasste Ordner.
CURATED_COLLECTIONS = {
    "netlabels": "Netlabels (elektronische Musik, ueberwiegend CC-lizenziert)",
    "georgeblood": "78rpm- und Zylinder-Aufnahmen (georgeblood-Sammlung, groesstenteils PD)",
    "etree": "Live Music Archive (Konzertmitschnitte, Taping-Policy-Bands)",
}

# Das eigentliche Sicherheitskriterium: nur Treffer mit hinterlegter
# CC- oder PD-Lizenz-URL.
#
# KORREKTUR nach echtem Testlauf (Internet Archive lieferte plötzlich
# GAR NICHTS mehr): Die urspruengliche Fassung nutzte einen Suchbegriff
# mit FUEHRENDEM Platzhalter (*creativecommons.org...*) - solche Anfragen
# lehnen viele Suchindizes (offenbar auch der von archive.org) grundsaetzlich
# ab oder liefern nie Treffer. Jetzt serverseitig nur eine reine
# Existenzpruefung ("hat ueberhaupt eine Lizenz-URL", kein Platzhalter
# noetig), die eigentliche CC/PD-Pruefung passiert zusaetzlich
# clientseitig in _tracks_from_item() per einfachem Text-Vergleich.
LICENSE_FILTER = "licenseurl:[* TO *]"


def _has_cc_or_pd_license(license_url):
    if not license_url:
        return False
    return "creativecommons.org" in license_url

_AUDIO_EXTS = (".mp3", ".ogg", ".flac", ".m4a")


def _parse_duration(length_value):
    """IA liefert die Laenge manchmal als reine Sekundenzahl ('134.56'),
    manchmal als 'MM:SS' oder 'HH:MM:SS' (siehe echter Testlauf-Fehler:
    ValueError bei '20:54'). Beide Formen abfangen, sonst None."""
    if not length_value:
        return None
    try:
        return int(float(length_value))
    except (ValueError, TypeError):
        pass
    try:
        parts = [int(p) for p in str(length_value).split(":")]
        seconds = 0
        for p in parts:
            seconds = seconds * 60 + p
        return seconds
    except (ValueError, TypeError):
        return None


class InternetArchiveProvider(BaseProvider):
    id = "internetarchive"
    name = "Internet Archive"
    display_name = "Internet Archive"

    def _search(self, query, rows=20, page=1, sort=None):
        params = {
            "q": query,
            "fl[]": ["identifier", "title", "creator", "date", "licenseurl", "collection"],
            "rows": rows,
            "page": page,
            "output": "json",
        }
        if sort:
            params["sort[]"] = sort
        r = requests.get(SEARCH_URL, params=params, timeout=15)
        r.raise_for_status()
        return r.json().get("response", {}).get("docs", [])

    def _files_for_item(self, identifier):
        r = requests.get("%s/%s" % (METADATA_URL, identifier), timeout=8)
        r.raise_for_status()
        data = r.json()
        return data.get("files", []), data.get("metadata", {})

    def _tracks_from_item(self, doc, limit_files=30):
        license_url = doc.get("licenseurl")
        if not _has_cc_or_pd_license(license_url):
            # Server hat nur "irgendeine Lizenz-URL gesetzt" geprueft -
            # hier die eigentliche CC/PD-Pruefung. Kein Treffer -> raus.
            return []

        identifier = doc.get("identifier")
        files, meta = self._files_for_item(identifier)
        title_base = doc.get("title") or identifier
        artist = doc.get("creator") or "Unknown"
        if isinstance(artist, list):
            artist = ", ".join(artist)
        year = None
        if doc.get("date"):
            year_str = str(doc["date"])[:4]
            if year_str.isdigit():
                year = int(year_str)
        collection = doc.get("collection")
        genre = collection[0] if isinstance(collection, list) and collection else collection

        tracks = []
        audio_files = [f for f in files if (f.get("name") or "").lower().endswith(_AUDIO_EXTS)]
        # Manche Items haben denselben Track in mehreren Formaten (z.B.
        # .flac + .mp3) - das fuehrt sonst zu Duplikaten in der Liste.
        # Pro Basisname (ohne Endung) nur eine Datei behalten, mp3
        # bevorzugt (kleiner, universell abspielbar).
        by_base = {}
        for f in audio_files:
            base_name = f["name"].rsplit(".", 1)[0]
            ext = f["name"].rsplit(".", 1)[-1].lower()
            current = by_base.get(base_name)
            if current is None or (ext == "mp3" and current["name"].rsplit(".", 1)[-1].lower() != "mp3"):
                by_base[base_name] = f
        audio_files = list(by_base.values())
        for f in audio_files[:limit_files]:
            fname = f["name"]
            # Bei Multi-Track-Items (Album) den Dateinamen als Tracktitel
            # nehmen, bei Einzel-Items (nur 1 Audiodatei) den Item-Titel.
            track_title = fname.rsplit(".", 1)[0] if len(audio_files) > 1 else title_base
            tracks.append({
                "provider": self.id,
                "track_id": "%s/%s" % (identifier, fname),
                "title": track_title,
                "artist": artist,
                "album": title_base,
                "genre": genre,
                "year": year,
                "duration": _parse_duration(f.get("length")),
                "license": license_url,
                "thumb": "https://archive.org/services/img/%s" % identifier,
                "stream_url": "https://archive.org/download/%s/%s" % (identifier, quote(fname)),
                "date_added": doc.get("date"),
            })
        return tracks

    def get_genres(self):
        return list(CURATED_COLLECTIONS.keys())

    def get_artists(self, genre=None):
        # IAs Facetten-Suche liefert echte, gezaehlte Kuenstlernamen -
        # kein Raten/Scrapen noetig, offiziell dokumentiertes API-Feature.
        # Nutzt denselben Lizenz-Filter wie alles andere hier, damit auch
        # die Kuenstlerliste nur lizenzierten Content widerspiegelt.
        q_parts = ["mediatype:(audio)", LICENSE_FILTER]
        if genre and genre in CURATED_COLLECTIONS:
            q_parts.append("collection:(%s)" % genre)
        params = {
            "q": " AND ".join(q_parts),
            "rows": 0,
            "output": "json",
            "facet": "true",
            "facet.field": "creator",
            "facet.limit": 100,
        }
        try:
            r = requests.get(SEARCH_URL, params=params, timeout=15)
            r.raise_for_status()
            facet_data = r.json().get("response", {}).get("facet_counts", {}).get("facet_fields", {}).get("creator", [])
        except Exception:
            return []
        # facet_fields liefert eine flache Liste [name, count, name, count, ...]
        names = facet_data[0::2]
        return [{"id": n, "name": n} for n in names if n]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None and genre not in CURATED_COLLECTIONS:
            # Dieser Genre-Name kommt von einem anderen Anbieter und ist
            # hier nicht bekannt - lieber nichts zurueckgeben, als
            # faelschlich auf eine Standard-Collection auszuweichen (das
            # fuehrte dazu, dass jede Genre-Auswahl dieselben Treffer
            # zeigte, siehe Testlauf-Fehlerbericht).
            return []
        q_parts = ["mediatype:(audio)", LICENSE_FILTER]
        if genre:
            q_parts.append("collection:(%s)" % genre)
        if artist:
            q_parts.append('creator:("%s")' % artist)
        if year:
            q_parts.append("date:[%s-01-01 TO %s-12-31]" % (year, year))
        docs = self._search(" AND ".join(q_parts), rows=max(limit * 2, 30), page=(offset // 50) + 1)
        tracks = []
        for doc in docs:
            try:
                tracks.extend(self._tracks_from_item(doc))
            except Exception:
                # Ein einzelner kaputter/langsamer Treffer (siehe echter
                # Testlauf-Fehler: ValueError bei Dauer-Parsing riss die
                # KOMPLETTE Liste mit sich runter) darf nie die ganze
                # Anfrage abbrechen - einfach ueberspringen und weiter.
                continue
            if len(tracks) >= limit:
                break
        return tracks[:limit]

    def search(self, query, limit=50):
        q = "(%s) AND mediatype:(audio) AND %s" % (query, LICENSE_FILTER)
        docs = self._search(q, rows=max(limit * 2, 30))
        tracks = []
        for doc in docs:
            try:
                tracks.extend(self._tracks_from_item(doc))
            except Exception:
                # Ein einzelner kaputter/langsamer Treffer (siehe echter
                # Testlauf-Fehler: ValueError bei Dauer-Parsing riss die
                # KOMPLETTE Liste mit sich runter) darf nie die ganze
                # Anfrage abbrechen - einfach ueberspringen und weiter.
                continue
            if len(tracks) >= limit:
                break
        return tracks[:limit]

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        tracks = self.browse_tracks(genre=filters.get("genre"), limit=max(count * 3, 30))
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        q = "mediatype:(audio) AND %s" % LICENSE_FILTER
        docs = self._search(q, rows=max(limit * 2, 30), sort="addeddate desc")
        tracks = []
        for doc in docs:
            try:
                tracks.extend(self._tracks_from_item(doc))
            except Exception:
                # Ein einzelner kaputter/langsamer Treffer (siehe echter
                # Testlauf-Fehler: ValueError bei Dauer-Parsing riss die
                # KOMPLETTE Liste mit sich runter) darf nie die ganze
                # Anfrage abbrechen - einfach ueberspringen und weiter.
                continue
            if len(tracks) >= limit:
                break
        return tracks[:limit]
