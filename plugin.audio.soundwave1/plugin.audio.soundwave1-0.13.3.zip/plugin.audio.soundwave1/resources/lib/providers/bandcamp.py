# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Bandcamp (bandcamp.com)

KORREKTUR (Konzeptentscheidung nach Ruecksprache): Bandcamp wird bewusst
NICHT mehr auf Free/Name-your-price-Content gefiltert. Grund: Bandcamp
erlaubt praktisch jeden Track/jedes Album vollstaendig kostenlos und
ohne Login ANZUHOEREN (Streaming ueber den eingebetteten Player) - bezahlt
wird dort nur fuers Herunterladen/Besitzen der Datei. Da SoundWave 1
ausschliesslich streamt und nichts herunterlaedt, ist das dieselbe
oeffentliche Funktion, die Bandcamp jedem anonymen Besucher bietet - kein
Paywall-Bypass. Damit sind auch grosse/kommerzielle Acts (z.B. wurde Foo
Fighters im Testlauf ueber genau diesen Streaming-Weg gefunden und laesst
sich nachweislich ohne Anmeldung anhoeren) reguraerer Bestandteil des
Katalogs - bewusster Umfang-Gewinn statt Bug.

  1) Discover-API liefert eine breite Trefferliste nach Genre/Tag - POST
     auf /api/discover/1/discover_web mit tag_norm_names als Filter,
     cursor-basierte Pagination.

  2) Pro Kandidat wird die Album-/Track-Seite geladen (data-tralbum
     JSON-Attribut) fuer die Tracklist inkl. Stream-URLs
     (trackinfo[i]["file"]["mp3-128"]). Das Muster ist von diversen
     Bandcamp-Tools (u.a. yt-dlp) her bekannt und wurde im Testlauf
     bereits erfolgreich bestaetigt (echte Stream-URLs kamen zurueck).

  Korrektes URL-Feld im Discover-Ergebnis ist "item_url" (im Testlauf
  bestaetigt - meine erste Annahme "tralbum_url"/"item_url_root" war
  falsch und lieferte deshalb 0 Treffer).
"""
import html as html_module
import json
import os
import re

import requests

from .base import BaseProvider

DISCOVER_URL = "https://bandcamp.com/api/discover/1/discover_web"
_TRALBUM_RE = re.compile(r'data-tralbum="([^"]+)"')
_BAND_RE = re.compile(r'data-band="([^"]+)"')
_DEBUG = os.environ.get("SW1_DEBUG") == "1"


def _dbg(msg):
    if _DEBUG:
        import sys
        print("[bandcamp debug] %s" % msg, file=sys.stderr)


class BandcampProvider(BaseProvider):
    id = "bandcamp"
    name = "Bandcamp"
    display_name = "Bandcamp"

    def _discover(self, tag=None, size=60, cursor="*"):
        body = {
            "category_id": 0,
            "tag_norm_names": [tag] if tag else [],
            "geoname_id": 0,
            "slice": "top",
            "time_facet_id": None,
            "cursor": cursor,
            "size": size,
            "include_result_types": ["a", "s"],  # albums + tracks
            "followed_bands": False,
        }
        r = requests.post(DISCOVER_URL, json=body, timeout=15)
        r.raise_for_status()
        return r.json()

    def _load_tralbum(self, item_url):
        """Laedt die Release-Seite und liefert (band_name, tralbum_dict)
        oder (None, None) falls nicht auslesbar."""
        r = requests.get(item_url, timeout=15)
        r.raise_for_status()
        m = _TRALBUM_RE.search(r.text)
        if not m:
            _dbg("kein data-tralbum gefunden auf %s (Seitenlaenge %d Zeichen)" % (item_url, len(r.text)))
            return None, None
        try:
            data = json.loads(html_module.unescape(m.group(1)))
        except (ValueError, TypeError) as exc:
            _dbg("tralbum-JSON nicht parsebar auf %s: %s" % (item_url, exc))
            return None, None
        band_m = _BAND_RE.search(r.text)
        band_name = None
        if band_m:
            try:
                band_name = json.loads(html_module.unescape(band_m.group(1))).get("name")
            except (ValueError, TypeError):
                pass
        return band_name, data

    def _map_tracks(self, band_name, tralbum, source_url):
        album_title = (tralbum.get("current") or {}).get("title")
        out = []
        for t in tralbum.get("trackinfo", []):
            file_urls = t.get("file") or {}
            stream_url = file_urls.get("mp3-128")
            if not stream_url:
                continue  # Track ohne freigeschaltetes Stream-File ueberspringen (z.B. noch nicht veroeffentlicht)
            out.append({
                "provider": self.id,
                "track_id": str(t.get("id") or t.get("track_id") or ""),
                "title": t.get("title") or "Unknown",
                "artist": band_name or "Unknown",
                "album": album_title,
                "genre": None,  # Genre kommt aus dem Discover-Tag, nicht aus tralbum
                "year": None,
                "duration": int(t["duration"]) if t.get("duration") else None,
                "license": "Bandcamp (frei anhoerbar, Download ggf. kostenpflichtig)",
                "thumb": None,
                "stream_url": stream_url,
                "date_added": None,
            })
        return out

    def _candidates_to_tracks(self, results, limit):
        _dbg("Discover lieferte %d Kandidaten" % len(results))
        tracks = []
        no_url = 0
        no_tralbum = 0
        for item in results:
            url = item.get("item_url")
            if not url:
                no_url += 1
                continue
            band_name, tralbum = self._load_tralbum(url)
            if not tralbum:
                no_tralbum += 1
                continue
            mapped = self._map_tracks(band_name, tralbum, url)
            tracks.extend(mapped)
            if len(tracks) >= limit:
                break
        _dbg("ohne URL: %d, tralbum nicht lesbar: %d, Tracks gefunden: %d"
             % (no_url, no_tralbum, len(tracks)))
        return tracks[:limit]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        data = self._discover(tag=genre, size=max(limit * 2, 40))
        return self._candidates_to_tracks(data.get("results", []), limit)

    def search(self, query, limit=50):
        # Discover-API ist tag-basiert, keine Volltextsuche - fuer echte
        # Suche muesste bandcamp.com/search (separates HTML-Endpoint,
        # noch nicht mitgeschnitten) angebunden werden.
        return []

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(genre=(filters or {}).get("genre"), limit=max(count * 3, 30))
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        data = self._discover(size=max(limit * 2, 40))
        return self._candidates_to_tracks(data.get("results", []), limit)
