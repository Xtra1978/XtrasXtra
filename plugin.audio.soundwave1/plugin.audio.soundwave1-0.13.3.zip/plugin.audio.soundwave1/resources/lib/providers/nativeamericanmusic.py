# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Native American Music Awards (nativeamericanmusicawards.com)

Legitime, seit 1998 bestehende gemeinnuetzige Organisation (501(c)(3)),
anerkannte Branchen-Auszeichnung fuer indigene Musik in Nordamerika. Die
Winners-Music-Seite ist eine offizielle "Free Listening Station" mit
freiwillig eingereichter Musik nominierter/preisgekroenter Kuenstler -
kein Major-Label-Content, keine Grauzone.

Technik: Seite laeuft auf Bandzoogle (Website-Baukasten fuer Musiker,
erkennbar an bndzgl.com/bzglfiles.s3...-Domains). Pro Track liegen die
Metadaten direkt als HTML-Datenattribute am Play-Button vor, kein
separater API-Call noetig:
    data-id="{track_id}" data-artist="..." data-duration="M:SS"
    data-title="..." data-dest="/player/{player_id}/tracks/{track_id}.mp3"

Der "data-dest"-Pfad liefert per 302-Redirect direkt eine signierte
S3-URL (bestaetigt im HAR, Status 206 audio/mpeg) - kein resolve_stream()
noetig, Kodi folgt dem Redirect automatisch.

Kein Genre-/Kategorie-Feld in den Daten gefunden - bewusst kein
Genre-Filter unterstuetzt (return []), analog zu anderen Quellen ohne
dieses Konzept (Phish.in, ReverbNation).

Aktuell wird nur die einzelne Winners-Music-Seite gescraped (liefert im
Testlauf 138 Tracks) - falls die Seite per "Load more"/Infinite-Scroll
noch mehr Tracks nachlaedt, die per JS-API nachgeladen werden, ist das
noch nicht erfasst (keine entsprechenden Netzwerk-Aufrufe im HAR
gesehen).
"""
import re

import requests

from .base import BaseProvider

BASE = "https://nativeamericanmusicawards.com"
WINNERS_PATH = "/winners-music"

_TRACK_RE = re.compile(
    r'data-id="(\d+)"\s+data-artist="([^"]*)"\s+data-duration="([^"]*)"\s+'
    r'data-title="([^"]*)"\s+data-category="[^"]*"\s+'
    r'data-dest="(/player/\d+/tracks/\d+\.mp3)"'
)


def _clean_title(raw_title, artist):
    title = raw_title.strip()
    if artist:
        prefix = "%s -" % artist
        suffix = "- %s" % artist
        if title.startswith(prefix):
            title = title[len(prefix):].strip()
        if title.endswith(suffix):
            title = title[: -len(suffix)].strip()
    return title or raw_title


def _duration_to_seconds(value):
    if not value:
        return None
    try:
        parts = [int(p) for p in value.split(":")]
        seconds = 0
        for p in parts:
            seconds = seconds * 60 + p
        return seconds
    except (ValueError, TypeError):
        return None


class NativeAmericanMusicAwardsProvider(BaseProvider):
    id = "nativeamericanmusic"
    name = "Native American Music Awards"
    display_name = "Native American Music Awards"

    def _all_tracks(self):
        r = requests.get(BASE + WINNERS_PATH, timeout=15)
        r.raise_for_status()
        html = r.text
        tracks = []
        seen = set()
        for track_id, artist, duration, raw_title, dest in _TRACK_RE.findall(html):
            if track_id in seen:
                continue
            seen.add(track_id)
            tracks.append({
                "provider": self.id,
                "track_id": track_id,
                "title": _clean_title(raw_title, artist),
                "artist": artist or "Unknown",
                "album": None,
                "genre": None,
                "year": None,
                "duration": _duration_to_seconds(duration),
                "license": "Native American Music Awards - Free Listening Station",
                "thumb": None,
                "stream_url": BASE + dest,
                "date_added": None,
            })
        return tracks

    def get_genres(self):
        return []

    def get_artists(self, genre=None):
        tracks = self._all_tracks()
        seen = {}
        for t in tracks:
            if t["artist"] not in seen:
                seen[t["artist"]] = t["artist"]
        return [{"id": name, "name": name} for name in sorted(seen)]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None:
            return []  # kein Genre-Konzept, siehe Modul-Docstring
        tracks = self._all_tracks()
        if artist:
            tracks = [t for t in tracks if t.get("artist") == artist]
        return tracks[offset:offset + limit]

    def search(self, query, limit=50):
        query_lower = query.lower()
        tracks = self._all_tracks()
        matches = [
            t for t in tracks
            if query_lower in (t.get("title") or "").lower()
            or query_lower in (t.get("artist") or "").lower()
        ]
        return matches[:limit]

    def random_tracks(self, count=1, filters=None):
        if filters and filters.get("genre"):
            return []
        tracks = self.browse_tracks(artist=(filters or {}).get("artist"), limit=1000)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # Keine Datumsangaben verfuegbar - kein verlaessliches
        # "neu"-Konzept fuer diese Quelle.
        return []
