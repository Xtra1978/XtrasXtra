# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Ektoplazm (ektoplazm.com)

Kein API - Wordpress-artiger Blog mit Release-Postings, die die
komplette Tracklist direkt im Post-HTML enthalten (Homepage +
/style/{style}/-Listings). Kein separater Aufruf pro Release noetig,
das spart gegenueber Ektoplazm-typischem Verhalten sogar einen Request.

WICHTIG - Stream-URL-Muster ist eine Heuristik, noch nicht breit
verifiziert: Aus zwei Beispielen im HAR abgeleitet
(ektoplazm.com/audio/globular-popping-out.mp3 fuer Release "Globular",
Track "Popping Out"). Angenommenes Muster:
    /audio/{artist-slug}-{track-titel-slug}.mp3
Vor produktivem Einsatz an ein paar weiteren Releases gegenpruefen -
falls das Muster nicht generell stimmt, muesste stattdessen die
tatsaechliche Release-Detailseite (falls es eine gesonderte gibt)
nach echten Audio-Links durchsucht werden.

Der /audio/{slug}.mp3-Aufruf liefert 302 auf eine zeitlich begrenzte,
signierte ziggurat.ektoplazm.com-URL (?md5=...&expires=...). Deshalb
liefert browse_tracks() etc. bewusst NUR die /audio/{slug}.mp3-Basis-URL
als stream_url (die man direkt an den Kodi-Player uebergeben kann - der
folgt dem Redirect selbst automatisch curl/requests-Style). resolve_stream()
existiert zusaetzlich fuer Faelle, in denen die aufgeloeste Ziel-URL
separat gebraucht wird (z.B. fuer Anzeige/Debugging im Log).
"""
import re

import requests

from .base import BaseProvider

BASE = "https://ektoplazm.com"

_POST_RE = re.compile(
    r'<h1><a href="https://ektoplazm\.com/free-music/([a-z0-9-]+)"[^>]*title="Permanent Link to ([^"]+)".*?'
    r'<span class="style">(.*?)</span>.*?'
    r'<span class="d">([A-Za-z]+ \d{1,2}, \d{4})</span>.*?'
    r'<div class="tl">(.*?)</div>',
    re.DOTALL,
)
_TRACK_ROW_RE = re.compile(r'<span class="t">([^<]+)</span>')
_STYLE_LINK_RE = re.compile(r'>([^<]+)</a>')


def _slugify(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


class EktoplazmProvider(BaseProvider):
    id = "ektoplazm"
    name = "Ektoplazm"
    display_name = "Ektoplazm"

    def _get_html(self, path):
        r = requests.get(BASE + path, timeout=15)
        r.raise_for_status()
        return r.text

    def _parse_releases(self, html):
        tracks = []
        for release_slug, release_title, style_html, date_str, tl_html in _POST_RE.findall(html):
            artist = release_title.split("\u2013")[0].strip() if "\u2013" in release_title else release_title
            artist_slug = release_slug.split("-")[0]  # Konvention: Release-Slug beginnt mit Artist-Slug
            styles = _STYLE_LINK_RE.findall(style_html)
            genre = ", ".join(styles) if styles else None
            for track_title in _TRACK_ROW_RE.findall(tl_html):
                track_slug = _slugify(track_title)
                tracks.append({
                    "provider": self.id,
                    "track_id": "%s-%s" % (artist_slug, track_slug),
                    "title": track_title.strip(),
                    "artist": artist,
                    "album": release_title.replace("&#8211;", "-"),
                    "genre": genre,
                    "year": int(date_str[-4:]),
                    "duration": None,
                    "license": "CC (siehe Release-Seite)",
                    "thumb": "%s/img/%s-300x300.jpg" % (BASE, release_slug),
                    # Basis-URL, Redirect wird beim Abspielen live aufgeloest
                    "stream_url": "%s/audio/%s-%s.mp3" % (BASE, artist_slug, track_slug),
                    "date_added": date_str,
                })
        return tracks

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        html = self._get_html("/style/%s/" % genre) if genre else self._get_html("/")
        return self._parse_releases(html)[:limit]

    def search(self, query, limit=50):
        # kein Such-Endpunkt gefunden - ueber lokalen Metadaten-Index loesen
        return []

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(genre=(filters or {}).get("genre"), limit=200)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        return self._parse_releases(self._get_html("/"))[:limit]

    def resolve_stream(self, track_id):
        """Loest die zeitlich begrenzte, signierte Ziel-URL frisch auf.
        track_id hat die Form '{artist_slug}-{track_slug}'."""
        url = "%s/audio/%s.mp3" % (BASE, track_id)
        r = requests.get(url, timeout=15, stream=True, allow_redirects=True)
        r.close()
        return r.url
