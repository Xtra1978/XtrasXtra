# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Mixotic (via Internet Archive)

Mixotic ist ein seit ueber 17 Jahren aktives Netlabel fuer elektronische
DJ-Mixe, CC-BY-NC-ND-lizenziert. Statt mixotic.net direkt zu scrapen
(die Uebersichtsseiten liessen sich in der Aufnahme nicht mitschneiden -
leerer Seiteninhalt trotz HAR), gibt es einen deutlich einfacheren Weg:
Mixotic selbst hat alle 300 jemals veroeffentlichten Mixe als EIN
einzelnes Internet-Archive-Item hochgeladen:

    https://archive.org/details/mixotic.net_202209

Bestaetigt per offizieller IA-Metadaten-Seite: mediatype=audio,
33.8 GB Groesse, "All mixes are free to download under the terms of
the Creative Commons License". Kein eigenes Scraping/Browsing von
mixotic.net noetig - nur ein einziger Metadata-API-Call auf dieses
eine Item, das alle Mixe als Dateien enthaelt (plus Cover-Bilder, die
hier rausgefiltert werden).

Dateinamen-Muster (aus dem Item bestaetigt):
    Mixotic_{nummer}_-_{kuenstler}_-_{titel}.mp3
    Mixotic_{nummer}_-_{kuenstler}_-_{titel}_cover.jpg (wird ignoriert)

Jeder "Track" ist hier ein kompletter, langer DJ-Mix (kein Einzelsong) -
das ist normal fuer diese Quelle, kein Bug.

Kein Genre-Feld pro Datei verfuegbar (nur ein allgemeines Topic-Tag auf
Item-Ebene) - Genre-Filter deshalb nicht unterstuetzt.
"""
import re

import requests

from .base import BaseProvider
from urllib.parse import quote

METADATA_URL = "https://archive.org/metadata/mixotic.net_202209"
DOWNLOAD_BASE = "https://archive.org/download/mixotic.net_202209"

_FILENAME_RE = re.compile(r"^Mixotic_(\d+)_-_(.+?)_-_(.+)\.mp3$", re.IGNORECASE)


class MixoticProvider(BaseProvider):
    id = "mixotic"
    name = "Mixotic"
    display_name = "Mixotic"

    def _all_tracks(self):
        r = requests.get(METADATA_URL, timeout=20)
        r.raise_for_status()
        data = r.json()
        tracks = []
        for f in data.get("files", []):
            fname = f.get("name", "")
            if not fname.lower().endswith(".mp3"):
                continue
            m = _FILENAME_RE.match(fname)
            if m:
                number, artist, title = m.groups()
                artist = artist.replace("_", " ").strip()
                title = title.replace("_", " ").strip()
            else:
                number, artist, title = None, "Various Artists", fname.rsplit(".", 1)[0]
            tracks.append({
                "provider": self.id,
                "track_id": fname,
                "title": "Mixotic %s - %s" % (number, title) if number else title,
                "artist": artist,
                "album": None,
                "genre": None,
                "year": None,
                "duration": int(float(f["length"])) if f.get("length") else None,
                "license": "Creative Commons BY-NC-ND (Mixotic)",
                "thumb": None,
                "stream_url": "%s/%s" % (DOWNLOAD_BASE, quote(fname)),
                "date_added": None,
            })
        return tracks

    def get_genres(self):
        return []

    def get_artists(self, genre=None):
        tracks = self._all_tracks()
        seen = {}
        for t in tracks:
            if t["artist"] not in seen:
                seen[t["artist"]] = t["artist"]
        return [{"id": name, "name": name} for name in sorted(seen)]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None:
            return []  # kein Genre-Feld verfuegbar
        tracks = self._all_tracks()
        if artist:
            tracks = [t for t in tracks if t.get("artist") == artist]
        return tracks[offset:offset + limit]

    def search(self, query, limit=50):
        query_lower = query.lower()
        tracks = self._all_tracks()
        matches = [
            t for t in tracks
            if query_lower in (t.get("title") or "").lower()
            or query_lower in (t.get("artist") or "").lower()
        ]
        return matches[:limit]

    def random_tracks(self, count=1, filters=None):
        if filters and filters.get("genre"):
            return []
        tracks = self.browse_tracks(artist=(filters or {}).get("artist"), limit=1000)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # Dateinamen enthalten die Release-Nummer, keine Datumsangabe -
        # sortiert nach absteigender Nummer als Naeherung fuer "neu".
        tracks = self._all_tracks()
        tracks.sort(key=lambda t: t.get("track_id", ""), reverse=True)
        return tracks[:limit]
