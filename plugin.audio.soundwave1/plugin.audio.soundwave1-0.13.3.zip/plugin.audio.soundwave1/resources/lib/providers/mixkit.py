# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Mixkit (mixkit.co)

Envato-Ableger, bekannte seriöse Quelle fuer lizenzfreie Stock-Medien.
Eigene Mixkit-Lizenz: "can be used with no attribution or sign up
required" (Text direkt von der Seite bestaetigt) - grosszuegiger als
die meisten anderen Quellen im Addon, keine Pflicht-Verlinkung noetig.

Kein API - direkte, unsignierte MP3-Links (assets.mixkit.co/music/{id}/
{id}.mp3), Metadaten (Titel, Kuenstler, Genre-/Mood-Tags) stecken direkt
als HTML im jeweiligen Karten-Element auf den Genre-Uebersichtsseiten
(/free-stock-music/{genre-slug}/) - 102 Genre-Seiten insgesamt bestaetigt.

Kein Datum pro Track gefunden - new_releases() bleibt leer.
"""
import re

import requests

from .base import BaseProvider

BASE = "https://mixkit.co"

_CARD_RE = re.compile(
    r'data-audio-player-item-id-value="(\d+)".*?'
    r'data-audio-player-preview-url-value="([^"]+)".*?'
    r'item-grid-card__title">\s*([^<]+?)\s*</h2>\s*'
    r'<p class="item-grid-music-preview__author">\s*by\s*([^<]+?)\s*</p>.*?'
    r'href="/free-stock-music/([a-z0-9-]+)/"[^>]*>([^<]+)</a>',
    re.DOTALL,
)

# Bekannte Genre-Slugs (aus einer echten Aufnahme, 102 insgesamt - Auswahl
# der Hauptkategorien fuer das Genre-Menue; laesst sich jederzeit erweitern)
KNOWN_GENRES = [
    "ambient", "cinematic", "hip-hop", "corporate-music", "electronic",
    "acoustic", "rock", "jazz", "classical", "country", "pop", "blues",
    "chillout", "dance-pop", "deep-house", "lo-fi",
]


class MixkitProvider(BaseProvider):
    id = "mixkit"
    name = "Mixkit"
    display_name = "Mixkit"

    def _get_html(self, path):
        r = requests.get(BASE + path, timeout=15)
        r.raise_for_status()
        return r.text

    def _parse_tracks(self, html, genre_hint=None):
        tracks = []
        seen = set()
        for track_id, mp3_url, title, author, genre_slug, genre_name in _CARD_RE.findall(html):
            if track_id in seen:
                continue
            seen.add(track_id)
            tracks.append({
                "provider": self.id,
                "track_id": track_id,
                "title": title.strip() or "Unknown",
                "artist": author.strip() or "Unknown",
                "album": None,
                "genre": genre_hint or genre_name.strip(),
                "year": None,
                "duration": None,
                "license": "Mixkit License - free to use, no attribution required",
                "thumb": None,
                "stream_url": mp3_url,
                "date_added": None,
            })
        return tracks

    def get_genres(self):
        return [g.replace("-", " ").title() for g in KNOWN_GENRES]

    def get_artists(self, genre=None):
        tracks = self._parse_tracks(self._get_html("/free-stock-music/"))
        seen = {}
        for t in tracks:
            if t["artist"] not in seen:
                seen[t["artist"]] = t["artist"]
        return [{"id": name, "name": name} for name in sorted(seen)]

    def _slug_for_genre_name(self, genre_name):
        target = genre_name.lower().replace(" ", "-")
        return target if target in KNOWN_GENRES else None

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre:
            slug = self._slug_for_genre_name(genre)
            if not slug:
                return []  # unbekannter Genre-Name - lieber nichts als Falsches zeigen
            tracks = self._parse_tracks(self._get_html("/free-stock-music/%s/" % slug), genre_hint=genre)
        else:
            tracks = self._parse_tracks(self._get_html("/free-stock-music/"))
        if artist:
            tracks = [t for t in tracks if t.get("artist") == artist]
        return tracks[offset:offset + limit]

    def search(self, query, limit=50):
        query_lower = query.lower()
        tracks = self._parse_tracks(self._get_html("/free-stock-music/"))
        matches = [
            t for t in tracks
            if query_lower in (t.get("title") or "").lower()
            or query_lower in (t.get("artist") or "").lower()
        ]
        return matches[:limit]

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(genre=(filters or {}).get("genre"), limit=200)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # Keine Datumsangaben auf der Seite gefunden.
        return []
