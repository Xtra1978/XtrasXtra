# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Phish.in (phish.in)

Einzige Ein-Kuenstler-Quelle im Addon - passt aber gut unter "Kuenstler"
im Hauptmenue. Rechtliche Grundlage: Phish erlaubt seit Jahrzehnten
explizit das Aufnehmen und freie Teilen von Live-Mitschnitten durch Fans
("Taping Policy") - anders als z.B. TelevisionTunes.com KEIN
Graubereich, sondern ein anerkanntes, legales Modell. Offizielle
kommerzielle Releases (LivePhish.com) sind davon getrennt und NICHT
Teil dieser Quelle.

WICHTIG - noch zu verifizieren, sobald ein API-Key vorliegt:
  - Zugriff erfordert einen API-Key, den man sich PER E-MAIL bei den
    Maintainern des Projekts (github.com/jcraigk/phishin) besorgen muss -
    kein Self-Service-Formular wie bei Jamendo.
  - Die exakte aktuelle Basis-URL/Version (moeglich: /api/v2/...) sowie
    die genauen Feldnamen der JSON-Antworten (angenommen: "mp3_url" pro
    Track, "tracks" pro Show, "venue"/"date" pro Show) sind aus oeffent-
    lich zugaenglichen Quellen nicht abschliessend bestaetigt - die
    offizielle Doku unter phish.in/api-docs ist eine JS-App und liefert
    ohne Ausfuehrung keinen Text. Vor produktivem Einsatz einmal mit
    echtem Key gegenpruefen und dieses Modul ggf. anpassen.
  - Bekannt (aus oeffentlichen Nutzungsbeispielen anderer Tools):
    Konzepte "shows" (ein Konzert, mit Datum+Venue), "tracks" (einzelne
    Songs/Jams innerhalb einer Show), "venues", "songs" (Song-Katalog
    ueber alle Shows hinweg).
"""
import requests

from .base import BaseProvider

API_BASE = "https://phish.in/api/v2"


class PhishinProvider(BaseProvider):
    id = "phishin"
    name = "Phish.in"
    display_name = "Phish.in"

    def __init__(self, api_key=None):
        self.api_key = api_key

    def _get(self, path, params=None):
        headers = {"Authorization": "Bearer %s" % self.api_key} if self.api_key else {}
        r = requests.get("%s/%s" % (API_BASE, path), params=params or {}, headers=headers, timeout=15)
        r.raise_for_status()
        return r.json()

    def _map_track(self, track, show=None):
        show = show or track.get("show") or {}
        return {
            "provider": self.id,
            "track_id": str(track.get("id")),
            "title": track.get("title") or track.get("name") or "Unknown",
            "artist": "Phish",
            "album": show.get("date") and (
                "%s - %s" % (show.get("date"), (show.get("venue") or {}).get("name", ""))
            ),
            "genre": "Live",
            "year": int(show["date"][:4]) if show.get("date") else None,
            "duration": int(track["duration"] / 1000) if track.get("duration") else None,
            "license": "Audience Recording (Phish Taping Policy)",
            "thumb": None,
            "stream_url": track.get("mp3_url"),
            "date_added": show.get("date"),
        }

    def get_genres(self):
        # Kein Genre-Konzept bei einer Ein-Kuenstler-Quelle
        return []

    def get_artists(self, genre=None):
        return [{"id": "phish", "name": "Phish"}]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None:
            # Ein-Kuenstler-Quelle ohne Genre-Konzept - lieber nichts
            # zurueckgeben, als das Genre zu ignorieren (siehe
            # Testlauf-Fehlerbericht).
            return []
        params = {"per_page": limit, "page": (offset // limit) + 1 if limit else 1}
        if year:
            params["year"] = year
        data = self._get("tracks", params)
        return [self._map_track(t) for t in data.get("tracks", [])]

    def search(self, query, limit=50):
        data = self._get("search", {"term": query})
        tracks = []
        for show in data.get("shows", []):
            for t in show.get("tracks", []):
                tracks.append(self._map_track(t, show))
        return tracks[:limit]

    def random_tracks(self, count=1, filters=None):
        tracks = []
        for _ in range(count):
            show = self._get("shows/random")
            show_tracks = show.get("tracks", [])
            if show_tracks:
                import random
                tracks.append(self._map_track(random.choice(show_tracks), show))
        return tracks

    def new_releases(self, limit=30):
        # "sort=-updated_at" fuehrte im Testlauf zu 400 Bad Request -
        # vermutlich lehnt die Grape-API unbekannte/falsch benannte
        # Parameter strikt ab. Bewusst auf den simpelsten moeglichen
        # Aufruf reduziert, bis mit echtem API-Key klar ist, welche
        # Sortier-/Paginierungs-Parameter tatsaechlich unterstuetzt werden.
        data = self._get("shows", {"per_page": max(limit // 5, 5)})
        tracks = []
        for show in data.get("shows", []):
            for t in show.get("tracks", []):
                tracks.append(self._map_track(t, show))
        return tracks[:limit]
