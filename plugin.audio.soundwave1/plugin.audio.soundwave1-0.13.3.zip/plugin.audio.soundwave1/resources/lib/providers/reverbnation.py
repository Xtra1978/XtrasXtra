# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: ReverbNation (legacy.reverbnation.com)

RAETSEL GELOEST (dank echtem HAR-Mitschnitt mit tatsaechlich abgespielten
Songs): Der "client"-Parameter ist entgegen meiner urspruenglichen
Annahme KEIN zufaelliger/session-spezifischer Wert, sondern ein FESTER,
stabiler String ("234s3rwas") - identisch in zwei unabhaengigen
Aufnahmen, Wochen auseinander. Zusaetzlich verlangt der Endpunkt einen
passenden Referer- sowie diverse Fetch-Metadata-Header (sec-fetch-*),
ohne die er mit 403 abblockt - das war der eigentliche Fehler, nicht der
Client-Wert selbst.

Bestaetigtes minimales Query-Parameter-Set fuer einen "frischen" Song-
Start (aus dem allerersten Play-Request einer Sitzung uebernommen):
    ?client=234s3rwas&song_id={id}&d=0&pt=NaN&t=0
(Weitere Parameter wie sid/from_page_object/t mit echtem Zeitstempel
kommen bei Folge-Songs innerhalb einer Sitzung dazu, sind fuer eine
einzelne Stream-Aufloesung aber nicht erforderlich - alle 5 im HAR
mitgeschnittenen Varianten lieferten 302.)

Collection-Seiten (legacy.reverbnation.com/collection/{id}-{slug}) sind
weiterhin ganz normale, unauthentifizierte HTML-Seiten und liefern
Song-Links (href="/{artist_slug}/song/{song_id}-{titel_slug}") sowie den
"refresh_html_player_key" fuer die Stream-Aufloesung - kein CSRF-Schutz
noetig (der betraf nur /api/charts/regional, das wir bewusst nicht mehr
nutzen).
"""
import os
import re

import requests

from .base import BaseProvider

BASE = "https://legacy.reverbnation.com"
_REFRESH_KEY_RE = re.compile(r'"refresh_html_player_key":"([a-f0-9]+)"')
_SONG_LINK_RE = re.compile(r'href="/([a-z0-9_-]+)/song/(\d+)-([a-z0-9-]+)"')

# Manuell gepflegte Liste bekannter Collections (id-slug, wie in der URL).
# Die zwei vom Nutzer vorgeschlagenen/im HAR gesehenen als Startpunkt -
# beliebig erweiterbar, sobald weitere Collection-URLs bekannt sind.
KNOWN_COLLECTIONS = [
    "189-dark-pop",
    "643-the-come-up-rock",
]

# Bestaetigt fester Wert (siehe Modul-Docstring) - kein Zufallsgenerator
# mehr noetig.
PLAYER_CLIENT_ID = "234s3rwas"

_BASE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "de,de-DE;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
}

# Fuer normale HTML-Seitenaufrufe (Collection-Seiten)
_PAGE_HEADERS = dict(_BASE_HEADERS, **{
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
})

# Fuer den Stream-Aufloese-Endpunkt - erst mit diesen Headern (inkl.
# Referer und Fetch-Metadata-Headern) lief der Request im echten
# Mitschnitt durch (403 ohne sie).
_STREAM_HEADERS = dict(_BASE_HEADERS, **{
    "Accept": "*/*",
    "Range": "bytes=0-",
    "Referer": BASE + "/main/discover",
    "Sec-Fetch-Dest": "audio",
    "Sec-Fetch-Mode": "no-cors",
    "Sec-Fetch-Site": "same-origin",
})


class ReverbNationProvider(BaseProvider):
    id = "reverbnation"
    name = "ReverbNation"
    display_name = "ReverbNation"

    def _get_html(self, path):
        r = requests.get(BASE + path, headers=_PAGE_HEADERS, timeout=15)
        r.raise_for_status()
        return r.text

    def _tracks_from_collection(self, collection_slug, limit=50):
        html = self._get_html("/collection/%s" % collection_slug)
        key_m = _REFRESH_KEY_RE.search(html)
        refresh_key = key_m.group(1) if key_m else None
        if not refresh_key:
            return []
        tracks = []
        seen_ids = set()
        for artist_slug, song_id, title_slug in _SONG_LINK_RE.findall(html):
            if song_id in seen_ids:
                continue
            seen_ids.add(song_id)
            title = title_slug.replace("-", " ").title()
            tracks.append({
                "provider": self.id,
                "track_id": "%s:%s" % (refresh_key, song_id),
                "title": title,
                "artist": artist_slug,  # nur Slug verfuegbar auf Collection-Seiten, kein Klarname
                "album": None,
                "genre": None,
                "year": None,
                "duration": None,
                "license": None,
                "thumb": None,
                "stream_url": None,  # wird ueber resolve_stream() live aufgeloest
                "date_added": None,
            })
            if len(tracks) >= limit:
                break
        return tracks

    def get_genres(self):
        return []

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if genre is not None:
            # KNOWN_COLLECTIONS sind nicht nach dem gemeinsamen Genre-
            # Wortschatz organisiert - lieber nichts zurueckgeben, als
            # das Genre zu ignorieren (siehe Testlauf-Fehlerbericht).
            return []
        tracks = []
        for slug in KNOWN_COLLECTIONS:
            tracks.extend(self._tracks_from_collection(slug, limit=limit))
            if len(tracks) >= limit:
                break
        return tracks[:limit]

    def search(self, query, limit=50):
        # Kein Such-Endpunkt ohne CSRF-Schutz gefunden
        return []

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(limit=200)
        import random as _random
        _random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # Collections sind nicht nach Datum sortiert - kein verlaessliches
        # "neu"-Konzept fuer diese Quelle
        return []

    def resolve_stream(self, track_id):
        """track_id hat die Form '{refresh_key}:{song_id}'. Nutzt den
        bestaetigt festen PLAYER_CLIENT_ID-Wert plus das minimale
        Parameter-Set eines "frischen" Song-Starts (siehe Modul-
        Docstring) - im echten Mitschnitt fuehrte das zu 302 statt 403."""
        refresh_key, _, song_id = str(track_id).partition(":")
        if not refresh_key or not song_id:
            return None
        url = "%s/audio_player/html_player_stream/%s" % (BASE, refresh_key)
        params = {
            "client": PLAYER_CLIENT_ID,
            "song_id": song_id,
            "d": "0",
            "pt": "NaN",
            "t": "0",
        }
        r = requests.get(url, params=params, headers=_STREAM_HEADERS, timeout=15, allow_redirects=True)
        if os.environ.get("SW1_DEBUG") == "1":
            import sys
            print("[reverbnation debug] status=%d history=%s final_url=%s content-type=%s body[:200]=%r"
                  % (r.status_code, [h.status_code for h in r.history], r.url,
                     r.headers.get("content-type"), r.text[:200]), file=sys.stderr)
        if r.status_code >= 400:
            return None
        return r.url
