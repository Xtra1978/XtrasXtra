# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider Base Interface

Alle Provider-Module implementieren dieselben Methoden (duck-typed, kein
erzwungenes Vererbungs-Interface, analog zum bestehenden Source-Modul-Muster
in Saschas anderen Addons). Ein Provider MUSS nicht jede Methode sinnvoll
befuellen koennen (z.B. kein "get_artists" bei manchen Quellen) - dann
gibt die Methode einfach eine leere Liste zurueck.

Rueckgabeformat (einheitlich ueber alle Provider hinweg):

Track-Dict:
{
    "provider":    str   # provider-id, z.B. "musopen"
    "track_id":    str   # provider-interne ID (als String)
    "title":       str
    "artist":      str
    "album":       str | None
    "genre":       str | None
    "year":        int | None
    "duration":    int | None   # Sekunden
    "license":     str | None   # z.B. "CC-BY", "CC-PD"
    "thumb":       str | None   # Cover-URL
    "stream_url":  str          # direkt abspielbar ODER vom Router live
                                 # per resolve_stream() aufzuloesen
    "date_added":  str | None   # ISO-Datum, fuer "New on SoundWave 1"
}

Provider, deren Stream-URL zeitlich begrenzt/signiert ist (z.B. Ektoplazm),
liefern in stream_url bewusst nur eine Platzhalter-Kennung und werden ueber
resolve_stream(track_id) zum Abspielzeitpunkt frisch aufgeloest. Bei den in
dieser Runde umgesetzten 7 Quellen ist das nicht noetig - stream_url ist
direkt final.
"""


class BaseProvider(object):
    # von jeder Unterklasse zu ueberschreiben
    id = "base"
    name = "Base Provider"
    # taucht in "New on SoundWave 1" als Herkunftsangabe auf
    display_name = "Base"

    def get_genres(self):
        """Liste von Genre-Namen (str), sofern die Quelle das hergibt."""
        return []

    def get_artists(self, genre=None):
        """Liste von Artist-Dicts: {"id": str, "name": str}"""
        return []

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        """Haupt-Browsing-Methode, liefert Liste von Track-Dicts."""
        return []

    def search(self, query, limit=50):
        """Freitextsuche, liefert Liste von Track-Dicts."""
        return []

    def random_tracks(self, count=1, filters=None):
        """Fuer SW1 Generator / Play for me. filters ist ein Subset von
        {"genre":..,"artist":..,"year":..} - Provider die kein natives
        Random unterstuetzen, ziehen lokal aus browse_tracks()/search()."""
        return []

    def new_releases(self, limit=30):
        """Fuer 'New on SoundWave 1'. Neueste Veroeffentlichungen."""
        return []

    def resolve_stream(self, track_id):
        """Nur fuer Provider mit zeitlich begrenzten Stream-URLs relevant.
        Liefert eine frisch aufgeloeste, abspielbare URL."""
        return None
