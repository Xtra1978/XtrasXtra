# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Blocsonic (blocsonic.com)

Kein JSON-API - Custom-CMS mit sauberer URL-Struktur, per HTML-Scraping
angebunden (wie Ektoplazm), aber mit dem entscheidenden Unterschied:
Stream-Links sind statisch und UNSIGNIERT, kein zeitliches Ablaufen
(aus zwei unabhaengigen Live-Captures mit tatsaechlich abgespielten
Tracks bestaetigt) - resolve_stream() daher nicht noetig.

URL-Muster:
  Genre-Listing:   /releases/genre/{genre-slug}/{page}
  Release-Seite:   /releases/{artist-slug}/{release-slug}
  Track-MP3:       assets.blocsonic.com/releases/{kategorie}/{release-code}/
                    {NN}-{TrackName}_192kb.mp3

Pro Track direkt auf der Release-Seite verfuegbar: Titel, Genre(s)
(Mehrfachauswahl moeglich, z.B. "Rock, Pop, Punk"), Jahr, Label
(z.B. "blocSonic" oder Sub-Label "maxBlocs"). Lizenz durchgaengig
Creative Commons (im geprueften Beispiel BY-NC-SA 3.0) - je Release
im Footer der Release-Seite verlinkt.
"""
import re

import requests

from .base import BaseProvider

BASE = "https://blocsonic.com"

_TRACK_LINK_RE = re.compile(
    r'href="(https://assets\.blocsonic\.com/releases/[^"]+?/(\d+)-([^"/]+?)_192kb\.mp3)"'
)
_RELEASE_LINK_RE = re.compile(r'href="(/releases/[a-z0-9-]+/[a-z0-9-]+)"')
_GENRE_ROW_RE = re.compile(
    r'Genre:.*?</strong>\s*<ul[^>]*>(.*?)</ul>', re.DOTALL
)
_YEAR_RE = re.compile(r'Year:\s*</strong>\s*(\d{4})')
_LICENSE_RE = re.compile(r'creativecommons\.org/licenses/([a-z-]+)/([0-9.]+)')
_TITLE_RE = re.compile(r'<title>([^<]*)</title>')


class BlocsonicProvider(BaseProvider):
    id = "blocsonic"
    name = "Blocsonic"
    display_name = "Blocsonic"

    def _get_html(self, path):
        r = requests.get(BASE + path, timeout=15)
        r.raise_for_status()
        return r.text

    def _release_slugs_from_genre(self, genre_slug, page=1):
        html = self._get_html("/releases/genre/%s/%s" % (genre_slug, page))
        return sorted(set(_RELEASE_LINK_RE.findall(html)))

    def get_artists(self, genre=None):
        # KEIN dediziertes /artists-Endpunkt-Scraping (Struktur nicht
        # verifiziert) - stattdessen Kuenstler-Slugs aus den bereits
        # bestaetigten Release-Pfaden (/releases/{artist}/{release})
        # ueber eine Handvoll Beispiel-Genres ableiten. Stichproben-
        # basiert, nicht erschoepfend - nutzt aber dasselbe verifizierte
        # Muster wie das normale Browsing.
        sample_genres = ["rock", "electronic", "hip-hop", "downtempo", "punk"]
        seen = {}
        for g in sample_genres:
            try:
                for release_path in self._release_slugs_from_genre(g):
                    parts = release_path.strip("/").split("/")
                    if len(parts) >= 2:
                        artist_slug = parts[1]
                        if artist_slug not in seen:
                            seen[artist_slug] = artist_slug.replace("-", " ").title()
            except Exception:
                continue
        return [{"id": slug, "name": name} for slug, name in seen.items()]

    def _tracks_from_release(self, release_path):
        html = self._get_html(release_path)
        title_m = _TITLE_RE.search(html)
        # Titel-Tag hat Form 'Artist "Release"' - fuer Artist-Feld splitten
        artist = "Unknown"
        album = title_m.group(1) if title_m else "Unknown"
        if title_m and "\u201c" in title_m.group(1):
            artist, _, rest = title_m.group(1).partition("\u201c")
            artist = artist.strip()
            album = rest.rstrip("\u201d").strip()

        year_m = _YEAR_RE.search(html)
        year = int(year_m.group(1)) if year_m else None

        lic_m = _LICENSE_RE.search(html)
        license_str = "CC-%s-%s" % (lic_m.group(1).upper(), lic_m.group(2)) if lic_m else None

        genre_m = _GENRE_ROW_RE.search(html)
        genre = None
        if genre_m:
            names = re.findall(r'>([^<]+)</a>', genre_m.group(1))
            genre = ", ".join(names) if names else None

        tracks = []
        for url, track_no, raw_name in _TRACK_LINK_RE.findall(html):
            # Manche Releases haben eine Disc-Track-Doppelnummerierung im
            # Dateinamen (z.B. "01-02-BrandNewDay" fuer Disc1/Track2) -
            # verbleibende fuehrende "NN-" Praefixe vor dem Titel abstreifen,
            # dann Unterstriche als Worttrenner behandeln, dann CamelCase splitten.
            clean = re.sub(r"^\d+-", "", raw_name).replace("_", " ")
            title = re.sub(r"(?<!^)(?=[A-Z])", " ", clean)
            title = re.sub(r"\s+", " ", title).strip()
            tracks.append({
                "provider": self.id,
                "track_id": url.rsplit("/", 1)[-1],
                "title": title,
                "artist": artist,
                "album": album,
                "genre": genre,
                "year": year,
                "duration": None,
                "license": license_str,
                "thumb": None,
                "stream_url": url,
                "date_added": None,
            })
        return tracks

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if artist and not genre:
            # Keine eigene Kuenstler-Seiten-Struktur verifiziert - dieselbe
            # Stichproben-Genre-Suche wie in get_artists() nutzen und auf
            # den gewuenschten Kuenstler-Slug filtern.
            sample_genres = ["rock", "electronic", "hip-hop", "downtempo", "punk"]
            tracks = []
            seen_paths = set()
            for g in sample_genres:
                for release_path in self._release_slugs_from_genre(g):
                    if release_path in seen_paths:
                        continue
                    parts = release_path.strip("/").split("/")
                    if len(parts) >= 2 and parts[1] == artist:
                        seen_paths.add(release_path)
                        tracks.extend(self._tracks_from_release(release_path))
            return tracks[:limit]
        if not genre:
            return []
        slugs = self._release_slugs_from_genre(genre, page=(offset // 20) + 1)
        tracks = []
        for slug in slugs[:limit]:
            tracks.extend(self._tracks_from_release(slug))
        return tracks

    def search(self, query, limit=50):
        # Kein Such-Endpunkt gefunden - ueber /artists bzw. Genre-Listen
        # muesste eine lokale Such-/Index-Schicht aufgebaut werden
        # (siehe Metadaten-Index-Empfehlung aus der Grundlagenanalyse).
        return []

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        genre = filters.get("genre") or "rock"
        slugs = self._release_slugs_from_genre(genre)
        import random
        random.shuffle(slugs)
        tracks = []
        for slug in slugs:
            tracks.extend(self._tracks_from_release(slug))
            if len(tracks) >= count * 3:
                break
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # /releases (ohne Genre-Filter) ist bereits nach Neuheit sortiert
        html = self._get_html("/releases")
        slugs = sorted(set(_RELEASE_LINK_RE.findall(html)))
        tracks = []
        for slug in slugs[: max(limit // 5, 5)]:
            tracks.extend(self._tracks_from_release(slug))
        return tracks[:limit]
