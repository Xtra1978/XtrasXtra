# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Audius (audius.co)

Nutzt ausschliesslich die offizielle oeffentliche REST-API unter
api.audius.co/v1/ - NICHT das komplizierte clientseitige Signatur-
Verfahren der Web-App (siehe Analyse: mehrere Content-Node-Domains,
ECDSA-Signaturen). Der offizielle Stream-Endpunkt loest das serverseitig
auf und liefert per 302-Redirect direkt die MP3:

    GET https://api.audius.co/v1/tracks/{track_id}/stream

Kodi/urlresolver folgt dem Redirect automatisch - resolve_stream() gibt
daher einfach die Stream-Endpunkt-URL selbst zurueck (kein extra
Request noetig, der Player loest den Redirect beim Abspielen auf).

app_name-Parameter ist Pflicht laut Audius-API-Konvention (kurzer,
selbst gewaehlter Identifier fuer die eigene App/das eigene Addon).
"""
import requests

from .base import BaseProvider

API_BASE = "https://api.audius.co/v1"
APP_NAME = "SoundWave1-KodiAddon"


class AudiusProvider(BaseProvider):
    id = "audius"
    name = "Audius"
    display_name = "Audius"

    def _get(self, path, params=None):
        p = dict(params or {})
        p["app_name"] = APP_NAME
        r = requests.get("%s/%s" % (API_BASE, path), params=p, timeout=15)
        r.raise_for_status()
        return r.json()

    def _map_track(self, t):
        return {
            "provider": self.id,
            "track_id": t.get("id"),
            "title": t.get("title") or "Unknown",
            "artist": (t.get("user") or {}).get("name", "Unknown"),
            "album": None,
            "genre": t.get("genre"),
            "year": int(t["release_date"][:4]) if t.get("release_date") else None,
            "duration": t.get("duration"),
            "license": None,
            "thumb": ((t.get("artwork") or {}).get("480x480")),
            # Stream-Endpunkt direkt als "stream_url" - der Player folgt
            # dem 302-Redirect selbst, kein separates resolve_stream() noetig
            "stream_url": "%s/tracks/%s/stream?app_name=%s" % (API_BASE, t.get("id"), APP_NAME),
            "date_added": t.get("release_date"),
        }

    def get_genres(self):
        data = self._get("tracks/trending", {"limit": 1})
        # Audius liefert keine feste Genre-Liste ueber die oeffentliche API;
        # Vorschlag: kuratierte Liste (Electronic, Hip-Hop, Rock, ...) fest
        # in der Addon-UI pflegen und als "genre"-Filterparameter durchreichen.
        return []

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        if artist:
            data = self._get("users/%s/tracks" % artist, {"limit": limit, "offset": offset})
        else:
            params = {"limit": limit, "offset": offset}
            if genre:
                params["genre"] = genre
            data = self._get("tracks/trending", params)
        return [self._map_track(t) for t in data.get("data", [])]

    def search(self, query, limit=50):
        data = self._get("tracks/search", {"query": query, "limit": limit})
        return [self._map_track(t) for t in data.get("data", [])]

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        params = {"limit": max(count * 3, 30)}
        if filters.get("genre"):
            params["genre"] = filters["genre"]
        data = self._get("tracks/trending", params)
        results = data.get("data", [])
        import random
        random.shuffle(results)
        return [self._map_track(t) for t in results[:count]]

    def new_releases(self, limit=30):
        data = self._get("tracks/trending", {"limit": limit, "time": "week"})
        return [self._map_track(t) for t in data.get("data", [])]
