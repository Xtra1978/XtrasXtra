# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: worldhiphopbeats.com

Kleine, aber echte Nischenquelle - Hip-Hop-Beats/Instrumentals eines
Produzenten-Teams. Bestaetigt Creative-Commons-lizenziert (Attribution-
NonCommercial-ShareAlike 3.0 US), Pflicht-Namensnennung "Beat by
WorldHipHopBeats.com" - siehe "license"-Feld im Track-Dict, MUSS in der
Player-/Detailansicht sichtbar gemacht werden.

Statische HTML-Seite (kein Login, kein JS-Rendering noetig), direkte
MP3-Links direkt in einer HTML-Tabelle auf einer einzigen Seite
(free_hip_hop_beats.html). "Purchase"-Spalte (iTunes-Kauflink) ist rein
optional und betrifft nicht den freien Download/Stream - wird hier
ignoriert.

Kein eigenes Genre-Feld auf der Seite gepflegt, ABER viele MP3-Pfade
liegen in aussagekraeftigen Unterordnern (z.B. mp3/westcoast-beats/...,
mp3/gangsta-beats/...) - das wird hier als Genre-Ersatz genutzt.

Katalog ist klein (ca. 30 Tracks) - passt zur Erwartung "nicht viel,
aber nicht nichts".
"""
import re

import requests

from .base import BaseProvider
from urllib.parse import quote

BASE = "https://www.worldhiphopbeats.com"
CATALOG_PATH = "/free_hip_hop_beats.html"

_MP3_LINK_RE = re.compile(r'\]\(mp3/([^)]+\.mp3)\)')
_BPM_SUFFIX_RE = re.compile(r'(\d+)bpm$', re.IGNORECASE)

LICENSE_TEXT = (
    "Creative Commons Attribution-NonCommercial-ShareAlike 3.0 US - "
    "Credit required: \"Beat by WorldHipHopBeats.com\""
)


def _title_from_filename(fname):
    base = fname.rsplit(".", 1)[0]
    base = _BPM_SUFFIX_RE.sub("", base).rstrip()
    # CamelCase -> Leerzeichen (z.B. "CoffeeAndHash" -> "Coffee And Hash")
    spaced = re.sub(r"(?<!^)(?=[A-Z])", " ", base)
    spaced = re.sub(r"\s+", " ", spaced).strip()
    return spaced or base


def _bpm_from_filename(fname):
    m = _BPM_SUFFIX_RE.search(fname.rsplit(".", 1)[0])
    return int(m.group(1)) if m else None


class WorldHipHopBeatsProvider(BaseProvider):
    id = "worldhiphopbeats"
    name = "World Hip Hop Beats"
    display_name = "World Hip Hop Beats"

    def _all_tracks(self):
        r = requests.get(BASE + CATALOG_PATH, timeout=15)
        r.raise_for_status()
        html = r.text
        tracks = []
        seen = set()
        for rel_path in _MP3_LINK_RE.findall(html):
            if rel_path in seen:
                continue
            seen.add(rel_path)
            parts = rel_path.split("/")
            fname = parts[-1]
            genre = None
            if len(parts) > 1:
                # z.B. "westcoast-beats" -> "Westcoast Beats"
                genre = parts[0].replace("-", " ").title()
            tracks.append({
                "provider": self.id,
                "track_id": rel_path,
                "title": _title_from_filename(fname),
                "artist": "World Hip Hop Beats",
                "album": None,
                "genre": genre,
                "year": None,
                "duration": None,
                "license": LICENSE_TEXT,
                "thumb": None,
                "stream_url": "%s/mp3/%s" % (BASE, quote(rel_path)),
                "date_added": None,
                "_bpm": _bpm_from_filename(fname),
            })
        return tracks

    def get_genres(self):
        tracks = self._all_tracks()
        return sorted({t["genre"] for t in tracks if t.get("genre")})

    def get_artists(self, genre=None):
        # Ein-Team-Quelle, wie Phish.in/Incompetech strukturell.
        return [{"id": "world-hip-hop-beats", "name": "World Hip Hop Beats"}]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        tracks = self._all_tracks()
        if genre:
            tracks = [t for t in tracks if t.get("genre") == genre]
        return tracks[offset:offset + limit]

    def search(self, query, limit=50):
        query_lower = query.lower()
        tracks = self._all_tracks()
        matches = [t for t in tracks if query_lower in (t.get("title") or "").lower()]
        return matches[:limit]

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(genre=(filters or {}).get("genre"), limit=1000)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # Keine Datumsangaben auf der Seite - kein verlaessliches
        # "neu"-Konzept fuer diese Quelle.
        return []
