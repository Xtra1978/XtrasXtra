# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: incompetech.com (Kevin MacLeod)

Ein-Komponist-Quelle (aehnlich Phish.in strukturell: ein "Kuenstler"),
aber mit riesigem Katalog (mehrere tausend Stuecke). Kevin MacLeod ist
einer der bekanntesten und meistgenutzten Anbieter lizenzfreier Musik
im Netz.

KEIN Scraping/Raten noetig - incompetech betreibt eine eigene "Agent
Section" (incompetech.com/agent-section/) mit maschinenlesbarem
Vollkatalog:
  - https://incompetech.com/music/royalty-free/pieces.json (alle Stuecke)
  - https://incompetech.com/music/royalty-free/genre.json (Genre-ID -> Name)
  - Audiodateien liegen alle unter
    https://incompetech.com/music/royalty-free/mp3-royaltyfree/{filename}

LIZENZ: Alle Stuecke stehen unter Creative Commons BY (3.0 oder 4.0,
teils mit Standard-License-Kaufoption fuer Nennungs-Verzicht - fuer uns
irrelevant, wir nutzen ausschliesslich die freie CC-BY-Variante).
Namensnennung ist Pflicht - siehe "license"-Feld im Track-Dict, das den
exakten von incompetech vorgegebenen Credit-Text enthaelt. WICHTIG:
Das ist keine Public-Domain-Musik (haeufiges Missverstaendnis laut
incompetechs eigenem FAQ) - Namensnennung MUSS in der Player-/
Detailansicht sichtbar gemacht werden.

Der Katalog wird bei jedem Aufruf frisch vom Server geladen (keine
eigene Zwischenspeicherung in diesem Modul - passt zu Saschas
Cache-Cleaner-Konzept auf Addon-Ebene statt Provider-Ebene).
"""
import requests

from .base import BaseProvider
from urllib.parse import quote

PIECES_URL = "https://incompetech.com/music/royalty-free/pieces.json"
GENRE_URL = "https://incompetech.com/music/royalty-free/genre.json"
MP3_BASE = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/"

ATTRIBUTION_TEMPLATE = (
    '"%s" by Kevin MacLeod (incompetech.com) - Licensed under Creative Commons: By Attribution 4.0'
)


def _parse_hhmmss(value):
    if not value:
        return None
    try:
        parts = [int(p) for p in value.split(":")]
        seconds = 0
        for p in parts:
            seconds = seconds * 60 + p
        return seconds
    except (ValueError, TypeError):
        return None


class IncompetechProvider(BaseProvider):
    id = "incompetech"
    name = "Incompetech"
    display_name = "Incompetech (Kevin MacLeod)"

    def __init__(self):
        self._genre_names = None  # Lazy geladen, id -> Name

    def _genre_map(self):
        if self._genre_names is None:
            r = requests.get(GENRE_URL, timeout=15)
            r.raise_for_status()
            self._genre_names = {str(g["id"]): g["genre"] for g in r.json()}
        return self._genre_names

    def _all_pieces(self):
        r = requests.get(PIECES_URL, timeout=20)
        r.raise_for_status()
        return r.json()

    def _map_track(self, p):
        genre_id = str(p.get("genre", ""))
        genre_name = self._genre_map().get(genre_id)
        title = (p.get("title") or "Unknown").strip()
        year = None
        if p.get("uploaded"):
            year_str = str(p["uploaded"])[:4]
            if year_str.isdigit():
                year = int(year_str)
        return {
            "provider": self.id,
            "track_id": p.get("filename"),
            "title": title,
            "artist": "Kevin MacLeod",
            "album": None,
            "genre": genre_name,
            "year": year,
            "duration": _parse_hhmmss(p.get("length")),
            "license": ATTRIBUTION_TEMPLATE % title,
            "thumb": None,
            "stream_url": MP3_BASE + quote(p.get("filename", "")),
            "date_added": p.get("uploaded"),
        }

    def get_genres(self):
        return sorted(self._genre_map().values())

    def get_artists(self, genre=None):
        # Ein-Komponist-Quelle - trotzdem als "Kuenstler"-Eintrag
        # anbieten, konsistent mit Phish.in.
        return [{"id": "kevin-macleod", "name": "Kevin MacLeod"}]

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        pieces = self._all_pieces()
        genre_map = self._genre_map()
        if genre:
            # Umgekehrtes Mapping Name -> ID(s), da pieces.json nur die ID fuehrt
            matching_ids = {gid for gid, name in genre_map.items() if name == genre}
            pieces = [p for p in pieces if str(p.get("genre")) in matching_ids]
        if year:
            pieces = [p for p in pieces if str(p.get("uploaded", ""))[:4] == str(year)]
        pieces = pieces[offset:offset + limit]
        return [self._map_track(p) for p in pieces]

    def search(self, query, limit=50):
        pieces = self._all_pieces()
        query_lower = query.lower()
        matches = [p for p in pieces if query_lower in (p.get("title") or "").lower()]
        return [self._map_track(p) for p in matches[:limit]]

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        tracks = self.browse_tracks(genre=filters.get("genre"), limit=100000)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        pieces = sorted(self._all_pieces(), key=lambda p: p.get("uploaded", ""), reverse=True)
        return [self._map_track(p) for p in pieces[:limit]]
