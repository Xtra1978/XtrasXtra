# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: Open Music Archive (openmusicarchive.org)

WICHTIGER KLARSTELLUNGS-HINWEIS (Korrektur gegenueber der ersten
Einschaetzung in der Grundlagenanalyse):
Im HAR gab es zwei ganz unterschiedliche Dinge auf derselben Domain:
  1) Die Startseite (/) bindet ein SoundCloud-Playlist-Widget ein
     (api-widget.soundcloud.com, HLS-Streaming, client_id noetig) -
     vermutlich nur eine "Featured"-Anzeige auf der Startseite.
  2) Der eigentliche Katalog unter browse.php / browse_tag.php ist eine
     schlichte, alte PHP-Seite mit DIREKTEN, statischen MP3-Links
     (audio/{Dateiname}.mp3, kein Token, keine Signatur).
Fuer SoundWave 1 nutzen wir ausschliesslich (2) - der Katalog ist damit
technisch so einfach wie Musopen/ccMixter, KEIN SoundCloud/HLS noetig.
(Einzige Einschraenkung: kein tatsaechlicher Play-Request in der Aufnahme
bestaetigt, dass audio/*.mp3 wirklich ohne Weiteres abspielbar ist -
sollte einmal live gegengeprueft werden, ist aber ein normaler <a href>
Downloadlink, keine JS-generierte URL.)

Kein API - "Tags" (browse_tag.php?tag=...) sind eine flache Folksonomy:
Genre, Jahrzehnt, Kuenstlername, Plattenlabel etc. liegen alle im selben
Tag-Topf. get_genres() liefert deshalb bewusst nichts Belastbares zurueck;
Filterung funktioniert praktisch nur ueber die Tag-Suche selbst.
"""
import os
import re

import requests

from .base import BaseProvider

BASE = "https://www.openmusicarchive.org"
_DEBUG = os.environ.get("SW1_DEBUG") == "1"

# WICHTIG - Korrektur nach echtem Testlauf: browse.php (ohne Tag) ist nur
# eine Landing-Page ("Use tags to browse the archive...") OHNE direkte
# Trackliste. Die urspruengliche Testprobe mit echten Treffern kam von
# browse_tag.php?tag=Free-to-air. Deshalb IMMER einen Tag verwenden,
# nie das nackte browse.php aufrufen.
DEFAULT_TAG = "Free-to-air"

_TRACK_BLOCK_RE = re.compile(
    r'bodytitles">([^<]+)</span>.*?bodytrackname">([^<]+)</span>.*?href="(audio/[^"]+\.mp3)"',
    re.DOTALL,
)


class OpenMusicArchiveProvider(BaseProvider):
    id = "openmusicarchive"
    name = "Open Music Archive"
    display_name = "Open Music Archive"

    def _get_html(self, path):
        r = requests.get("%s/%s" % (BASE, path), timeout=15)
        r.raise_for_status()
        return r.text

    def _parse_tracks(self, html):
        tracks = []
        for artist, title, rel_url in _TRACK_BLOCK_RE.findall(html):
            tracks.append({
                "provider": self.id,
                "track_id": rel_url,
                "title": title.strip(),
                "artist": artist.strip(),
                "album": None,
                "genre": None,  # keine strukturierten Genres, siehe Modul-Docstring
                "year": None,  # Jahr steckt teils als Tag drin (z.B. "1920s"), nicht strukturiert auswertbar
                "duration": None,
                "license": "Public Domain",  # OMA kuratiert gezielt gemeinfreie 78rpm-Aufnahmen
                "thumb": None,
                "stream_url": "%s/%s" % (BASE, rel_url),
                "date_added": None,
            })
        if _DEBUG and not tracks:
            import sys
            print("[openmusicarchive debug] 0 Treffer - Seitenlaenge %d Zeichen, erste 500: %r"
                  % (len(html), html[:500]), file=sys.stderr)
        return tracks

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        html = self._get_html("browse_tag.php?tag=%s" % (genre or DEFAULT_TAG))
        return self._parse_tracks(html)[:limit]

    def search(self, query, limit=50):
        html = self._get_html("browse_tag.php?tag=%s" % query)
        return self._parse_tracks(html)[:limit]

    def random_tracks(self, count=1, filters=None):
        tracks = self.browse_tracks(genre=(filters or {}).get("genre"), limit=200)
        import random
        random.shuffle(tracks)
        return tracks[:count]

    def new_releases(self, limit=30):
        # Keine Datumsangaben im Katalog - "New on SoundWave 1" kann fuer
        # diese Quelle praktisch nicht befuellt werden, daher leer.
        return []
