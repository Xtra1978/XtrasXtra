# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: ccMixter (ccmixter.org)

WICHTIG - Verifizierungshinweis:
Die HAR-Aufnahme enthielt keinen tatsaechlichen Aufruf von
ccmixter.org/api/query (nur den Platzhalter-Link im HTML). Die Feldnamen
unten (upload_id, upload_name, user_name, license_url, download_url,
sample_id) basieren auf der oeffentlich dokumentierten ccHost-API (der
Open-Source-Plattform hinter ccMixter), sind aber NICHT gegen eine echte
Antwort verifiziert. Vor dem produktiven Einsatz: einmal echten Call
absetzen (z.B. https://ccmixter.org/api/query?f=json&limit=5&sort=rank)
und dieses Modul ggf. an die tatsaechliche Struktur anpassen.

Direkte MP3-Links liegen bei ccMixter unter ccmixter.org/content/{user}/
{file}.mp3 - unsigniert, dauerhaft (aus der HTML-Aufnahme bestaetigt).
"""
import http.client

import requests

from .base import BaseProvider

# WORKAROUND (aus echtem Testlauf-Fehler): ccmixter.org liefert
# gelegentlich einen ungewoehnlich langen HTTP-Header zurueck (>64KB),
# an dem Pythons eingebauter http.client-Parser mit "LineTooLong"
# abbricht - Standardlimit ist 65536 Bytes. Grosszuegiger setzen, damit
# das nicht mehr an einem einzelnen Fehlverhalten des Servers scheitert.
# Betrifft nur diesen Prozess/dieses Modul, keine globale Kodi-Aenderung.
http.client._MAXLINE = 655360

API_BASE = "https://ccmixter.org/api/query"


class CCMixterProvider(BaseProvider):
    id = "ccmixter"
    name = "ccMixter"
    display_name = "ccMixter"

    def _query(self, params):
        p = dict(params)
        p["f"] = "json"
        r = requests.get(API_BASE, params=p, timeout=15)
        r.raise_for_status()
        return r.json()

    def _map_track(self, item):
        files = item.get("files") or []
        stream_url = files[0]["download_url"] if files and files[0].get("download_url") else item.get("download_url")
        return {
            "provider": self.id,
            "track_id": str(item.get("upload_id") or item.get("id") or ""),
            "title": item.get("upload_name") or item.get("title") or "Unknown",
            "artist": item.get("user_name") or item.get("username") or "Unknown",
            "album": None,
            "genre": ",".join(item.get("tags", [])) if isinstance(item.get("tags"), list) else item.get("tags"),
            "year": None,
            "duration": None,
            "license": item.get("license_url") or item.get("license_name"),
            "thumb": item.get("upload_image") or item.get("thumb"),
            "stream_url": stream_url,
            "date_added": item.get("upload_date"),
        }

    def get_genres(self):
        # ccHost kennt "tags" statt fester Genres - Vorschlag: feste
        # Liste gaengiger ccMixter-Tags pflegen statt live abzufragen.
        return []

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        params = {"limit": limit}
        if genre:
            params["tags"] = genre
        if artist:
            params["user_name"] = artist
        data = self._query(params)
        return [self._map_track(i) for i in data]

    def search(self, query, limit=50):
        data = self._query({"search": query, "limit": limit})
        return [self._map_track(i) for i in data]

    def random_tracks(self, count=1, filters=None):
        filters = filters or {}
        params = {"limit": max(count * 3, 30), "sort": "rand"}
        if filters.get("genre"):
            params["tags"] = filters["genre"]
        if filters.get("artist"):
            params["user_name"] = filters["artist"]
        data = self._query(params)
        import random
        random.shuffle(data)
        return [self._map_track(i) for i in data[:count]]

    def new_releases(self, limit=30):
        data = self._query({"limit": limit, "sort": "date"})
        return [self._map_track(i) for i in data]
