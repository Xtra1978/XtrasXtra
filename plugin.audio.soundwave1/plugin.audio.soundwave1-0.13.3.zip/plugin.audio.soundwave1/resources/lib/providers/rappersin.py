# -*- coding: utf-8 -*-
"""
SoundWave 1 - Provider: rappers.in (Free-Modus)

Nur frei zugaengliches Material, bewusst OHNE Login und OHNE "Weitere laden":
der Provider liefert pro Liste genau das, was die Webseite einem nicht
angemeldeten Besucher zeigt (Startseite, Neue Musik, Beats-Genres, Songs-
Kategorien, Top-50-Listen). Die Vollversion mit Login, Mehr laden, Playlisten
und Generator ist das eigenstaendige Addon plugin.audio.rappersin.

Technik (aus den Aufnahmen bestaetigt):
- Erst die Startseite aufrufen: liefert Session-Cookies und den Session-Hash
  (<input class="main_session" value="...">), der als hash_id mitgeschickt wird.
- Listen sind normale Seiten (/free-beats/<slug>, /explore-genres/<id>,
  /new_music, /) bzw. ajax-load.php?path=top-genres/<id> fuer die Top-50-Listen.
- Kartenmarkup: <li class="song_search_list">, <div class="track_list"> und
  <li class="list-recommended"> mit playSong('<audioID>').
- Stream: /endpoints/get-song-info?hash_id=..&id=<audioID> -> songURL (mp3).
  Die URL wird erst zum Abspielen aufgeloest (resolve_stream), stream_url
  bleibt in den Listen deshalb leer.
"""
import html as html_module
import random
import re
import time
import uuid

import requests

from .base import BaseProvider

BASE = "https://rappers.in"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

LICENSE_TEXT = "Rappers.in - kostenlos, Upload durch Nutzer der Plattform (keine Pruefung durch SoundWave 1)"

# Genre-Name -> (Art, Argument). 'free' = /free-beats/<slug>, 'cat' = /explore-genres/<id>,
# 'top50' = Top-50-Liste (top-genres/<id>)
GENRES = [
    ("Beats / Instrumentals", "cat", "1"),
    ("Aggressive Beats", "free", "aggro"),
    ("Deep Beats", "free", "deep"),
    ("Experimental Beats", "free", "experimental"),
    ("Fun Beats", "free", "fun"),
    ("Oldschool Beats", "free", "oldschool"),
    ("Smooth Beats", "free", "smooth"),
    ("Trap Beats", "free", "trap"),
    ("HipHop (english)", "cat", "2"),
    ("HipHop (german)", "cat", "3"),
    ("HipHop (other languages)", "cat", "4"),
    ("Other genres", "cat", "7"),
    ("Top 50 - Beats / Instrumentals", "top50", "1"),
    ("Top 50 - HipHop (english)", "top50", "2"),
    ("Top 50 - HipHop (german)", "top50", "3"),
    ("Top 50 - HipHop (other languages)", "top50", "4"),
    ("Top 50 - Other genres", "top50", "7"),
]
_GENRE_MAP = {name.lower(): (kind, arg, name) for name, kind, arg in GENRES}
# Versteckte Einträge für die Menüpunkte "Home" und "New Music" (nicht in der Genre-Liste)
_GENRE_MAP["__home__"] = ("home", "", None)
_GENRE_MAP["__new__"] = ("new", "", None)

# Menü innerhalb des Anbieters (folgt der Navigation der Webseite):
# (Beschriftung, Abschnitt) bzw. (Beschriftung, None, Genre-Name)
_MENU_ROOT = [
    {"label": "Home", "genre": "__home__"},
    {"label": "Beats", "section": "beats"},
    {"label": "Songs", "section": "songs"},
    {"label": "New Music", "genre": "__new__"},
    {"label": "Top 50", "section": "top"},
]
_MENU_SECTIONS = {
    "beats": [{"label": "All Beats", "genre": "Beats / Instrumentals"}] + [
        {"label": n.replace(" Beats", ""), "genre": n} for n, k, _ in GENRES if k == "free"],
    "songs": [{"label": n, "genre": n} for n, k, a in GENRES if k == "cat" and a != "1"],
    "top": [{"label": n.replace("Top 50 - ", ""), "genre": n} for n, k, _ in GENRES if k == "top50"],
}

# Maximal so viele Titel pro Liste zurueckgeben - bewusst unter SW1s PAGE_SIZE (100),
# damit nirgends ein "Weitere laden" erscheint.
MAX_TRACKS = 90
_CACHE_TTL = 600
_CACHE = {}

_MARK = re.compile(
    r'<(?:li|div)\b[^>]*\bclass="[^"]*\b(?:song_search_list|track_list|list-recommended)\b[^"]*"[^>]*>', re.S)


def _log(msg):
    try:
        from .. import logger  # nur im Addon-Betrieb vorhanden, nicht in Tests
        logger.log("rappersin: %s" % msg)
    except Exception:
        pass


def _clean(s):
    s = html_module.unescape(re.sub(r"<[^>]+>", "", s or ""))
    return re.sub(r"\s+", " ", s).strip()


def _title(raw):
    return re.sub(r"\.mp3$", "", _clean(raw), flags=re.IGNORECASE)


def parse_cards(page):
    """Tracks aus allen Kartentypen der Webseite."""
    marks = list(_MARK.finditer(page))
    items, seen = [], set()
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(page)
        chunk = page[m.start():end]
        pid = re.search(r"playSong\('([A-Za-z0-9]+)'\)", chunk)
        if not pid or pid.group(1) in seen:
            continue
        seen.add(pid.group(1))
        title = (re.search(r'<span class="title">(.*?)</span>', chunk, re.S)
                 or re.search(r"<h4>\s*<a[^>]*>(.*?)</a\s*>", chunk, re.S)
                 or re.search(r"<h4>(.*?)</h4>", chunk, re.S))
        artists = [_clean(a) for a in re.findall(r'<span class="artist"[^>]*>(.*?)</span\s*>', chunk, re.S)]
        artists = [a for a in artists if a and "{{" not in a]
        if not artists:
            a = (re.search(r"<p>\s*<a[^>]*>(.*?)</a\s*>", chunk, re.S)
                 or re.search(r'class="a_name">\s*<a[^>]*>(.*?)</a\s*>', chunk, re.S))
            artists = [_clean(a.group(1))] if a else []
        cover = re.search(r'<img[^>]+src="(https://[^"]+?)(?:\?[^"]*)?"', chunk)
        items.append({
            "audio_id": pid.group(1),
            "title": _title(title.group(1)) if title else pid.group(1),
            "artist": artists[-1] if artists else "Unknown",
            "cover": html_module.unescape(cover.group(1)) if cover else None,
        })
    return items


class RappersInProvider(BaseProvider):
    id = "rappersin"
    name = "Rappers.in"
    display_name = "Rappers.in"

    def __init__(self, *_ignored):
        # Konstruktor akzeptiert (und ignoriert) Zugangsdaten - Free-Modus kennt keinen Login
        self._session = None
        self._hash_id = None

    # -------------------------------------------------------------- Session

    def _ensure_session(self):
        if self._session:
            return
        self._session = requests.Session()
        self._session.headers.update({"User-Agent": UA, "Referer": BASE + "/",
                                      "Accept-Language": "de,en;q=0.8"})
        try:
            page = self._session.get(BASE + "/", timeout=15).text
            m = re.search(r'class="main_session"\s+value="([A-Za-z0-9]+)"', page)
            self._hash_id = m.group(1) if m else None
            _log("Session-Hash %s" % ("gefunden" if m else "NICHT gefunden"))
        except requests.RequestException as exc:
            _log("Startseite fehlgeschlagen: %s" % exc)
        if not self._hash_id:
            self._hash_id = uuid.uuid4().hex + uuid.uuid4().hex[:8]

    def _get(self, path, params=None, ajax=False):
        self._ensure_session()
        headers = {"X-Requested-With": "XMLHttpRequest"} if ajax else None
        r = self._session.get(BASE + path, params=params, headers=headers, timeout=20)
        r.raise_for_status()
        return r

    # -------------------------------------------------------------- Listen

    def _listing(self, kind, arg=""):
        key = (kind, arg)
        hit = _CACHE.get(key)
        if hit and time.time() - hit[0] < _CACHE_TTL:
            return list(hit[1])
        if kind == "top50":
            self._ensure_session()
            params = {"path": "top-genres/%s" % arg, "hash_id": self._hash_id, "_": int(time.time() * 1000)}
            page = self._get("/ajax-load.php", params=params, ajax=True).text
        else:
            path = {"home": "/", "new": "/new_music"}.get(kind) or (
                "/free-beats/%s" % arg if kind == "free" else "/explore-genres/%s" % arg)
            page = self._get(path).text
        items = parse_cards(page)
        _log("%s %s -> %d Titel" % (kind, arg, len(items)))
        _CACHE[key] = (time.time(), list(items))
        return items

    def _to_track(self, item, genre=None):
        return {
            "provider": self.id,
            "track_id": item["audio_id"],
            "title": item["title"],
            "artist": item["artist"],
            "album": None,
            "genre": genre,
            "year": None,
            "duration": None,
            "license": LICENSE_TEXT,
            "thumb": item["cover"],
            "stream_url": "",  # wird beim Abspielen ueber resolve_stream() aufgeloest
            "date_added": None,
        }

    def _tracks_for(self, kind, arg, genre_name=None):
        try:
            return [self._to_track(i, genre_name) for i in self._listing(kind, arg)]
        except requests.RequestException as exc:
            _log("Liste %s %s fehlgeschlagen: %s" % (kind, arg, exc))
            return []

    # -------------------------------------------------------------- Interface

    def get_menu(self, section=None):
        """Menüpunkte innerhalb des Anbieters (Home, Beats, Songs, New Music, Top 50).
        Liefert Dicts mit "label" und entweder "section" (Untermenü) oder "genre" (Titelliste)."""
        if section is None:
            return list(_MENU_ROOT)
        return list(_MENU_SECTIONS.get(section, []))

    def get_genres(self):
        return [name for name, _, _ in GENRES]

    def get_artists(self, genre=None):
        return []

    def browse_tracks(self, genre=None, artist=None, year=None, limit=50, offset=0):
        # Free-Modus: kein Kuenstlerfilter und kein Weiterblaettern (offset > 0 -> leer),
        # damit SW1 nie ein "Weitere laden" anbietet.
        if artist or offset:
            return []
        if genre:
            entry = _GENRE_MAP.get(str(genre).lower())
            if not entry:
                return []
            kind, arg, name = entry
            tracks = self._tracks_for(kind, arg, name)
            if not tracks and kind == "new":
                tracks = self._tracks_for("home", "")
        else:
            tracks = self._tracks_for("home", "")
        return tracks[:min(limit, MAX_TRACKS)]

    def search(self, query, limit=50):
        return []

    def random_tracks(self, count=1, filters=None):
        genre = (filters or {}).get("genre")
        if genre:
            pool = self.browse_tracks(genre=genre, limit=MAX_TRACKS)
        else:
            pool = self.browse_tracks(limit=MAX_TRACKS)
            name, kind, arg = random.choice(GENRES)
            try:
                pool += self._tracks_for(kind, arg, name)
            except Exception as exc:  # ein ausfallendes Zusatz-Genre darf die Auswahl nicht kippen
                _log("random: Zusatzliste %s fehlgeschlagen: %s" % (name, exc))
        seen, unique = set(), []
        for t in pool:
            if t["track_id"] not in seen:
                seen.add(t["track_id"])
                unique.append(t)
        random.shuffle(unique)
        return unique[:count]

    def new_releases(self, limit=30):
        tracks = self._tracks_for("new", "") or self._tracks_for("home", "")
        return tracks[:min(limit, MAX_TRACKS)]

    def resolve_stream(self, track_id):
        self._ensure_session()
        r = self._get("/endpoints/get-song-info",
                      params={"hash_id": self._hash_id, "id": track_id, "audio_ad_id": 0,
                              "_": int(time.time() * 1000)}, ajax=True)
        try:
            info = r.json()
        except ValueError:
            return None
        if not isinstance(info, dict) or str(info.get("status")) != "200":
            return None
        if str(info.get("purchase", "")).lower() in ("true", "1"):
            return None  # nur frei verfuegbare Titel
        return info.get("songURL") or None
