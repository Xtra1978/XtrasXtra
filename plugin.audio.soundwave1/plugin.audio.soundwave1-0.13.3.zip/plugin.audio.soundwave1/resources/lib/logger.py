# -*- coding: utf-8 -*-
"""
SoundWave 1 - kompaktes Debug-Log

Eigenes, schlankes Log (getrennt vom allgemeinen kodi.log), wie in
Saschas Standard fuer groessere Addons vorgesehen. Nur aktiv, wenn der
Nutzer "Debug-Log aktivieren" in den Settings einschaltet. Datei liegt
im Addon-Datenverzeichnis (special://profile/addon_data/...), damit sie
beim Cache-Leeren NICHT versehentlich mitgeloescht wird (Cache und Log
sind bewusst getrennte Verzeichnisse, siehe cache.py).
"""
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
LOG_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
LOG_PATH = LOG_DIR + "soundwave1_debug.log"

_MAX_BYTES = 1024 * 1024  # 1 MB - danach wird die Datei rotiert


def _ensure_dir():
    if not xbmcvfs.exists(LOG_DIR):
        xbmcvfs.mkdirs(LOG_DIR)


def _enabled():
    return ADDON.getSettingBool("debug_log_enabled")


def log(message, level="INFO"):
    if not _enabled():
        return
    try:
        _ensure_dir()
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = "%s [%s] %s\n" % (timestamp, level, message)

        existing = ""
        if xbmcvfs.exists(LOG_PATH):
            f = xbmcvfs.File(LOG_PATH)
            existing = f.read()
            f.close()
            if len(existing.encode("utf-8")) > _MAX_BYTES:
                # einfache Rotation: alte Inhalte verwerfen statt endlos wachsen
                existing = ""

        # Bewusst komplett neu schreiben statt Anhaenge-Modus ("a") zu
        # nutzen - der wird von xbmcvfs.File auf manchen Plattformen
        # (u.a. Android) nicht zuverlaessig unterstuetzt und schlaegt
        # dann still fehl, ohne dass die Datei ueberhaupt entsteht.
        f = xbmcvfs.File(LOG_PATH, "w")
        f.write(existing + line)
        f.close()
    except Exception as exc:
        # Logging darf selbst nie einen Absturz verursachen - aber
        # wenigstens ins normale kodi.log spiegeln, damit ein Fehlschlag
        # beim eigenen Log-File nicht komplett unsichtbar bleibt.
        try:
            xbmc.log("SoundWave 1: eigenes Debug-Log fehlgeschlagen: %s: %s"
                     % (type(exc).__name__, exc), level=xbmc.LOGWARNING)
        except Exception:
            pass


def error(message):
    log(message, level="ERROR")
