# -*- coding: utf-8 -*-
"""
SoundWave 1 - Einstiegspunkt

Bewusst schlank gehalten (Saschas Standard-Muster): die eigentliche
Menu-/Navigationslogik steckt in resources/lib/navigation.py, die
Anbieter-Anbindung in resources/lib/router.py (Provider-Router, siehe
dort). addon.py selbst tut nur: Parameter einlesen, an navigation.py
durchreichen.
"""
import sys
from urllib.parse import parse_qsl

from resources.lib import navigation

if __name__ == "__main__":
    base_url = sys.argv[0]
    addon_handle = int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2][1:]))
    navigation.router(base_url, addon_handle, params)
