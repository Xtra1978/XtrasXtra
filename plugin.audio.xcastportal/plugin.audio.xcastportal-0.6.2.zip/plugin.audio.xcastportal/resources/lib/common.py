# -*- coding: utf-8 -*-
"""
Gemeinsame Helfer für alle sources/-Module.
Analog zu api.py/stream.py in den anderen Addons: zentrale Stelle fuer
HTTP-Zugriffe, URL-Aufbau und ListItem-Erzeugung, damit die einzelnen
Portal-Module schlank bleiben.
"""
import sys
import urllib.parse

import requests
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0 Safari/537.36"
)

_session = None


def http_session():
    """Liefert eine wiederverwendbare requests-Session mit Standard-Headern."""
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.8",
        })
    return _session


def get(url, **kwargs):
    return http_session().get(url, timeout=15, **kwargs)


def build_url(**kwargs):
    """Baut eine plugin://-URL aus Query-Parametern."""
    return "plugin://{}/?{}".format(ADDON_ID, urllib.parse.urlencode(kwargs))


def media_path(filename):
    return "special://home/addons/{}/resources/media/{}".format(ADDON_ID, filename)


def add_dir_item(label, action, source=None, is_folder=True, icon=None, fanart=None,
                  favorite_kind=None, favorite_id=None, **extra):
    """Fuegt einen Verzeichnis-/Aktionseintrag zur Kodi-Liste hinzu.

    favorite_kind/favorite_id: wenn gesetzt (z.B. favorite_kind="podcast"),
    wird ein Kontextmenue-Eintrag "Zu XCast-Favoriten hinzufuegen" angehaengt
    (sofern die Einstellung "Favoriten" aktiv ist)."""
    params = {"action": action}
    if source:
        params["source"] = source
    params.update(extra)
    url = build_url(**params)

    list_item = xbmcgui.ListItem(label=label)
    art = {}
    if icon:
        art["icon"] = icon
        art["thumb"] = icon
    if fanart:
        art["fanart"] = fanart
    if art:
        list_item.setArt(art)

    if favorite_kind and favorite_id and is_favorites_enabled():
        fav_url = build_url(
            action="add_favorite",
            kind=favorite_kind,
            source=source or "",
            item_id=urllib.parse.quote_plus(favorite_id),
            name=urllib.parse.quote_plus(label),
            image=urllib.parse.quote_plus(icon or ""),
        )
        list_item.addContextMenuItems([
            ("Zu XCast-Favoriten hinzufügen", "RunPlugin({})".format(fav_url)),
        ])

    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)


def add_playable_item(label, stream_url, icon=None, description=None, duration=None,
                       source=None, episode_id=None):
    """Fuegt eine abspielbare Episode zur Kodi-Liste hinzu."""
    list_item = xbmcgui.ListItem(label=label)
    list_item.setProperty("IsPlayable", "true")

    info_tag = list_item.getMusicInfoTag() if hasattr(list_item, "getMusicInfoTag") else None
    if info_tag is not None:
        try:
            info_tag.setTitle(label)
            if description:
                info_tag.setComment(description)
            if duration:
                info_tag.setDuration(duration)
        except Exception:
            pass  # je nach Kodi-Version koennen einzelne Setter fehlen

    if icon:
        list_item.setArt({"icon": icon, "thumb": icon})

    context_items = []
    if is_download_enabled():
        download_url = build_url(
            action="download",
            url=urllib.parse.quote_plus(stream_url),
            name=urllib.parse.quote_plus(label),
        )
        context_items.append(("Download", "RunPlugin({})".format(download_url)))

    if episode_id and is_favorites_enabled():
        fav_url = build_url(
            action="add_favorite",
            kind="episode",
            source=source or "",
            item_id=urllib.parse.quote_plus(episode_id),
            name=urllib.parse.quote_plus(label),
            image=urllib.parse.quote_plus(icon or ""),
            stream=urllib.parse.quote_plus(stream_url),
        )
        context_items.append(("Zu XCast-Favoriten hinzufügen", "RunPlugin({})".format(fav_url)))

    if context_items:
        list_item.addContextMenuItems(context_items)

    url = build_url(action="play", url=urllib.parse.quote_plus(stream_url))
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)


def notify_error(message):
    xbmcgui.Dialog().notification("XCast-Portal", message, xbmcgui.NOTIFICATION_ERROR, 4000)


# ---------------------------------------------------------------------------
# Settings (siehe resources/settings.xml)
# ---------------------------------------------------------------------------

def get_max_results():
    """Maximale Anzahl Ergebnisse/Podcasts pro Seite (Settings: Allgemein)."""
    try:
        return max(5, int(ADDON.getSettingInt("max_results")))
    except Exception:
        return 20


def get_preferred_quality():
    """0=Niedrig, 1=Mittel, 2=Hoch - nur relevant fuer Quellen mit mehreren
    Bitrate-Varianten. Aktuell nutzt noch keine der vier Quellen mehrere
    Qualitaetsstufen aktiv; die Einstellung ist als Vorbereitung angelegt."""
    try:
        return int(ADDON.getSettingInt("preferred_quality"))
    except Exception:
        return 2


def get_credentials(source_key):
    """Liefert (username, password) fuer ein Portal, falls in den Settings
    hinterlegt. Aktuell von keiner Quelle zwingend benoetigt (alle vier
    Portale sind ohne Login nutzbar) - fuer optionale, personalisierte
    Funktionen in einer spaeteren Ausbaustufe vorbereitet."""
    try:
        user = ADDON.getSetting("{}_username".format(source_key))
        pwd = ADDON.getSetting("{}_password".format(source_key))
        return (user or None, pwd or None)
    except Exception:
        return (None, None)


def get_active_languages():
    """Liefert die Menge aktiver Sprach-Tags ('de'/'en'), gesteuert ueber
    die Settings 'Nur DE-Inhalte' (Override) und die zwei Sprach-Toggles.
    Quellen mit LANGUAGE == 'multi' (podcasts-online.org) sind hiervon
    unabhaengig immer sichtbar - deren Filterung laeuft ueber die eigene
    Laender-Auswahl."""
    try:
        if ADDON.getSettingBool("only_de"):
            return {"de"}
        languages = set()
        if ADDON.getSettingBool("show_de_sources"):
            languages.add("de")
        if ADDON.getSettingBool("show_en_sources"):
            languages.add("en")
        return languages or {"de", "en"}  # Falls beide Toggles aus sind: nicht alles verstecken
    except Exception:
        return {"de", "en"}


def is_source_enabled(source_key):
    """Anbieter-Auswahl (Settings: Anbieter) - Quelle einzeln an-/abschaltbar."""
    try:
        return ADDON.getSettingBool("enable_{}".format(source_key))
    except Exception:
        return True


def get_active_sources(all_sources):
    """Filtert das SOURCES-dict aus router.py auf aktivierte Anbieter unter
    Beruecksichtigung der Sprach-Einstellungen. 'multi'-Quellen (podcasts-
    online.org) werden nur ueber is_source_enabled gefiltert, nicht ueber
    die Sprachauswahl."""
    active_languages = get_active_languages()
    result = {}
    for key, module in all_sources.items():
        if not is_source_enabled(key):
            continue
        lang = getattr(module, "LANGUAGE", "de")
        if lang != "multi" and lang not in active_languages:
            continue
        result[key] = module
    return result


def is_favorites_enabled():
    try:
        return ADDON.getSettingBool("enable_favorites")
    except Exception:
        return True


def is_download_enabled():
    try:
        return ADDON.getSettingBool("enable_download")
    except Exception:
        return False


def get_download_path():
    try:
        path = ADDON.getSetting("download_path")
        return path or "special://temp/xcastportal_downloads/"
    except Exception:
        return "special://temp/xcastportal_downloads/"


def download_episode(stream_url, filename):
    """Laedt eine Episode in den in den Settings hinterlegten Ordner herunter.
    Laeuft blockierend mit Fortschrittsdialog - fuer Kodi-Verhaeltnisse
    ausreichend, da Downloads i.d.R. ueber den Kontextmenue-Eintrag einer
    einzelnen Episode gestartet werden."""
    import os
    import xbmcvfs

    dest_dir = get_download_path()
    if not xbmcvfs.exists(dest_dir):
        xbmcvfs.mkdirs(dest_dir)

    safe_name = "".join(c for c in filename if c.isalnum() or c in " ._-").strip() or "episode"
    if not safe_name.lower().endswith((".mp3", ".m4a", ".aac")):
        safe_name += ".mp3"
    dest_path = dest_dir + safe_name

    progress = xbmcgui.DialogProgress()
    progress.create("XCast-Portal", "Download: {}".format(filename))

    try:
        resp = http_session().get(stream_url, stream=True, timeout=30)
        resp.raise_for_status()
        total = int(resp.headers.get("content-length", 0))
        written = 0

        f = xbmcvfs.File(dest_path, "w")
        for chunk in resp.iter_content(chunk_size=65536):
            if progress.iscanceled():
                break
            f.write(chunk)
            written += len(chunk)
            if total:
                progress.update(int(written * 100 / total))
        f.close()
        progress.close()
        xbmcgui.Dialog().notification("XCast-Portal", "Download abgeschlossen", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as exc:
        progress.close()
        notify_error("Download fehlgeschlagen: {}".format(exc))
