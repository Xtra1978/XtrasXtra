# -*- coding: utf-8 -*-
"""
Kanonische Kategorien fuer das gemischte Hauptmenue "Kategorien".

Nicht alle Quellen haben Kategorien (podcast.de, Podlist.de und
GetPodcast aktuell nicht - siehe deren list_categories()). Von den
verbleibenden Quellen benennt jede ihre Kategorien anders (bestpodcasts.co.uk
z.B. "Society and Culture" auf Englisch, deutschepodcasts.de "Gesellschaft
und Kultur" auf Deutsch). Damit trotzdem eine gemeinsame Ordnerstruktur
("Comedy" enthaelt Podcasts aus mehreren Quellen gleichzeitig) entsteht,
matchen wir die von den Quellen live gescrapten Kategorienamen gegen
Schluesselwoerter - keine hartkodierten IDs/URLs, nur eine Uebersetzungs-
bruecke zwischen unterschiedlichen Taxonomien.

Kategorien ohne Treffer (z.B. bestpodcasts.co.uk-Nischen wie "Wrestling",
"Fantasy football") bleiben ausschliesslich ueber die direkte
Anbieter-Navigation (Anbieter -> Kategorien) erreichbar - das ist gewollt,
sie passen in kein gemeinsames Nachbar-Genre.

podcasts-online.org ist zweistufig (Land -> Genre); fuer die gemischte
Kategorien-Ansicht wird standardmaessig "Germany" als Land verwendet, da
der Adressatenkreis des Addons primaer deutschsprachig ist. Die vollstaendige
Laenderauswahl bleibt ueber den eigenen Hauptmenuepunkt "Laender" erreichbar.
"""
from collections import OrderedDict

CANONICAL = OrderedDict([
    ("comedy", {"label": "Comedy", "keywords": ["comedy", "humor"]}),
    ("true_crime", {"label": "True Crime", "keywords": ["true crime", "truecrime", "kriminal"]}),
    ("news", {"label": "Nachrichten", "keywords": ["news", "nachrichten", "politi"]}),
    ("history", {"label": "Geschichte", "keywords": ["history", "geschichte"]}),
    ("technology", {"label": "Technologie", "keywords": ["tech"]}),
    ("business", {"label": "Wirtschaft", "keywords": ["business", "wirtschaft", "finance", "marketing"]}),
    ("health", {"label": "Gesundheit", "keywords": ["health", "gesundheit", "fitness", "mental", "meditation"]}),
    ("society_culture", {"label": "Gesellschaft & Kultur", "keywords": ["society", "culture", "gesellschaft", "kultur"]}),
    ("sports", {"label": "Sport", "keywords": ["sport", "football", "tennis", "golf", "wrestling"]}),
    ("music", {"label": "Musik", "keywords": ["music", "musik"]}),
    ("arts", {"label": "Kunst", "keywords": ["arts", "kunst"]}),
    ("education", {"label": "Bildung", "keywords": ["education", "bildung", "learn english", "philosoph"]}),
    ("religion_spirituality", {"label": "Religion & Spiritualitaet", "keywords": ["religion", "spiritual", "christian", "glaube"]}),
    ("science", {"label": "Wissenschaft", "keywords": ["science", "wissenschaft"]}),
    ("tv_film", {"label": "TV & Film", "keywords": ["tv", "film", "entertainment"]}),
    ("fiction", {"label": "Fiktion", "keywords": ["fiction", "horror", "mystery", "fantasy"]}),
    ("kids_family", {"label": "Kinder & Familie", "keywords": ["kids", "family", "kinder", "parenting", "familie"]}),
    ("government", {"label": "Regierung", "keywords": ["government", "regierung"]}),
    ("leisure", {"label": "Freizeit", "keywords": ["leisure", "freizeit", "hobbies", "travel", "food", "gaming"]}),
])

# podcasts-online.org-Genres sind auf Englisch benannt (Apple-Standardkatalog);
# Standardland fuer die gemischte Ansicht.
PODCASTSONLINE_DEFAULT_COUNTRY = "germany"


def canonicalize(name):
    """Liefert den canonical key fuer einen Kategorienamen, oder None."""
    lowered = name.lower()
    for key, info in CANONICAL.items():
        for kw in info["keywords"]:
            if kw in lowered:
                return key
    return None


def collect_mixed_categories(sources):
    """
    sources: dict {source_key: module} der aktiven, sprachlich zulaessigen Quellen.

    Liefert (canonical_items, contributions):
      canonical_items: [{"id": key, "name": label}, ...] - nur Keys mit >=1 Treffer
      contributions:  {key: [(source_key, raw_category_id), ...], ...}
    """
    contributions = {}

    for source_key, module in sources.items():
        try:
            if source_key == "podcastsonline":
                raw_categories = module.list_subcategories(PODCASTSONLINE_DEFAULT_COUNTRY)
            else:
                raw_categories = module.list_categories()
        except Exception:
            # Ein einzelner instabiler/kurzzeitig nicht erreichbarer Anbieter
            # (z.B. 502 Bad Gateway) darf nicht das gesamte Hauptmenue oder
            # die Kategorien-Ansicht mit runterreissen - einfach ueberspringen.
            continue

        for raw in raw_categories:
            key = canonicalize(raw["name"])
            if not key:
                continue
            contributions.setdefault(key, []).append((source_key, raw["id"]))

    canonical_items = [
        {"id": key, "name": CANONICAL[key]["label"]}
        for key in CANONICAL
        if key in contributions
    ]
    return canonical_items, contributions
