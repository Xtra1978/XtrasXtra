# -*- coding: utf-8 -*-
"""
Router fuer XCast-Portal.

Hauptmenue (action=main):
  Meine Favoriten     (action=favorites)              - falls aktiviert
  Globale Suche       (action=global_search)           - fragt Keyboard ab, fragt alle aktiven Quellen parallel ab
  Kategorien          (action=mixed_categories)        - nur sichtbar, wenn mind. 1 kanonische Kategorie Treffer hat
  Laender             (action=categories, source=podcastsonline) - Wiederverwendung der bestehenden Kategorie-Navigation
  Anbieter            (action=providers)               - Liste aktivierter Portale, wie bisher "source_menu" darunter
  Einstellungen       (action=open_settings)           - oeffnet die Addon-Einstellungen direkt

Anbieter-Untermenue (unveraendert):
  -> Suche              (action=search, source=<key>)
  -> Kategorien          (action=categories, source=<key>)
       -> Podcasts        (action=podcasts, source=<key>, category=<id>)
            -> Episoden    (action=episodes, source=<key>, podcast=<id>)
                 -> Wiedergabe (action=play, url=<stream_url>)

Gemischte Kategorien (neu):
  Kategorien -> Genre (action=browse_mixed_category, category=<canonical_key>)
             -> Episoden je Treffer wie gewohnt (action=episodes, source=<key>, podcast=<id>)
"""
import concurrent.futures
import urllib.parse

import xbmcgui
import xbmcplugin

from resources.lib import common, favorites, categories
from resources.lib.sources import (
    podcastde, playpodcast, bestpodcasts, podcastsonline,
    getpodcast, podlist, deutschepodcasts,
)

SOURCES = {
    "podcastde": podcastde,
    "playpodcast": playpodcast,
    "bestpodcasts": bestpodcasts,
    "podcastsonline": podcastsonline,
    "getpodcast": getpodcast,
    "podlist": podlist,
    "deutschepodcasts": deutschepodcasts,
}

# Anzeigenamen im Anbieter-Menue (spaeter ueber strings.po lokalisiert,
# String-IDs siehe resources/language/*/strings.po). Keine Webadresse mehr
# im Klartext - die steht ohnehin schon im jeweiligen Untermenue-Kontext.
SOURCE_LABELS = {
    "podcastde": 30010,
    "playpodcast": 30011,
    "bestpodcasts": 30012,
    "podcastsonline": 30013,
    "getpodcast": 30014,
    "podlist": 30015,
    "deutschepodcasts": 30016,
}

PORTAL_ORDER = (
    "podcastde", "playpodcast", "bestpodcasts", "podcastsonline",
    "getpodcast", "podlist", "deutschepodcasts",
)

SEARCH_TIMEOUT_SECONDS = 10


def _addon():
    return common.ADDON


def _(string_id):
    return _addon().getLocalizedString(string_id)


# ---------------------------------------------------------------------------
# Hauptmenue
# ---------------------------------------------------------------------------

def list_main_menu():
    active_sources = common.get_active_sources(SOURCES)

    if common.is_favorites_enabled():
        common.add_dir_item(label=_(30070), action="favorites",  # "Meine Favoriten"
                             icon=common.media_path("favorites.png"), fanart=common.media_path("fanart.jpg"))

    common.add_dir_item(label=_(30071), action="global_search",  # "Globale Suche"
                         icon=common.media_path("search.png"), fanart=common.media_path("fanart.jpg"))

    canonical_items, _contrib = categories.collect_mixed_categories(active_sources)
    if canonical_items:
        common.add_dir_item(label=_(30021), action="mixed_categories",  # "Kategorien"
                             icon=common.media_path("categories.png"), fanart=common.media_path("fanart.jpg"))

    if "podcastsonline" in active_sources:
        common.add_dir_item(label=_(30072), action="categories", source="podcastsonline",  # "Laender"
                             icon=common.media_path("countries.png"), fanart=common.media_path("fanart.jpg"))

    common.add_dir_item(label=_(30073), action="providers",  # "Anbieter"
                         icon=common.media_path("providers.png"), fanart=common.media_path("fanart.jpg"))

    common.add_dir_item(label=_(30074), action="open_settings", is_folder=False,  # "Einstellungen"
                         icon=common.media_path("settings.png"), fanart=common.media_path("fanart.jpg"))

    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def list_providers():
    active_sources = common.get_active_sources(SOURCES)
    for key in PORTAL_ORDER:
        if key not in active_sources:
            continue
        common.add_dir_item(
            label=_(SOURCE_LABELS[key]),
            action="source_menu",
            source=key,
            icon=common.media_path("icon.png"),
            fanart=common.media_path("fanart.jpg"),
        )
    if not active_sources:
        common.notify_error(_(30075))  # "Keine Anbieter aktiviert - siehe Einstellungen"
    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def open_settings():
    common.ADDON.openSettings()


# ---------------------------------------------------------------------------
# Anbieter-Untermenue (wie bisher)
# ---------------------------------------------------------------------------

def list_source_menu(source_key):
    module = SOURCES[source_key]

    common.add_dir_item(label=_(30020), action="search", source=source_key)  # "Suche"

    if module.list_categories():
        common.add_dir_item(label=_(30021), action="categories", source=source_key)  # "Kategorien"

    # Feste Direkt-Verknuepfungen einzelner Portale leben hier im jeweiligen
    # Untermenue statt im Hauptmenue (das jetzt einheitlich strukturiert ist).
    if source_key == "getpodcast":
        common.add_dir_item(label=_(30017), action="podcasts", source="getpodcast", category="top100")  # "Top 100"
    if source_key == "deutschepodcasts":
        common.add_dir_item(label=_(30018), action="podcasts", source="deutschepodcasts", category="top")  # "Charts"

    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def list_categories(source_key):
    module = SOURCES[source_key]
    for cat in module.list_categories():
        common.add_dir_item(
            label=cat["name"],
            action="browse_category",
            source=source_key,
            category=cat["id"],
        )
    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def browse_category(source_key, category_id):
    """Rekursive Zwischenstufe: einige Portale (bestpodcasts) haben nur eine
    Kategorie-Ebene, andere (podcastsonline: Land -> Genre) zwei. Diese
    Funktion prueft bei jedem Schritt, ob es eine weitere Unterebene gibt,
    und faellt andernfalls auf die Podcast-Liste durch."""
    module = SOURCES[source_key]
    subs = module.list_subcategories(category_id)

    if subs:
        for sub in subs:
            common.add_dir_item(
                label=sub["name"],
                action="browse_category",
                source=source_key,
                category=sub["id"],
            )
        xbmcplugin.setContent(common.HANDLE, "files")
        xbmcplugin.endOfDirectory(common.HANDLE)
    else:
        list_podcasts(source_key, category_id=category_id)


def list_podcasts(source_key, category_id=None, query=None, page=1):
    module = SOURCES[source_key]
    podcasts = module.list_podcasts(category_id=category_id, query=query, page=page)

    if not podcasts:
        common.notify_error(_(30030))  # "Keine Ergebnisse gefunden"

    for pod in podcasts:
        common.add_dir_item(
            label=pod["name"],
            action="episodes",
            source=source_key,
            podcast=urllib.parse.quote_plus(pod["id"]),
            icon=pod.get("image"),
            favorite_kind="podcast",
            favorite_id=pod["id"],
        )

    # Naechste Seite anbieten, solange die aktuelle Seite voll war
    # (Anzahl == Settings-Wert "max_results" -> vermutlich gibt es mehr).
    if len(podcasts) >= common.get_max_results():
        common.add_dir_item(
            label=_(30022),  # "Weitere Ergebnisse..."
            action="podcasts",
            source=source_key,
            category=category_id or "",
            query=query or "",
            page=page + 1,
        )

    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def list_episodes(source_key, podcast_id):
    module = SOURCES[source_key]
    episodes = module.list_episodes(podcast_id)

    if not episodes:
        common.notify_error(_(30031))  # "Keine Episoden gefunden"

    for ep in episodes:
        if not ep.get("stream_url"):
            continue
        common.add_playable_item(
            label=ep["name"],
            stream_url=ep["stream_url"],
            icon=ep.get("image"),
            description=ep.get("description"),
            duration=ep.get("duration"),
            source=source_key,
            episode_id=ep["id"],
        )
    xbmcplugin.setContent(common.HANDLE, "songs")
    xbmcplugin.endOfDirectory(common.HANDLE)


def do_search(source_key):
    keyboard = xbmcgui.Dialog().input(_(30020), type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard:
        xbmcplugin.endOfDirectory(common.HANDLE, succeeded=False)
        return
    list_podcasts(source_key, query=keyboard)


# ---------------------------------------------------------------------------
# Globale Suche - fragt alle aktiven Quellen parallel ab
# ---------------------------------------------------------------------------

def _search_one_source(source_key, module, query):
    try:
        results = module.list_podcasts(query=query)
    except Exception:
        results = []
    return source_key, results


def global_search():
    keyboard = xbmcgui.Dialog().input(_(30071), type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard:
        xbmcplugin.endOfDirectory(common.HANDLE, succeeded=False)
        return

    active_sources = common.get_active_sources(SOURCES)
    found_any = False

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, len(active_sources))) as executor:
        futures = {
            executor.submit(_search_one_source, key, module, keyboard): key
            for key, module in active_sources.items()
        }
        try:
            for future in concurrent.futures.as_completed(futures, timeout=SEARCH_TIMEOUT_SECONDS):
                source_key, results = future.result()
                for pod in results:
                    found_any = True
                    common.add_dir_item(
                        label="{} [{}]".format(pod["name"], _(SOURCE_LABELS[source_key])),
                        action="episodes",
                        source=source_key,
                        podcast=urllib.parse.quote_plus(pod["id"]),
                        icon=pod.get("image"),
                        favorite_kind="podcast",
                        favorite_id=pod["id"],
                    )
        except concurrent.futures.TimeoutError:
            pass  # was bis hierhin fertig war, wird trotzdem angezeigt

    if not found_any:
        common.notify_error(_(30030))  # "Keine Ergebnisse gefunden"

    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


# ---------------------------------------------------------------------------
# Gemischte Kategorien (mehrere Quellen im selben Ordner)
# ---------------------------------------------------------------------------

def list_mixed_categories():
    active_sources = common.get_active_sources(SOURCES)
    canonical_items, _contrib = categories.collect_mixed_categories(active_sources)
    for item in canonical_items:
        common.add_dir_item(label=item["name"], action="browse_mixed_category", category=item["id"])
    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def _mixed_category_one_source(source_key, module, raw_category_id):
    try:
        results = module.list_podcasts(category_id=raw_category_id)
    except Exception:
        results = []
    return source_key, results


def browse_mixed_category(canonical_key):
    active_sources = common.get_active_sources(SOURCES)
    _items, contributions = categories.collect_mixed_categories(active_sources)
    contributors = contributions.get(canonical_key, [])

    found_any = False
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, len(contributors))) as executor:
        futures = {
            executor.submit(_mixed_category_one_source, source_key, active_sources[source_key], raw_id): source_key
            for source_key, raw_id in contributors
        }
        try:
            for future in concurrent.futures.as_completed(futures, timeout=SEARCH_TIMEOUT_SECONDS):
                source_key, results = future.result()
                for pod in results:
                    found_any = True
                    common.add_dir_item(
                        label="{} [{}]".format(pod["name"], _(SOURCE_LABELS[source_key])),
                        action="episodes",
                        source=source_key,
                        podcast=urllib.parse.quote_plus(pod["id"]),
                        icon=pod.get("image"),
                        favorite_kind="podcast",
                        favorite_id=pod["id"],
                    )
        except concurrent.futures.TimeoutError:
            pass

    if not found_any:
        common.notify_error(_(30030))  # "Keine Ergebnisse gefunden"

    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


# ---------------------------------------------------------------------------
# Favoriten
# ---------------------------------------------------------------------------

def list_favorites():
    all_favs = favorites.list_all()
    for fav in all_favs:
        if fav["kind"] == "podcast":
            common.add_dir_item(
                label=fav["name"],
                action="episodes",
                source=fav["source"],
                podcast=urllib.parse.quote_plus(fav["item_id"]),
                icon=fav.get("image"),
            )
        else:  # "episode"
            common.add_playable_item(
                label=fav["name"],
                stream_url=fav["stream_url"],
                icon=fav.get("image"),
            )

    if not all_favs:
        common.notify_error(_(30076))  # "Noch keine Favoriten gespeichert"

    xbmcplugin.setContent(common.HANDLE, "files")
    xbmcplugin.endOfDirectory(common.HANDLE)


def add_favorite(kind, source_key, item_id, name, image, stream_url=None):
    if kind == "podcast":
        favorites.add_podcast(source_key, item_id, name, image or None)
    else:
        favorites.add_episode(source_key, item_id, name, stream_url, image or None)
    xbmcgui.Dialog().notification("XCast-Portal", "Zu Favoriten hinzugefügt", xbmcgui.NOTIFICATION_INFO, 2500)


# ---------------------------------------------------------------------------
# Wiedergabe / Download
# ---------------------------------------------------------------------------

def play(stream_url):
    list_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(common.HANDLE, True, list_item)


def download(stream_url, name):
    common.download_episode(stream_url, name)


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def run(argv):
    params = dict(urllib.parse.parse_qsl(argv[2].lstrip("?"))) if len(argv) > 2 else {}
    action = params.get("action", "main")
    source_key = params.get("source")
    page = int(params.get("page", 1))

    if action == "main" or not action:
        list_main_menu()
    elif action == "providers":
        list_providers()
    elif action == "open_settings":
        open_settings()
    elif action == "source_menu":
        list_source_menu(source_key)
    elif action == "categories":
        list_categories(source_key)
    elif action == "browse_category":
        browse_category(source_key, params.get("category", ""))
    elif action == "podcasts":
        list_podcasts(source_key, category_id=params.get("category") or None, query=params.get("query") or None, page=page)
    elif action == "search":
        do_search(source_key)
    elif action == "global_search":
        global_search()
    elif action == "mixed_categories":
        list_mixed_categories()
    elif action == "browse_mixed_category":
        browse_mixed_category(params.get("category", ""))
    elif action == "favorites":
        list_favorites()
    elif action == "add_favorite":
        add_favorite(
            kind=params.get("kind", "podcast"),
            source_key=params.get("source", ""),
            item_id=urllib.parse.unquote_plus(params.get("item_id", "")),
            name=urllib.parse.unquote_plus(params.get("name", "")),
            image=urllib.parse.unquote_plus(params.get("image", "")),
            stream_url=urllib.parse.unquote_plus(params.get("stream", "")) or None,
        )
    elif action == "episodes":
        list_episodes(source_key, urllib.parse.unquote_plus(params.get("podcast", "")))
    elif action == "play":
        play(urllib.parse.unquote_plus(params.get("url", "")))
    elif action == "download":
        download(
            urllib.parse.unquote_plus(params.get("url", "")),
            urllib.parse.unquote_plus(params.get("name", "episode")),
        )
    else:
        xbmcplugin.endOfDirectory(common.HANDLE, succeeded=False)
