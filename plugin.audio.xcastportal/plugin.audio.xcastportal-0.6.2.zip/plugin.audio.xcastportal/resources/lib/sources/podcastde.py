# -*- coding: utf-8 -*-
"""
Portal: podcast.de (Deutschland)

WICHTIGE KORREKTUR (11.07.2026): Die fruehere Annahme eines oeffentlichen
JSON-API unter api.podcast.de war falsch geraten und nie live verifiziert -
podcast.de hat kein solches API. Die echte Struktur (per Live-Fetch der
Seite bestaetigt):

- Kategorien-Uebersicht: /kategorien, Kategorie-Detailseiten unter
  /beste-podcasts/{name}-{numerische-id} (z.B. /beste-podcasts/comedy-27).
  Pagination ueber ?query={name}&page=N.
- Podcast-Detailseite: /podcast/{numerische-id}/{slug}. Episoden (Titel,
  Datum, Dauer, Beschreibung) stehen direkt im HTML - keine weitere
  Aufloesung fuer die Metadaten noetig.
- Die eigentliche Stream-URL steht NICHT in der Episodenliste, sondern nur
  im <meta property="og:audio"> jeder einzelnen Episodenseite
  (/episode/{id}/{slug}). Viele Podcasts sind ueber Spotify/Anchor gehostet;
  deren og:audio-Wert ist ein Anchor.fm-Wrapper der Form
  "https://anchor.fm/s/{show}/podcast/play/{id}/{url-kodierte-echte-URL}" -
  wir entpacken diesen direkt, statt den Redirect erst zur Laufzeit
  aufzuloesen (robuster plattformuebergreifend).
- Suche: /suche?query={begriff} - dasselbe "query"-Parameter-Schema wie bei
  den Kategorieseiten (dort filtert "query" bereits als Volltextsuche
  gekoppelt mit der Kategorie-URL) - mit hoher Wahrscheinlichkeit korrekt,
  aber nicht per HAR-Capture bestaetigt.
# TODO HAR-Check: /suche?query= ist aus dem Kategorie-Pagination-Muster
# abgeleitet, nicht direkt beobachtet.
"""
import re
import urllib.parse

from bs4 import BeautifulSoup

from resources.lib import common

NAME = "podcast.de"
LANGUAGE = "de"
BASE = "https://www.podcast.de"

_ANCHOR_WRAPPER_RE = re.compile(r"^https?://anchor\.fm/s/[^/]+/podcast/play/\d+/(.+)$")


def list_categories():
    resp = common.get(BASE + "/kategorien")
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    categories = []
    seen = set()
    for link in soup.select("a[href*='/beste-podcasts/']"):
        href = link.get("href", "")
        slug = href.rstrip("/").split("/beste-podcasts/")[-1]
        name = link.get_text(strip=True)
        if not slug or not name or slug in seen:
            continue
        seen.add(slug)
        categories.append({"id": slug, "name": name})
    return categories


def list_subcategories(category_id):
    return []  # podcast.de-Kategorien sind einstufig


def list_podcasts(category_id=None, query=None, page=1):
    if category_id:
        # Der Pagination-Query-Parameter nutzt den Namen ohne die
        # numerische ID, z.B. "comedy-27" -> "comedy".
        query_term = category_id.rsplit("-", 1)[0]
        url = "{}/beste-podcasts/{}".format(BASE, category_id)
        params = {"query": query_term, "page": page} if page > 1 else None
    elif query:
        url = "{}/suche".format(BASE)
        params = {"query": query}
    else:
        return []

    resp = common.get(url, params=params)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    seen = set()
    for link in soup.select("a[href*='/podcast/']"):
        href = link.get("href", "")
        if not re.search(r"/podcast/\d+/", href):
            continue  # nur echte Podcast-Detaillinks, keine Kategorie-Breadcrumbs
        if href in seen:
            continue

        img = link.find("img")
        name = link.get_text(strip=True) or (img.get("alt", "").strip() if img else "")
        if not name:
            continue

        seen.add(href)
        image = img.get("src") if img else None
        results.append({"id": href, "name": name, "image": image})
        if len(results) >= max_results:
            break
    return results


def _resolve_stream_url(episode_url):
    resp = common.get(episode_url)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    meta = soup.find("meta", attrs={"property": "og:audio"})
    if not meta or not meta.get("content"):
        return None
    raw_url = meta["content"]

    wrapped = _ANCHOR_WRAPPER_RE.match(raw_url)
    if wrapped:
        return urllib.parse.unquote(wrapped.group(1))
    return raw_url


def list_episodes(podcast_id):
    """podcast_id ist die volle oder relative Podcast-URL, z.B. /podcast/3073965/030-comedy."""
    url = podcast_id if podcast_id.startswith("http") else BASE + podcast_id
    resp = common.get(url)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    max_results = common.get_max_results()
    episode_links = []
    seen = set()
    for link in soup.select("a[href*='/episode/']"):
        href = link.get("href", "")
        if not re.search(r"/episode/\d+/", href):
            continue
        if href in seen:
            continue
        seen.add(href)
        episode_links.append((href, link))
        if len(episode_links) >= max_results:
            break

    episodes = []
    for href, link in episode_links:
        name = link.get_text(strip=True)
        if not name:
            continue
        full_url = href if href.startswith("http") else BASE + href
        stream_url = _resolve_stream_url(full_url)
        if not stream_url:
            continue
        episodes.append({
            "id": href,
            "name": name,
            "stream_url": stream_url,
            "image": None,
            "description": None,
            "duration": None,
        })
    return episodes
