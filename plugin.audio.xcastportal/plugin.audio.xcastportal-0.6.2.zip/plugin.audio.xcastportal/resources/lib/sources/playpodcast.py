# -*- coding: utf-8 -*-
"""
Portal: PlayPodcast.net (USA)

Ersetzt ab 11.07.2026 iHeart, dessen Kategorie-Browsing sich als clientseitig
gerendert (also nicht scrapbar ohne HAR-Capture) herausgestellt hat.

PlayPodcast.net ist die US-Schwesterseite von bestpodcasts.co.uk - direkte
Bestaetigung dafuer: bestpodcasts.co.uk referenziert Podcast-Cover ueber
"www.playpodcast.net/wp-content/uploads/..."-URLs (og:image), beide Seiten
laufen also auf derselben WordPress-Multisite-Installation mit identischem
Backend (pods2.podcastyradio.es). Diese Datei ist daher eine 1:1-Kopie der
bestpodcasts.py-Logik mit anderer Domain - noch nicht eigenstaendig live
gegengeprueft, aber hohe Zuversicht durch die gemeinsame Infrastruktur.
"""
from bs4 import BeautifulSoup

from resources.lib import common

NAME = "PlayPodcast.net"
LANGUAGE = "en"
BASE = "https://www.playpodcast.net"


def list_categories():
    """Liest die Kategorienavigation live von der Startseite - kein Hardcoding."""
    resp = common.get(BASE + "/")
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    categories = []
    seen = set()
    for link in soup.select("a.mlink[href^='/p/']"):
        href = link.get("href", "").strip("/")
        slug = href.split("/")[-1]
        name = link.get_text(strip=True)
        if slug and slug not in seen and name:
            seen.add(slug)
            categories.append({"id": slug, "name": name})
    return categories


def list_subcategories(category_id):
    return []  # einstufig, wie bestpodcasts.co.uk


def list_podcasts(category_id=None, query=None, page=1):
    if query:
        url = "{}/".format(BASE)
        params = {"s": query}
    elif category_id:
        url = "{}/p/{}/".format(BASE, category_id)
        if page > 1:
            url = "{}/p/{}/page/{}/".format(BASE, category_id, page)
        params = None
    else:
        return []

    resp = common.get(url, params=params)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    for link in soup.select("a[href*='/podcast/']"):
        href = link.get("href", "")
        if "/podcast/" not in href:
            continue
        img = link.find("img")
        name = img.get("alt", "").strip() if img else link.get_text(strip=True)
        if not name:
            continue
        if name.lower().endswith(" podcast"):
            name = name[:-len(" podcast")].strip()
        image = img.get("data-src") or img.get("src") if img else None

        results.append({"id": href, "name": name, "image": image})
        if len(results) >= max_results:
            break
    return results


def list_episodes(podcast_id):
    """podcast_id ist die volle oder relative Podcast-URL, z.B. /podcast/some-show/.

    Live verifiziert am 12.07.2026 (Quelltext-Analyse): die Stream-URL steht
    direkt als sound="..."-Attribut an jeder Episoden-Zeile im initial
    geladenen HTML - kein JSON-Endpunkt noetig. Format je Episode:
    <... sound="{mp3-url}" peid="{id}" sname="{name}" class="episode epirow">
    mit <span class="duration">{HH:MM:SS}</span> als Kind-Element.

    Hinweis: Es gibt zusaetzlich einen "Show all episodes"-Link fuer aeltere
    Episoden jenseits der initial gerenderten Liste (vermutlich per
    JSON-Nachladen) - aktuell nicht implementiert, nur die initial sichtbaren
    Episoden werden erfasst."""
    url = podcast_id if podcast_id.startswith("http") else BASE + podcast_id
    resp = common.get(url)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    max_results = common.get_max_results()
    episodes = []
    for row in soup.find_all(attrs={"sound": True}):
        stream_url = row.get("sound")
        name = row.get("sname") or row.get_text(strip=True)
        if not stream_url or not name:
            continue

        duration_tag = row.find("span", class_="duration")
        duration = duration_tag.get_text(strip=True) if duration_tag else None

        episodes.append({
            "id": row.get("peid") or stream_url,
            "name": name,
            "stream_url": stream_url,
            "image": None,
            "description": None,
            "duration": duration,
        })
        if len(episodes) >= max_results:
            break
    return episodes
