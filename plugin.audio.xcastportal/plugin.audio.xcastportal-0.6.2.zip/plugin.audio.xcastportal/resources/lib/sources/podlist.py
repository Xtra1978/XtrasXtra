# -*- coding: utf-8 -*-
"""
Portal: Podlist.de (Deutschland)

Live verifiziert am 09.07.2026:
- Kein Kategoriesystem, aber eine vollstaendige, alphabetisch sortierte
  A-Z-Liste unter /podcast/all/{seite} (paginiert). Wird als einzige
  Pseudo-Kategorie angeboten, damit man auch ohne funktionierende Suche
  browsen kann.
- Podcast-Detail-/Episodenlisten-URL: /podcast/{slug}/all/{seite}
  (etwas ungewoehnlich: auch die Episodenliste einer einzelnen Show
  haengt "/all/{seite}" an).
- Episoden-Detailseite exponiert die direkte MP3-URL im Klartext (Link
  + separater "Download"-Link) - kein Scraping-Umweg noetig.

# TODO HAR-Check: Es gibt keinen bestaetigten Such-Endpunkt; die Suche
# liefert daher aktuell keine Ergebnisse und weist per Notification darauf hin.
"""
import re

from bs4 import BeautifulSoup

from resources.lib import common

NAME = "Podlist.de"
LANGUAGE = "de"
BASE = "https://podlist.de"

_AUDIO_URL_RE = re.compile(r'https?://[^"\'\s]+\.(?:mp3|m4a|aac)(?:\?[^"\'\s]*)?', re.IGNORECASE)


def list_categories():
    return [{"id": "all", "name": "Alle Podcasts (A-Z)"}]


def list_subcategories(category_id):
    return []


def list_podcasts(category_id=None, query=None, page=1):
    if query:
        # TODO HAR-Check: kein bestaetigter Such-Endpunkt vorhanden.
        common.notify_error("Suche auf Podlist.de noch nicht verfuegbar - bitte 'Alle Podcasts' nutzen")
        return []
    if category_id != "all":
        return []

    resp = common.get("{}/podcast/all/{}".format(BASE, page))
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    seen = set()
    for link in soup.select("a[href^='/podcast/']"):
        href = link.get("href", "")
        match = re.match(r"^/podcast/([^/]+)/all/\d+$", href)
        if not match:
            continue
        slug = match.group(1)
        if slug in seen:
            continue
        seen.add(slug)

        name = link.get_text(strip=True)
        if not name:
            continue

        results.append({"id": slug, "name": name, "image": None})
        if len(results) >= max_results:
            break
    return results


def list_episodes(podcast_id):
    """podcast_id ist der Podcast-Slug, z.B. '0630-der-newspodcast'."""
    resp = common.get("{}/podcast/{}/all/1".format(BASE, podcast_id))
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    episode_links = []
    seen = set()
    prefix = "/podcast/{}/".format(podcast_id)
    for link in soup.select("a[href^='{}']".format(prefix)):
        href = link.get("href", "")
        rest = href[len(prefix):]
        if not rest or "/" in rest:
            continue  # das sind Pagination-Links ("all/2") oder die Show selbst
        if href in seen:
            continue
        seen.add(href)
        episode_links.append(href)

    max_results = common.get_max_results()
    episodes = []
    for href in episode_links[:max_results]:
        detail = common.get(BASE + href)
        detail.raise_for_status()
        detail_soup = BeautifulSoup(detail.text, "html.parser")

        title_tag = detail_soup.find("h1")
        name = title_tag.get_text(strip=True) if title_tag else href.rsplit("/", 1)[-1]

        match = _AUDIO_URL_RE.search(detail.text)
        if not match:
            continue

        img = detail_soup.find("img")
        image = img.get("src") if img else None

        episodes.append({
            "id": href,
            "name": name,
            "stream_url": match.group(0),
            "image": image,
            "description": None,
            "duration": None,
        })
    return episodes
