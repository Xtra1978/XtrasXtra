# -*- coding: utf-8 -*-
"""
Portal: Deutsche Podcasts (deutschepodcasts.de)

Live verifiziert am 09.07.2026:
- Echtes Kategoriesystem unter /category/{slug} (Comedy, Kunst, Bildung,
  Wirtschaft, Kinder und Familie, Musik, Religion und Spiritualitaet,
  Gesellschaft und Kultur, Technologie, TV und Film, Fiktion, Geschichte,
  Wahre Kriminalfaelle, Nachrichten, Freizeit, Regierung, Gesundheit und
  Fitness, Wissenschaft, Sport) - wird live aus der Nav gescrapt.
- Charts unter /top (das ist die von Sascha gewuenschte Direkt-Verknuepfung).
- Bester Fund: jeder Podcast-Eintrag im Listing zeigt direkt einen RSS-Link
  (Icon "RSS" neben Apple Podcasts/Spotify/Podtail/Google Podcasts) - der
  Feed muss NICHT erst von der Podcast-Detailseite geholt werden.

# TODO HAR-Check: Die Zuordnung "welcher RSS-Link gehoert zu welchem
# Podcast-Eintrag" basiert auf Naehe im HTML (naechster RSS-Link nach dem
# Podcast-Titel-Link) - das ist eine Heuristik. Falls sich das Grid-Layout
# aendert, bitte mit echtem HTML gegenpruefen.
# TODO HAR-Check: Kein bestaetigter Such-Endpunkt vorhanden.
"""
import re

from bs4 import BeautifulSoup

from resources.lib import common
from resources.lib.sources import podcastsonline  # Episoden-Aufloesung via RSS wiederverwenden

NAME = "Deutsche Podcasts"
LANGUAGE = "de"
BASE = "https://deutschepodcasts.de"


def list_categories():
    resp = common.get(BASE + "/top")
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    categories = []
    seen = set()
    for link in soup.select("a[href*='/category/']"):
        slug = link.get("href", "").rstrip("/").split("/category/")[-1]
        name = link.get_text(strip=True)
        if slug and name and slug not in seen:
            seen.add(slug)
            categories.append({"id": slug, "name": name})
    return categories


def list_subcategories(category_id):
    return []


def list_podcasts(category_id=None, query=None, page=1):
    if category_id == "top":
        url = BASE + "/top"
    elif category_id:
        url = "{}/category/{}".format(BASE, category_id)
    elif query:
        # TODO HAR-Check: kein bestaetigter Such-Endpunkt vorhanden.
        return []
    else:
        return []

    resp = common.get(url)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    seen = set()
    for title_link in soup.select("a[href^='/podcast/']"):
        href = title_link.get("href", "")
        if href in seen:
            continue

        name = title_link.get_text(strip=True)
        if not name:
            continue

        # Naechstgelegenen RSS-Link in der Naehe suchen (gleicher Elternknoten
        # oder direkt nachfolgendes Geschwisterelement).
        container = title_link.find_parent()
        rss_link = None
        if container:
            rss_img = container.find("img", alt=re.compile("RSS", re.IGNORECASE))
            if rss_img and rss_img.find_parent("a"):
                rss_link = rss_img.find_parent("a").get("href")
        if not rss_link:
            continue  # ohne Feed koennen wir keine Episoden auflösen

        seen.add(href)
        results.append({"id": rss_link, "name": name, "image": None})
        if len(results) >= max_results:
            break
    return results


def list_episodes(podcast_id):
    """podcast_id ist hier direkt die RSS-Feed-URL."""
    return podcastsonline._episodes_from_feed(podcast_id)
