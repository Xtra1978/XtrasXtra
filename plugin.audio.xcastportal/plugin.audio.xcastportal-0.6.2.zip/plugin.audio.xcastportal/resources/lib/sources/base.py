# -*- coding: utf-8 -*-
"""
Vertrag fuer alle Portal-Module unter resources/lib/sources/.

Jedes Modul (podcastde.py, playpodcast.py, bestpodcasts.py, podcastsonline.py)
implementiert dieselben vier Funktionen, damit router.py sie einheitlich
ansprechen kann - unabhaengig davon, ob im Hintergrund ein echtes API,
eine inoffizielle JSON-Schnittstelle oder HTML-Scraping steckt.

    list_categories() -> list[dict]
        [{"id": str, "name": str}, ...]
        Kann leer sein, wenn ein Portal keine Kategorien anbietet
        (dann uebernimmt "Suche" die Rolle des Einstiegspunkts).
        MUSS live von der Webseite/API gelesen werden - keine hartkodierten
        Listen, da sich Slugs/Namen jederzeit aendern koennen.

    list_subcategories(category_id) -> list[dict]
        [{"id": str, "name": str}, ...]
        Optional, fuer zweistufige Portale (z.B. podcasts-online.org:
        Land -> Genre). Standardmaessig leer (= das Portal hat nur eine
        Kategorie-Ebene, category_id geht direkt an list_podcasts()).

    list_podcasts(category_id=None, query=None, page=1) -> list[dict]
        [{"id": str, "name": str, "image": str|None}, ...]
        "id" ist rein intern (kann z.B. eine URL, ein Hash oder eine
        Apple-Podcast-ID sein) und wird 1:1 an list_episodes() zurueckgegeben.
        "page" respektiert die Settings-Option "max_results" (Ergebnisse
        pro Seite) - Umsetzung liegt beim jeweiligen Modul (z.B. durch
        Abschneiden der gescrapten Liste oder echten Query-Parameter).

    list_episodes(podcast_id) -> list[dict]
        [{"id": str, "name": str, "stream_url": str, "image": str|None,
          "description": str|None, "duration": int|None}, ...]
        "stream_url" muss eine direkt abspielbare Audio-URL sein
        (kein weiterer Redirect/HTML noetig).

    NAME: str
        Anzeigename des Portals im Hauptmenue (wird ueber strings.po lokalisiert,
        hier nur als Fallback/Debug-Name hinterlegt).

Alle Netzwerk-Endpunkte, die mit "# TODO HAR-Check" markiert sind, wurden
aus Beobachtungen (Seiten-Quelltext, Netzwerk-Tab) abgeleitet, aber noch
nicht live auf dem Fire TV Stick verifiziert. Bitte vor dem ersten Release
gegenpruefen.
"""


def list_subcategories(category_id):
    """Default-Implementierung fuer einstufige Portale. Module mit echten
    Unterkategorien (aktuell nur podcastsonline.py) ueberschreiben dies."""
    return []
