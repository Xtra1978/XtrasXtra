# -*- coding: utf-8 -*-
"""
Portal: GetPodcast (getpodcast.com, radio.de GmbH)

Live verifiziert am 09.07.2026:
- Next.js-Seite. Die Top-100-Liste (https://getpodcast.com/de/podcast) und
  jede Podcast-Detailseite (https://getpodcast.com/de/podcast/{slug}) zeigen
  Episodentitel, Datum, Dauer und Beschreibung direkt im HTML - keine
  zusaetzliche Detailseite noetig fuer die Metadaten.
- Podcast-Links haben genau ein Pfadsegment nach /de/podcast/ (z.B.
  /de/podcast/hotelmatze), Episoden-Links haben ein zweites Segment
  (z.B. /de/podcast/hotelmatze/campino-2026-wann-ist-man-fertig_7d877102fa).

# TODO HAR-Check: Die eigentliche Audio-URL wird auf der Episodenseite nicht
# inline ausgeliefert, sondern vermutlich clientseitig ueber eine interne
# API (aehnlich radio.net) nachgeladen. Der Best-Effort-Ansatz unten sucht
# im "__NEXT_DATA__"-JSON-Block der Seite nach einer Audio-URL - das ist
# eine Heuristik und noch nicht live bestaetigt. Bitte per Netzwerk-Tab
# gegenpruefen, sobald moeglich (Player abspielen, XHR-Request suchen).
# TODO HAR-Check: Kategorie- und Such-Endpunkte sind nicht bestaetigt.
"""
import json
import re

from bs4 import BeautifulSoup

from resources.lib import common

NAME = "GetPodcast"
LANGUAGE = "de"
BASE = "https://getpodcast.com/de"

_AUDIO_URL_RE = re.compile(r'https?://[^"\'\s]+\.(?:mp3|m4a|aac)(?:\?[^"\'\s]*)?', re.IGNORECASE)


def list_categories():
    return []  # TODO HAR-Check: Kategorie-URL-Schema unbestaetigt


def list_subcategories(category_id):
    return []


def _podcast_links(soup, min_segments=1, max_segments=1):
    """Findet <a href="/de/podcast/..."> mit genau der gewuenschten Anzahl
    zusaetzlicher Pfadsegmente (1 = Podcast-Detailseite, 2 = Episodenseite)."""
    results = []
    for link in soup.select("a[href^='/de/podcast/']"):
        href = link.get("href", "")
        segments = href[len("/de/podcast/"):].strip("/").split("/")
        if min_segments <= len(segments) <= max_segments:
            results.append(link)
    return results


def list_podcasts(category_id=None, query=None, page=1):
    if category_id == "top100":
        url = "{}/podcast".format(BASE)
    elif query:
        # TODO HAR-Check: Such-Endpunkt unbestaetigt.
        url = "{}/search".format(BASE)
    else:
        return []

    resp = common.get(url, params={"q": query} if query else None)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    seen = set()
    for link in _podcast_links(soup, 1, 1):
        href = link.get("href", "")
        if href in seen:
            continue
        seen.add(href)

        title_attr = link.get("title", "")
        name = title_attr.replace("Jetzt ", "").replace(" Podcast hören", "").strip()
        if not name:
            img = link.find("img")
            name = img.get("alt", "").replace(" podcast", "").strip() if img else ""
        if not name:
            continue

        img = link.find("img")
        image = img.get("src") if img else None

        results.append({"id": href, "name": name, "image": image})
        if len(results) >= max_results:
            break
    return results


def list_episodes(podcast_id):
    """podcast_id ist der relative Pfad, z.B. /de/podcast/hotelmatze."""
    url = podcast_id if podcast_id.startswith("http") else BASE.replace("/de", "") + podcast_id
    resp = common.get(url)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    episodes = []
    max_results = common.get_max_results()
    for link in _podcast_links(soup, 2, 2):
        href = link.get("href", "")
        title_attr = link.get("title", "")
        name = re.sub(r"^Jetzt .*? Podcast – Episode: ", "", title_attr)
        name = name.replace(" hören", "").strip()
        if not name:
            continue

        episodes.append({
            "id": href,
            "name": name,
            "stream_url": None,  # wird unten lazy aufgeloest
            "image": None,
            "description": None,
            "duration": None,
        })
        if len(episodes) >= max_results:
            break

    # Stream-URL pro Episode aufloesen (TODO HAR-Check, siehe Modul-Docstring)
    resolved = []
    for ep in episodes:
        ep["stream_url"] = _resolve_stream_url(ep["id"])
        if ep["stream_url"]:
            resolved.append(ep)
    return resolved


def _resolve_stream_url(episode_path):
    """Best-Effort-Heuristik: sucht im __NEXT_DATA__-JSON-Block der
    Episodenseite nach einer Audio-URL. Unbestaetigt, siehe TODO oben."""
    try:
        url = episode_path if episode_path.startswith("http") else BASE.replace("/de", "") + episode_path
        resp = common.get(url)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")

        next_data = soup.find("script", id="__NEXT_DATA__")
        if next_data and next_data.string:
            match = _AUDIO_URL_RE.search(next_data.string)
            if match:
                return match.group(0)

        # Fallback: irgendwo im restlichen HTML nach einer Audio-URL suchen
        match = _AUDIO_URL_RE.search(resp.text)
        return match.group(0) if match else None
    except Exception:
        return None
