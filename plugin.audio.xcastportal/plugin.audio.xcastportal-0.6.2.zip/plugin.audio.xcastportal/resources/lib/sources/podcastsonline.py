# -*- coding: utf-8 -*-
"""
Portal: podcasts-online.org (weitere Laender)

Live verifiziert am 09.07.2026 (die zuvor hartkodierten Kategorie-Slugs
waren falsch geraten und fuehrten zu HTTP 404 - dieses Modul liest jetzt
alles live von der Seite):

- Struktur ist zweistufig: Land -> Genre, z.B.
  https://www.podcasts-online.org/country/germany/genre/comedy
- Die Laenderliste (~150 Laender) und die 15 Standard-Genres (Apple-
  Podcasts-Kategorien) stehen im Footer/Nav jeder Land-/Genre-Seite und
  werden dynamisch gescrapt - keine hartkodierte Liste mehr.
- Podcast-Eintraege sind einfache <a>-Tags mit href auf die Podcast-Detail-
  seite (deren Slug auf eine numerische Apple-Podcast-ID endet), die ein
  <img alt="Podcastname"> umschliessen.
- Die Seite spiegelt inhaltlich den Apple-Podcasts-Katalog, daher loesen
  wir Episoden nicht per Scraping auf, sondern ueber die offizielle,
  freie iTunes-Lookup-API zum echten RSS-Feed (robuster, immer aktuell,
  automatisch DRM-frei).
"""
import re

import feedparser
from bs4 import BeautifulSoup

from resources.lib import common

NAME = "podcasts-online.org"
LANGUAGE = "multi"
BASE = "https://www.podcasts-online.org"
ITUNES_LOOKUP = "https://itunes.apple.com/lookup"

_APPLE_ID_RE = re.compile(r"-(\d{6,})/?$")

# TODO HAR-Check: Der Suchendpunkt der Seite wurde noch nicht live verifiziert.
# Platzhalter-Pfad, bitte vor Nutzung im Browser-Netzwerk-Tab gegenpruefen.
_SEARCH_URL = BASE + "/search"


def list_categories():
    """Laender-Liste, live aus dem Footer-Nav gescrapt (Kontinente werden
    dabei zu einer flachen Liste zusammengefasst - Kodi kommt mit langen
    Listen gut zurecht, ein zweistufiges Kontinent-Menue waere Komfort,
    aber keine Notwendigkeit).

    Bewusst von der Startseite statt einer Landesseite gescrapt: auf einer
    Landesseite (z.B. /country/germany) gibt es zusaetzlich einen "All"-Link
    zurueck zur eigenen Genre-Uebersicht, der sonst faelschlich als Land
    "All" mit Slug des aktuellen Landes erkannt wird."""
    resp = common.get(BASE + "/")
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    countries = []
    seen = set()
    for link in soup.select("a[href*='/country/']"):
        href = link.get("href", "")
        if "/genre/" in href:
            continue  # das sind Genre-Links, nicht Land-Links
        slug = href.rstrip("/").split("/country/")[-1]
        name = link.get_text(strip=True)
        if not slug or not name:
            continue
        if name.lower() in ("all", "alle"):
            continue  # Schutz gegen den "All"-Ruecklink, siehe Docstring
        if slug not in seen:
            seen.add(slug)
            countries.append({"id": slug, "name": name})
    return countries


def list_subcategories(category_id):
    """Genres fuer das gewaehlte Land, live gescrapt aus dem
    "Podcasts by Category"-Nav der jeweiligen Land-Seite."""
    if "|" in category_id:
        return []  # bereits eine finale Land|Genre-Auswahl - keine weitere Ebene

    resp = common.get("{}/country/{}".format(BASE, category_id))
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    genres = [{"id": "{}|".format(category_id), "name": "Alle Genres"}]
    seen = set()
    for link in soup.select("a[href*='/genre/']"):
        href = link.get("href", "")
        genre_slug = href.rstrip("/").split("/genre/")[-1]
        name = link.get_text(strip=True)
        if not genre_slug or not name:
            continue
        if genre_slug not in seen:
            seen.add(genre_slug)
            genres.append({"id": "{}|{}".format(category_id, genre_slug), "name": name})
    return genres


def list_podcasts(category_id=None, query=None, page=1):
    if query:
        # TODO HAR-Check: siehe _SEARCH_URL oben.
        resp = common.get(_SEARCH_URL, params={"q": query})
    elif category_id:
        country_id, _, genre_id = category_id.partition("|")
        if genre_id:
            url = "{}/country/{}/genre/{}".format(BASE, country_id, genre_id)
        else:
            url = "{}/country/{}".format(BASE, country_id)
        resp = common.get(url, params={"page": page} if page > 1 else None)
    else:
        return []

    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    seen = set()
    for link in soup.select("a[href*='" + BASE + "/']"):
        href = link.get("href", "")
        apple_id_match = _APPLE_ID_RE.search(href)
        if not apple_id_match or href in seen:
            continue
        seen.add(href)

        img = link.find("img")
        name = img.get("alt", "").strip() if img else link.get_text(strip=True)
        if not name:
            continue

        results.append({"id": apple_id_match.group(1), "name": name, "image": None})
        if len(results) >= max_results:
            break
    return results


def list_episodes(podcast_id):
    """podcast_id ist hier die numerische Apple-Podcast-ID."""
    resp = common.get(ITUNES_LOOKUP, params={"id": podcast_id, "entity": "podcast"})
    resp.raise_for_status()
    data = resp.json()

    if not data.get("results"):
        common.notify_error("Podcast bei Apple nicht gefunden")
        return []

    feed_url = data["results"][0].get("feedUrl")
    if not feed_url:
        common.notify_error("Kein RSS-Feed hinterlegt")
        return []

    return _episodes_from_feed(feed_url)


def _episodes_from_feed(feed_url):
    """Gemeinsame RSS-Episoden-Auflösung, auch von deutschepodcasts.py genutzt
    (dort liegt die Feed-URL bereits direkt im Portal-Listing vor)."""
    parsed = feedparser.parse(feed_url)

    episodes = []
    max_results = common.get_max_results()
    for entry in parsed.entries[:max_results]:
        stream_url = None
        for link in entry.get("links", []):
            if link.get("type", "").startswith("audio") or link.get("rel") == "enclosure":
                stream_url = link.get("href")
                break
        if not stream_url:
            continue

        image = None
        if "image" in entry:
            image = entry["image"].get("href")

        episodes.append({
            "id": entry.get("id", entry.get("link")),
            "name": entry.get("title", ""),
            "stream_url": stream_url,
            "image": image,
            "description": entry.get("summary"),
            "duration": entry.get("itunes_duration"),
        })
    return episodes
