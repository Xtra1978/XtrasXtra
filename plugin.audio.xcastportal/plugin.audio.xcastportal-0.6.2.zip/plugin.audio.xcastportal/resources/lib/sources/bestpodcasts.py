# -*- coding: utf-8 -*-
"""
Portal: bestpodcasts.co.uk (Grossbritannien)

Kategorien und Podcast-Listen kommen aus dem WordPress-HTML (kein API).

KORREKTUR (12.07.2026): Die urspruengliche Annahme eines JSON-Endpunkts
(pods2.podcastyradio.es/json/{hash}.json) fuer die Episodenliste war nur
teilweise richtig - per Quelltext-Analyse der Schwesterseite playpodcast.net
(identisches Netzwerk) hat sich gezeigt, dass die Stream-URL direkt als
sound="..."-Attribut an jeder initial geladenen Episoden-Zeile im HTML
steht - kein JSON-Aufruf noetig. Der JSON-Endpunkt existiert vermutlich nur
fuer den "Show all episodes"-Link (Nachladen aelterer Episoden), was hier
aktuell nicht implementiert ist.

Live verifiziert am 09.07.2026 gegen echtes Seiten-HTML:
- Kategorienavigation befindet sich im "Categories"-Untermenue jeder Seite
  (<a class="mlink" href="/p/{slug}/">{Name}</a>) - wird live gescrapt,
  keine hartkodierte Liste mehr.
- Podcast-Eintraege auf einer Kategorieseite sind einfache <a>-Tags mit
  href="/podcast/{slug}/", die ein <img alt="..."> umschliessen - eine
  andere Struktur als die "Aehnliche Podcasts"-Randspalte (dort wird
  <div class="catpod"> mit data-src verwendet).
"""
from bs4 import BeautifulSoup

from resources.lib import common

NAME = "BestPodcasts.co.uk"
LANGUAGE = "en"
BASE = "https://www.bestpodcasts.co.uk"


def list_categories():
    """Liest die Kategorienavigation live von der Startseite - kein Hardcoding."""
    resp = common.get(BASE + "/")
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    categories = []
    seen = set()
    for link in soup.select("a.mlink[href^='/p/']"):
        href = link.get("href", "").strip("/")  # "p/history-podcasts"
        slug = href.split("/")[-1]
        name = link.get_text(strip=True)
        if slug and slug not in seen and name:
            seen.add(slug)
            categories.append({"id": slug, "name": name})
    return categories


def list_subcategories(category_id):
    return []  # bestpodcasts.co.uk ist einstufig (keine Unter-Genres)


def list_podcasts(category_id=None, query=None, page=1):
    if query:
        url = "{}/".format(BASE)
        params = {"s": query}
    elif category_id:
        url = "{}/p/{}/".format(BASE, category_id)
        if page > 1:
            url = "{}/p/{}/page/{}/".format(BASE, category_id, page)
        params = None
    else:
        return []

    resp = common.get(url, params=params)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    results = []
    max_results = common.get_max_results()
    for link in soup.select("a[href*='/podcast/']"):
        href = link.get("href", "")
        if "/podcast/" not in href:
            continue
        img = link.find("img")
        name = img.get("alt", "").strip() if img else link.get_text(strip=True)
        if not name:
            continue
        # Das alt-Attribut auf bestpodcasts.co.uk haengt konsequent " podcast"
        # an den eigentlichen Namen an (z.B. "The Rest Is History podcast").
        if name.lower().endswith(" podcast"):
            name = name[:-len(" podcast")].strip()
        image = img.get("data-src") or img.get("src") if img else None

        results.append({"id": href, "name": name, "image": image})
        if len(results) >= max_results:
            break
    return results


def list_episodes(podcast_id):
    """podcast_id ist die volle oder relative Podcast-URL, z.B. /podcast/football-weekly/.

    Siehe Modul-Docstring: Stream-URL steht direkt als sound="..."-Attribut
    an jeder Episoden-Zeile im initial geladenen HTML, kein JSON-Aufruf noetig."""
    url = podcast_id if podcast_id.startswith("http") else BASE + podcast_id
    resp = common.get(url)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    max_results = common.get_max_results()
    episodes = []
    for row in soup.find_all(attrs={"sound": True}):
        stream_url = row.get("sound")
        name = row.get("sname") or row.get_text(strip=True)
        if not stream_url or not name:
            continue

        duration_tag = row.find("span", class_="duration")
        duration = duration_tag.get_text(strip=True) if duration_tag else None

        episodes.append({
            "id": row.get("peid") or stream_url,
            "name": name,
            "stream_url": stream_url,
            "image": None,
            "description": None,
            "duration": duration,
        })
        if len(episodes) >= max_results:
            break
    return episodes
