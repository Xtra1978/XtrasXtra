# -*- coding: utf-8 -*-
"""
XCast-eigene Favoritenverwaltung - bewusst getrennt von Kodis eingebautem
Favoriten-System (das nur exakte plugin://-Aufrufe merkt und keine
kuratierte, editierbare Liste mit eigenen Icons/Namen erlaubt).

Speicherung als einfache JSON-Datei im Addon-Profilordner
(special://profile/addon_data/plugin.audio.xcastportal/favorites.json),
analog zum Muster "eine Datei, ein Ordner" aus den anderen Addons.

Datensatz-Struktur:
    {
      "<source_key>|<kind>|<item_id>": {
          "source": str, "kind": "podcast"|"episode", "item_id": str,
          "name": str, "image": str|None,
          "stream_url": str|None   # nur bei kind == "episode"
      },
      ...
    }
"""
import json

import xbmcvfs

from resources.lib import common

_FAVORITES_FILE = "favorites.json"


def _profile_dir():
    path = xbmcvfs.translatePath(common.ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _file_path():
    return _profile_dir() + _FAVORITES_FILE


def _load():
    path = _file_path()
    if not xbmcvfs.exists(path):
        return {}
    try:
        f = xbmcvfs.File(path, "r")
        content = f.read()
        f.close()
        return json.loads(content) if content else {}
    except Exception:
        return {}


def _save(data):
    try:
        f = xbmcvfs.File(_file_path(), "w")
        f.write(json.dumps(data, ensure_ascii=False, indent=2))
        f.close()
        return True
    except Exception:
        return False


def _key(source_key, kind, item_id):
    return "{}|{}|{}".format(source_key, kind, item_id)


def is_favorite(source_key, kind, item_id):
    return _key(source_key, kind, item_id) in _load()


def add_podcast(source_key, item_id, name, image=None):
    data = _load()
    data[_key(source_key, "podcast", item_id)] = {
        "source": source_key, "kind": "podcast", "item_id": item_id,
        "name": name, "image": image, "stream_url": None,
    }
    _save(data)


def add_episode(source_key, item_id, name, stream_url, image=None):
    data = _load()
    data[_key(source_key, "episode", item_id)] = {
        "source": source_key, "kind": "episode", "item_id": item_id,
        "name": name, "image": image, "stream_url": stream_url,
    }
    _save(data)


def remove(source_key, kind, item_id):
    data = _load()
    data.pop(_key(source_key, kind, item_id), None)
    _save(data)


def list_all():
    """Liste aller gespeicherten Favoriten (Podcasts und Episoden gemischt)."""
    return list(_load().values())
