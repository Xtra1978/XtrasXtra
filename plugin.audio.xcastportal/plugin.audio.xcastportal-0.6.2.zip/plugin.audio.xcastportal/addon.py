# -*- coding: utf-8 -*-
"""
XCast-Portal – Einstiegspunkt.
Analog zum Aufbau der anderen Addons (EUscreen, RSN-Radio, laut.fm):
addon.py bleibt schlank, die eigentliche Logik liegt in resources/lib/.
"""
import sys
from resources.lib import router

if __name__ == "__main__":
    router.run(sys.argv)
